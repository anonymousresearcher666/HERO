import argparse
from pathlib import Path
from typing import Dict, Iterable
import torch
import numpy as np
import scipy.io
from ogb.nodeproppred import NodePropPredDataset


def _load_mat(path: Path) -> Dict:
    if not path.exists():
        raise FileNotFoundError(f"Missing MAT file at {path}")
    return scipy.io.loadmat(path)

def _ensure_coo(edge_index: np.ndarray) -> np.ndarray:
    if edge_index.ndim != 2:
        raise ValueError(f"edge_index must be 2D, got shape {edge_index.shape}")
    if edge_index.shape[0] != 2 and edge_index.shape[1] == 2:
        edge_index = edge_index.T
    if edge_index.shape[0] != 2:
        raise ValueError(f"edge_index must have shape [2, m], got {edge_index.shape}")
    return edge_index.astype(np.int64, copy=False)


def _normalize_indices(indices: Iterable) -> np.ndarray:
    arr = np.asarray(indices, dtype=np.int64).reshape(-1)
    if arr.size == 0:
        return arr
    if arr.min() >= 1:
        arr = arr - 1
    return arr


def _collect_split_dicts(bundle) -> list[Dict[str, Iterable]]:
    splits = []
    for entry in bundle:
        if isinstance(entry, dict):
            keys = set(entry.keys())
            if {'train', 'valid', 'test'} <= keys:
                splits.append(entry)
    if not splits:
        raise KeyError("Could not locate split dictionaries with train/valid/test keys in bundle")
    return splits

def load_arxiv_year_dataset(nclass=5):
    filename = 'arxiv-year'
    ogb_dataset = NodePropPredDataset(name='ogbn-arxiv')
    dataset.graph = ogb_dataset.graph
    dataset.graph['edge_index'] = torch.as_tensor(dataset.graph['edge_index'])
    dataset.graph['node_feat'] = torch.as_tensor(dataset.graph['node_feat'])

    label = even_quantile_labels(
        dataset.graph['node_year'].flatten(), nclass, verbose=False)
    dataset.label = torch.as_tensor(label).reshape(-1, 1)
    return dataset

def process_dataset(name: str) -> None:
    base_dir = Path(__file__).resolve().parent
    dataset_dir = base_dir / name
    dataset_dir.mkdir(parents=True, exist_ok=True)

    mat_path = dataset_dir / f"{name}.mat"
    data = _load_mat(mat_path)

    if 'node_feat' not in data or 'label' not in data or 'edge_index' not in data:
        raise KeyError(f"MAT file {mat_path} must contain node_feat, label, and edge_index arrays")

    features = data['node_feat'].astype(np.float32)
    labels = data['label'].squeeze().astype(np.int64)
    edge_index = _ensure_coo(data['edge_index'])

    np.save(dataset_dir / 'features.npy', features)
    np.save(dataset_dir / 'labels.npy', labels)
    np.save(dataset_dir / 'edge_index.npy', edge_index)

    bundle_path = dataset_dir / f"{name}.npy"
    if bundle_path.exists():
        bundle = np.load(bundle_path, allow_pickle=True)
        split_dicts = _collect_split_dicts(bundle)
        num_splits = len(split_dicts)
        num_nodes = labels.shape[0]
        train_mask = np.zeros((num_nodes, num_splits), dtype=bool)
        val_mask = np.zeros((num_nodes, num_splits), dtype=bool)
        test_mask = np.zeros((num_nodes, num_splits), dtype=bool)

        for s, split_dict in enumerate(split_dicts):
            train_vals = split_dict['train']
            val_vals = split_dict['valid']
            test_vals = split_dict['test']

            train_idx = _normalize_indices(train_vals)
            val_idx = _normalize_indices(val_vals)
            test_idx = _normalize_indices(test_vals)

            if train_idx.size:
                train_mask[train_idx, s] = True
            if val_idx.size:
                val_mask[val_idx, s] = True
            if test_idx.size:
                test_mask[test_idx, s] = True
        np.save(dataset_dir / 'train_mask.npy', train_mask)
        np.save(dataset_dir / 'val_mask.npy', val_mask)
        np.save(dataset_dir / 'test_mask.npy', test_mask)
    else:
        print(f"No split bundle found at {bundle_path}; skipping mask generation.")

    print(f"✔ Converted {name}: {features.shape[0]:,} nodes, {features.shape[1]} features")


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert custom MAT/NPY datasets to HERO format")
    parser.add_argument('datasets', nargs='*', default=['genius'], help="Dataset names under data/<name>/")
    args = parser.parse_args()
    for name in args.datasets:
        process_dataset(name)


if __name__ == '__main__':
    main()
