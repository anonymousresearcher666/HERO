# Running HERO and Baselines

## Setup
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

If you already manage PyTorch separately, install the matching wheel first and then run the commands above.

For optional approximate-nearest-neighbour support in the pseudo-label safety proxy:
```bash
pip install faiss-cpu
```

## Common runner
All experiments use the shared runner:
```bash
PYTHONPATH=. python hero/runners/experiment.py --config <config.json> --config-dir ''
```
Append `--device cpu`, `--device mpw`, or `--device cuda` to force the backend.

You can override the device at runtime:
```bash
PYTHONPATH=. python hero/runners/experiment.py \
  --config <config.json> --config-dir '' --device cuda
```

## HERO (`new_hero`)
Run HERO on a single dataset:
```bash
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/new_hero.json --config-dir '' \
  --dataset roman_empire --tag new_hero_roman_empire
```

## Baselines
Baseline configs live in `configs/done/`.

Implementation provenance:
- GWN — official repo: <https://github.com/YueAWu/Graph-Wave-Networks>
- ACM-GNN — official repo: <https://github.com/SitaoLuan/ACM-GNN>
- LINKX — official repo: <https://github.com/CUAI/Non-Homophily-Large-Scale>
- R2LP — official repo: <https://github.com/cy623/R2LP>
- UniFilter — official repo: <https://github.com/kkhuang81/UniFilter>
- ASGC — authors' Jupyter demo, wrapped in our training loop:
  <https://github.com/schariya/adaptive-simple-convolution>
- LG-GNN — public but undocumented implementation:
  <https://github.com/BERA-wx/LG-GNN>
- EG-GCN and HeterGP are in-house re-implementations because no public code was available at submission time.

Examples:
```bash
# Graph WaveNet
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/gwn.json --config-dir ''

# ACM-GNN
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/acm.json --config-dir ''

# LINKX
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/linkx.json --config-dir ''

# UniFilter
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/unifilter.json --config-dir ''

# LG-GNN style
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/lggnn.json --config-dir ''

# EG-GCN style
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/eggcn.json --config-dir ''

# HeterGP style
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/hetergp.json --config-dir ''

# R2LP style
PYTHONPATH=. python hero/runners/experiment.py \
  --config configs/done/r2lp.json --config-dir ''
```

## Synthetic SBM generator
Generate an SBM dataset and cache it like any other dataset:
```bash
PYTHONPATH=. python hero/runners/generate_sbm.py \
  --name sbm_h02_n10000 \
  --num-nodes 10000 --num-classes 5 --feature-dim 128 \
  --homophily 0.2 --avg-degree 10 --num-splits 10
```
Then run any method with `--dataset sbm_h02_n10000`.

## Results
Each run writes to:
```text
results/<dataset>/<module>/<tag>/summary.json
```
The summary includes accuracy/AUC, timing, memory, and per-split metrics.
