#!/usr/bin/env python3
"""Run short policy probes, select best with anti-overfit checks, then run full training."""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from hero.runners.experiment import _make_module, _resolve_param_groups, run as run_experiment

_ACC_DATASETS = {"roman_empire", "amazon_ratings", "actor"}


def _load_config(path: Path) -> dict[str, Any]:
    with path.open("r") as f:
        return json.load(f)


def _read_summary(run_dir: str) -> dict[str, Any]:
    summary = Path(run_dir) / "summary.json"
    if not summary.exists():
        return {}
    with summary.open("r") as f:
        return json.load(f)


def _policy_overrides(policy: str) -> dict[str, float]:
    table = {
        "conservative": {
            "pseudo_confidence": 0.75,
            "pseudo_weight": 0.12,
            "gate_weight": 0.01,
        },
        "balanced": {
            "pseudo_confidence": 0.65,
            "pseudo_weight": 0.22,
            "gate_weight": 0.01,
        },
        "permissive": {
            "pseudo_confidence": 0.55,
            "pseudo_weight": 0.35,
            "gate_weight": 0.008,
        },
    }
    if policy not in table:
        raise ValueError(f"Unknown policy: {policy}")
    return table[policy]


def _merge_params(base_cfg: dict[str, Any]) -> dict[str, Any]:
    return dict(_resolve_param_groups(base_cfg.get("params", {})))


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _primary_metric_key(dataset: str, mean: dict[str, Any], override: str = "auto") -> str:
    if override != "auto":
        return override
    if dataset.lower() in _ACC_DATASETS:
        return "val_acc"
    if "val_roc_auc" in mean:
        return "val_roc_auc"
    return "val_acc"


def _score(mean: dict[str, Any], lambda_gap: float, metric_key: str) -> tuple[float, float, float, float]:
    val_metric = _safe_float(mean.get(metric_key, 0.0))
    train_key = "train_roc_auc" if metric_key == "val_roc_auc" else "train_acc"
    train_metric = _safe_float(mean.get(train_key, val_metric), default=val_metric)
    gap = max(0.0, train_metric - val_metric)
    return (val_metric - lambda_gap * gap, val_metric, train_metric, gap)


def main() -> None:
    parser = argparse.ArgumentParser(description="Auto probe policies with anti-overfit selector, then run full training.")
    parser.add_argument("--config", required=True, help="Base JSON config path")
    parser.add_argument("--dataset", required=True, help="Dataset name")
    parser.add_argument("--probe-epochs", type=int, default=20)
    parser.add_argument("--full-epochs", type=int, default=150)
    parser.add_argument("--eval-interval", type=int, default=10)
    parser.add_argument("--val-patience", type=int, default=50)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--policies", nargs="+", default=["conservative", "balanced", "permissive"])
    parser.add_argument("--tag-prefix", default="auto_probe")
    parser.add_argument("--lambda-gap", type=float, default=0.5)
    parser.add_argument("--min-score-gap", type=float, default=0.003)
    parser.add_argument("--max-val-std", type=float, default=0.03)
    parser.add_argument("--min-improve-over-baseline", type=float, default=0.002)
    parser.add_argument("--force-full", action="store_true")
    parser.add_argument("--no-plots", action="store_true", help="Disable plots for probe/full runs (recommended for automation).")
    parser.add_argument("--primary-metric", choices=["auto", "val_acc", "val_roc_auc"], default="auto")
    args = parser.parse_args()

    cfg = _load_config(Path(args.config))
    module_name = cfg.get("module", "new_hero")
    if module_name != "new_hero":
        raise ValueError("This script currently supports only module=new_hero")
    base_params = _merge_params(cfg)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    baseline_tag = f"{args.tag_prefix}_{args.dataset}_baseline_probe_{ts}"
    baseline_params = dict(base_params)
    baseline_params.update(
        {
            "epochs": int(args.probe_epochs),
            "eval_interval": int(args.eval_interval),
            "val_patience": int(args.probe_epochs),
            "device": args.device,
            "autoadapt": False,
            "profile_policy_auto": False,
            "tag_prefix": baseline_tag,
        }
    )
    baseline_module = _make_module(module_name, baseline_params)
    baseline_payload = {"dataset": args.dataset, "module": module_name, "params": baseline_params}
    if args.no_plots:
        baseline_payload["plots"] = {"enable": False}
    baseline_out = run_experiment(
        baseline_module,
        args.dataset,
        baseline_tag,
        baseline_payload,
    )
    baseline_summary = _read_summary(baseline_out["dir"])
    baseline_mean = baseline_summary.get("mean", {}) or {}
    primary_metric = _primary_metric_key(args.dataset, baseline_mean, args.primary_metric)
    baseline_score, baseline_val, baseline_train, baseline_gap = _score(
        baseline_mean,
        float(args.lambda_gap),
        primary_metric,
    )

    probe_runs: list[dict[str, Any]] = []
    for policy in args.policies:
        params = dict(base_params)
        tag = f"{args.tag_prefix}_{args.dataset}_{policy}_probe_{ts}"
        params.update(_policy_overrides(policy))
        params.update(
            {
                "epochs": int(args.probe_epochs),
                "eval_interval": int(args.eval_interval),
                "val_patience": int(args.probe_epochs),
                "device": args.device,
                "autoadapt": False,
                "profile_policy_auto": False,
                "tag_prefix": tag,
            }
        )
        module = _make_module(module_name, params)
        probe_payload = {"dataset": args.dataset, "module": module_name, "params": params}
        if args.no_plots:
            probe_payload["plots"] = {"enable": False}
        out = run_experiment(module, args.dataset, tag, probe_payload)
        summary = _read_summary(out["dir"])
        mean = summary.get("mean", {}) or {}
        std = summary.get("std", {}) or {}
        score, val_metric, train_metric, gap = _score(mean, float(args.lambda_gap), primary_metric)
        metric_std = _safe_float(std.get(primary_metric, 0.0))
        probe_runs.append(
            {
                "policy": policy,
                "tag": tag,
                "dir": out["dir"],
                "score": score,
                "primary_metric": primary_metric,
                "val_metric": val_metric,
                "train_metric": train_metric,
                "generalization_gap": gap,
                "val_metric_std": metric_std,
                "val_acc": _safe_float(mean.get("val_acc", 0.0)),
                "val_roc_auc": _safe_float(mean.get("val_roc_auc", 0.0)),
                "train_acc": _safe_float(mean.get("train_acc", 0.0)),
                "train_roc_auc": _safe_float(mean.get("train_roc_auc", 0.0)),
                "test_acc": _safe_float(mean.get("test_acc", 0.0)),
                "test_f1": _safe_float(mean.get("test_f1", 0.0)),
                "test_roc_auc": _safe_float(mean.get("test_roc_auc", 0.0)),
            }
        )

    probe_runs.sort(key=lambda x: (-x["score"], -x["val_metric"], -x["test_acc"]))
    winner = probe_runs[0]
    runner_up = probe_runs[1] if len(probe_runs) > 1 else None
    winner_policy = winner["policy"]
    score_gap = float(winner["score"] - (runner_up["score"] if runner_up else 0.0))

    stable = bool(
        (winner["val_metric_std"] <= float(args.max_val_std))
        and (score_gap >= float(args.min_score_gap))
        and (winner["score"] >= baseline_score + float(args.min_improve_over_baseline))
    )

    full_out = None
    full_mean: dict[str, Any] = {}
    full_tag = None
    if stable or args.force_full:
        full_params = dict(base_params)
        full_tag = f"{args.tag_prefix}_{args.dataset}_{winner_policy}_full_{ts}"
        full_params.update(_policy_overrides(winner_policy))
        full_params.update(
            {
                "epochs": int(args.full_epochs),
                "eval_interval": int(args.eval_interval),
                "val_patience": int(args.val_patience),
                "device": args.device,
                "autoadapt": False,
                "profile_policy_auto": False,
                "tag_prefix": full_tag,
            }
        )
        full_module = _make_module(module_name, full_params)
        full_payload = {"dataset": args.dataset, "module": module_name, "params": full_params}
        if args.no_plots:
            full_payload["plots"] = {"enable": False}
        full_out = run_experiment(full_module, args.dataset, full_tag, full_payload)
        full_mean = (_read_summary(full_out["dir"]).get("mean", {}) or {})

    report = {
        "dataset": args.dataset,
        "base_config": str(Path(args.config)),
        "timestamp": ts,
        "selection": {
            "primary_metric": primary_metric,
            "lambda_gap": float(args.lambda_gap),
            "min_score_gap": float(args.min_score_gap),
            "max_val_std": float(args.max_val_std),
            "min_improve_over_baseline": float(args.min_improve_over_baseline),
            "baseline_probe": {
                "tag": baseline_tag,
                "dir": baseline_out["dir"],
                "score": baseline_score,
                "val_metric": baseline_val,
                "train_metric": baseline_train,
                "generalization_gap": baseline_gap,
            },
            "winner_score_gap": score_gap,
            "stable": stable,
            "force_full": bool(args.force_full),
        },
        "probe_runs": probe_runs,
        "winner_policy": winner_policy,
        "winner_probe": winner,
        "full_run": ({
            "tag": full_tag,
            "dir": full_out["dir"] if full_out is not None else None,
            "metrics": full_mean,
        } if full_out is not None else None),
    }

    anchor_dir = full_out["dir"] if full_out is not None else winner["dir"]
    report_path = Path(anchor_dir) / "auto_probe_report.json"
    with report_path.open("w") as f:
        json.dump(report, f, indent=2)

    print(json.dumps(report, indent=2))
    print(f"\nSaved auto-probe report: {report_path}")


if __name__ == "__main__":
    main()
