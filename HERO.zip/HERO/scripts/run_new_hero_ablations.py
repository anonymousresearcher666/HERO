"""Run a standardized ablation pack for new_hero and save a compact report."""

from __future__ import annotations

import argparse
import json
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any

from hero.paths import get_results_dir
from hero.runners.experiment import _make_module, _resolve_config_path, run as run_experiment


ABLATIONS: dict[str, dict[str, Any]] = {
    "full": {},
    "no_edge_loss": {"use_edge_loss": False},
    "no_pseudo_loss": {"use_pseudo_loss": False},
    "no_signed_consistency": {"use_signed_consistency": False},
    "no_router_supervision": {"use_value_loss": False, "use_gate_prior_loss": False},
    "base_only": {"force_expert": "base", "auto_experts": False, "experts": ["base"]},
    "signed_only": {"force_expert": "signed", "auto_experts": False, "experts": ["signed"]},
    "teacher_off": {"experts": ["base", "signed", "twohop", "highpass", "ripple", "gwn", "acm"]},
}


def resolve_param_groups(raw_params: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(raw_params, dict):
        return {}
    grouped_keys = {"architecture", "router", "losses", "training", "diagnostics", "autoadapt"}
    merged: dict[str, Any] = {}
    for key, value in raw_params.items():
        if key in grouped_keys and isinstance(value, dict):
            merged.update(value)
        else:
            merged[key] = value
    return merged


def load_config(config_path: Path) -> dict[str, Any]:
    with config_path.open("r") as f:
        return json.load(f)


def primary_metric(dataset: str, mean: dict[str, Any]) -> float:
    if dataset in {"roman_empire", "amazon_ratings"}:
        return float(mean.get("test_acc", 0.0))
    return float(mean.get("test_roc_auc", mean.get("test_acc", 0.0)))


def write_markdown_report(path: Path, payload: dict[str, Any]) -> None:
    lines = [
        f"# New HERO Ablations: {payload['dataset']}",
        "",
        f"Config: `{payload['config']}`",
        f"Generated: `{payload['timestamp']}`",
        "",
        "| ablation | primary | test_acc | test_f1 | gate_entropy | pseudo_cov | oracle_test |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for run in payload["runs"]:
        mean = run["mean"]
        lines.append(
            "| {name} | {primary:.4f} | {test_acc:.4f} | {test_f1:.4f} | {gate_entropy:.4f} | {pseudo_cov:.4f} | {oracle:.4f} |".format(
                name=run["name"],
                primary=float(run["primary_metric"]),
                test_acc=float(mean.get("test_acc", 0.0)),
                test_f1=float(mean.get("test_f1", 0.0)),
                gate_entropy=float(mean.get("gate_entropy_mean", 0.0)),
                pseudo_cov=float(mean.get("pseudo_coverage_open", 0.0)),
                oracle=float(mean.get("oracle_test_acc", 0.0)),
            )
        )
    path.write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a standard ablation pack for new_hero.")
    parser.add_argument("--config", default="configs/new_hero.json", help="Base JSON config.")
    parser.add_argument("--dataset", required=True, help="Dataset to run.")
    parser.add_argument("--only", nargs="*", default=None, help="Optional subset of ablation names.")
    args = parser.parse_args()

    config_path = _resolve_config_path(args.config)
    cfg = load_config(config_path)
    base_params = deepcopy(resolve_param_groups(cfg.get("params", {})))
    module_name = cfg.get("module", "new_hero")
    selected = args.only or list(ABLATIONS.keys())

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_root = Path(get_results_dir()) / args.dataset / "new_hero_ablation_pack"
    report_root.mkdir(parents=True, exist_ok=True)

    runs: list[dict[str, Any]] = []
    for name in selected:
        if name not in ABLATIONS:
            raise ValueError(f"Unknown ablation: {name}")
        params = deepcopy(base_params)
        params.update(ABLATIONS[name])
        params["diagnostics"] = True
        tag = f"ablation_{name}_{timestamp}"
        module = _make_module(module_name, params)
        out = run_experiment(
            module,
            args.dataset,
            tag,
            {
                "dataset": args.dataset,
                "module": module_name,
                "tag": tag,
                "params": params,
                "ablation": name,
            },
        )
        mean = out.get("mean", {})
        runs.append(
            {
                "name": name,
                "tag": tag,
                "dir": out.get("dir"),
                "mean": mean,
                "primary_metric": primary_metric(args.dataset, mean),
            }
        )

    runs.sort(key=lambda item: item["primary_metric"], reverse=True)
    payload = {
        "dataset": args.dataset,
        "config": str(config_path),
        "timestamp": timestamp,
        "runs": runs,
    }

    json_path = report_root / f"ablation_pack_{timestamp}.json"
    md_path = report_root / f"ablation_pack_{timestamp}.md"
    json_path.write_text(json.dumps(payload, indent=2) + "\n")
    write_markdown_report(md_path, payload)

    print(f"Saved ablation report to: {json_path}")
    print(f"Saved markdown report to: {md_path}")
    if runs:
        print("Best ablation:")
        print(json.dumps(runs[0], indent=2))


if __name__ == "__main__":
    main()
