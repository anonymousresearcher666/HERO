"""
Affinity-Based Graph Rewiring Framework
Combines end-to-end affinity learning with dynamic graph rewiring
"""

import json
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from torch_geometric.datasets import WikipediaNetwork, Planetoid, HeterophilousGraphDataset
from torch_geometric.transforms import NormalizeFeatures

# -------------------------------
# Device
# -------------------------------
if torch.backends.mps.is_available():
    DEVICE = "mps"
    print("🔥 Using Apple Silicon GPU (MPS)")
elif torch.cuda.is_available():
    DEVICE = "cuda"
    print("🚀 Using CUDA GPU")
else:
    DEVICE = "cpu"
    print("💻 Using CPU")


# -------------------------------
# Mask utilities
# -------------------------------
def resolve_mask(mask, split_idx: int) -> np.ndarray:
    """Return a 1-D boolean mask for the chosen split."""
    m = np.asarray(mask, dtype=bool)
    if m.ndim == 1:
        return m
    return m[:, split_idx]


def ensure_2d_mask(mask: Optional[np.ndarray], n_nodes: int) -> Optional[np.ndarray]:
    """Ensure mask is shape (n_nodes, num_splits). If 1-D, make it (n_nodes, 1)."""
    if mask is None:
        return None
    m = np.asarray(mask, dtype=bool)
    if m.ndim == 1:
        m = m.reshape(n_nodes, 1)
    return m


# -------------------------------
# Dataset Loader
# -------------------------------
class DatasetLoader:
    """Load and preprocess graph datasets."""

    @staticmethod
    def load_dataset(name):
        """Load dataset with standardized format."""
        try:
            print(f"📂 Loading {name} dataset...")

            if name.lower() in ['cora', 'citeseer', 'pubmed']:
                dataset = Planetoid(root='./data', name=name.capitalize(), transform=NormalizeFeatures())
                data = dataset[0]

            elif name.lower() in ['chameleon', 'squirrel']:
                dataset = WikipediaNetwork(root='./data', name=name.lower(), transform=NormalizeFeatures())
                data = dataset[0]

            elif name.lower() in ['roman_empire', 'amazon_ratings', 'minesweeper', 'tolokers', 'questions']:
                dataset = HeterophilousGraphDataset(root='./data', name=name.lower(), transform=NormalizeFeatures())
                data = dataset[0]

            else:
                print(f"❌ Unknown dataset: {name}")
                return None, None, None, None

            # Convert to numpy and ensure correct dtypes
            features = data.x.cpu().numpy().astype(np.float32)
            labels = data.y.cpu().numpy().astype(np.int64)

            # Create adjacency matrix
            edge_index = data.edge_index.cpu().numpy()
            n_nodes = features.shape[0]
            adjacency_matrix = np.zeros((n_nodes, n_nodes), dtype=np.float32)
            adjacency_matrix[edge_index[0], edge_index[1]] = 1
            adjacency_matrix[edge_index[1], edge_index[0]] = 1  # make undirected

            # Masks -> boolean arrays, ensure 2D shape (n_nodes, num_splits)
            if hasattr(data, 'train_mask') and data.train_mask is not None:
                train_mask = data.train_mask.cpu().numpy().astype(bool)
                val_mask   = data.val_mask.cpu().numpy().astype(bool)  if hasattr(data, 'val_mask')  and data.val_mask  is not None else None
                test_mask  = data.test_mask.cpu().numpy().astype(bool) if hasattr(data, 'test_mask') and data.test_mask is not None else None
            else:
                train_mask = val_mask = test_mask = None

            train_mask = ensure_2d_mask(train_mask, n_nodes) if train_mask is not None else None
            val_mask   = ensure_2d_mask(val_mask,   n_nodes) if val_mask   is not None else None
            test_mask  = ensure_2d_mask(test_mask,  n_nodes) if test_mask  is not None else None

            # Create default single split if missing/empty
            if train_mask is None or train_mask.size == 0 or not np.any(train_mask):
                print("   Creating default train/val/test splits (single split)...")
                n_train = max(20, int(0.6 * n_nodes))
                n_val   = max(10, int(0.2 * n_nodes))
                idx = np.random.permutation(n_nodes)
                tm = np.zeros(n_nodes, dtype=bool)
                vm = np.zeros(n_nodes, dtype=bool)
                sm = np.zeros(n_nodes, dtype=bool)
                tm[idx[:n_train]] = True
                vm[idx[n_train:n_train + n_val]] = True
                sm[idx[n_train + n_val:]] = True
                train_mask = tm.reshape(n_nodes, 1)
                val_mask   = vm.reshape(n_nodes, 1)
                test_mask  = sm.reshape(n_nodes, 1)

            # If val/test missing or mismatched, build per split
            if val_mask is None or val_mask.shape[1] != train_mask.shape[1]:
                cols = train_mask.shape[1]
                vs = np.zeros((n_nodes, cols), dtype=bool)
                for s in range(cols):
                    remain = np.where(~train_mask[:, s])[0]
                    if remain.size > 0:
                        vsize = max(10, max(1, remain.size // 3))
                        sel = np.random.choice(remain, min(vsize, remain.size), replace=False)
                        vs[sel, s] = True
                val_mask = vs

            if test_mask is None or test_mask.shape[1] != train_mask.shape[1]:
                cols = train_mask.shape[1]
                ts = np.zeros((n_nodes, cols), dtype=bool)
                for s in range(cols):
                    ts[:, s] = ~(train_mask[:, s] | val_mask[:, s])
                test_mask = ts

            masks = {'train_mask': train_mask, 'val_mask': val_mask, 'test_mask': test_mask}

            print(f"✅ Loaded {name}: {features.shape[0]} nodes, {features.shape[1]} features")
            print(f"   Splits: {train_mask.shape[1]}")
            print(f"   Train/Val/Test (split 0): {np.sum(train_mask[:,0])}/{np.sum(val_mask[:,0])}/{np.sum(test_mask[:,0])}")

            return features, adjacency_matrix, labels, masks

        except Exception as e:
            print(f"❌ Error loading {name}: {e}")
            import traceback
            traceback.print_exc()
            return None, None, None, None


# -------------------------------
# Homophily Calculators
# -------------------------------
class HomophilyCalculator:
    @staticmethod
    def edge_homophily(adjacency_matrix, labels):
        edges = np.where(adjacency_matrix > 0)
        if len(edges[0]) == 0:
            return 0.0
        same_class = np.sum(labels[edges[0]] == labels[edges[1]])
        return same_class / len(edges[0])

    @staticmethod
    def node_homophily(adjacency_matrix, labels):
        homophily_scores = []
        for node in range(len(adjacency_matrix)):
            neighbors = np.where(adjacency_matrix[node] > 0)[0]
            if len(neighbors) == 0:
                continue
            same_class = np.sum(labels[neighbors] == labels[node])
            homophily_scores.append(same_class / len(neighbors))
        return np.mean(homophily_scores) if homophily_scores else 0.0


# -------------------------------
# Affinity-based Classifier
# -------------------------------
class AffinityClassifier:
    def __init__(self, model, config):
        self.model = model
        self.config = config

    def predict(self, labels, train_mask, test_mask, split_idx: int = 0):
        train_mask_1d = resolve_mask(train_mask, split_idx)
        test_mask_1d  = resolve_mask(test_mask,  split_idx)

        affinity_vectors = self.model.get_affinity_vectors()

        train_indices = np.where(train_mask_1d)[0]
        test_indices  = np.where(test_mask_1d)[0]

        if len(train_indices) == 0 or len(test_indices) == 0:
            print("⚠️ Warning: Empty training or test set for affinity classification")
            return {idx: 0 for idx in test_indices}

        train_affinities = affinity_vectors[train_indices]
        train_labels = labels[train_indices]
        test_affinities = affinity_vectors[test_indices]

        predictions = {}
        k_actual = min(self.config.k_neighbors, len(train_indices))

        for i, test_idx in enumerate(test_indices):
            test_vec = test_affinities[i]
            distances = np.linalg.norm(train_affinities - test_vec, axis=1)
            nearest_indices = np.argsort(distances)[:k_actual]
            nearest_labels = train_labels[nearest_indices]

            if self.config.use_weighted_voting and len(nearest_indices) > 0:
                nearest_distances = distances[nearest_indices]
                weights = 1.0 / (nearest_distances + 1e-8)
                unique_labels = np.unique(nearest_labels)
                label_scores = {int(lbl): float(np.sum(weights[nearest_labels == lbl])) for lbl in unique_labels}
                predicted_label = max(label_scores.keys(), key=label_scores.get)
            else:
                predicted_label = int(np.bincount(nearest_labels).argmax()) if len(nearest_labels) > 0 else int(np.bincount(train_labels).argmax())

            predictions[test_idx] = predicted_label

        return predictions


# -------------------------------
# Baseline Classifiers
# -------------------------------
class BaselineClassifiers:
    def __init__(self, config):
        self.config = config

    def classify_graph_neighbors(self, adjacency_matrix, labels, train_mask, test_mask, split_idx: int = 0):
        train_mask_1d = resolve_mask(train_mask, split_idx)
        test_mask_1d  = resolve_mask(test_mask,  split_idx)

        predictions = {}
        test_indices = np.where(test_mask_1d)[0]

        for test_idx in test_indices:
            neighbors = np.where(adjacency_matrix[test_idx] > 0)[0]
            train_neighbors = [labels[n] for n in neighbors if train_mask_1d[n]]

            if train_neighbors:
                predicted_label = max(set(train_neighbors), key=train_neighbors.count)
            else:
                train_labels = labels[train_mask_1d]
                predicted_label = int(np.bincount(train_labels).argmax())

            predictions[test_idx] = int(predicted_label)

        return predictions

    def classify_feature_similarity(self, features, labels, train_mask, test_mask, split_idx: int = 0):
        train_mask_1d = resolve_mask(train_mask, split_idx)
        test_mask_1d  = resolve_mask(test_mask,  split_idx)

        train_indices = np.where(train_mask_1d)[0]
        test_indices  = np.where(test_mask_1d)[0]

        if len(train_indices) == 0 or len(test_indices) == 0:
            print("⚠️ Warning: Empty training or test set for feature similarity classification")
            return {idx: 0 for idx in test_indices}

        train_features = features[train_indices]
        train_labels = labels[train_indices]
        test_features = features[test_indices]

        scaler = StandardScaler()
        train_features_scaled = scaler.fit_transform(train_features)
        test_features_scaled = scaler.transform(test_features)

        k_actual = min(self.config.k_neighbors, len(train_indices))
        knn = KNeighborsClassifier(n_neighbors=k_actual)
        knn.fit(train_features_scaled, train_labels)

        test_preds = knn.predict(test_features_scaled)
        return {int(test_indices[i]): int(test_preds[i]) for i in range(len(test_indices))}

    def classify_sklearn(self, features, labels, train_mask, test_mask, method='logistic', split_idx: int = 0):
        train_mask_1d = resolve_mask(train_mask, split_idx)
        test_mask_1d  = resolve_mask(test_mask,  split_idx)

        train_indices = np.where(train_mask_1d)[0]
        test_indices  = np.where(test_mask_1d)[0]

        if len(train_indices) == 0 or len(test_indices) == 0:
            print("⚠️ Warning: Empty training or test set for sklearn classification")
            return {idx: 0 for idx in test_indices}

        train_features = features[train_indices]
        train_labels = labels[train_indices]
        test_features = features[test_indices]

        scaler = StandardScaler()
        train_features_scaled = scaler.fit_transform(train_features)
        test_features_scaled = scaler.transform(test_features)

        if method == 'logistic':
            clf = LogisticRegression(max_iter=1000, random_state=42)
        else:
            raise ValueError(f"Unknown method: {method}")

        clf.fit(train_features_scaled, train_labels)
        test_preds = clf.predict(test_features_scaled)
        return {int(test_indices[i]): int(test_preds[i]) for i in range(len(test_indices))}


# -------------------------------
# Config
# -------------------------------
@dataclass
class RewiringConfig:
    datasets: List[str] = None
    affinity_dim: int = 64
    learning_rate: float = 0.01
    epochs: int = 200
    early_stopping_patience: int = 20

    structure_weight: float = 1.0
    label_weight: float = 1.0

    rewiring_epochs: List[int] = None  # e.g. [50, 100, 150]
    k_top: int = 15
    k_bottom: int = 8
    rewiring_strategy: str = "affinity"

    k_neighbors: int = 5
    use_weighted_voting: bool = True
    test_runs: int = 3
    save_results: bool = True
    results_dir: str = "affinity_rewiring_experiments"

    def __post_init__(self):
        if self.datasets is None:
            self.datasets = ['cora', 'citeseer', 'chameleon', 'squirrel', 'roman_empire', 'amazon_ratings']
        if self.rewiring_epochs is None:
            self.rewiring_epochs = [50, 100, 150]


# -------------------------------
# Model
# -------------------------------
class AffinityRewiringModel(nn.Module):
    def __init__(self, n_nodes: int, feature_dim: int, affinity_dim: int, device: str = DEVICE):
        super().__init__()
        self.n_nodes = n_nodes
        self.feature_dim = feature_dim
        self.affinity_dim = affinity_dim
        self.device = device

        self.affinity_vectors = nn.Parameter(
            torch.randn(n_nodes, affinity_dim, device=device) * 0.1
        )
        self.feature_projection = nn.Linear(feature_dim, affinity_dim).to(device)

        print(f"🔥 Initialized Affinity-Rewiring Model ({device.upper()}):")
        print(f"   Nodes: {n_nodes:,}")
        print(f"   Feature dim: {feature_dim}")
        print(f"   Affinity dim: {affinity_dim}")
        print(f"   🔄 Graph rewiring enabled!")

    def forward(self, features, edge_list=None):
        if edge_list is not None:
            return self.compute_edge_affinities(features, edge_list)
        else:
            return self.compute_full_affinity_matrix(features)

    def compute_edge_affinities(self, features, edge_list):
        projected_features = self.feature_projection(features)
        projected_features_norm = F.normalize(projected_features, dim=1, eps=1e-8)
        affinity_vectors_norm = F.normalize(self.affinity_vectors, dim=1, eps=1e-8)

        src_nodes = edge_list[:, 0].long()
        dst_nodes = edge_list[:, 1].long()

        src_features = projected_features_norm[src_nodes]
        dst_affinities = affinity_vectors_norm[dst_nodes]
        edge_affinities = torch.sum(src_features * dst_affinities, dim=1)

        return edge_affinities, src_nodes, dst_nodes

    def compute_full_affinity_matrix(self, features):
        projected_features = self.feature_projection(features)
        projected_features_norm = F.normalize(projected_features, dim=1, eps=1e-8)
        affinity_vectors_norm = F.normalize(self.affinity_vectors, dim=1, eps=1e-8)
        return torch.mm(projected_features_norm, affinity_vectors_norm.t())

    def compute_structure_loss_optimized(self, edge_affinities, edge_list, n_nodes, features):
        affinity_probs = torch.sigmoid(edge_affinities)
        target_probs = torch.ones_like(affinity_probs)
        pos_loss = F.binary_cross_entropy(affinity_probs, target_probs)

        n_neg_samples = min(len(edge_affinities) // 2, 500)
        if n_neg_samples > 10:
            try:
                neg_src = torch.randint(0, n_nodes, (n_neg_samples * 2,), device=self.device)
                neg_dst = torch.randint(0, n_nodes, (n_neg_samples * 2,), device=self.device)

                mask = neg_src != neg_dst
                neg_src = neg_src[mask][:n_neg_samples]
                neg_dst = neg_dst[mask][:n_neg_samples]

                if len(neg_src) > 0:
                    projected_features = self.feature_projection(features.detach())
                    projected_norm = F.normalize(projected_features, dim=1, eps=1e-8)
                    affinity_norm = F.normalize(self.affinity_vectors, dim=1, eps=1e-8)

                    neg_affinities = torch.sum(
                        projected_norm[neg_src] * affinity_norm[neg_dst], dim=1
                    )
                    neg_probs = torch.sigmoid(neg_affinities)
                    neg_targets = torch.zeros_like(neg_probs)
                    neg_loss = F.binary_cross_entropy(neg_probs, neg_targets)
                    return pos_loss + 0.05 * neg_loss
            except Exception:
                pass
        return pos_loss

    def compute_label_loss(self, labels, train_mask, epoch=None):
        train_count = torch.sum(train_mask.float())
        if train_count < 2:
            return torch.tensor(0.0, device=self.device)

        train_indices = torch.where(train_mask)[0]
        train_affinities = self.affinity_vectors[train_indices]
        train_labels = labels[train_indices]
        n_train = len(train_indices)

        if n_train <= 150:
            selected_affinities = train_affinities
            selected_labels = train_labels
            if epoch == 0:
                print(f"   🎯 Label loss: using all {n_train} training nodes")
        else:
            target_samples = 150
            if epoch == 0:
                print(f"   🎯 Label loss: stratified sampling {target_samples} from {n_train} training nodes")

            unique_labels = torch.unique(train_labels)
            sampled_indices = []
            samples_per_class = max(1, target_samples // len(unique_labels))

            for label in unique_labels:
                label_mask = train_labels == label
                label_indices = torch.where(label_mask)[0]
                if len(label_indices) <= samples_per_class:
                    sampled_indices.extend(label_indices.tolist())
                else:
                    perm = torch.randperm(len(label_indices))[:samples_per_class]
                    sampled_indices.extend(label_indices[perm].tolist())

            sampled_tensor_indices = torch.tensor(sampled_indices, device=self.device)
            selected_affinities = train_affinities[sampled_tensor_indices]
            selected_labels = train_labels[sampled_tensor_indices]

            if epoch == 0:
                print(f"   ✅ Actually sampled {len(sampled_indices)} nodes for label loss")

        n_selected = len(selected_affinities)
        if n_selected < 2:
            return torch.tensor(0.0, device=self.device)

        diff = selected_affinities.unsqueeze(1) - selected_affinities.unsqueeze(0)
        pairwise_dist = torch.sum(diff ** 2, dim=2)
        same_label = (selected_labels.unsqueeze(1) == selected_labels.unsqueeze(0)).float()

        mask = ~torch.eye(n_selected, dtype=torch.bool, device=self.device)
        triu_mask = torch.triu(mask)

        same_label_pairs = same_label[triu_mask]
        distances = pairwise_dist[triu_mask]

        if len(distances) == 0:
            return torch.tensor(0.0, device=self.device)

        same_mask = same_label_pairs == 1
        diff_mask = same_label_pairs == 0

        same_loss = torch.mean(distances[same_mask]) if torch.sum(same_mask) > 0 else 0
        diff_loss = torch.mean(distances[diff_mask]) if torch.sum(diff_mask) > 0 else 0

        return same_loss - diff_loss

    def compute_affinity_homophily(self):
        affinity_norm = F.normalize(self.affinity_vectors, dim=1, eps=1e-8)
        similarity_matrix = torch.mm(affinity_norm, affinity_norm.t())
        diagonal = torch.diag(similarity_matrix)
        n_nodes = similarity_matrix.shape[0]
        off_diagonal_mask = ~torch.eye(n_nodes, dtype=torch.bool, device=self.device)
        off_diagonal = similarity_matrix[off_diagonal_mask]
        mean_diagonal = torch.mean(diagonal)
        mean_off_diagonal = torch.mean(off_diagonal)
        homophily_signal = mean_diagonal - mean_off_diagonal
        return float(torch.sigmoid(homophily_signal).cpu())

    def get_affinity_vectors(self):
        return self.affinity_vectors.detach().cpu().numpy()


# -------------------------------
# Graph Rewirer
# -------------------------------
class GraphRewirer:
    def __init__(self, config: RewiringConfig):
        self.config = config
        print(f"🔄 Graph Rewirer initialized:")
        print(f"   Rewiring epochs: {config.rewiring_epochs}")
        print(f"   k_top: {config.k_top}, k_bottom: {config.k_bottom}")
        print(f"   Strategy: {config.rewiring_strategy}")

    def should_rewire(self, epoch: int) -> bool:
        return epoch in self.config.rewiring_epochs

    def rewire_graph(self, model: AffinityRewiringModel, features: torch.Tensor,
                     current_adjacency: np.ndarray, epoch: int) -> np.ndarray:
        print(f"🔄 Rewiring graph at epoch {epoch}...")

        with torch.no_grad():
            affinity_matrix = model.compute_full_affinity_matrix(features)
            affinity_np = affinity_matrix.cpu().numpy()

        new_adjacency = current_adjacency.copy()
        n_nodes = len(current_adjacency)
        edges_added = 0
        edges_removed = 0

        for node in range(n_nodes):
            current_neighbors = set(np.where(current_adjacency[node] > 0)[0])
            node_affinities = affinity_np[node]
            sorted_indices = np.argsort(node_affinities)[::-1]
            sorted_indices = sorted_indices[sorted_indices != node]

            # Add top-k non-neighbors
            candidates_to_add = []
            for idx in sorted_indices:
                if idx not in current_neighbors and len(candidates_to_add) < self.config.k_top:
                    candidates_to_add.append(idx)
            for neighbor in candidates_to_add:
                if new_adjacency[node, neighbor] == 0:
                    new_adjacency[node, neighbor] = 1
                    new_adjacency[neighbor, node] = 1
                    edges_added += 1

            # Remove bottom-k among current neighbors
            current_neighbors_list = list(current_neighbors)
            if len(current_neighbors_list) > self.config.k_bottom:
                neighbor_affinities = [(nbr, node_affinities[nbr]) for nbr in current_neighbors_list]
                neighbor_affinities.sort(key=lambda x: x[1])  # low first
                neighbors_to_remove = neighbor_affinities[:self.config.k_bottom]
                for neighbor, _ in neighbors_to_remove:
                    if new_adjacency[node, neighbor] == 1:
                        new_adjacency[node, neighbor] = 0
                        new_adjacency[neighbor, node] = 0
                        edges_removed += 1

        old_edges = int(np.sum(current_adjacency)) // 2
        new_edges = int(np.sum(new_adjacency)) // 2

        print(f"   ✅ Rewiring completed:")
        print(f"      Edges added: {edges_added // 2}")
        print(f"      Edges removed: {edges_removed // 2}")
        print(f"      Total edges: {old_edges} → {new_edges}")
        print(f"      Net change: {new_edges - old_edges:+d}")

        return new_adjacency

    def compute_homophily_change(self, old_adj: np.ndarray, new_adj: np.ndarray, labels: np.ndarray) -> Dict[str, float]:
        def edge_homophily(adj, labels_):
            edges = np.where(adj > 0)
            same_class = np.sum(labels_[edges[0]] == labels_[edges[1]])
            return same_class / max(len(edges[0]), 1)

        old_homophily = edge_homophily(old_adj, labels)
        new_homophily = edge_homophily(new_adj, labels)
        return {
            'old_homophily': old_homophily,
            'new_homophily': new_homophily,
            'homophily_change': new_homophily - old_homophily
        }


# -------------------------------
# Trainer
# -------------------------------
class AffinityRewiringTrainer:
    def __init__(self, model: AffinityRewiringModel, config: RewiringConfig):
        self.model = model
        self.config = config
        self.optimizer = optim.Adam(model.parameters(), lr=config.learning_rate)
        self.rewirer = GraphRewirer(config)
        self.rewiring_history = []

    def train(self, features, adjacency_matrix, labels, train_mask):
        n_nodes = len(features)
        n_edges = int(np.sum(adjacency_matrix))
        density = n_edges / (n_nodes * (n_nodes - 1)) if n_nodes > 1 else 0

        print(f"🔥 Training affinity model with rewiring on {self.model.device.upper()}...")
        print(f"   Initial: {n_nodes:,} nodes, {n_edges:,} edges, density: {density:.6f}")

        use_edge_optimization = (density < 0.05 and n_nodes > 500)
        opt_name = "edge-only O(|E|)" if use_edge_optimization else "full-matrix O(n²)"
        print(f"   Strategy: {opt_name}")

        features = self._to_tensor(features, torch.float32)
        labels = self._to_tensor(labels, torch.long)
        train_mask = self._to_tensor(train_mask, torch.bool)

        current_adjacency = adjacency_matrix.copy()

        return self._training_loop_with_rewiring(
            features, current_adjacency, labels, train_mask, use_edge_optimization
        )

    def _to_tensor(self, data, dtype=None):
        if not isinstance(data, torch.Tensor):
            data = torch.tensor(data, device=self.model.device)
        else:
            data = data.to(device=self.model.device)
        if dtype is not None:
            data = data.to(dtype=dtype)
        return data

    def _adjacency_to_edge_list(self, adjacency_matrix):
        edges = np.where(adjacency_matrix > 0)
        return np.column_stack([edges[0], edges[1]])

    def _training_loop_with_rewiring(self, features, initial_adjacency, labels, train_mask, use_edge_optimization):
        print("🔥 Starting training with dynamic rewiring...")

        history = {'total_loss': [], 'structure_loss': [], 'label_loss': [],
                   'rewiring_epochs': [], 'homophily_changes': []}
        best_loss = float('inf')
        patience_counter = 0
        current_adjacency = initial_adjacency.copy()
        self.model.train()

        for epoch in range(self.config.epochs):
            # Rewire if scheduled
            if self.rewirer.should_rewire(epoch):
                print(f"\n🔄 === REWIRING AT EPOCH {epoch} ===")
                old_homophily = self._compute_edge_homophily(current_adjacency, labels.cpu().numpy())
                new_adjacency = self.rewirer.rewire_graph(self.model, features, current_adjacency, epoch)
                new_homophily = self._compute_edge_homophily(new_adjacency, labels.cpu().numpy())
                homophily_change = new_homophily - old_homophily
                print(f"   📊 Homophily: {old_homophily:.4f} → {new_homophily:.4f} ({homophily_change:+.4f})")
                current_adjacency = new_adjacency
                self.rewiring_history.append({
                    'epoch': epoch,
                    'old_homophily': old_homophily,
                    'new_homophily': new_homophily,
                    'homophily_change': homophily_change
                })
                history['rewiring_epochs'].append(epoch)
                history['homophily_changes'].append(homophily_change)
                print(f"🔄 === REWIRING COMPLETE ===\n")

            # Prepare current graph tensors
            if use_edge_optimization:
                edge_list = self._adjacency_to_edge_list(current_adjacency)
                edge_list_tensor = self._to_tensor(edge_list, torch.long)
                current_adj_tensor = None
            else:
                edge_list_tensor = None
                current_adj_tensor = self._to_tensor(current_adjacency, torch.float32)

            self.optimizer.zero_grad()

            # Structure loss
            if edge_list_tensor is not None:
                edge_affinities, _, _ = self.model(features, edge_list_tensor)
                structure_loss = self.model.compute_structure_loss_optimized(
                    edge_affinities, edge_list_tensor, self.model.n_nodes, features
                )
                opt_suffix = "EDGE"
            else:
                affinity_matrix = self.model(features)
                structure_loss = self._compute_structure_loss_full(affinity_matrix, current_adj_tensor)
                opt_suffix = "FULL"

            # Label loss
            label_loss = self.model.compute_label_loss(labels, train_mask, epoch)
            total_loss = (self.config.structure_weight * structure_loss +
                          self.config.label_weight * label_loss)

            total_loss.backward()
            self.optimizer.step()

            total_val = float(total_loss.detach().cpu())
            struct_val = float(structure_loss.detach().cpu())
            label_val = float(label_loss.detach().cpu())
            history['total_loss'].append(total_val)
            history['structure_loss'].append(struct_val)
            history['label_loss'].append(label_val)

            # Early stopping
            if total_val < best_loss:
                best_loss = total_val
                patience_counter = 0
            else:
                patience_counter += 1

            if epoch % 20 == 0 or patience_counter >= self.config.early_stopping_patience:
                rewire_indicator = "🔄" if epoch in self.config.rewiring_epochs else "  "
                print(f"   {rewire_indicator} Epoch {epoch:3d}: Loss={total_val:.4f} "
                      f"(Struct: {struct_val:.4f}, Label: {label_val:.4f}) [{opt_suffix}]")

            if patience_counter >= self.config.early_stopping_patience:
                print(f"   🛑 Early stopping at epoch {epoch}")
                break

        print(f"✅ Training with rewiring completed!")

        if self.rewiring_history:
            print(f"\n📊 REWIRING SUMMARY:")
            total_homophily_change = sum(r['homophily_change'] for r in self.rewiring_history)
            print(f"   Total rewiring events: {len(self.rewiring_history)}")
            print(f"   Total homophily change: {total_homophily_change:+.4f}")
            print(f"   Final homophily: {self.rewiring_history[-1]['new_homophily']:.4f}")

        return history, current_adjacency

    def _compute_structure_loss_full(self, affinity_matrix, adjacency_matrix):
        n_nodes = affinity_matrix.shape[0]
        mask = ~torch.eye(n_nodes, dtype=torch.bool, device=self.model.device)
        affinity_probs = torch.sigmoid(affinity_matrix)
        affinity_flat = affinity_probs[mask]
        adjacency_flat = adjacency_matrix[mask]
        return F.binary_cross_entropy(affinity_flat, adjacency_flat)

    def _compute_edge_homophily(self, adjacency_matrix, labels):
        edges = np.where(adjacency_matrix > 0)
        if len(edges[0]) == 0:
            return 0.0
        same_class = np.sum(labels[edges[0]] == labels[edges[1]])
        return same_class / len(edges[0])


# -------------------------------
# Experiment Runner
# -------------------------------
class RewiringExperimentRunner:
    def __init__(self, config: RewiringConfig):
        self.config = config
        os.makedirs(config.results_dir, exist_ok=True)
        print(f"🚀 Rewiring Experiment Runner initialized")
        print(f"   Device: {DEVICE.upper()}")
        print(f"   Results: {config.results_dir}")

    def run_dataset_experiment(self, dataset_name: str):
        print(f"\n{'=' * 60}")
        print(f"🔄 REWIRING EXPERIMENT: {dataset_name.upper()}")
        print(f"{'=' * 60}")

        features, adjacency_matrix, labels, masks = DatasetLoader.load_dataset(dataset_name)
        if features is None:
            return None

        n_nodes, n_features = features.shape
        n_edges = int(np.sum(adjacency_matrix)) // 2
        density = n_edges / max(n_nodes * (n_nodes - 1) / 2, 1)

        edge_homophily = HomophilyCalculator.edge_homophily(adjacency_matrix, labels)
        node_homophily = HomophilyCalculator.node_homophily(adjacency_matrix, labels)
        is_homophilic = edge_homophily > 0.5

        print(f"\n📊 Dataset Analysis:")
        print(f"   Nodes: {n_nodes:,}, Edges: {n_edges:,}, Density: {density:.6f}")
        print(f"   Edge homophily: {edge_homophily:.4f}")
        print(f"   Node homophily: {node_homophily:.4f}")
        print(f"   Type: {'Homophilic' if is_homophilic else 'Heterophilic'}")

        all_results = []
        num_splits = masks['train_mask'].shape[1]
        print(f"\n   Running over {num_splits} split(s)")

        for split_idx in range(num_splits):
            print(f"\n=== Split {split_idx + 1}/{num_splits} ===")
            for run in range(self.config.test_runs):
                print(f"\n🔄 Run {run + 1}/{self.config.test_runs}")

                model = AffinityRewiringModel(n_nodes, n_features, self.config.affinity_dim, DEVICE)
                trainer = AffinityRewiringTrainer(model, self.config)

                history, final_adjacency = trainer.train(
                    features, adjacency_matrix, labels, resolve_mask(masks['train_mask'], split_idx)
                )

                affinity_homophily = model.compute_affinity_homophily()
                final_edge_homophily = HomophilyCalculator.edge_homophily(final_adjacency, labels)
                final_node_homophily = HomophilyCalculator.node_homophily(final_adjacency, labels)

                baseline = BaselineClassifiers(self.config)
                affinity_classifier = AffinityClassifier(model, self.config)

                affinity_preds = affinity_classifier.predict(labels, masks['train_mask'], masks['test_mask'], split_idx)
                rewired_graph_preds = baseline.classify_graph_neighbors(final_adjacency, labels, masks['train_mask'], masks['test_mask'], split_idx)
                original_graph_preds = baseline.classify_graph_neighbors(adjacency_matrix, labels, masks['train_mask'], masks['test_mask'], split_idx)
                feature_preds = baseline.classify_feature_similarity(features, labels, masks['train_mask'], masks['test_mask'], split_idx)
                lr_preds = baseline.classify_sklearn(features, labels, masks['train_mask'], masks['test_mask'], 'logistic', split_idx)

                test_indices = np.where(resolve_mask(masks['test_mask'], split_idx))[0]
                true_labels = [labels[i] for i in test_indices]

                def eval_preds(preds):
                    pred_labels = [int(preds[i]) for i in test_indices]
                    acc = accuracy_score(true_labels, pred_labels) if len(test_indices) > 0 else 0.0
                    f1 = f1_score(true_labels, pred_labels, average='weighted') if len(test_indices) > 0 else 0.0
                    return acc, f1

                acc_aff, f1_aff = eval_preds(affinity_preds)
                acc_rw, f1_rw   = eval_preds(rewired_graph_preds)
                acc_or, f1_or   = eval_preds(original_graph_preds)
                acc_feat, f1_feat = eval_preds(feature_preds)
                acc_lr, f1_lr     = eval_preds(lr_preds)

                print(f"\n🎯 Classification (split {split_idx}):")
                print(f"   {'affinity':>13}: Acc={acc_aff:.4f}, F1={f1_aff:.4f}")
                print(f"   {'rewired_graph':>13}: Acc={acc_rw:.4f}, F1={f1_rw:.4f}")
                print(f"   {'original_graph':>13}: Acc={acc_or:.4f}, F1={f1_or:.4f}")
                print(f"   {'feature':>13}: Acc={acc_feat:.4f}, F1={f1_feat:.4f}")
                print(f"   {'logistic':>13}: Acc={acc_lr:.4f}, F1={f1_lr:.4f}")

                results = {
                    'dataset': dataset_name,
                    'split_idx': split_idx,
                    'run': run,
                    'n_nodes': n_nodes,
                    'n_edges': n_edges,
                    'final_n_edges': int(np.sum(final_adjacency)) // 2,
                    'density': density,
                    'final_density': (int(np.sum(final_adjacency)) // 2) / max(n_nodes * (n_nodes - 1) / 2, 1),
                    'edge_homophily': edge_homophily,
                    'node_homophily': node_homophily,
                    'final_edge_homophily': final_edge_homophily,
                    'final_node_homophily': final_node_homophily,
                    'affinity_homophily': affinity_homophily,
                    'is_homophilic': is_homophilic,
                    'device': DEVICE,
                    'rewiring_epochs': self.config.rewiring_epochs,
                    'k_top': self.config.k_top,
                    'k_bottom': self.config.k_bottom,
                    'homophily_change': final_edge_homophily - edge_homophily,
                    'edges_change': (int(np.sum(final_adjacency)) // 2) - n_edges,
                    'affinity_accuracy': acc_aff, 'affinity_f1': f1_aff,
                    'rewired_graph_accuracy': acc_rw, 'rewired_graph_f1': f1_rw,
                    'original_graph_accuracy': acc_or, 'original_graph_f1': f1_or,
                    'feature_accuracy': acc_feat, 'feature_f1': f1_feat,
                    'logistic_accuracy': acc_lr, 'logistic_f1': f1_lr,
                }

                results['affinity_vs_original'] = results['affinity_accuracy'] - results['original_graph_accuracy']
                results['affinity_vs_rewired'] = results['affinity_accuracy'] - results['rewired_graph_accuracy']
                results['rewired_vs_original'] = results['rewired_graph_accuracy'] - results['original_graph_accuracy']
                results['affinity_vs_feature'] = results['affinity_accuracy'] - results['feature_accuracy']
                results['affinity_vs_logistic'] = results['affinity_accuracy'] - results['logistic_accuracy']

                if hasattr(trainer, 'rewiring_history'):
                    results['rewiring_events'] = len(trainer.rewiring_history)
                    results['total_homophily_change_from_rewiring'] = sum(
                        r['homophily_change'] for r in trainer.rewiring_history) if trainer.rewiring_history else 0
                else:
                    results['rewiring_events'] = 0
                    results['total_homophily_change_from_rewiring'] = 0

                all_results.append(results)

        return self._aggregate_results(all_results)

    def _aggregate_results(self, all_results):
        """Aggregate results across runs and splits."""
        if not all_results:
            return {}

        agg = {}
        for key in ['dataset', 'n_nodes', 'n_edges', 'density', 'edge_homophily',
                    'node_homophily', 'is_homophilic', 'device', 'rewiring_epochs',
                    'k_top', 'k_bottom']:
            agg[key] = all_results[0][key]

        keys_to_avg = ['final_n_edges', 'final_density', 'final_edge_homophily', 'final_node_homophily',
                       'affinity_homophily', 'homophily_change', 'edges_change',
                       'affinity_accuracy', 'affinity_f1', 'rewired_graph_accuracy', 'rewired_graph_f1',
                       'original_graph_accuracy', 'original_graph_f1', 'feature_accuracy', 'feature_f1',
                       'logistic_accuracy', 'logistic_f1',
                       'affinity_vs_original', 'affinity_vs_rewired', 'rewired_vs_original',
                       'affinity_vs_feature', 'affinity_vs_logistic',
                       'rewiring_events', 'total_homophily_change_from_rewiring']

        for key in keys_to_avg:
            values = [r[key] for r in all_results]
            agg[f'{key}_mean'] = float(np.mean(values))
            agg[f'{key}_std'] = float(np.std(values))

        return agg

    def run_all_experiments(self):
        print(f"\n🚀 STARTING AFFINITY-BASED GRAPH REWIRING EXPERIMENTS")
        print(f"   Device: {DEVICE.upper()}")
        print(f"   Datasets: {self.config.datasets}")
        print(f"   Runs per dataset: {self.config.test_runs}")
        print(f"   Rewiring strategy: Add {self.config.k_top}, Remove {self.config.k_bottom}")

        all_results = []
        for dataset_name in self.config.datasets:
            result = self.run_dataset_experiment(dataset_name)
            if result:
                all_results.append(result)

        self._generate_final_report(all_results)

        if self.config.save_results:
            self._save_results(all_results)

        return all_results

    def _generate_final_report(self, all_results):
        """Generate comprehensive final report for rewiring experiments."""
        print(f"\n{'=' * 80}")
        print(f"🎉 FINAL AFFINITY-BASED GRAPH REWIRING REPORT")
        print(f"{'=' * 80}")

        if not all_results:
            print("❌ No successful experiments!")
            return

        homophilic = [r for r in all_results if r['is_homophilic']]
        heterophilic = [r for r in all_results if not r['is_homophilic']]

        print(f"\n📊 SUMMARY:")
        print(f"   Device: {all_results[0]['device'].upper()}")
        print(f"   Total datasets: {len(all_results)}")
        print(f"   Homophilic: {len(homophilic)}")
        print(f"   Heterophilic: {len(heterophilic)}")
        print(f"   Rewiring: Add {all_results[0]['k_top']}, Remove {all_results[0]['k_bottom']}")

        print(f"\n🔄 REWIRING EFFECTS:")
        for result in all_results:
            dataset_type = "Homophilic" if result['is_homophilic'] else "Heterophilic"
            homophily_change = result['homophily_change_mean']
            edges_change = result['edges_change_mean']

            direction = "🔺" if homophily_change > 0.01 else "🔻" if homophily_change < -0.01 else "➡️"

            print(f"   {direction} {result['dataset']:<15} ({dataset_type:<12}): "
                  f"Homophily {homophily_change:+.4f}, Edges {edges_change:+.0f}")

        print(f"\n🎯 CLASSIFICATION RESULTS:")
        for result in all_results:
            dataset_type = "Homophilic" if result['is_homophilic'] else "Heterophilic"

            # Key comparisons
            affinity_vs_original = result['affinity_vs_original_mean']
            rewired_vs_original = result['rewired_vs_original_mean']
            affinity_vs_rewired = result['affinity_vs_rewired_mean']

            # Choose best indicator
            if affinity_vs_original > 0.05:
                status = "🎯"  # Strong improvement
            elif affinity_vs_original > 0.02:
                status = "✅"  # Good improvement
            elif affinity_vs_original > 0:
                status = "🟡"  # Slight improvement
            else:
                status = "⚠️"  # No improvement

            print(f"   {status} {result['dataset']:<15} ({dataset_type:<12}): "
                  f"Affinity vs Original: {affinity_vs_original:+.4f}")
            print(f"     {'':18} Rewired vs Original: {rewired_vs_original:+.4f}, "
                  f"Affinity vs Rewired: {affinity_vs_rewired:+.4f}")

        # Heterophilic performance analysis
        if heterophilic:
            het_improvements = [r['affinity_vs_original_mean'] for r in heterophilic]
            het_rewiring_benefits = [r['rewired_vs_original_mean'] for r in heterophilic]

            avg_het_improvement = np.mean(het_improvements)
            avg_rewiring_benefit = np.mean(het_rewiring_benefits)

            print(f"\n🚀 HETEROPHILIC PERFORMANCE ANALYSIS:")
            print(f"   Affinity vs Original: {avg_het_improvement:+.4f}")
            print(f"   Rewiring benefit: {avg_rewiring_benefit:+.4f}")

            successful_affinity = sum(1 for imp in het_improvements if imp > 0.02)
            successful_rewiring = sum(1 for imp in het_rewiring_benefits if imp > 0.02)

            print(f"   Successful affinity method: {successful_affinity}/{len(heterophilic)}")
            print(f"   Beneficial rewiring: {successful_rewiring}/{len(heterophilic)}")

            if avg_het_improvement > 0.05:
                print(f"   🎯 SUCCESS: Strong improvements on heterophilic graphs!")
            elif avg_het_improvement > 0.02:
                print(f"   ✅ GOOD: Moderate improvements on heterophilic graphs")
            else:
                print(f"   ⚠️ LIMITED: Method needs improvement for heterophilic graphs")

        print(f"\n✅ AFFINITY-BASED GRAPH REWIRING EXPERIMENTS COMPLETED!")

    def _save_results(self, all_results):
        """Save rewiring experiment results to files."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")

        # Convert NumPy types to native Python types for JSON compatibility
        def convert_numpy_types(obj):
            """Recursively convert NumPy types to native Python types."""
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {key: convert_numpy_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy_types(item) for item in obj]
            else:
                return obj

        # Convert all results to JSON-compatible format
        json_compatible_results = convert_numpy_types(all_results)

        # CSV
        df = pd.DataFrame(all_results)
        csv_path = os.path.join(self.config.results_dir, f"affinity_rewiring_results_{timestamp}.csv")
        df.to_csv(csv_path, index=False)

        # JSON
        json_path = os.path.join(self.config.results_dir, f"affinity_rewiring_results_{timestamp}.json")
        with open(json_path, 'w') as f:
            json.dump(json_compatible_results, f, indent=2)

        print(f"💾 Rewiring results saved:")
        print(f"   CSV: {csv_path}")
        print(f"   JSON: {json_path}")


# -------------------------------
# Main
# -------------------------------
def main():
    print(f"🔄 AFFINITY-BASED GRAPH REWIRING FRAMEWORK")
    print(f"   Device: {DEVICE.upper()}")
    print(f"   Combines end-to-end affinity learning with dynamic graph rewiring!")

    config = RewiringConfig(
        datasets=['tolokers',  'questions', 'minesweeper'], #'citeseer', 'chameleon', 'squirrel',
        affinity_dim=128,
        learning_rate=0.01,
        epochs=200,
        early_stopping_patience=20,
        rewiring_epochs=[10,30,50, 100, 150],
        k_top=15,
        k_bottom=10,
        k_neighbors=8,
        test_runs=3,
        save_results=True
    )

    print(f"\n📊 EXPERIMENT CONFIGURATION:")
    print(f"   Datasets: {config.datasets}")
    print(f"   Affinity dimensions: {config.affinity_dim}")
    print(f"   Test runs per dataset: {config.test_runs}")
    print(f"   Rewiring epochs: {config.rewiring_epochs}")
    print(f"   Rewiring: Add {config.k_top} edges, Remove {config.k_bottom} edges")

    runner = RewiringExperimentRunner(config)
    results = runner.run_all_experiments()

    print(f"\n🎉 ALL AFFINITY-REWIRING EXPERIMENTS COMPLETED!")
    print(f"✅ Successfully combined affinity learning with dynamic graph rewiring!")
    return results


if __name__ == "__main__":
    main()