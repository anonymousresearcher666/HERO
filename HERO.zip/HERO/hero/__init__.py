"""HERO package root.

This package provides stable import paths that wrap the current modules.
As we refactor, internal modules can move without breaking user imports.
"""

