"""
program: utilities needed by affinity matrix computation script
author: indranil ojha

"""
import os
from random import seed as random_seed

import matplotlib.pyplot as plt
import pandas as pd
from numpy.random import seed as np_seed


# set all seeds for reproducibility
def set_seeds(seed=13):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random_seed(seed)
    np_seed(seed)

# retrieve best parameters for dataset
def get_params(dataset_name, root):
    # Build params path robustly (root may be '.' or a directory)
    params_fname = os.path.join(root, "params", "params.csv")
    params_df = pd.read_csv(params_fname)
    params_df = params_df[params_df['dataset']==dataset_name]
    params_df = params_df[['emb_ratio', 'max_nodes', 'k', 'init_lr', 'lr_decay', 'epochs']]
    emb_ratio, max_nodes, k, init_lr, lr_decay, epochs = params_df.iloc[0].values
    max_nodes = int(max_nodes)
    epochs = int(epochs)
    return(emb_ratio, max_nodes, k, init_lr, lr_decay, epochs)

# retrieve best parameters for datase

def plot_hist(hist_loss, hist_aff, dataset, results_folder):
    # summarize trend for loss & affinity score
    plt.subplot(121)
    plt.plot(hist_loss)
    #plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.subplot(122)
    plt.plot(hist_aff)
    #plt.title('affinity score')
    plt.ylabel('affinity score')
    plt.xlabel('epoch')
    plt.ylim(0,1)
    plt.suptitle(dataset)
    savefile=f"{results_folder}/hist/{dataset}.png"
    plt.savefig(savefile)
    plt.close()
