"""Run the New HERO module across multiple datasets using a fixed config.

The script reuses a JSON config (e.g., the best roman_empire parameters) and
executes the same module configuration on a list of datasets. Results for each
dataset are saved in the regular experiment directories, and an aggregated
summary JSON is written under ``results/<module>/<tag_prefix>/``.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from hero.paths import get_results_dir
from hero.runners.experiment import _make_module, run as run_experiment


JsonDict = Dict[str, Any]


DEFAULT_DATASETS: List[str] = [
    "actor",
    "chameleon",
    "squirrel",
    "cora",
    "citeseer",
    "pubmed",
]


@dataclass
class RunSummary:
    dataset: str
    tag: str
    exp_dir: Path
    summary_path: Path
    metrics: JsonDict


def load_config(path: Path) -> JsonDict:
    with path.open("r") as handle:
        return json.load(handle)


def extract_metrics(summary_path: Path) -> JsonDict:
    with summary_path.open("r") as handle:
        payload = json.load(handle)
    metrics: JsonDict = {}
    if "mean" in payload and isinstance(payload["mean"], dict):
        metrics.update({k: v for k, v in payload["mean"].items() if isinstance(v, (int, float))})
    if payload.get("splits"):
        for split in payload["splits"]:
            if not isinstance(split, dict):
                continue
            smetrics = split.get("metrics", {})
            for key, value in (smetrics or {}).items():
                if isinstance(value, (int, float)):
                    metrics.setdefault(f"split_{split.get('split', 0)}_{key}", value)
    return metrics


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def run_all_datasets(config_path: Path, datasets: Optional[Iterable[str]], tag_prefix: str,
                     disable_plots: bool, save_tex: bool) -> Dict[str, Any]:
    cfg = load_config(config_path)
    module_name = cfg.get("module", "new_hero")
    params = cfg.get("params", {})

    config_datasets = None
    if "batch" in cfg and isinstance(cfg["batch"], dict):
        maybe = cfg["batch"].get("datasets")
        if isinstance(maybe, (list, tuple)):
            config_datasets = [str(x) for x in maybe]
    if config_datasets is None and isinstance(cfg.get("datasets"), (list, tuple)):
        config_datasets = [str(x) for x in cfg["datasets"]]

    if datasets is None or not list(datasets):
        if config_datasets:
            datasets = config_datasets
        else:
            datasets = DEFAULT_DATASETS
    datasets = list(datasets)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    group_tag = f"{tag_prefix}_{timestamp}"

    results: List[RunSummary] = []
    failed: List[str] = []

    for dataset in datasets:
        dataset = dataset.strip()
        if not dataset:
            continue
        tag = f"{group_tag}_{dataset}"
        module = _make_module(module_name, params)
        payload: JsonDict = {"params": params, "batch": True}
        if disable_plots or save_tex:
            payload.setdefault("plots", {})
            if disable_plots:
                payload["plots"]["enable"] = False
            if save_tex:
                payload["plots"]["save_tex"] = True
        try:
            out = run_experiment(module, dataset, tag, payload)
        except RuntimeError as exc:
            print(f"⚠️ Failed on dataset {dataset}: {exc}")
            failed.append(dataset)
            continue

        exp_dir = Path(out["dir"])
        summary_path = exp_dir / "summary.json"
        if not summary_path.exists():
            print(f"⚠️ Missing summary for dataset {dataset} at {summary_path}")
            failed.append(dataset)
            continue

        metrics = extract_metrics(summary_path)
        results.append(RunSummary(dataset=dataset, tag=tag, exp_dir=exp_dir,
                                  summary_path=summary_path, metrics=metrics))

    report_root = Path(get_results_dir()) / module_name / tag_prefix
    ensure_dir(report_root)
    report_path = report_root / f"batch_summary_{timestamp}.json"

    with report_path.open("w") as handle:
        json.dump(
            {
                "config": str(config_path),
                "module": module_name,
                "timestamp": timestamp,
                "tag_prefix": tag_prefix,
                "datasets": [summary.dataset for summary in results],
                "failed": failed,
                "runs": [
                    {
                        "dataset": summary.dataset,
                        "tag": summary.tag,
                        "exp_dir": str(summary.exp_dir),
                        "summary": str(summary.summary_path),
                        "metrics": summary.metrics,
                    }
                    for summary in results
                ],
            },
            handle,
            indent=2,
        )

    return {
        "report": str(report_path),
        "failed": failed,
        "runs": len(results),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the New HERO module on multiple datasets with fixed params.")
    parser.add_argument(
        "--config",
        default="/Volumes/DATI/GitHub/HERO/configs/new_hero_roman_empire_best.json",
        help="JSON config containing the parameter set to reuse.",
    )
    parser.add_argument(
        "--datasets",
        nargs="*",
        default=None,
        help="Datasets to evaluate. Defaults to a heterophilous + citation set.",
    )
    parser.add_argument(
        "--tag-prefix",
        default="new_hero_roman_best",
        help="Prefix for generated experiment tags and summary directories.",
    )
    parser.add_argument(
        "--no-plots",
        action="store_true",
        help="Disable plot generation for individual runs.",
    )
    parser.add_argument(
        "--tex",
        action="store_true",
        help="Export plots in TikZ/LaTeX when supported.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = Path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")

    info = run_all_datasets(
        config_path=config_path,
        datasets=args.datasets,
        tag_prefix=args.tag_prefix,
        disable_plots=args.no_plots,
        save_tex=args.tex,
    )

    print("\nBatch summary saved to:", info["report"])
    print(f"Completed runs: {info['runs']}")
    if info.get("failed"):
        print("Failed datasets:", ", ".join(info["failed"]))


if __name__ == "__main__":
    main()
