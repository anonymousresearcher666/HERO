import argparse
import itertools
import json
import os
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

from hero.paths import get_results_dir
try:
    # Prefer absolute import so the script can be run both via -m and direct path
    from hero.runners.auto_router import run_auto_router  # type: ignore
except Exception:  # pragma: no cover
    from .auto_router import run_auto_router  # fallback


DEFAULT_DATASETS = ['roman_empire'
]
#'questions' 'roman_empire', 'amazon_ratings', 'minesweeper', 'tolokers',

def make_grid_from_config(cfg: dict):
    g = cfg.get('grid', {})
    # Fallback to defaults if not provided
    profile_dims = g.get('profile_dims', [64, 128])
    neg_ratios = g.get('neg_ratios', [0.5, 1.0])
    coverage_thresholds = g.get('coverage_thresholds', [0.10, 0.15])
    contrastive_weights = g.get('contrastive_weights', [0.5, 1.0])
    hard_neg_fracs = g.get('hard_neg_fracs', [0.3, 0.5])
    eic_temperatures = g.get('eic_temperatures', [ 0.2, 0.3])
    edge_batch_sizes = g.get('edge_batch_sizes', [1024,2048])
    local_K = g.get('local_K', [ 5, 8])
    local_beta = g.get('local_beta', [2.5, 5.0])
    kappa_thrs = g.get('kappa_thrs', [0.5, 0.6])
    pl_conf_thrs = g.get('pl_conf_thrs', [0.6, 0.75])
    pl_per_class_caps = g.get('pl_per_class_caps', [0.03, 0.05])
    pl_global_caps = g.get('pl_global_caps', [0.10, 0.20])
    pl_rounds = g.get('pl_rounds', [2, 4])
    pl_agreement = g.get('pl_agreement', [False, True])

    grid = []
    for pd, nr, ct, cw, hnf, eit, ebs, k_loc, b_loc, kap, plc, plpc, plgc, plr, pla in itertools.product(
        profile_dims, neg_ratios, coverage_thresholds, contrastive_weights,
        hard_neg_fracs, eic_temperatures, edge_batch_sizes,
        local_K, local_beta, kappa_thrs,
        pl_conf_thrs, pl_per_class_caps, pl_global_caps, pl_rounds, pl_agreement,
    ):
        grid.append({
            'unsup_overrides': {
                'profile_dim': pd,
                'neg_ratio': nr,
                'hard_neg_frac': hnf,
                'eic_temperature': eit,
                'contrastive_weight': cw,
                'edge_batch_size': ebs,
            },
            'local_params': {
                'K': k_loc,
                'beta': b_loc,
                'cov_thr': ct,
                'kappa_thr': kap,
            },
            'pl_params': {
                'conf_thr': plc,
                'per_class_cap': plpc,
                'global_cap': plgc,
                'pl_rounds': plr,
                'agreement': pla,
            },
            'safety_conf_thr': plc,
        })
    return grid


def _worker(job_idx, ds, cfg, stamp):
    tag = f"{stamp}_{job_idx:05d}"
    return run_auto_router(
        ds,
        tag=tag,
        paper_mode=True,
        agreement=bool(cfg['pl_params'].get('agreement', True)),
        pl_rounds=int(cfg['pl_params'].get('pl_rounds', 3)),
        quick=False,
        use_local=True,
        unsup_overrides=cfg['unsup_overrides'],
        local_params=cfg['local_params'],
        pl_params=cfg['pl_params'],
        safety_conf_thr=float(cfg.get('safety_conf_thr', 0.9)),
    )


def main():
    parser = argparse.ArgumentParser(description='Novel sweep over datasets with appropriate metrics (no quick mode).')
    parser.add_argument('--datasets', nargs='*', default=DEFAULT_DATASETS)
    parser.add_argument('--limit', type=int, default=0, help='Optional limit on total runs (0 = no limit)')
    parser.add_argument('--dry-run', action='store_true', help='Only write manifest, do not execute')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--config', default=None, help='Path to a JSON config with grid definitions')
    parser.add_argument('--workers', type=int, default=10, help='Number of parallel workers')
    args = parser.parse_args()

    # Load grid/datasets from config if provided
    cfg_file = None
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r') as f:
            cfg_file = json.load(f)
    datasets = cfg_file.get('datasets', args.datasets) if cfg_file else args.datasets
    grid = make_grid_from_config(cfg_file or {})
    if args.limit and args.limit > 0:
        grid = grid[: args.limit]

    stamp = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')
    out_root = os.path.join(get_results_dir(), '_sweeps', f'novel_{stamp}')
    os.makedirs(out_root, exist_ok=True)
    manifest_path = os.path.join(out_root, 'manifest.jsonl')

    # Write manifest
    with open(manifest_path, 'w') as f:
        for ds in datasets:
            for cfg in grid:
                rec = {
                    'dataset': ds,
                    **cfg,
                }
                f.write(json.dumps(rec) + '\n')

    if args.dry_run:
        print(f'Wrote manifest with {len(grid) * len(args.datasets)} runs to: {manifest_path}')
        return

    # Execute runs in parallel (no quick mode)
    jobs = []
    for ds in datasets:
        for cfg in grid:
            jobs.append((ds, cfg))

    total = len(jobs)
    print(f"Launching {total} runs with {args.workers} workers...")

    ctx = mp.get_context("spawn")
    with ProcessPoolExecutor(max_workers=max(1, int(args.workers)), mp_context=ctx) as ex:
        futures = {}
        for i, (ds, cfg) in enumerate(jobs, start=1):
            futures[ex.submit(_worker, i, ds, cfg, stamp)] = (i, ds, cfg)
        done = 0
        err_path = os.path.join(out_root, 'errors.log')
        for fut in as_completed(futures):
            i, ds, cfg = futures[fut]
            try:
                _ = fut.result()
                done += 1
                print(f"[{done}/{total}] ✅ {ds} tag={stamp}_{i:05d}")
            except Exception as e:
                with open(err_path, 'a') as ef:
                    ef.write(json.dumps({'dataset': ds, 'cfg': cfg, 'error': str(e)}) + '\n')
                done += 1
                print(f"[{done}/{total}] ❌ {ds} tag={stamp}_{i:05d} :: {e}")


if __name__ == '__main__':
    main()
