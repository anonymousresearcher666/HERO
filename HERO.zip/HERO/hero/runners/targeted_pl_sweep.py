import argparse
import itertools
import json
import os
import time
from datetime import datetime

from hero.runners.experiment import run as run_module, _make_module
from hero.paths import get_results_dir


def run_one(dataset: str, tag: str, params: dict) -> dict:
    start = time.time()
    module = _make_module('affinity_pl', params)
    out = run_module(module, dataset, tag, {'params': params, 'sweep': True, 'plots': {'enable': False}})
    res_dir = out['dir']
    sum_path = os.path.join(res_dir, 'summary.json')
    with open(sum_path, 'r') as f:
        summary = json.load(f)
    return {
        'exp_dir': res_dir,
        'summary': summary,
        'elapsed_s': time.time() - start,
        'tag': tag,
        'params': params,
    }


def main():
    parser = argparse.ArgumentParser(description='Targeted sweep for pseudo-label tuning')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--affinity-dim', type=int, default=128)
    parser.add_argument('--agreement', action='store_true', help='Require kNN + logistic agreement for PLs')
    parser.add_argument('--pl-rounds', type=int, default=3, help='Number of curriculum PL rounds')
    # Provide sensible default sweeps; pass a single value to fix them
    parser.add_argument('--semi-label-weights', type=str, default="0.10,0.15,0.20",
                        help='Comma-separated list of semi label weights')
    parser.add_argument('--semi-contrastive-weights', type=str, default="0.3,0.5",
                        help='Comma-separated list of semi contrastive weights')
    parser.add_argument('--unsup-epochs', type=int, default=10, help='Override unsupervised epochs for faster sweeps')
    parser.add_argument('--semi-epochs', type=int, default=10, help='Override semi-supervised epochs for faster sweeps')
    parser.add_argument('--quick', action='store_true', help='Use only the first value of each grid dimension')
    args = parser.parse_args()

    dataset = args.dataset
    seed = args.seed

    # Targeted grid: stricter selection & per-class quotas
    grid = {
        'conf_thr': [0.75, 0.85],
        'per_class_cap': [0.05, 0.08],
        'global_cap': [0.05, 0.10],
    }
    if args.quick:
        grid = {k: [v[0]] for k, v in grid.items()}
    # Optionally sweep weights
    if args.semi_label_weights:
        ws = [float(x) for x in args.semi_label_weights.split(',') if x.strip()]
        if ws:
            grid['semi_label_weight'] = ws
    if args.semi_contrastive_weights:
        ws = [float(x) for x in args.semi_contrastive_weights.split(',') if x.strip()]
        if ws:
            grid['semi_contrastive_weight'] = ws

    base_params = {
        'affinity_dim': args.affinity_dim,
        'agreement': bool(args.agreement),
        'pl_rounds': int(args.pl_rounds),
        'unsup_epochs': int(args.unsup_epochs),
        'semi_epochs': int(args.semi_epochs),
    }
    keys = list(grid.keys())
    values = list(grid.values())
    combos = list(itertools.product(*values))

    results = []
    for i, vals in enumerate(combos, start=1):
        p = dict(base_params)
        p.update({k: v for k, v in zip(keys, vals)})
        tag = datetime.now().strftime('%Y%m%d_%H%M%S') + f"_{i:03d}"
        results.append(run_one(dataset, tag, p))

    # Rank by semi performance then unsup
    def score(run):
        s = run['summary']
        mean = s.get('mean', {})
        # Support both keys depending on module wiring
        pl = mean.get('pl_acc') or s.get('mean_acc', {}).get('affinity_semi', 0.0)
        au = mean.get('affinity_unsup_acc') or s.get('mean_acc', {}).get('affinity_unsup', 0.0)
        try:
            return (float(pl), float(au))
        except Exception:
            return (0.0, 0.0)

    summary = sorted(results, key=lambda x: (-score(x)[0], -score(x)[1]))
    best = summary[0]

    # Save sweep summary
    method_name = 'profile_pl_targeted'
    base_dir = os.path.join(get_results_dir(), dataset, method_name)
    os.makedirs(base_dir, exist_ok=True)
    sweep_report = {
        'dataset': dataset,
        'method': method_name,
        'seed': seed,
        'runs': summary,
        'best': best,
    }
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    with open(os.path.join(base_dir, f'sweep_summary_{stamp}.json'), 'w') as f:
        json.dump(sweep_report, f, indent=2)
    print("\n=== Best configuration (by semi acc) ===")
    print(json.dumps(best, indent=2))


if __name__ == '__main__':
    main()
