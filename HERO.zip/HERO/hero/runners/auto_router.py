import argparse
import json
import os
from datetime import datetime

import numpy as np
import torch

from hero.core.dataset import DatasetLoader
from hero.core.config import ExperimentConfig, DEVICE
from hero.core.model import ProfileModel
from hero.core.trainer import ProfileTrainer
from hero.profiler.router import (
    compute_profile_effect_size,
    empirical_propagation_lift,
    pseudo_label_safety,
    route_regime,
)
from hero.paths import get_results_dir
try:
    # Absolute import to work both with -m and direct execution
    from hero.runners.local_router import local_router  # type: ignore
except Exception:  # pragma: no cover
    from .local_router import local_router  # fallback when package context is present
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from hero.utils.metrics import compute_standard_metrics, get_primary_metric, wants_auc


class _FineTuneMLP(torch.nn.Module):
    def __init__(self, in_dim: int, hidden: int, out_dim: int) -> None:
        super().__init__()
        self.layers = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.25),
            torch.nn.Linear(hidden, hidden),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.25),
            torch.nn.Linear(hidden, out_dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.layers(x)


def _train_finetune_mlp(
    Z: np.ndarray,
    y: np.ndarray,
    train_mask: np.ndarray,
    val_mask: np.ndarray,
    test_mask: np.ndarray,
    hidden: int,
    epochs: int,
    lr: float,
    weight_decay: float,
    pseudo_mask: np.ndarray | None = None,
    pseudo_weight: float = 0.5,
    patience: int = 10,
) -> dict:
    if DEVICE == 'mps' and getattr(torch.backends, 'mps', None) and torch.backends.mps.is_available():
        device = torch.device('mps')
    elif torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    X = torch.tensor(Z, dtype=torch.float32, device=device)
    y_all = torch.tensor(y, dtype=torch.long, device=device)
    mask_train = torch.tensor(train_mask, dtype=torch.bool, device=device)
    mask_val = torch.tensor(val_mask, dtype=torch.bool, device=device)

    model = _FineTuneMLP(Z.shape[1], hidden, int(y_all.max().item() + 1)).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = torch.nn.CrossEntropyLoss(reduction='none')

    if pseudo_mask is not None:
        pseudo_mask_t = torch.tensor(pseudo_mask, dtype=torch.bool, device=device)
    else:
        pseudo_mask_t = torch.zeros_like(mask_train)

    best_state = None
    best_val = float('inf')
    patience_ctr = 0

    for _ in range(max(1, epochs)):
        model.train()
        optimizer.zero_grad()
        logits = model(X[mask_train])
        losses = criterion(logits, y_all[mask_train])
        if pseudo_mask_t.any():
            weights = torch.ones_like(losses)
            weights[pseudo_mask_t[mask_train]] = pseudo_weight
            loss = (losses * weights).mean()
        else:
            loss = losses.mean()
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            if mask_val.any():
                val_logits = model(X[mask_val])
                val_loss = torch.nn.functional.cross_entropy(val_logits, y_all[mask_val]).item()
            else:
                val_loss = loss.detach().cpu().item()
        if val_loss < best_val - 1e-5:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            patience_ctr = 0
        else:
            patience_ctr += 1
            if patience_ctr >= patience:
                break

    if best_state is not None:
        model.load_state_dict({k: v.to(device) for k, v in best_state.items()})

    model.eval()
    with torch.no_grad():
        logits = model(X)
        proba = torch.softmax(logits, dim=1).cpu().numpy()
    y_pred = np.argmax(proba, axis=1)
    metrics = compute_standard_metrics(y[test_mask], y_pred[test_mask], proba[test_mask])
    metrics['finetune_val_loss'] = best_val if best_state is not None else float(loss.detach().cpu().item())
    return metrics


def _normalize(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


def run_auto_router(
    dataset: str,
    tag: str | None = None,
    paper_mode: bool = True,
    agreement: bool = True,
    pl_rounds: int = 3,
    quick: bool = False,
    use_local: bool = False,
    unsup_overrides: dict | None = None,
    local_params: dict | None = None,
    pl_params: dict | None = None,
    safety_conf_thr: float | None = None,
    safety_k: int | None = None,
) -> dict:
    X, A, y, masks = DatasetLoader.load_dataset(dataset)
    if X is None:
        raise RuntimeError(f"Failed to load dataset: {dataset}")
    n, d = X.shape
    # Build edge_index from adjacency
    ei = np.vstack(np.nonzero(A)).astype(np.int64)
    # Normalize masks to 1D
    def _mask1d(m):
        return m[:, 0] if getattr(m, 'ndim', 1) == 2 else m
    train_mask = _mask1d(masks['train_mask'])
    val_mask = _mask1d(masks.get('val_mask', masks['train_mask']))
    test_mask = _mask1d(masks['test_mask'])

    # Train unsupervised request-profile model (paper-mode by default)
    epochs_unsup = 6 if quick else 50
    # Allow overrides for unsupervised config
    profile_dim = int((unsup_overrides or {}).get('profile_dim', 128))
    neg_ratio = float((unsup_overrides or {}).get('neg_ratio', 1.0))
    hard_neg_frac = float((unsup_overrides or {}).get('hard_neg_frac', 0.5))
    eic_temperature = float((unsup_overrides or {}).get('eic_temperature', 0.2))
    contrastive_weight = float((unsup_overrides or {}).get('contrastive_weight', 1.0))
    edge_batch_size = int((unsup_overrides or {}).get('edge_batch_size', 4096))
    epochs_unsup = int((unsup_overrides or {}).get('epochs', epochs_unsup))
    cfg = ExperimentConfig(datasets=['custom'], profile_dim=profile_dim, epochs=epochs_unsup,
                           edge_loss_mode='paper' if paper_mode else 'legacy',
                           neg_ratio=neg_ratio, hard_neg_frac=hard_neg_frac, eic_temperature=eic_temperature,
                           balance_losses=True, edge_batch_size=edge_batch_size,
                           unsupervised=True, contrastive_weight=contrastive_weight, label_weight=0.0,
                           strategy='contrastive_proto')
    model = ProfileModel(n, d, cfg.affinity_dim, DEVICE)
    trainer = ProfileTrainer(model, cfg)
    trainer.train(X, A, y, train_mask if masks else np.ones(n, dtype=bool))
    # Extract embeddings Z_q and request profiles r
    with torch.no_grad():
        ft = torch.tensor(X, dtype=torch.float32, device=DEVICE)
        q = model.proj_head(model.feature_projection(ft)).detach().cpu().numpy()
        r = model.profile_vectors.detach().cpu().numpy()
    qn = _normalize(q); rn = _normalize(r)
    Z = np.concatenate([qn, rn], axis=1)
    # Diagnostics
    d_aff = compute_profile_effect_size(qn, rn)
    lift = empirical_propagation_lift(X, ei, y, train_mask, val_mask)
    # Optional overrides for PL safety params
    if safety_conf_thr is not None or safety_k is not None:
        from hero.profiler import router as _router
        cov, kappa = _router.pseudo_label_safety(Z, ei, y, train_mask,
                                                conf_thr=float(safety_conf_thr or 0.9),
                                                k=int(safety_k or 15))
    else:
        cov, kappa = pseudo_label_safety(Z, ei, y, train_mask)
    regime = route_regime(d_aff, lift, cov, kappa)

    results = {
        'dataset': dataset,
        'diagnostics': {
            'd_aff': d_aff,
            'propagation_lift': lift,
            'pl_coverage': cov,
            'pl_kappa': kappa,
            'regime': regime,
        }
    }

    # Execute selected regime
    # train_mask, test_mask already prepared
    if regime == 'A' or regime == 'undecided':
        # Affinity-only head with optional MLP fine-tuning
        lr = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
        lr.fit(Z[train_mask], y[train_mask])
        proba = lr.predict_proba(Z)
        y_pred = np.argmax(proba, axis=1)
        m = compute_standard_metrics(y[test_mask], y_pred[test_mask], proba[test_mask])
        results['regime'] = 'A'
        results['metrics'] = m
    elif regime == 'B':
        # Guarded PL via module runner (reuses full pipeline)
        from hero.runners.experiment import run as run_module, _make_module
        params = {
            'affinity_dim': profile_dim,
            'agreement': bool(agreement),
            'pl_rounds': int(pl_rounds),
            'conf_thr': 0.75,
            'per_class_cap': 0.05,
            'global_cap': 0.10,
        }
        if pl_params:
            params.update({k: v for k, v in pl_params.items() if k in {
                'profile_dim', 'affinity_dim', 'agreement', 'pl_rounds',
                'conf_thr', 'per_class_cap', 'global_cap', 'unsup_epochs', 'semi_epochs',
                'semi_label_weight', 'semi_contrastive_weight', 'agree_conf_thr'
            }})
        if quick:
            params.update({'unsup_epochs': 6, 'semi_epochs': 6})
        module = _make_module('profile_pl', params)
        out = run_module(module, dataset, tag, {'params': params, 'plots': {'enable': False}})
        results['regime'] = 'B'
        # Keep only serializable summary
        results['pl_summary'] = {'dir': out.get('dir'), 'mean': out.get('mean')}
    elif regime == 'C':
        # Apply best smoothing to LR(X)
        lr = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
        lr.fit(X[train_mask], y[train_mask])
        logits = lr.decision_function(X)
        if logits.ndim == 1:
            logits = np.stack([-logits, logits], axis=1)
        # Choose between C&S and APPNP by validation lift
        from . import auto_router as _self
        from hero.profiler.router import correct_and_smooth, _propagate_scores
        cs_logits = correct_and_smooth(ei, logits, y, train_mask)
        appnp_logits = _propagate_scores(ei, logits)
        val_mask_c = val_mask
        y_cs = np.argmax(cs_logits, axis=1); y_ap = np.argmax(appnp_logits, axis=1)
        acc_lr_val = accuracy_score(y[val_mask_c], np.argmax(logits, axis=1)[val_mask_c])
        acc_cs_val = accuracy_score(y[val_mask_c], y_cs[val_mask_c])
        acc_ap_val = accuracy_score(y[val_mask_c], y_ap[val_mask_c])
        use_cs = acc_cs_val >= acc_ap_val
        final = y_cs if use_cs else y_ap
        # Build softmax probabilities for AUC
        logits_final = cs_logits if use_cs else appnp_logits
        p = np.exp(logits_final - logits_final.max(axis=1, keepdims=True))
        proba = p / (p.sum(axis=1, keepdims=True) + 1e-8)
        y_pred = np.argmax(proba, axis=1)
        m = compute_standard_metrics(y[test_mask], y_pred[test_mask], proba[test_mask])
        results['regime'] = 'C'
        res_metrics = m.copy()
        res_metrics['method'] = 'C&S' if use_cs else 'APPNP'
        results['metrics'] = res_metrics

    # Persist
    # Optionally run local router and compare
    local_summary = None
    proba_local = None
    if use_local:
        try:
            # Local router parameter overrides
            params_local = local_params or {}
            K_raw = params_local.get('K', 5)
            if isinstance(K_raw, (list, tuple, set)):
                K_loc = [int(k) for k in K_raw]
            elif isinstance(K_raw, str) and ',' in K_raw:
                K_loc = [int(part.strip()) for part in K_raw.split(',') if part.strip()]
            else:
                K_loc = int(K_raw)
            beta_loc = float(params_local.get('beta', 5.0))
            cov_thr = float(params_local.get('cov_thr', 0.08))
            kappa_thr = float(params_local.get('kappa_thr', 0.6))
            strict = bool(params_local.get('strict', False))
            cluster_head = params_local.get('head', 'global_lr')
            unsup_local = params_local.get('unsup_overrides')
            lr_out = local_router(
                dataset,
                K=K_loc,
                beta=beta_loc,
                quick=quick,
                cov_thr=cov_thr,
                kappa_thr=kappa_thr,
                unsup_overrides=unsup_local,
                cluster_strict=strict,
                cluster_head=cluster_head,
                threshold_weights=params_local.get('threshold_weights'),
                utility_params=params_local.get('utility_params'),
                safety_params=params_local.get('safety_params'),
                bootstrap_samples=int(params_local.get('bootstrap_samples', 64)),
                validation_threshold=float(params_local.get('validation_threshold', 0.02)),
                utility_unc=float(params_local.get('utility_unc', 0.05)),
                safety_unc=float(params_local.get('safety_unc', 0.05)),
            )
            # local_router returns (summary, rn, labels, centroids, proba)
            if isinstance(lr_out, tuple) and len(lr_out) >= 1 and isinstance(lr_out[0], dict):
                local_summary = lr_out[0]
                proba_local = lr_out[4] if len(lr_out) >= 5 else None
            elif isinstance(lr_out, dict):
                local_summary = lr_out
                proba_local = None
        except Exception as e:
            local_summary = {'error': str(e)}

    if proba_local is not None and isinstance(local_summary, dict) and 'metrics' in local_summary:
        params_local = local_params or {}
        ft_conf = float(params_local.get('ft_conf', 0.85))
        ft_epochs = int(params_local.get('ft_epochs', 60))
        ft_hidden = int(params_local.get('ft_hidden', 256))
        ft_lr = float(params_local.get('ft_lr', 1e-3))
        proba_np = np.asarray(proba_local)
        if proba_np.ndim == 2 and proba_np.shape[0] == Z.shape[0]:
            pseudo_probs = proba_np.max(axis=1)
            pseudo_labels = np.argmax(proba_np, axis=1)
            pseudo_mask = (pseudo_probs >= ft_conf) & (~train_mask)
            if pseudo_mask.sum() > 0:
                fine_mask = train_mask.copy()
                fine_mask[pseudo_mask] = True
                y_fine = y.copy()
                y_fine[pseudo_mask] = pseudo_labels[pseudo_mask]
                pseudo_only_mask = np.zeros_like(train_mask)
                pseudo_only_mask[pseudo_mask] = True
                ft_weight_decay = float(params_local.get('ft_weight_decay', 1e-4))
                ft_pseudo_weight = float(params_local.get('ft_pseudo_weight', 0.5))
                ft_patience = int(params_local.get('ft_patience', 10))
                metrics_ft = _train_finetune_mlp(
                    Z,
                    y_fine,
                    fine_mask,
                    val_mask,
                    test_mask,
                    ft_hidden,
                    ft_epochs,
                    ft_lr,
                    ft_weight_decay,
                    pseudo_only_mask,
                    ft_pseudo_weight,
                    ft_patience,
                )
                local_summary['finetune'] = metrics_ft
                try:
                    base_score = get_primary_metric(local_summary.get('metrics', {}), dataset)
                except Exception:
                    base_score = None
                ft_score = get_primary_metric(metrics_ft, dataset)
                if isinstance(ft_score, float) and (base_score is None or ft_score > base_score):
                    local_summary['metrics'] = metrics_ft
                    local_summary['finetune_applied'] = True
            else:
                local_summary['finetune'] = {'info': 'no pseudo labels above threshold'}

    out_dir = os.path.join(get_results_dir(), dataset, 'auto_router', tag or datetime.now().strftime('%Y%m%d_%H%M%S'))
    os.makedirs(out_dir, exist_ok=True)
    combined = results.copy()
    if local_summary and isinstance(local_summary, dict) and 'metrics' in local_summary:
        combined['local_router'] = local_summary
        try:
            # Choose by primary metric (AUC for specific datasets, else accuracy)
            # Get global metrics: prefer direct metrics, else PL mean (acc only)
            metrics_g = combined.get('metrics', {})
            if not metrics_g and combined.get('pl_summary'):
                # Provide a metrics-like dict for PL summary, include pl_auc when present
                mean = combined['pl_summary'].get('mean', {}) if isinstance(combined.get('pl_summary'), dict) else {}
                metrics_g = {
                    'acc': mean.get('pl_acc'),
                    'auc': mean.get('pl_auc'),
                }
            score_g = get_primary_metric(metrics_g, dataset)
            score_l = get_primary_metric(local_summary['metrics'], dataset)
            combined['chosen'] = 'local' if (isinstance(score_l, float) and isinstance(score_g, float) and score_l > score_g) else 'global'
        except Exception:
            combined['chosen'] = 'global'
    # Save config and summary for reproducibility
    cfg_payload = {
        'dataset': dataset,
        'tag': os.path.basename(out_dir),
        'paper_mode': bool(paper_mode),
        'agreement': bool(agreement),
        'pl_rounds': int(pl_rounds),
        'quick': bool(quick),
        'use_local': bool(use_local),
        'unsup_overrides': unsup_overrides or {},
        'local_params': local_params or {},
        'pl_params': pl_params or {},
        'safety_conf_thr': safety_conf_thr,
        'safety_k': safety_k,
    }
    try:
        import sys as _sys
        cfg_payload['repro_command'] = f"python {' '.join(_sys.argv)}"
    except Exception:
        pass
    with open(os.path.join(out_dir, 'config.json'), 'w') as f:
        json.dump(cfg_payload, f, indent=2)
    with open(os.path.join(out_dir, 'summary.json'), 'w') as f:
        json.dump(combined, f, indent=2)
    return results


def main():
    parser = argparse.ArgumentParser(description='Auto-router: train affinity, profile, route to regime A/B/C')
    parser.add_argument('--dataset', default='amazon_ratings')
    parser.add_argument('--paper-mode', action='store_true', help='Use paper-mode affinity training')
    parser.add_argument('--agreement', action='store_true', help='Require kNN+LR agreement in PL regime')
    parser.add_argument('--pl-rounds', type=int, default=3)
    parser.add_argument('--tag', default=None)
    parser.add_argument('--quick', action='store_true',default=False, help='Use reduced epochs for faster routing')
    parser.add_argument('--local', action='store_true', default=True,help='Also run local subgraph profiling and compare')
    args = parser.parse_args()
    out = run_auto_router(args.dataset, args.tag, paper_mode=args.paper_mode, agreement=args.agreement, pl_rounds=args.pl_rounds, quick=args.quick, use_local=args.local)
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
