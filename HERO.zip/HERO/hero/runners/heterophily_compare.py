"""Run heterophily comparison framework and save a report."""

import argparse
import json
import os
from datetime import datetime

import numpy as np

from hero.comparators.heterophily_comparison import ComparisonConfig, HeterophilyComparisonFramework
from hero.core.dataset import DatasetLoader
from hero.paths import get_results_dir


def _edge_array_from_masks(adj: np.ndarray) -> np.ndarray:
    edges = np.where(adj > 0)
    return np.column_stack([edges[0], edges[1]]).astype(np.int64)


def main():
    parser = argparse.ArgumentParser(description='HERO heterophily comparison runner')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--no-plots', action='store_true')
    parser.add_argument('--tex', action='store_true')
    args = parser.parse_args()

    X, adj, y, masks = DatasetLoader.load_dataset(args.dataset)
    if X is None:
        raise RuntimeError(f"Failed to load dataset: {args.dataset}")
    edges = _edge_array_from_masks(adj)

    cfg = ComparisonConfig()
    framework = HeterophilyComparisonFramework(cfg)
    # Prepare output dir first and pass for plots/artifacts
    tag = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')
    out_dir = os.path.join(get_results_dir(), args.dataset, 'heterophily_compare', tag)
    os.makedirs(out_dir, exist_ok=True)
    report = framework.run_complete_analysis(
        X, edges, y, None, args.dataset, masks,
        output_dir=(None if args.no_plots else out_dir),
        save_tex=args.tex and (not args.no_plots)
    )

    with open(os.path.join(out_dir, 'comparison.json'), 'w') as f:
        json.dump(report, f, indent=2)
    print('Saved:', os.path.join(out_dir, 'comparison.json'))


if __name__ == '__main__':
    main()
