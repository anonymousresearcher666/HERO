import argparse
import itertools
import json
import os
import time
from datetime import datetime

from hero.runners.experiment import run as run_module, _make_module


def run_one(dataset: str, module_name: str, tag: str, params: dict) -> dict:
    print(f"\n>>> Running: {module_name} | tag={tag} ...")
    start = time.time()
    module = _make_module(module_name, params)
    out = run_module(module, dataset, tag, {'params': params, 'sweep': True})
    res_dir = out['dir']
    sum_path = os.path.join(res_dir, 'summary.json')
    with open(sum_path, 'r') as f:
        summary = json.load(f)
    out = {
        'exp_dir': res_dir,
        'summary': summary,
        'elapsed_s': time.time() - start,
    }
    return out


def main():
    parser = argparse.ArgumentParser(description='HERO sweep runner')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--method', default='affinity_pl_grid')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    dataset = args.dataset
    method_base = args.method
    seed = args.seed

    # Define a compact grid (16 runs)
    grid = {
        'HERO_UNSUP_PROTO_WEIGHT': [0.10, 0.12],
        'HERO_SEMI_LABEL_WEIGHT': [0.10, 0.15],
        'HERO_SEMI_CONTRASTIVE_WEIGHT': [0.5],
        'HERO_PL_MARGIN': [0.06, 0.08],
        'HERO_PL_GLOBAL_CAP': [0.15, 0.20],
    }

    fixed_params = {'affinity_dim': 128}

    keys = list(grid.keys())
    values = list(grid.values())
    combos = list(itertools.product(*values))

    results = []
    for i, vals in enumerate(combos, start=1):
        overrides = {k: v for k, v in zip(keys, vals)}
        tag = datetime.now().strftime('%Y%m%d_%H%M%S') + f"_{i:03d}"
        params = dict(fixed_params)
        if 'HERO_PL_GLOBAL_CAP' in overrides:
            params['global_cap'] = overrides['HERO_PL_GLOBAL_CAP']
        out = run_one(dataset, 'affinity_pl', tag, params)
        out['tag'] = tag
        out['overrides'] = overrides
        results.append(out)

    # Rank and save sweep summary
    from hero.paths import get_results_dir
    base_dir = os.path.join(get_results_dir(), dataset, method_base)
    os.makedirs(base_dir, exist_ok=True)
    summary = sorted(results, key=lambda x: (-x['affinity_semi'], -x['affinity_unsup']))
    best = summary[0]
    sweep_report = {
        'dataset': dataset,
        'method': method_base,
        'seed': seed,
        'runs': summary,
        'best': best,
    }
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    with open(os.path.join(base_dir, f'sweep_summary_{stamp}.json'), 'w') as f:
        json.dump(sweep_report, f, indent=2)
    print("\n=== Best configuration ===")
    print(json.dumps(best, indent=2))


if __name__ == '__main__':
    main()
