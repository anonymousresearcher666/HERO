"""Batch experiments runner.

Reads a JSON config listing datasets and methods (modules) to run, executes all
runs with plotting options, and produces per-dataset comparison charts.

Config schema (example):
{
  "datasets": ["roman_empire", "amazon_ratings"],
  "methods": [
    {"module": "affinity_pl", "params": {"affinity_dim": 128, "conf_thr": 0.6}},
    {"module": "label_rewire", "params": {"pos_k": 10, "conf_thr": 0.75}}
  ],
  "plots": {"enable": true, "save_tex": false},
  "metric": "auto"  // or a specific key to compare on
}
"""

from __future__ import annotations

import os
import json
import argparse
from datetime import datetime
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt

from hero.paths import get_results_dir
from hero.runners.experiment import run as run_module, _make_module
from hero.plotting.plots import write_root_index, _try_save_tex


DEFAULT_METRIC_BY_MODULE = {
    'affinity_pl': 'pl_acc',
    'affinity_contrastive': 'affinity_unsup_acc',
    'spectral_lp': 'lp_acc',
    'label_rewire': 'label_rewire_acc',
}


def _best_by_metric(runs: List[Tuple[str, Dict]], metric: str) -> Tuple[str, Dict, float]:
    best_tag = None
    best_sum = None
    best_val = float('-inf')
    for tag, s in runs:
        v = s.get('mean', {}).get(metric)
        if isinstance(v, (int, float)) and float(v) > best_val:
            best_val = float(v); best_tag = tag; best_sum = s
    return best_tag or runs[0][0], best_sum or runs[0][1], float(best_val if best_val > float('-inf') else 0.0)


def _collect_runs(dataset: str) -> Dict[str, List[Tuple[str, Dict]]]:
    base = os.path.join(get_results_dir(), dataset)
    out: Dict[str, List[Tuple[str, Dict]]] = {}
    if not os.path.isdir(base):
        return out
    for module in os.listdir(base):
        mod_dir = os.path.join(base, module)
        if not os.path.isdir(mod_dir):
            continue
        runs = []
        for tag in os.listdir(mod_dir):
            run_dir = os.path.join(mod_dir, tag)
            sum_path = os.path.join(run_dir, 'summary.json')
            if os.path.isfile(sum_path):
                try:
                    with open(sum_path, 'r') as f:
                        summary = json.load(f)
                    runs.append((tag, summary))
                except Exception:
                    continue
        if runs:
            out[module] = runs
    return out


def _pick_metric(summary: Dict, default: str) -> str:
    # If default present, use it; else pick first numeric key
    mean = summary.get('mean', {})
    if default in mean:
        return default
    for k, v in mean.items():
        if isinstance(v, (int, float)):
            return k
    return default


def main():
    parser = argparse.ArgumentParser(description='HERO batch experiments')
    parser.add_argument('--config', required=True, help='JSON config with datasets and methods')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--no-plots', action='store_true')
    parser.add_argument('--tex', action='store_true')
    args = parser.parse_args()

    with open(args.config, 'r') as f:
        cfg = json.load(f)
    datasets: List[str] = cfg.get('datasets', [])
    methods: List[Dict] = cfg.get('methods', [])
    plots_cfg = cfg.get('plots', {})
    metric_pref = cfg.get('metric', 'auto')
    if not datasets or not methods:
        raise ValueError('Config must include non-empty datasets and methods')

    # Iterate datasets and methods
    runs_index: Dict[str, Dict[str, str]] = {}  # dataset -> module -> run_dir
    overall: Dict[str, List[float]] = {}
    for ds in datasets:
        print(f"\n=== Dataset: {ds} ===")
        for m in methods:
            module_name = m.get('module')
            params = m.get('params', {})
            tag = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')
            module = _make_module(module_name, params)
            payload = {'params': params, 'plots': {'enable': not args.no_plots, 'save_tex': args.tex}}
            out = run_module(module, ds, tag, payload)
            runs_index.setdefault(ds, {})[module_name] = out['dir']

        # After running all methods for this dataset, aggregate
        collected = _collect_runs(ds)
        # Decide metric per module (fallback to first numeric in summary)
        best = {}
        labels = []
        vals = []
        for module_name, run_list in collected.items():
            default_metric = DEFAULT_METRIC_BY_MODULE.get(module_name, None)
            # Pick metric
            if metric_pref == 'auto':
                # find metric from the first run
                metric = _pick_metric(run_list[0][1], default_metric or 'accuracy')
            else:
                metric = metric_pref
            tag, summary, val = _best_by_metric(run_list, metric)
            best[module_name] = (tag, summary, metric)
            labels.append(module_name)
            vals.append(val)

        out_root = os.path.join(get_results_dir(), ds, 'batch', args.tag or datetime.now().strftime('%Y%m%d_%H%M%S'))
        os.makedirs(out_root, exist_ok=True)
        # Plot comparison
        plt.figure(figsize=(6,3.5))
        plt.bar(labels, vals, color=['#4e79a7','#f28e2b','#e15759','#76b7b2','#59a14f'][:len(labels)])
        plt.ylim(0,1)
        plt.ylabel(metric_pref if metric_pref != 'auto' else 'score')
        plt.title(f'Best per module ({ds})')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        comp_base = os.path.join(out_root, 'comparison')
        plt.savefig(comp_base + '.png', dpi=150)
        _try_save_tex(comp_base, args.tex)
        plt.close()
        # Write index
        links = [('comparison.png', 'comparison.png')]
        for mod, (tag, _, _) in best.items():
            links.append((f'{mod}/{tag}', f"../{mod}/{tag}/plots/index.html"))
        write_root_index(out_root, f"Batch – {ds}", links)
        # Save summary JSON
        summary = {'dataset': ds, 'best_by_module': best, 'metric': metric_pref}
        with open(os.path.join(out_root, 'summary.json'), 'w') as f:
            json.dump(summary, f, indent=2)

        # Update overall aggregates
        for mod, (_, _, v) in best.items():
            overall.setdefault(mod, []).append(float(v))

    # Overall aggregate across datasets
    if overall:
        labels = list(overall.keys())
        vals = [sum(overall[m]) / max(1, len(overall[m])) for m in labels]
        over_root = os.path.join(get_results_dir(), 'batch_overall', args.tag or datetime.now().strftime('%Y%m%d_%H%M%S'))
        os.makedirs(over_root, exist_ok=True)
        plt.figure(figsize=(6,3.5))
        plt.bar(labels, vals, color=['#4e79a7','#f28e2b','#e15759','#76b7b2','#59a14f'][:len(labels)])
        plt.ylim(0,1)
        plt.ylabel(metric_pref if metric_pref != 'auto' else 'score')
        plt.title('Best per module (mean across datasets)')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        comp_base = os.path.join(over_root, 'comparison_overall')
        plt.savefig(comp_base + '.png', dpi=150)
        _try_save_tex(comp_base, args.tex)
        plt.close()
        # Index
        links = [('comparison_overall.png', 'comparison_overall.png')]
        write_root_index(over_root, 'Batch – overall', links)
        with open(os.path.join(over_root, 'summary.json'), 'w') as f:
            json.dump({'overall': overall, 'metric': metric_pref}, f, indent=2)


if __name__ == '__main__':
    main()
