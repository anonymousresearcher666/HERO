import argparse
import json
import os
from dataclasses import asdict
from typing import Dict

import numpy as np
import torch
from sklearn.metrics import roc_auc_score

from hero.core.dataset import DatasetLoader
from hero.core.config import ExperimentConfig, DEVICE
from hero.core.model import ProfileModel
from hero.core.trainer import ProfileTrainer
from hero.calculators.homophily import HomophilyCalculator
from hero.profiler.router import compute_profile_effect_size
from hero.paths import get_results_dir


def _normalize(X: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(X, axis=1, keepdims=True) + 1e-8
    return X / n


def sym_prob(qn: np.ndarray, an: np.ndarray, i: np.ndarray, j: np.ndarray, alpha: float = 1.0) -> np.ndarray:
    s1 = (qn[i] * an[j]).sum(axis=1)
    s2 = (qn[j] * an[i]).sum(axis=1)
    p = 0.5 * (1.0 / (1.0 + np.exp(-alpha * s1)) + 1.0 / (1.0 + np.exp(-alpha * s2)))
    return p


def compare(dataset: str, quick: bool = True) -> Dict:
    X, A, y, masks = DatasetLoader.load_dataset(dataset)
    n = X.shape[0]
    edge_index = np.vstack(np.nonzero(A)).astype(np.int64)  # [2, m]
    edges = edge_index.T

    # Real homophily metrics
    real = HomophilyCalculator.calculate_all_homophily_measures(edges, y)

    # Train affinity (quick by default)
    epochs = 6 if quick else 20
    cfg = ExperimentConfig(datasets=['custom'], affinity_dim=128, epochs=epochs,
                           edge_loss_mode='paper', neg_ratio=1.0, hard_neg_frac=0.5,
                           eic_temperature=0.2, balance_losses=True, edge_batch_size=4096,
                           unsupervised=True, contrastive_weight=1.0, label_weight=0.0,
                           strategy='contrastive_proto')
    model = ProfileModel(n, X.shape[1], cfg.affinity_dim, DEVICE)
    trainer = ProfileTrainer(model, cfg)
    train_mask = masks['train_mask'][:, 0] if masks['train_mask'].ndim == 2 else masks['train_mask']
    trainer.train(X, A, y, train_mask)

    with torch.no_grad():
        ft = torch.tensor(X, dtype=torch.float32, device=DEVICE)
        q = model.proj_head(model.feature_projection(ft)).cpu().numpy()
        a = model.affinity_vectors.detach().cpu().numpy()
    qn = _normalize(q); an = _normalize(a)

    # Request-profile diagnostics
    d_aff = compute_profile_effect_size(qn, an, num_samples=min(200_000, n * 50))

    # Edge-level alignment: probability on edges; compare same vs diff class, and ROC-AUC
    i = edges[:, 0]; j = edges[:, 1]
    p_e = sym_prob(qn, an, i, j)
    same = (y[i] == y[j]).astype(np.int32)
    mean_p_same = float(p_e[same == 1].mean()) if np.any(same == 1) else 0.0
    mean_p_diff = float(p_e[same == 0].mean()) if np.any(same == 0) else 0.0
    try:
        auc = float(roc_auc_score(same, p_e))
    except Exception:
        auc = 0.0

    out = {
        'dataset': dataset,
        'real_homophily': real,
        'affinity': {
            'd_aff': float(d_aff),
            'edge_mean_prob_same': mean_p_same,
            'edge_mean_prob_diff': mean_p_diff,
            'edge_roc_auc_same_vs_diff': auc,
        }
    }
    return out


def main():
    parser = argparse.ArgumentParser(description='Compare real homophily vs affinity-based scores')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--quick', action='store_true', help='Use reduced epochs for faster comparison')
    args = parser.parse_args()
    out = compare(args.dataset, quick=args.quick)
    out_dir = os.path.join(get_results_dir(), args.dataset, 'homophily_compare')
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, 'homophily_vs_affinity.json'), 'w') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
