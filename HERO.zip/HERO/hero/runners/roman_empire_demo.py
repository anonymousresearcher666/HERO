"""
Roman Empire focused demo: stronger unsupervised training + calibrated, stable pseudo-labeling
with validation-based K selection and a richer embedding for classification. Goal: beat logistic.

Pipeline (per split):
  A) Unsupervised training (contrastive_2hop, structure_weight=0)
  B) Pick K by validation (K in {5, 10, 15, 25, 35, 50}), embedding = projected
  C) Calibrated pseudo-label selection on non-train/non-test (includes val):
     - dynamic confidence threshold via validation
     - margin filter (p_top - p_second >= 0.05)
     - per-class top 10–15% cap (balanced)
     - stability across 3 stochastic views (feature dropout)
  D) Semi-supervised fine-tuning (label_weight=0.6) and classify with concat embedding

This script is self-contained and uses the components from completePIPELINE.py.
"""
import json
import os
import sys
import time
from datetime import datetime
from typing import Tuple, Dict

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score

from hero.core import (
    DatasetLoader,
    AffinityModel,
    AffinityTrainer,
    AffinityClassifier,
    BaselineClassifiers,
    ExperimentConfig,
    DEVICE,
)
from hero.paths import get_results_dir


def _row_norm(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


def set_seed(seed: int = 42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _env_str(name: str, default: str) -> str:
    return os.getenv(name, default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except Exception:
        return default


def _env_bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.lower() in {'1', 'true', 'yes', 'y', 'on'}


def _env_list_int(name: str, default: str) -> list:
    raw = os.getenv(name, default)
    try:
        return [int(x.strip()) for x in raw.split(',') if x.strip()]
    except Exception:
        return [int(x) for x in default.split(',')]


SEED = 42
set_seed(SEED)

# Global settings container (populated in main from env)
SETTINGS: Dict = {}


def knn_probs(emb_test: np.ndarray, emb_train: np.ndarray, y_train: np.ndarray, k: int, batch: int = 4096) -> Tuple[np.ndarray, np.ndarray]:
    """Return (pred_labels, confidences) using cosine-sim kNN with weighted vote.
    emb_* must be L2-normalized.
    """
    n_test = emb_test.shape[0]
    preds = np.zeros(n_test, dtype=np.int64)
    conf = np.zeros(n_test, dtype=np.float32)
    for s in range(0, n_test, batch):
        e = min(s + batch, n_test)
        S = emb_test[s:e] @ emb_train.T  # [b, n_train]
        # top-k indices
        kk = min(k, S.shape[1])
        idx = np.argpartition(-S, kth=kk - 1, axis=1)[:, :kk]
        # weighted voting
        for i in range(idx.shape[0]):
            neigh = idx[i]
            w = S[i, neigh]
            w = np.maximum(w, 0)
            if w.sum() == 0:
                w = np.ones_like(w)
            w = w / (w.sum() + 1e-8)
            labs = y_train[neigh]
            classes, inv = np.unique(labs, return_inverse=True)
            probs = np.zeros(len(classes), dtype=np.float32)
            for j, cidx in enumerate(inv):
                probs[cidx] += w[j]
            best = int(classes[probs.argmax()])
            preds[s + i] = best
            conf[s + i] = float(probs.max())
    return preds, conf


def knn_class_probs(emb_test: np.ndarray, emb_train: np.ndarray, y_train: np.ndarray, n_classes: int, k: int, batch: int = 4096) -> np.ndarray:
    """Return per-class probability vectors from cosine kNN weighted voting.
    emb_* must be L2-normalized. Shape: [n_test, n_classes].
    """
    n_test = emb_test.shape[0]
    out = np.zeros((n_test, n_classes), dtype=np.float32)
    for s in range(0, n_test, batch):
        e = min(s + batch, n_test)
        S = emb_test[s:e] @ emb_train.T
        kk = min(k, S.shape[1])
        idx = np.argpartition(-S, kth=kk - 1, axis=1)[:, :kk]
        for i in range(idx.shape[0]):
            neigh = idx[i]
            w = S[i, neigh]
            w = np.maximum(w, 0)
            if w.sum() == 0:
                w = np.ones_like(w)
            w = w / (w.sum() + 1e-8)
            probs = np.zeros(n_classes, dtype=np.float32)
            labs = y_train[neigh]
            for j, lab in enumerate(labs):
                probs[int(lab)] += w[j]
            out[s + i] = probs
    return out


def val_pick_k(E: np.ndarray, y: np.ndarray, train_mask: np.ndarray, val_mask: np.ndarray, Ks=(5, 10, 15, 25, 35, 50, 65, 85)) -> int:
    train_idx = np.where(train_mask)[0]
    val_idx = np.where(val_mask)[0]
    if val_idx.size == 0 or train_idx.size == 0:
        return Ks[0]
    E_train = _row_norm(E[train_idx])
    E_val = _row_norm(E[val_idx])
    y_train = y[train_idx]
    y_val = y[val_idx]
    best_k, best_acc = Ks[0], -1.0
    for k in Ks:
        p, _ = knn_probs(E_val, E_train, y_train, k)
        acc = (p == y_val).mean()
        if acc > best_acc:
            best_acc, best_k = acc, k
    return best_k


def get_embedding(model: AffinityModel, features: np.ndarray, emb_type: str = 'projected') -> np.ndarray:
    with torch.no_grad():
        ft = torch.tensor(features, dtype=torch.float32, device=model.device)
        proj = model.proj_head(model.feature_projection(ft))
        proj = F.normalize(proj, dim=1, eps=1e-8).cpu().numpy()
        if emb_type == 'projected':
            return proj
        elif emb_type == 'concat':
            aff = model.get_affinity_vectors()
            return _row_norm(np.concatenate([proj, aff], axis=1))
        else:
            return proj


def spectral_smooth(E: np.ndarray, adj: np.ndarray, steps: int = 1, alpha: float = 0.5) -> np.ndarray:
    if steps <= 0:
        return E
    A = adj.astype(np.float32)
    np.fill_diagonal(A, 0.0)
    deg = A.sum(axis=1) + 1e-8
    D_inv_sqrt = 1.0 / np.sqrt(deg)
    # sym-normalized adjacency \hat{A} = D^{-1/2} A D^{-1/2}
    W = (D_inv_sqrt[:, None] * A) * D_inv_sqrt[None, :]
    I = np.eye(A.shape[0], dtype=np.float32)
    S = alpha * I + (1.0 - alpha) * W
    X = E.astype(np.float32)
    for _ in range(steps):
        X = S @ X
    return _row_norm(X)


def compute_class_prototypes(E_train: np.ndarray, y_train: np.ndarray, n_classes: int) -> np.ndarray:
    protos = np.zeros((n_classes, E_train.shape[1]), dtype=np.float32)
    for c in range(n_classes):
        idx = np.where(y_train == c)[0]
        if idx.size > 0:
            m = E_train[idx].mean(axis=0)
            n = np.linalg.norm(m) + 1e-8
            protos[c] = m / n
    return protos


def proto_probs(E_test: np.ndarray, prototypes: np.ndarray, tau: float = 1.0) -> np.ndarray:
    S = E_test @ prototypes.T
    if tau <= 0:
        tau = 1.0
    S = S / tau
    # softmax
    S = S - S.max(axis=1, keepdims=True)
    P = np.exp(S)
    P = P / (P.sum(axis=1, keepdims=True) + 1e-8)
    return P.astype(np.float32)


def pick_best_classifier(model: AffinityModel, features: np.ndarray, labels: np.ndarray,
                         train_mask: np.ndarray, val_mask: np.ndarray, k: int,
                         adj: np.ndarray) -> Tuple[str, str, Dict]:
    """Return (clf_type, emb_type, params) maximizing validation accuracy.
    clf_type in { 'knn', 'logreg', 'proto', 'blend' }, emb_type in { 'projected', 'concat' }.
    params holds extra keys depending on clf_type.
    """
    best = (None, None, {})
    best_acc = -1.0
    val_idx = np.where(val_mask)[0]
    if val_idx.size == 0:
        return ('knn', 'projected', {})

    for emb_type in ('projected', 'concat'):
        E_base = get_embedding(model, features, emb_type)
        # IMPORTANT: disable smoothing by default (it overfits val in practice)
        for smooth in (0,):
            E = E_base
        E_train = E[train_mask]
        y_train = labels[train_mask]
        E_val = E[val_mask]
        y_val = labels[val_mask]
        n_classes = int(labels.max()) + 1

        # kNN
        p_knn = None
        try:
            p_knn = knn_class_probs(_row_norm(E_val), _row_norm(E_train), y_train, n_classes, k)
            acc = (p_knn.argmax(axis=1) == y_val).mean()
            if acc > best_acc:
                best_acc = acc
                best = ('knn', emb_type, {'k': k, 'smooth': smooth})
        except Exception:
            pass

        # Logistic regression on embedding
        if E_val.shape[0] > 0 and E_train.shape[0] > 0:
            lr = LogisticRegression(max_iter=1000)
            lr.fit(E_train, y_train)
            y_hat = lr.predict(E_val)
            acc_lr = (y_hat == y_val).mean()
            if acc_lr > best_acc:
                best_acc = acc_lr
                best = ('logreg', emb_type, {'smooth': smooth})

        # Prototypes
        protos = compute_class_prototypes(_row_norm(E_train), y_train, n_classes)
        for tau in (0.5, 1.0):
            Pp = proto_probs(_row_norm(E_val), protos, tau=tau)
            acc_p = (Pp.argmax(axis=1) == y_val).mean()
            if acc_p > best_acc:
                best_acc = acc_p
                best = ('proto', emb_type, {'tau': tau, 'smooth': smooth})

        # Blended (kNN + prototype)
        if p_knn is None:
            p_knn = knn_class_probs(_row_norm(E_val), _row_norm(E_train), y_train, n_classes, k)
        for alpha in (0.25, 0.5, 0.75):
            for tau in (0.5, 1.0):
                Pp = proto_probs(_row_norm(E_val), protos, tau=tau)
                P = alpha * p_knn + (1 - alpha) * Pp
                acc_b = (P.argmax(axis=1) == y_val).mean()
                if acc_b > best_acc:
                    best_acc = acc_b
                    best = ('blend', emb_type, {'alpha': alpha, 'tau': tau, 'smooth': smooth})

    return best


def stability_votes(model: AffinityModel, features: np.ndarray, emb_train: np.ndarray, y_train: np.ndarray,
                    cand_idx: np.ndarray, base_pred: np.ndarray, k: int, views: int = 3, drop_p: float = 0.3) -> np.ndarray:
    """Return boolean mask where candidate predictions are stable across stochastic feature-dropout views.
    Uses projected embedding with random feature dropout.
    """
    dev = model.device
    # base_pred is already aligned with cand_idx ordering (predictions over E_cand)
    agree = np.zeros_like(base_pred, dtype=np.int32)
    with torch.no_grad():
        ft_full = torch.tensor(features, dtype=torch.float32, device=dev)
        for _ in range(views):
            noise_mask = (torch.rand_like(ft_full) > drop_p).float()
            ft_aug = ft_full * noise_mask
            proj = model.proj_head(model.feature_projection(ft_aug))
            proj = F.normalize(proj, dim=1, eps=1e-8).cpu().numpy()
            E_test = _row_norm(proj[cand_idx])
            p_view, _ = knn_probs(E_test, emb_train, y_train, k)
            agree += (p_view == base_pred).astype(np.int32)
    # require all views to agree
    return agree == views


def run_split(features, adj, labels, masks, split_idx: int):
    tm = masks['train_mask'][:, split_idx] if masks['train_mask'].ndim == 2 else masks['train_mask']
    vm = masks['val_mask'][:, split_idx] if masks.get('val_mask') is not None and masks['val_mask'].ndim == 2 else (masks.get('val_mask') if masks.get('val_mask') is not None else np.zeros_like(tm))
    sm = masks['test_mask'][:, split_idx] if masks['test_mask'].ndim == 2 else masks['test_mask']

    n_nodes, n_features = features.shape

    # A) Unsupervised strong training
    cfg_unsup = ExperimentConfig(
        datasets=['roman_empire'],
        affinity_dim=SETTINGS.get('unsup_aff_dim', 128),
        learning_rate=SETTINGS.get('unsup_lr', 0.005),
        epochs=SETTINGS.get('unsup_epochs', 50),
        early_stopping_patience=10,
        structure_weight=0.0,
        label_weight=0.0,
        contrastive_weight=1.0,
        unsupervised=True,
        temperature=SETTINGS.get('unsup_temp', 0.1),
        strategy='contrastive_proto',
        proto_weight=SETTINGS.get('unsup_proto_w', 0.1),
        feature_dropout=0.3,
        edge_dropout=0.3,
        k_neighbors=25,
        embedding_type='projected',
        use_weighted_voting=True,
        test_runs=1,
        save_results=False,
    )
    model = AffinityModel(n_nodes, n_features, cfg_unsup.affinity_dim, DEVICE)
    trainer = AffinityTrainer(model, cfg_unsup)
    t0_unsup = time.time()
    trainer.train(features, adj, labels, tm)
    t_unsup_train = time.time() - t0_unsup

    # Build projected embedding
    with torch.no_grad():
        ft = torch.tensor(features, dtype=torch.float32, device=model.device)
        proj = model.proj_head(model.feature_projection(ft))
        proj = F.normalize(proj, dim=1, eps=1e-8).cpu().numpy()

    # B) Pick K on validation (broader sweep)
    Ks = tuple(SETTINGS.get('k_sweep', [5,10,15,25,35,50,65,85]))
    k_star = val_pick_k(proj, labels, tm, vm, Ks=Ks) if vm.any() else Ks[0]

    # C) Calibrated pseudo-label selection
    # Candidate pool: not in train/test (include val)
    cand_mask = (~tm) & (~sm)
    cand_idx = np.where(cand_mask)[0]
    if cand_idx.size == 0:
        raise RuntimeError("No candidates for pseudo-labeling.")

    train_idx = np.where(tm)[0]
    E_train = _row_norm(proj[train_idx])
    E_cand = _row_norm(proj[cand_idx])
    y_train = labels[train_idx]

    # Base predictions and confidences
    pred_cand, conf_cand = knn_probs(E_cand, E_train, y_train, k_star)

    # Compute proper margins from per-class probabilities
    n_classes = int(labels.max()) + 1
    prob_cand = knn_class_probs(E_cand, E_train, y_train, n_classes, k_star)
    top1 = prob_cand.max(axis=1)
    top2 = np.partition(prob_cand, -2, axis=1)[:, -2]
    margin = top1 - top2

    # Dynamic confidence threshold using validation (when available)
    conf_thr = SETTINGS.get('pl_conf_min', 0.60)
    if vm.any():
        val_idx = np.where(vm & (~tm) & (~sm))[0]
        if val_idx.size > 0:
            E_val = _row_norm(proj[val_idx])
            p_val, conf_val = knn_probs(E_val, E_train, y_train, k_star)
            y_val_true = labels[val_idx]
            correct_conf = conf_val[p_val == y_val_true]
            if correct_conf.size > 0:
                q = np.quantile(correct_conf, SETTINGS.get('pl_conf_q', 0.4))
                conf_thr = float(max(SETTINGS.get('pl_conf_min', 0.60), q))

    margin_thr = SETTINGS.get('pl_margin_thr', 0.08)

    # Stability across stochastic views
    stable_mask = stability_votes(model, features, E_train, y_train, cand_idx, pred_cand, k_star, views=3, drop_p=0.3)

    # K-consensus across nearby K values
    ks_cons = [max(5, k_star - 5), k_star, min(k_star + 10, E_train.shape[0])]
    agree_k = np.ones_like(pred_cand, dtype=bool)
    for kk in ks_cons:
        p_k, _ = knn_probs(E_cand, E_train, y_train, kk)
        agree_k &= (p_k == pred_cand)

    # Per-class top-cap selection with filters
    accept = np.zeros_like(conf_cand, dtype=bool)
    for c in np.unique(pred_cand):
        idx_c = np.where(pred_cand == c)[0]
        if idx_c.size == 0:
            continue
        # apply filters first
        filt = (conf_cand[idx_c] >= conf_thr) & (margin[idx_c] >= margin_thr) & (stable_mask[idx_c]) & (agree_k[idx_c])
        idx_f = idx_c[filt]
        if idx_f.size == 0:
            continue
        cap = max(3, int(SETTINGS.get('pl_per_class_cap', 0.10) * idx_c.size))
        order = np.argsort(-conf_cand[idx_f])[:cap]
        chosen = idx_f[order]
        accept[chosen] = True

    accept_idx = cand_idx[accept]
    # Global cap to avoid overpowering labeled set (more conservative)
    max_global = max(0, int(SETTINGS.get('pl_global_cap', 0.2) * train_idx.size))
    if accept_idx.size > max_global > 0:
        order = np.argsort(-conf_cand[accept])[:max_global]
        accept_local = np.zeros_like(accept)
        accept_local[np.where(accept)[0][order]] = True
        accept = accept_local
        accept_idx = cand_idx[accept]

    # D) Retrain semi-supervised with pseudo labels
    tm_pl = tm.copy()
    labels_pl = labels.copy()
    if accept_idx.size > 0:
        tm_pl[accept_idx] = True
        labels_pl[accept_idx] = pred_cand[accept]

    cfg_semi = ExperimentConfig(
        datasets=['roman_empire'],
        affinity_dim=SETTINGS.get('unsup_aff_dim', 128),
        learning_rate=SETTINGS.get('semi_lr', 0.003),
        epochs=SETTINGS.get('semi_epochs', 30),
        early_stopping_patience=8,
        structure_weight=0.0,
        label_weight=SETTINGS.get('semi_label_w', 0.15),
        contrastive_weight=SETTINGS.get('semi_contrast_w', 0.5),
        unsupervised=False,
        temperature=SETTINGS.get('unsup_temp', 0.1),
        strategy='contrastive_proto',
        proto_weight=SETTINGS.get('semi_proto_w', 0.1),
        feature_dropout=0.3,
        edge_dropout=0.3,
        k_neighbors=k_star,
        embedding_type='projected',
        use_weighted_voting=True,
        test_runs=1,
        save_results=False,
    )
    model_semi = AffinityModel(n_nodes, n_features, cfg_semi.affinity_dim, DEVICE)
    trainer_semi = AffinityTrainer(model_semi, cfg_semi)
    # Freeze affinity vectors to reduce PL drift; fine-tune projection only (configurable)
    if SETTINGS.get('freeze_affinity', True):
        try:
            model_semi.affinity_vectors.requires_grad_(False)
        except Exception:
            pass
    t0_semi = time.time()
    trainer_semi.train(features, adj, labels_pl, tm_pl)
    t_semi_train = time.time() - t0_semi

    # Evaluate: pick classifier/embedding by validation for both stages
    # UNSUP
    t0_unsup_eval = time.time()
    best_unsup = pick_best_classifier(model, features, labels, tm, vm if vm.any() else sm, k_star, adj)
    clf_type_u, emb_type_u, params_u = best_unsup
    if clf_type_u == 'knn':
        cfg_tmp = ExperimentConfig(datasets=['roman_empire'], k_neighbors=k_star, embedding_type=emb_type_u,
                                   use_weighted_voting=True, unsupervised=True, structure_weight=0.0,
                                   label_weight=0.0, contrastive_weight=0.0, epochs=0)
        clf_unsup = AffinityClassifier(model, cfg_tmp, features)
        preds_unsup = clf_unsup.predict(labels, tm, sm)
    elif clf_type_u == 'proto':
        E_u = get_embedding(model, features, emb_type_u)
        if params_u.get('smooth', 0) > 0:
            E_u = spectral_smooth(E_u, adj, steps=params_u['smooth'], alpha=0.5)
        n_classes = int(labels.max()) + 1
        protos = compute_class_prototypes(_row_norm(E_u[tm]), labels[tm], n_classes)
        P = proto_probs(_row_norm(E_u[sm]), protos, tau=params_u.get('tau', 1.0))
        test_idx = np.where(sm)[0]
        y_hat = P.argmax(axis=1)
        preds_unsup = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    elif clf_type_u == 'blend':
        E_u = get_embedding(model, features, emb_type_u)
        if params_u.get('smooth', 0) > 0:
            E_u = spectral_smooth(E_u, adj, steps=params_u['smooth'], alpha=0.5)
        n_classes = int(labels.max()) + 1
        P_knn = knn_class_probs(_row_norm(E_u[sm]), _row_norm(E_u[tm]), labels[tm], n_classes, k_star)
        protos = compute_class_prototypes(_row_norm(E_u[tm]), labels[tm], n_classes)
        Pp = proto_probs(_row_norm(E_u[sm]), protos, tau=params_u.get('tau', 1.0))
        alpha = params_u.get('alpha', 0.5)
        P = alpha * P_knn + (1 - alpha) * Pp
        test_idx = np.where(sm)[0]
        y_hat = P.argmax(axis=1)
        preds_unsup = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    else:
        E_u = get_embedding(model, features, emb_type_u)
        if params_u.get('smooth', 0) > 0:
            E_u = spectral_smooth(E_u, adj, steps=params_u['smooth'], alpha=0.5)
        lr_u = LogisticRegression(max_iter=1000)
        lr_u.fit(E_u[tm], labels[tm])
        test_idx = np.where(sm)[0]
        y_hat = lr_u.predict(E_u[sm])
        preds_unsup = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    test_idx = np.where(sm)[0]
    y_true = [labels[i] for i in test_idx]
    y_unsup = [preds_unsup[i] for i in test_idx]
    acc_unsup = accuracy_score(y_true, y_unsup)
    f1_unsup = f1_score(y_true, y_unsup, average='weighted')
    t_unsup_eval = time.time() - t0_unsup_eval

    # SEMI
    t0_semi_eval = time.time()
    # Use validation nodes that are NOT used as pseudo-labels for model selection
    vm_clean = (vm & (~tm_pl)) if vm.any() else sm
    best_semi = pick_best_classifier(model_semi, features, labels_pl, tm_pl, vm_clean, k_star, adj)
    clf_type_s, emb_type_s, params_s = best_semi
    if clf_type_s == 'knn':
        cfg_tmp2 = ExperimentConfig(datasets=['roman_empire'], k_neighbors=k_star, embedding_type=emb_type_s,
                                    use_weighted_voting=True, unsupervised=False, structure_weight=0.0,
                                    label_weight=0.0, contrastive_weight=0.0, epochs=0)
        clf_semi = AffinityClassifier(model_semi, cfg_tmp2, features)
        preds_semi = clf_semi.predict(labels_pl, tm_pl, sm)
    elif clf_type_s == 'proto':
        E_s = get_embedding(model_semi, features, emb_type_s)
        if params_s.get('smooth', 0) > 0:
            E_s = spectral_smooth(E_s, adj, steps=params_s['smooth'], alpha=0.5)
        n_classes = int(labels.max()) + 1
        protos = compute_class_prototypes(_row_norm(E_s[tm_pl]), labels_pl[tm_pl], n_classes)
        P = proto_probs(_row_norm(E_s[sm]), protos, tau=params_s.get('tau', 1.0))
        test_idx = np.where(sm)[0]
        y_hat = P.argmax(axis=1)
        preds_semi = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    elif clf_type_s == 'blend':
        E_s = get_embedding(model_semi, features, emb_type_s)
        if params_s.get('smooth', 0) > 0:
            E_s = spectral_smooth(E_s, adj, steps=params_s['smooth'], alpha=0.5)
        n_classes = int(labels.max()) + 1
        P_knn = knn_class_probs(_row_norm(E_s[sm]), _row_norm(E_s[tm_pl]), labels_pl[tm_pl], n_classes, k_star)
        protos = compute_class_prototypes(_row_norm(E_s[tm_pl]), labels_pl[tm_pl], n_classes)
        Pp = proto_probs(_row_norm(E_s[sm]), protos, tau=params_s.get('tau', 1.0))
        alpha = params_s.get('alpha', 0.5)
        P = alpha * P_knn + (1 - alpha) * Pp
        test_idx = np.where(sm)[0]
        y_hat = P.argmax(axis=1)
        preds_semi = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    else:
        E_s = get_embedding(model_semi, features, emb_type_s)
        if params_s.get('smooth', 0) > 0:
            E_s = spectral_smooth(E_s, adj, steps=params_s['smooth'], alpha=0.5)
        lr_s = LogisticRegression(max_iter=1000)
        lr_s.fit(E_s[tm_pl], labels_pl[tm_pl])
        test_idx = np.where(sm)[0]
        y_hat = lr_s.predict(E_s[sm])
        preds_semi = {test_idx[i]: int(y_hat[i]) for i in range(len(test_idx))}
    y_semi = [preds_semi[i] for i in test_idx]
    acc_semi = accuracy_score(y_true, y_semi)
    f1_semi = f1_score(y_true, y_semi, average='weighted')
    t_semi_eval = time.time() - t0_semi_eval

    # Baselines on this split
    t0_base = time.time()
    base = BaselineClassifiers(cfg_unsup)
    graph_preds = base.classify_graph_neighbors(adj, labels, tm, sm)
    feat_preds = base.classify_feature_similarity(features, labels, tm, sm)
    log_preds = base.classify_sklearn(features, labels, tm, sm, 'logistic')
    y_graph = [graph_preds[i] for i in test_idx]
    y_feat = [feat_preds[i] for i in test_idx]
    y_log = [log_preds[i] for i in test_idx]

    acc_graph = accuracy_score(y_true, y_graph)
    acc_feat = accuracy_score(y_true, y_feat)
    acc_log = accuracy_score(y_true, y_log)
    t_baselines = time.time() - t0_base

    print(f"\nSplit {split_idx+1}: K*={k_star} | PL added: {accept_idx.size} | UNSUP {clf_type_u}/{emb_type_u} | SEMI {clf_type_s}/{emb_type_s}")
    print(f"  affinity_unsup: Acc={acc_unsup:.4f}, F1={f1_unsup:.4f}")
    print(f"  affinity_semi (PL): Acc={acc_semi:.4f}, F1={f1_semi:.4f}")
    print(f"  feature: Acc={acc_feat:.4f} | logistic: Acc={acc_log:.4f} | graph: Acc={acc_graph:.4f}")

    return {
        'k_star': k_star,
        'acc_unsup': acc_unsup,
        'f1_unsup': f1_unsup,
        'acc_semi': acc_semi,
        'f1_semi': f1_semi,
        'acc_feat': acc_feat,
        'acc_log': acc_log,
        'acc_graph': acc_graph,
        'pl_added': int(accept_idx.size),
        'unsup_clf': clf_type_u,
        'unsup_emb': emb_type_u,
        'unsup_params': params_u,
        'semi_clf': clf_type_s,
        'semi_emb': emb_type_s,
        'semi_params': params_s,
        'timing': {
            'unsup_train_s': t_unsup_train,
            'semi_train_s': t_semi_train,
            'unsup_select_eval_s': t_unsup_eval,
            'semi_select_eval_s': t_semi_eval,
            'baselines_eval_s': t_baselines
        }
    }


def main():
    print("🔥 Roman Empire calibrated pseudo-labeling demo")
    import argparse
    parser = argparse.ArgumentParser(description='Roman Empire demo')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--method', default='affinity_proto_pl_auto')
    parser.add_argument('--tag', default=None)
    args = parser.parse_args()
    dataset = args.dataset
    method = args.method
    timestamp = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')

    feats, adj, labels, masks = DatasetLoader.load_dataset(dataset)
    if feats is None:
        raise RuntimeError(f"Failed to load {dataset}")

    # Prepare results directory and save exact configuration at START
    # results/<dataset>/<method>/<timestamp> under project root
    exp_dir = os.path.join(get_results_dir(), dataset, method, timestamp)
    os.makedirs(exp_dir, exist_ok=True)

    # Build exact repro command
    repro_cmd = f"python {' '.join(sys.argv)}" if len(sys.argv) > 0 else "python mlx_backend/roman_empire_demo.py"

    # Effective hyperparameters (defaults)
    unsup_aff_dim = 128
    unsup_lr = 0.005
    unsup_epochs = 50
    unsup_temp = 0.1
    unsup_proto_w = 0.1

    semi_lr = 0.003
    semi_epochs = 30
    semi_label_w = 0.15
    semi_contrast_w = 0.5
    semi_proto_w = 0.1
    freeze_affinity = True

    k_sweep = [5,10,15,25,35,50,65,85]

    pl_margin_thr = 0.08
    pl_conf_min = 0.60
    pl_conf_q = 0.4
    pl_per_class_cap = 0.10
    pl_global_cap = 0.2

    # Persist effective settings for internal use (and reproducibility)
    global SETTINGS
    SETTINGS.update({
        'unsup_aff_dim': unsup_aff_dim,
        'unsup_lr': unsup_lr,
        'unsup_epochs': unsup_epochs,
        'unsup_temp': unsup_temp,
        'unsup_proto_w': unsup_proto_w,
        'semi_lr': semi_lr,
        'semi_epochs': semi_epochs,
        'semi_label_w': semi_label_w,
        'semi_contrast_w': semi_contrast_w,
        'semi_proto_w': semi_proto_w,
        'freeze_affinity': freeze_affinity,
        'k_sweep': k_sweep,
        'pl_margin_thr': pl_margin_thr,
        'pl_conf_min': pl_conf_min,
        'pl_conf_q': pl_conf_q,
        'pl_per_class_cap': pl_per_class_cap,
        'pl_global_cap': pl_global_cap,
    })

    cfg = {
        'seed': SEED,
        'device': DEVICE,
        'dataset': dataset,
        'method': method,
        'started_at': timestamp,
        'repro_command': repro_cmd,
        'unsup_config': {
            'affinity_dim': unsup_aff_dim,
            'learning_rate': unsup_lr,
            'epochs': unsup_epochs,
            'early_stopping_patience': 10,
            'structure_weight': 0.0,
            'label_weight': 0.0,
            'contrastive_weight': 1.0,
            'unsupervised': True,
            'temperature': unsup_temp,
            'strategy': 'contrastive_proto',
            'proto_weight': unsup_proto_w,
            'feature_dropout': 0.3,
            'edge_dropout': 0.3,
            'embedding_type': 'projected'
        },
        'semi_config': {
            'affinity_dim': unsup_aff_dim,
            'learning_rate': semi_lr,
            'epochs': semi_epochs,
            'early_stopping_patience': 8,
            'structure_weight': 0.0,
            'label_weight': semi_label_w,
            'contrastive_weight': semi_contrast_w,
            'unsupervised': False,
            'temperature': unsup_temp,
            'strategy': 'contrastive_proto',
            'proto_weight': semi_proto_w,
            'feature_dropout': 0.3,
            'edge_dropout': 0.3
        },
        'k_sweep': k_sweep,
        'pl_selection': {
            'stability_views': 3,
            'k_consensus': True,
            'margin_thr': pl_margin_thr,
            'dynamic_conf_from_val': True,
            'per_class_cap_pct': pl_per_class_cap,
            'global_cap_x_train': pl_global_cap,
            'conf_quantile': pl_conf_q,
            'conf_min': pl_conf_min
        },
        'readout_selection': ['knn', 'logreg', 'proto', 'blend'],
        'smoothing': {'steps_options': [0], 'alpha': 0.5}
    }
    with open(os.path.join(exp_dir, 'config.json'), 'w') as f:
        json.dump(cfg, f, indent=2)
    print(f"🗂️ Results directory: {exp_dir}")

    n_splits = masks['train_mask'].shape[1] if masks['train_mask'].ndim == 2 else 1
    results = []
    overall_start = time.time()
    for s in range(n_splits):
        split_start = time.time()
        res = run_split(feats, adj, labels, masks, s)
        res['timing']['total_split_s'] = time.time() - split_start
        results.append(res)

    # Aggregate
    acc_unsup = np.mean([r['acc_unsup'] for r in results])
    acc_semi  = np.mean([r['acc_semi'] for r in results])
    acc_feat  = np.mean([r['acc_feat'] for r in results])
    acc_log   = np.mean([r['acc_log'] for r in results])
    print("\n==== Summary (mean across splits) ====")
    print(f"affinity_unsup: {acc_unsup:.4f}")
    print(f"affinity_semi (PL): {acc_semi:.4f}")
    print(f"feature kNN: {acc_feat:.4f}")
    print(f"logistic: {acc_log:.4f}")

    # Save per-split CSV-like and summary JSON
    header = ['split','k_star','acc_unsup','f1_unsup','acc_semi','f1_semi','acc_feat','acc_log','acc_graph','pl_added','unsup_clf','unsup_emb','unsup_params','semi_clf','semi_emb','semi_params']
    lines = [','.join(header)]
    for i, r in enumerate(results):
        row = [
            str(i+1), str(r['k_star']), f"{r['acc_unsup']:.6f}", f"{r['f1_unsup']:.6f}", f"{r['acc_semi']:.6f}", f"{r['f1_semi']:.6f}",
            f"{r['acc_feat']:.6f}", f"{r['acc_log']:.6f}", f"{r['acc_graph']:.6f}", str(r.get('pl_added',0)),
            r.get('unsup_clf',''), r.get('unsup_emb',''), json.dumps(r.get('unsup_params',{})),
            r.get('semi_clf',''), r.get('semi_emb',''), json.dumps(r.get('semi_params',{}))
        ]
        lines.append(','.join(row))
    with open(os.path.join(exp_dir, 'results.csv'), 'w') as f:
        f.write('\n'.join(lines))

    summary = {
        'dataset': dataset,
        'method': method,
        'timestamp': timestamp,
        'seed': SEED,
        'mean_acc': {
            'affinity_unsup': float(acc_unsup),
            'affinity_semi': float(acc_semi),
            'feature_knn': float(acc_feat),
            'logistic': float(acc_log)
        },
        'splits': results
    }
    with open(os.path.join(exp_dir, 'summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    # Running time report
    times = {
        'dataset': dataset,
        'method': method,
        'timestamp': timestamp,
        'seed': SEED,
        'splits': [
            {
                'split': i+1,
                **r['timing']
            } for i, r in enumerate(results)
        ]
    }
    # Aggregate totals
    keys = ['unsup_train_s','semi_train_s','unsup_select_eval_s','semi_select_eval_s','baselines_eval_s','total_split_s']
    totals = {k: float(np.sum([r['timing'].get(k, 0.0) for r in results])) for k in keys}
    times['totals'] = totals
    times['overall_s'] = float(time.time() - overall_start)
    with open(os.path.join(exp_dir, 'running_time.json'), 'w') as f:
        json.dump(times, f, indent=2)


if __name__ == '__main__':
    main()
