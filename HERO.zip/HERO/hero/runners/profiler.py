"""Run the dataset profiler and save/print a profile report."""

import argparse
from datetime import datetime

from hero.paths import get_results_dir
from hero.profiler import DatasetProfiler


def _print_table(report: dict):
    rows = [
        ("n_nodes", report.get('n_nodes')),
        ("n_edges", report.get('n_edges')),
        ("density", f"{report.get('density'):.6f}"),
        ("avg_degree", f"{report.get('avg_degree'):.3f}"),
        ("train_fraction", f"{report.get('train_fraction'):.3f}"),
        ("edge_homophily_train", f"{report.get('edge_homophily_train'):.3f}"),
        ("node_homophily_train", f"{report.get('node_homophily_train'):.3f}"),
        ("adjusted_edge_homophily_train", f"{report.get('adjusted_edge_homophily_train'):.3f}"),
        ("label_informativeness_train", f"{report.get('label_informativeness_train'):.3f}"),
        ("feature_logistic_acc_val", f"{report.get('feature_logistic_acc_val'):.3f}"),
        ("feature_knn_acc_val", f"{report.get('feature_knn_acc_val'):.3f}"),
        ("graph_neighbor_acc_val", f"{report.get('graph_neighbor_acc_val'):.3f}"),
        ("delta_feature_vs_graph", f"{report.get('delta_feature_vs_graph'):.3f}"),
        ("delta_knn_vs_graph", f"{report.get('delta_knn_vs_graph'):.3f}"),
        ("recommended_module", report.get('recommended_module')),
        ("reason", report.get('recommendation_reason')),
    ]
    width = max(len(k) for k, _ in rows)
    for k, v in rows:
        print(f"{k.ljust(width)} : {v}")


def main():
    parser = argparse.ArgumentParser(description='HERO dataset profiler')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--print-table', action='store_true', help='Print a concise table to stdout')
    args = parser.parse_args()

    dataset = args.dataset
    tag = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')
    profiler = DatasetProfiler(results_root=get_results_dir())
    report = profiler.profile(dataset, tag)
    print("Profile saved:", f"results/{dataset}/profiler/{tag}/profile.json")
    print("Recommendation:", report.get('recommended_module'))
    if args.print_table:
        print()
        _print_table(report)


if __name__ == '__main__':
    main()
