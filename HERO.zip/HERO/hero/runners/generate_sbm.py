"""CLI utility to generate SBM synthetic graphs and cache them as datasets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from hero.core.dataset import DatasetLoader
from hero.data.synthetic import generate_sbm_dataset
from hero.paths import get_data_dir


def _parse_floats(value: str | None) -> np.ndarray | None:
    if value is None:
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    if not parts:
        return None
    return np.array([float(p) for p in parts], dtype=np.float64)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate an SBM synthetic dataset and cache it.")
    parser.add_argument("--name", default=None, help="Dataset name for cache (default: auto)")
    parser.add_argument("--num-nodes", type=int, default=10000)
    parser.add_argument("--num-classes", type=int, default=5)
    parser.add_argument("--feature-dim", type=int, default=128)
    parser.add_argument("--homophily", type=float, default=0.5)
    parser.add_argument("--avg-degree", type=float, default=10.0)
    parser.add_argument("--p-total", type=float, default=None)
    parser.add_argument("--p-in", type=float, default=None)
    parser.add_argument("--p-out", type=float, default=None)
    parser.add_argument("--feature-noise", type=float, default=1.0)
    parser.add_argument("--center-radius", type=float, default=1.0)
    parser.add_argument("--class-probs", type=str, default=None, help="Comma-separated class probabilities")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--self-loops", action="store_true")
    parser.add_argument("--directed", action="store_true")
    parser.add_argument("--dense-adjacency", action="store_true", help="Store dense adjacency matrix")
    parser.add_argument("--train-ratio", type=float, default=0.2)
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--num-splits", type=int, default=10)
    args = parser.parse_args()

    class_probs = _parse_floats(args.class_probs)
    if args.name:
        name = args.name
    else:
        name = f"sbm_c{args.num_classes}_h{args.homophily:.2f}_n{args.num_nodes}"
    name_lower = name.lower()

    synth = generate_sbm_dataset(
        num_nodes=args.num_nodes,
        num_classes=args.num_classes,
        feature_dim=args.feature_dim,
        homophily=args.homophily,
        avg_degree=args.avg_degree,
        p_total=args.p_total,
        p_in=args.p_in,
        p_out=args.p_out,
        class_probs=class_probs,
        feature_noise=args.feature_noise,
        center_radius=args.center_radius,
        seed=args.seed,
        self_loops=args.self_loops,
        directed=args.directed,
        dense_adjacency=args.dense_adjacency,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio,
        num_splits=args.num_splits,
    )

    DatasetLoader._store_disk_cache(name_lower, (  # pylint: disable=protected-access
        synth.features, synth.adjacency, synth.labels, synth.masks
    ))

    # Save metadata for reproducibility
    cache_dir = Path(get_data_dir()) / "_processed_cache"
    meta_path = cache_dir / f"{DatasetLoader._cache_key(name_lower)}_meta.json"  # pylint: disable=protected-access

    edge_index = synth.edge_index
    if edge_index.size:
        src, dst = edge_index
        same = (synth.labels[src] == synth.labels[dst]).mean()
        avg_deg = edge_index.shape[1] / max(1, args.num_nodes)
    else:
        same = 0.0
        avg_deg = 0.0

    meta = {
        "name": name_lower,
        "num_nodes": args.num_nodes,
        "num_classes": args.num_classes,
        "feature_dim": args.feature_dim,
        "homophily_target": args.homophily,
        "avg_degree_target": args.avg_degree,
        "p_total": args.p_total,
        "p_in": args.p_in,
        "p_out": args.p_out,
        "feature_noise": args.feature_noise,
        "center_radius": args.center_radius,
        "class_probs": class_probs.tolist() if class_probs is not None else None,
        "seed": args.seed,
        "directed": args.directed,
        "self_loops": args.self_loops,
        "dense_adjacency": args.dense_adjacency,
        "train_ratio": args.train_ratio,
        "val_ratio": args.val_ratio,
        "num_splits": args.num_splits,
        "actual_edge_homophily": float(same),
        "actual_avg_degree": float(avg_deg),
    }
    meta_path.write_text(json.dumps(meta, indent=2))

    print(f"✅ Cached synthetic dataset '{name_lower}' to {DatasetLoader._cache_path(name_lower)}")  # pylint: disable=protected-access
    print(f"   Meta: {meta_path}")
    print("Use with: --dataset", name_lower)


if __name__ == "__main__":
    main()
