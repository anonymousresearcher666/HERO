"""Modular experiment runner based on HeterophilyModule."""

import argparse
import json
import os
import sys
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any

def _canonical_device_name(device: str | None) -> str | None:
    if device is None:
        return None
    normalized = device.strip().lower()
    if normalized == "mpw":
        normalized = "mps"
    if normalized not in {"cpu", "cuda", "mps"}:
        raise ValueError("Device must be one of: cpu, mpw/mps, cuda")
    return normalized


def _bootstrap_device_override(argv: list[str]) -> None:
    if os.environ.get("HERO_DEVICE"):
        return
    for index, arg in enumerate(argv):
        if arg == "--device" and index + 1 < len(argv):
            normalized = _canonical_device_name(argv[index + 1])
            if normalized:
                os.environ["HERO_DEVICE"] = normalized
            return
        if arg.startswith("--device="):
            normalized = _canonical_device_name(arg.split("=", 1)[1])
            if normalized:
                os.environ["HERO_DEVICE"] = normalized
            return


_bootstrap_device_override(sys.argv)

from hero.modules import (
    HeterophilyModule,
    ProfileContrastiveModule,
    SpectralLabelPropagationModule,
    ProfilePseudoLabelModule,
    LabelGuidedRewiringModule,
    E2EHeroModule,
    NewHeroModule,
    HeroHPPRModule,
    LinkxModule,
    ACMModule,
    UniFilterModule,
    GWNModule,
    LGGNNModule,
    R2LPModule,
    EGGCNModule,
    HeterGPModule,
)
from hero.paths import get_results_dir, PROJECT_ROOT

_PARAM_GROUP_KEYS = ("architecture", "router", "losses", "training", "diagnostics", "autoadapt")


def run(module: HeterophilyModule, dataset: str, tag: str | None = None, cfg: dict | None = None):
    effective_tag = tag or datetime.now().strftime('%Y%m%d_%H%M%S')
    if cfg:
        tag_prefix = cfg.get('tag_prefix')
        if tag_prefix is None:
            tag_prefix = _resolve_param_groups(cfg.get('params') or {}).get('tag_prefix')
        if tag_prefix:
            effective_tag = f"{tag_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            if cfg is not None:
                cfg = dict(cfg)
                cfg['generated_tag'] = effective_tag
    out = module.run_dataset(dataset, effective_tag, cfg)
    print(f"Saved results to: {out['dir']}")
    return out


def _resolve_param_groups(raw_params: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(raw_params, dict):
        return {}
    merged: dict[str, Any] = {}
    for key, value in raw_params.items():
        if key in _PARAM_GROUP_KEYS and isinstance(value, dict):
            merged.update(value)
        else:
            merged[key] = value
    return merged


def _resolve_config_path(config_arg: str) -> Path:
    if not config_arg:
        raise FileNotFoundError('Config argument is empty')

    raw = Path(config_arg).expanduser()
    if raw.is_file():
        return raw.resolve()

    candidates: list[Path] = [raw]
    if not raw.suffix:
        candidates.insert(0, raw.with_suffix('.json'))

    for candidate in candidates:
        if candidate.is_absolute():
            if candidate.is_file():
                return candidate.resolve()
            continue

        parts = candidate.parts
        search_roots = [Path.cwd(), Path(PROJECT_ROOT)]
        if len(parts) == 1:
            search_roots.extend([
                Path(PROJECT_ROOT) / 'configs',
                Path(PROJECT_ROOT) / 'configs' / 'old',
            ])

        for base in search_roots:
            resolved = (base / candidate).resolve()
            if resolved.is_file():
                return resolved

    raise FileNotFoundError(
        f"Config file not found: {config_arg}."
        " Provide an absolute path or a name located under configs/ or configs/old/."
    )


def main():
    parser = argparse.ArgumentParser(description='HERO experiment runner')
    parser.add_argument('--config', default='configs/new_hero.json', help='JSON config for single- or multi-run')
    parser.add_argument('--dataset', nargs='+', default=None, help='Override dataset list')
    parser.add_argument('--module', nargs='+', default=None, help='Override module list')
    parser.add_argument('--tag', default=None, help='Run tag prefix (default: profile_run)')
    parser.add_argument('--device', default=None, choices=['cpu', 'mpw', 'mps', 'cuda'], help='Override device (cpu, mpw/mps, or cuda)')
    parser.add_argument('--no-plots', action='store_true', help='Disable plot generation')
    parser.add_argument('--tex', action='store_true', help='Export TikZ/LaTeX plots when possible')
    parser.add_argument('--config-dir', default='configs/', help='Directory containing JSON configs to run sequentially')
    args = parser.parse_args()
    args.device = _canonical_device_name(args.device)

    config_paths, base_dir = _collect_config_paths(args.config, args.config_dir)
    if base_dir is not None:
        print(f"[Runner] Directory mode: executing {len(config_paths)} configs from {base_dir}")
    else:
        print(f"[Runner] Single config mode: executing {config_paths[0]}")
    for idx, cfg_path in enumerate(config_paths, start=1):
        if base_dir is not None:
            print(f"[Runner] ({idx}/{len(config_paths)}) Executing config: {cfg_path}")
        else:
            print(f"[Runner] Executing config: {cfg_path}")
        _run_config(cfg_path, args)


def _collect_config_paths(config: str | None, config_dir: str | None) -> tuple[list[Path], Path | None]:
    if config_dir:
        raw = Path(config_dir).expanduser()
        candidates = [raw]
        if not raw.is_absolute():
            candidates.append((Path(PROJECT_ROOT) / raw).resolve())
        for base in candidates:
            if base.exists() and base.is_dir():
                configs = sorted(p.resolve() for p in base.iterdir() if p.suffix == '.json' and p.is_file())
                if not configs:
                    raise FileNotFoundError(f"No JSON configs found under {base}")
                return configs, base.resolve()
        raise FileNotFoundError(f"Config directory not found: {config_dir}")
    cfg_path = _resolve_config_path(config or 'configs/new_hero.json')
    return [cfg_path], None


def _run_config(cfg_path: Path, args: argparse.Namespace) -> None:
    with open(cfg_path, 'r') as f:
        cfg = json.load(f)
    _validate_config(cfg)

    base_params = _resolve_param_groups(cfg.get('params', {}))
    base_tag = args.tag or cfg.get('tag') or 'profile_run'

    run_specs: list[dict[str, Any]] = []

    if 'runs' in cfg:
        for entry in cfg['runs']:
            _validate_run(entry)
            dataset = entry.get('dataset')
            module_name = entry.get('module', cfg.get('module'))
            if not dataset or not module_name:
                raise ValueError('Each run entry must specify dataset and module')
            params = dict(base_params)
            params.update(_resolve_param_groups(entry.get('params', {})))
            if args.device:
                params['device'] = args.device
            tag = entry.get('tag', f"{base_tag}_{dataset}")
            run_specs.append({
                'dataset': dataset,
                'module': module_name,
                'tag': tag,
                'params': params,
            })
    else:
        datasets = args.dataset or cfg.get('batch', {}).get('datasets')
        if datasets is None and cfg.get('dataset'):
            datasets = [cfg['dataset']]
        if not datasets:
            raise ValueError('No datasets specified (use --dataset or batch.datasets in config)')

        modules = args.module or [cfg.get('module')]
        if modules is None or modules[0] is None:
            raise ValueError('No module specified (use --module or set "module" in config)')
        if len(modules) == 1 and len(datasets) > 1:
            modules = modules * len(datasets)
        if len(modules) != len(datasets):
            raise ValueError('Number of modules must match datasets or be 1')

        for dataset, module_name in zip(datasets, modules):
            params = dict(base_params)
            if args.device:
                params['device'] = args.device
            run_specs.append({
                'dataset': dataset,
                'module': module_name,
                'tag': f"{base_tag}_{dataset}",
                'params': params,
            })

    base_payload = deepcopy(cfg)
    base_payload.pop('runs', None)
    base_payload.pop('dataset', None)
    base_payload.pop('module', None)
    base_payload.pop('batch', None)

    for spec in run_specs:
        dataset = spec['dataset']
        module_name = spec['module']
        tag = spec['tag']
        params = deepcopy(spec['params'])

        print(f"[Runner] Launching {module_name} on {dataset} (tag={tag})")
        module = _make_module(module_name, params)

        payload = deepcopy(base_payload) if base_payload else {}
        payload['dataset'] = dataset
        payload['module'] = module_name
        payload['tag'] = tag
        payload['params'] = params

        if args.no_plots or args.tex:
            payload.setdefault('plots', {})
            if args.no_plots:
                payload['plots']['enable'] = False
            if args.tex:
                payload['plots']['save_tex'] = True

        run(module, dataset, tag, payload)


def _make_module(name: str, params: dict) -> HeterophilyModule:
    name = (name or '').lower()
    rr = get_results_dir()
    if name == 'profile_contrastive':
        # Map legacy affinity_dim -> profile_dim
        if 'affinity_dim' in params and 'profile_dim' not in params:
            params = dict(params, profile_dim=params['affinity_dim'])
        return ProfileContrastiveModule(results_root=rr, **{k: v for k, v in params.items() if k in {'profile_dim'}})
    if name == 'spectral_lp':
        return SpectralLabelPropagationModule(results_root=rr, **{k: v for k, v in params.items() if k in {'steps','alpha'}})
    if name == 'profile_pl':
        keys = {'profile_dim','conf_thr','per_class_cap','global_cap',
                'agreement','agree_conf_thr','pl_rounds','semi_label_weight','semi_contrastive_weight',
                'unsup_epochs','semi_epochs'}
        # Map legacy affinity_dim -> profile_dim
        if 'affinity_dim' in params and 'profile_dim' not in params:
            params = dict(params, profile_dim=params['affinity_dim'])
        return ProfilePseudoLabelModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'label_rewire':
        keys = {'pos_k','conf_thr','neg_drop','neg_sim_thr','affinity_dim'}
        return LabelGuidedRewiringModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'e2e_hero':
        keys = {
            'hidden_dim', 'prototype_count', 'dropout', 'epochs', 'lr', 'weight_decay',
            'structure_weight', 'pseudo_weight', 'smoothing_weight', 'entropy_weight',
            'propensity_weight', 'mix_uniform_weight', 'propensity_bias', 'propensity_floor',
            'device'
        }
        return E2EHeroModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'new_hero':
        keys = {
            'hidden_dim', 'prototype_count', 'ppr_alpha', 'ppr_steps', 'dropout',
            'epochs', 'lr', 'weight_decay', 'edge_weight',
            'pseudo_weight', 'smoothing_weight', 'value_weight',
            'experts_weight', 'gate_weight', 'gate_entropy_weight', 'ema_decay',
            'base_gate_weight', 'gate_prior_weight',
            'pseudo_confidence', 'device', 'profile', 'profile_epochs', 'profile_dir',
            'edge_neg_sample_ratio', 'edge_sample_ratio', 'eval_interval', 'val_patience', 'twohop_max_neighbors',
            'warmup_steps', 'ramp_steps', 'q_min', 'q_max',
            'tau_hi', 'tau_lo', 'entropy_mu_lr', 'entropy_target_delta',
            'proxy_ema_decay', 'knn_k', 'knn_anchor', 'knn_exact_max', 'compat_slope',
            'ripple_time_horizon', 'ripple_dt', 'ripple_init_residual', 'use_features',
            'gwn_time_horizon', 'gwn_dt', 'gwn_dropout', 'gwn_laplacian', 'gwn_method', 'gwn_init_residual',
            'force_expert',
            'acm_hidden_dim', 'acm_dropout', 'acm_structure_info', 'acm_variant', 'acm_init_layers_feat',
            'experts', 'auto_experts',
            'use_edge_loss', 'use_pseudo_loss', 'use_signed_consistency',
            'use_value_loss', 'use_gate_prior_loss', 'diagnostics',
            'gate_prior_mix_uniform',
            'autoadapt', 'autoadapt_check_every', 'autoadapt_warmup_epochs',
            'autoadapt_stagnation_patience', 'autoadapt_rollback',
            'autoadapt_rollback_patience', 'autoadapt_rollback_tolerance',
            'autoadapt_min_lr', 'autoadapt_max_lr',
            'autoadapt_min_pseudo_confidence', 'autoadapt_max_pseudo_confidence',
            'autoadapt_min_pseudo_weight', 'autoadapt_max_pseudo_weight',
            'autoadapt_min_smoothing_weight', 'autoadapt_max_smoothing_weight',
            'autoadapt_max_gate_weight', 'autoadapt_max_gate_prior_mix',
            'autoadapt_profile_init', 'autoadapt_allow_lr_updates',
            'autoadapt_allow_smoothing_updates', 'autoadapt_acceptance_margin',
            'profile_policy_auto',
        }
        filtered = {k: v for k, v in params.items() if k in keys}
        print(f"[Runner] new_hero params -> {filtered}")
        if 'auto_experts' in filtered:
            print(f"[Runner] auto_experts passed? {filtered['auto_experts']} ({type(filtered['auto_experts'])})")
        return NewHeroModule(results_root=rr, **filtered)
    if name == 'linkx':
        keys = {
            'hidden_dim', 'final_layers', 'dropout', 'lr', 'weight_decay',
            'epochs', 'patience', 'init_layers_adj', 'init_layers_feat',
            'inner_activation', 'inner_dropout', 'device'
        }
        return LinkxModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'acm':
        keys = {
            'hidden_dim', 'dropout', 'lr', 'weight_decay', 'epochs',
            'patience', 'structure_info', 'variant', 'init_layers_feat', 'device'
        }
        return ACMModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'unifilter':
        keys = {
            'hidden_dim', 'num_layers', 'mlp_dropout', 'comb_dropout',
            'mlp_lr', 'comb_lr', 'mlp_weight_decay', 'comb_weight_decay',
            'epochs', 'patience', 'K', 'tau', 'sole', 'plain', 'bias', 'device'
        }
        return UniFilterModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'gwn':
        keys = {
            'hidden_dim', 'time_horizon', 'dt', 'dropout', 'laplacian',
            'method', 'init_residual', 'epochs', 'patience', 'lr', 'weight_decay', 'device'
        }
        return GWNModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'lggnn':
        keys = {'hidden_dim', 'dropout', 'global_steps', 'epochs', 'patience', 'lr', 'weight_decay', 'device'}
        return LGGNNModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'r2lp':
        keys = {'steps', 'alpha', 'rounds', 'conf_thr', 'knn_k'}
        return R2LPModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'eggcn':
        keys = {'hidden_dim', 'dropout', 'edge_threshold', 'epochs', 'patience', 'lr', 'weight_decay', 'device'}
        return EGGCNModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'hetergp':
        keys = {
            'hidden_dim', 'dropout', 'epochs', 'patience', 'lr', 'weight_decay',
            'num_prompts', 'walk_length', 'walk_count', 'p_dfs', 'q_dfs',
            'tintra_homo', 'tintra_heter', 'tinter_homo', 'tinter_heter', 'device'
        }
        return HeterGPModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    if name == 'hero_hppr':
        keys = {
            'hidden_dim', 'prototype_count', 'temperature', 'hetero_gamma', 'restart_lambda',
            'hppr_iters', 'dropout', 'epochs', 'lr', 'weight_decay', 'edge_weight',
            'pseudo_weight', 'device'
        }
        return HeroHPPRModule(results_root=rr, **{k: v for k, v in params.items() if k in keys})
    raise ValueError(f"Unknown module: {name}")


def _validate_config(cfg: dict) -> None:
    if not isinstance(cfg, dict):
        raise ValueError('Config must be a JSON object')
    if 'runs' in cfg:
        if not isinstance(cfg['runs'], list):
            raise ValueError('Config.runs must be a list')
        for i, run in enumerate(cfg['runs']):
            if not isinstance(run, dict):
                raise ValueError(f'Config.runs[{i}] must be an object')
            _validate_run(run)
    else:
        if 'module' not in cfg:
            raise ValueError('Config must specify "module" when runs are not provided')
        has_dataset = 'dataset' in cfg
        has_batch = isinstance(cfg.get('batch'), dict) and cfg['batch'].get('datasets')
        if not has_dataset and not has_batch:
            raise ValueError('Config must include either "dataset" or "batch.datasets"')
        if not isinstance(cfg.get('params', {}), dict):
            raise ValueError('params must be an object when provided')


def _validate_run(run: dict) -> None:
    if 'dataset' not in run or 'module' not in run:
        raise ValueError('Each run must include dataset and module')
    if 'params' in run and not isinstance(run['params'], dict):
        raise ValueError('run.params must be an object')


if __name__ == '__main__':
    main()
