"""Optuna-based hyperparameter search for HERO modules.

This helper mirrors the JSON sweep config format used by ``new_hero_sweep``
and runs an Optuna study where each trial samples parameters from the same
definitions (base params + fixed overrides + grid search values).

Usage example::

    python -m hero.runners.new_hero_optuna \
        --config configs/new_hero_arxiv-year_grid.json \
        --trials 50 \
        --metric val_acc

The script expects ``optuna`` to be installed. Install via ``pip install optuna``
if needed.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import optuna
except ImportError as exc:  # pragma: no cover - make the dependency explicit
    raise RuntimeError(
        "Optuna is required for the Optuna sweep helper. Install it with `pip install optuna`."
    ) from exc

from hero.runners.experiment import _make_module, run as run_experiment
from hero.paths import get_results_dir


JsonDict = Dict[str, Any]


@dataclass
class TrialRecord:
    number: int
    tag: str
    params: JsonDict
    metric: float
    summary_path: Path
    exp_dir: Path


def load_config(path: Path) -> JsonDict:
    with path.open("r") as handle:
        return json.load(handle)


def sample_param(trial: optuna.Trial, name: str, spec: Any) -> Any:
    """Translate config entries into Optuna suggestions.

    Supports:
    - list/tuple of choices (categorical)
    - dict with ``choices``
    - dict with ``low``/``high`` (int/float), optional ``step`` and ``log``
    - scalar values treated as single-option categoricals
    """

    if isinstance(spec, (list, tuple)):
        choices = list(spec)
        if len(choices) == 1:
            return choices[0]
        return trial.suggest_categorical(name, choices)

    if isinstance(spec, dict):
        if "choices" in spec:
            choices = list(spec["choices"])
            if len(choices) == 1:
                return choices[0]
            return trial.suggest_categorical(name, choices)

        if "low" in spec and "high" in spec:
            low = spec["low"]
            high = spec["high"]
            step = spec.get("step")
            log = bool(spec.get("log", False))
            param_type = spec.get("type", "float")
            if param_type == "int":
                return trial.suggest_int(
                    name,
                    int(low),
                    int(high),
                    step=int(step) if step else 1,
                )
            return trial.suggest_float(
                name,
                float(low),
                float(high),
                step=float(step) if step else None,
                log=log,
            )

    # Fallback: treat as a fixed value via categorical with a single choice.
    return spec


def extract_metric(summary: JsonDict, metric: str) -> Optional[float]:
    mean_metrics = summary.get("mean", {})
    if metric in mean_metrics and mean_metrics[metric] is not None:
        return float(mean_metrics[metric])
    splits = summary.get("splits") or []
    for split in splits:
        metrics = (split or {}).get("metrics", {})
        if metric in metrics and metrics[metric] is not None:
            return float(metrics[metric])
    return None


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def run_optuna(config_path: Path, trials: int, metric: str, direction: str,
               study_name: Optional[str], storage: Optional[str],
               load_if_exists: bool, limit: Optional[int]) -> Dict[str, Any]:
    cfg = load_config(config_path)
    dataset = cfg.get("dataset") or "roman_empire"
    module_name = cfg.get("module") or "new_hero"
    sweep_cfg = cfg.get("sweep") or {}
    base_params = cfg.get("params") or {}
    fixed_params = sweep_cfg.get("fixed", {})
    grid = sweep_cfg.get("grid", {})
    tag_prefix = sweep_cfg.get("tag_prefix", "new_hero_optuna")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_prefix = f"{tag_prefix}_{timestamp}"

    study = optuna.create_study(
        direction=direction,
        study_name=study_name,
        storage=storage,
        load_if_exists=load_if_exists,
    )

    trial_records: List[TrialRecord] = []

    def objective(trial: optuna.Trial) -> float:
        if limit is not None and trial.number >= limit:
            raise optuna.exceptions.TrialPruned("Reached trial limit")

        trial_params: JsonDict = dict(base_params)
        trial_params.update(fixed_params)

        for key, spec in grid.items():
            trial_params[key] = sample_param(trial, key, spec)

        tag = f"{run_prefix}_{trial.number:03d}"

        try:
            module = _make_module(module_name, trial_params)
            result = run_experiment(module, dataset, tag, {
                "params": trial_params,
                "optuna": True,
            })
        except RuntimeError as exc:
            message = str(exc)
            if "Failed to load dataset" in message:
                raise optuna.exceptions.TrialPruned(message)
            raise

        exp_dir = Path(result["dir"])
        summary_path = exp_dir / "summary.json"
        if not summary_path.exists():
            raise FileNotFoundError(f"Missing summary at {summary_path}")

        with summary_path.open("r") as handle:
            summary = json.load(handle)

        score = extract_metric(summary, metric)
        if score is None:
            raise optuna.exceptions.TrialPruned(
                f"Metric '{metric}' not found in summary"
            )

        trial.set_user_attr("tag", tag)
        trial.set_user_attr("exp_dir", str(exp_dir))
        trial.set_user_attr("summary", str(summary_path))
        trial.set_user_attr("params", trial_params)
        trial.set_user_attr("metric_value", score)

        trial_records.append(
            TrialRecord(
                number=trial.number,
                tag=tag,
                params=trial_params,
                metric=score,
                summary_path=summary_path,
                exp_dir=exp_dir,
            )
        )

        return score

    study.optimize(objective, n_trials=trials, gc_after_trial=True)

    ranked = sorted(
        trial_records,
        key=lambda rec: rec.metric,
        reverse=(direction == "maximize"),
    )

    best_record = ranked[0] if ranked else None

    sweep_root = Path(get_results_dir()) / dataset / tag_prefix
    ensure_dir(sweep_root)
    report_path = sweep_root / f"optuna_summary_{timestamp}.json"

    report_payload = {
        "dataset": dataset,
        "module": module_name,
        "config": str(config_path),
        "timestamp": timestamp,
        "metric": metric,
        "direction": direction,
        "trials": [
            {
                "number": rec.number,
                "tag": rec.tag,
                "metric": rec.metric,
                "params": rec.params,
                "summary": str(rec.summary_path),
                "exp_dir": str(rec.exp_dir),
            }
            for rec in ranked
        ],
        "study": {
            "name": study.study_name,
            "best_value": study.best_value if study.best_trial else None,
            "best_trial": study.best_trial.number if study.best_trial else None,
        },
    }

    if best_record is not None:
        report_payload["best"] = {
            "number": best_record.number,
            "tag": best_record.tag,
            "metric": best_record.metric,
            "params": best_record.params,
            "summary": str(best_record.summary_path),
            "exp_dir": str(best_record.exp_dir),
        }

    with report_path.open("w") as handle:
        json.dump(report_payload, handle, indent=2)

    return {
        "report": str(report_path),
        "best": report_payload.get("best"),
        "study": report_payload["study"],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run an Optuna hyperparameter search using the sweep JSON format.")
    parser.add_argument(
        "--config",
        default="/Volumes/DATI/GitHub/HERO/configs/new_hero_roman_empire_grid.json",
        help="Path to the sweep config JSON file.",
    )
    parser.add_argument(
        "--metric",
        default="val_acc",
        help="Metric name to optimise (must exist in summary.json).",
    )
    parser.add_argument(
        "--trials",
        type=int,
        default=30,
        help="Number of Optuna trials to execute.",
    )
    parser.add_argument(
        "--direction",
        choices=["maximize", "minimize"],
        default="maximize",
        help="Optimisation direction for the metric.",
    )
    parser.add_argument(
        "--study-name",
        default=None,
        help="Optional study name (pass with --storage to reuse).",
    )
    parser.add_argument(
        "--storage",
        default=None,
        help="Optuna storage URL (e.g., sqlite:///optuna.db).",
    )
    parser.add_argument(
        "--load-if-exists",
        action="store_true",
        help="Reuse an existing study if the name/storage already exists.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional cap on trials evaluated in this run (useful when reusing a study).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = Path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")

    info = run_optuna(
        config_path=config_path,
        trials=args.trials,
        metric=args.metric,
        direction=args.direction,
        study_name=args.study_name,
        storage=args.storage,
        load_if_exists=args.load_if_exists,
        limit=args.limit,
    )

    print("\nOptuna summary saved to:", info["report"])
    if info.get("best"):
        print("Best trial:")
        print(json.dumps(info["best"], indent=2))


if __name__ == "__main__":
    main()
