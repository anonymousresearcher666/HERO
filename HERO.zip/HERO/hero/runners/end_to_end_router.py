"""End-to-end propagation router with learnable per-node gates."""

from __future__ import annotations

import argparse
import json
import math
import os
from datetime import datetime
from typing import Dict

import numpy as np
import torch

from hero.core.dataset import DatasetLoader
from hero.core.config import ExperimentConfig, DEVICE
from hero.core.model import ProfileModel
from hero.core.trainer import ProfileTrainer
from hero.paths import get_results_dir
from hero.utils.metrics import compute_standard_metrics


def _normalize(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


def _build_edge_index(A: np.ndarray) -> np.ndarray:
    return np.vstack(np.nonzero(A)).astype(np.int64)


def _normalize_adj(edge_index: np.ndarray, num_nodes: int) -> torch.sparse.Tensor:
    row = torch.from_numpy(edge_index[0]).long()
    col = torch.from_numpy(edge_index[1]).long()
    values = torch.ones(row.shape[0], dtype=torch.float32)
    adj = torch.sparse_coo_tensor(torch.stack([row, col]), values, (num_nodes, num_nodes))
    deg = torch.sparse.sum(adj, dim=1).to_dense()
    deg_inv_sqrt = torch.pow(deg + 1e-8, -0.5)
    deg_inv_sqrt[torch.isinf(deg_inv_sqrt)] = 0.0
    vals = deg_inv_sqrt[row] * values * deg_inv_sqrt[col]
    return torch.sparse_coo_tensor(torch.stack([row, col]), vals, (num_nodes, num_nodes))


class PropagationMixer(torch.nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, num_classes: int) -> None:
        super().__init__()
        self.classifier = torch.nn.Linear(in_dim, num_classes)
        self.gate = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim, 1),
        )

    def forward(self, Z: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logits = self.classifier(Z)
        alpha = torch.sigmoid(self.gate(Z)).clamp(0.0, 1.0)
        return logits, alpha


def appnp_smoothing(logits: torch.Tensor, norm_adj: torch.sparse.Tensor,
                    k: int = 10, teleport: float = 0.1) -> torch.Tensor:
    h = logits
    for _ in range(k):
        h = (1 - teleport) * torch.sparse.mm(norm_adj, h) + teleport * logits
    return h


def run(args: argparse.Namespace) -> Dict:
    X, A, y, masks = DatasetLoader.load_dataset(args.dataset)
    if X is None:
        raise RuntimeError(f"Failed to load dataset: {args.dataset}")
    n, d = X.shape
    train_mask = masks['train_mask'][:, 0] if masks['train_mask'].ndim == 2 else masks['train_mask']
    val_mask = masks.get('val_mask', train_mask)
    if getattr(val_mask, 'ndim', 1) == 2:
        val_mask = val_mask[:, 0]
    test_mask = masks['test_mask'][:, 0] if masks['test_mask'].ndim == 2 else masks['test_mask']

    edge_index = _build_edge_index(A)

    # Stage 1: label-free offer/request encoder
    overrides = {}
    if args.profile_dim:
        overrides['profile_dim'] = args.profile_dim
    profile_dim = int(overrides.get('profile_dim', 128))
    cfg = ExperimentConfig(
        datasets=['custom'],
        profile_dim=profile_dim,
        epochs=args.unsup_epochs,
        edge_loss_mode='paper',
        neg_ratio=0.5,
        hard_neg_frac=0.5,
        eic_temperature=0.2,
        balance_losses=True,
        edge_batch_size=1024,
        unsupervised=True,
        contrastive_weight=1.0,
        label_weight=0.0,
        strategy='contrastive_proto',
    )
    model = ProfileModel(n, d, cfg.affinity_dim, DEVICE)
    trainer = ProfileTrainer(model, cfg)
    trainer.train(X, A, y, train_mask)
    with torch.no_grad():
        ft = torch.tensor(X, dtype=torch.float32, device=DEVICE)
        q = model.proj_head(model.feature_projection(ft)).detach().cpu().numpy()
        r = model.profile_vectors.detach().cpu().numpy()
    qn = _normalize(q)
    rn = _normalize(r)
    Z = np.concatenate([qn, rn], axis=1)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    features = torch.tensor(Z, dtype=torch.float32, device=device)
    labels = torch.tensor(y, dtype=torch.long, device=device)
    mask_train = torch.tensor(train_mask, dtype=torch.bool, device=device)
    mask_val = torch.tensor(val_mask, dtype=torch.bool, device=device)
    mask_test = torch.tensor(test_mask, dtype=torch.bool, device=device)

    norm_adj = _normalize_adj(edge_index, n).coalesce().to(device)

    mixer = PropagationMixer(features.shape[1], args.hidden_dim, int(labels.max().item() + 1)).to(device)
    optimizer = torch.optim.Adam(mixer.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = torch.nn.CrossEntropyLoss()

    best_val = float('inf')
    best_state = None
    patience = args.patience
    patience_ctr = 0

    for epoch in range(args.epochs):
        mixer.train()
        optimizer.zero_grad()
        base_logits, alpha = mixer(features)
        smooth_logits = appnp_smoothing(base_logits, norm_adj, k=args.k_steps, teleport=args.teleport)
        mixed_logits = alpha * smooth_logits + (1 - alpha) * base_logits
        loss = criterion(mixed_logits[mask_train], labels[mask_train])
        loss.backward()
        optimizer.step()

        with torch.no_grad():
            mixer.eval()
            base_logits, alpha = mixer(features)
            smooth_logits = appnp_smoothing(base_logits, norm_adj, k=args.k_steps, teleport=args.teleport)
            mixed_logits = alpha * smooth_logits + (1 - alpha) * base_logits
            val_loss = criterion(mixed_logits[mask_val], labels[mask_val]).item()
        if val_loss < best_val - 1e-4:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in mixer.state_dict().items()}
            patience_ctr = 0
        else:
            patience_ctr += 1
            if patience_ctr >= patience:
                break

    if best_state is not None:
        mixer.load_state_dict({k: v.to(device) for k, v in best_state.items()})

    mixer.eval()
    with torch.no_grad():
        base_logits, alpha = mixer(features)
        smooth_logits = appnp_smoothing(base_logits, norm_adj, k=args.k_steps, teleport=args.teleport)
        mixed_logits = alpha * smooth_logits + (1 - alpha) * base_logits
        proba = torch.softmax(mixed_logits, dim=1).cpu().numpy()

    y_pred = np.argmax(proba, axis=1)
    metrics = compute_standard_metrics(y[test_mask], y_pred[test_mask], proba[test_mask])
    metrics['val_loss'] = best_val
    metrics['train_loss'] = float(loss.detach().cpu().item())
    alpha_stats = {
        'alpha_mean': float(alpha.mean().cpu().item()),
        'alpha_std': float(alpha.std().cpu().item()),
        'alpha_min': float(alpha.min().cpu().item()),
        'alpha_max': float(alpha.max().cpu().item()),
    }

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_dir = os.path.join(get_results_dir(), args.dataset, 'end_to_end', timestamp)
    os.makedirs(out_dir, exist_ok=True)
    payload = {
        'dataset': args.dataset,
        'metrics': metrics,
        'alpha_stats': alpha_stats,
        'config': vars(args),
    }
    with open(os.path.join(out_dir, 'summary.json'), 'w') as f:
        json.dump(payload, f, indent=2)
    np.save(os.path.join(out_dir, 'alpha.npy'), alpha.detach().cpu().numpy())
    np.save(os.path.join(out_dir, 'proba.npy'), proba)
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='End-to-end propagation router')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--profile-dim', type=int, default=128)
    parser.add_argument('--unsup-epochs', type=int, default=50)
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--lr', type=float, default=3e-3)
    parser.add_argument('--weight-decay', type=float, default=1e-4)
    parser.add_argument('--hidden-dim', type=int, default=256)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--k-steps', type=int, default=10)
    parser.add_argument('--teleport', type=float, default=0.1)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    result = run(args)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
