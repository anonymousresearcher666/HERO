"""Sweep runner for the new_hero module using JSON grid definitions."""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List

from hero.runners.experiment import run as run_experiment, _make_module
from hero.paths import get_results_dir


@dataclass
class SweepRun:
    tag: str
    params: Dict[str, Any]
    summary_path: Path
    metrics: Dict[str, float]
    exp_dir: Path


def _resolve_param_groups(raw_params: Dict[str, Any] | None) -> Dict[str, Any]:
    if not isinstance(raw_params, dict):
        return {}
    grouped_keys = {"architecture", "router", "losses", "training", "diagnostics", "autoadapt"}
    merged: Dict[str, Any] = {}
    for key, value in raw_params.items():
        if key in grouped_keys and isinstance(value, dict):
            merged.update(value)
        else:
            merged[key] = value
    return merged


def load_config(config_path: Path) -> Dict[str, Any]:
    with config_path.open('r') as f:
        return json.load(f)


def expand_grid(base: Dict[str, Any], fixed: Dict[str, Any], grid: Dict[str, Iterable[Any]]) -> Iterable[Dict[str, Any]]:
    keys = list(grid.keys())
    values = [list(grid[k]) for k in keys]
    if not keys:
        yield {**base, **fixed}
        return
    for combo in itertools.product(*values):
        overrides = {k: v for k, v in zip(keys, combo)}
        params = dict(base)
        params.update(fixed)
        params.update(overrides)
        yield params


def run_sweep(config_path: Path, limit: int | None = None, dataset_override: str | None = None) -> Dict[str, Any]:
    cfg = load_config(config_path)
    dataset = dataset_override or cfg.get('dataset') or 'roman_empire'
    module_name = cfg.get('module') or 'new_hero'
    sweep_cfg = cfg.get('sweep') or {}
    base_params = _resolve_param_groups(cfg.get('params') or {})
    fixed_params = _resolve_param_groups(sweep_cfg.get('fixed', {}))
    grid = sweep_cfg.get('grid', {})
    tag_prefix = sweep_cfg.get('tag_prefix', 'new_hero_sweep')

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    sweep_id = f"{tag_prefix}_{timestamp}"

    results: List[SweepRun] = []
    combos = expand_grid(base_params, fixed_params, grid)

    for idx, params in enumerate(combos, start=1):
        if limit is not None and idx > limit:
            break
        tag = f"{sweep_id}_{idx:03d}"
        module = _make_module(module_name, params)
        try:
            out = run_experiment(module, dataset, tag, {'params': params, 'sweep': True})
        except RuntimeError as exc:
            msg = str(exc)
            if 'Failed to load dataset' in msg or 'arxiv-year' in msg:
                print(f"⚠️ Skipping {tag}: {msg}")
                continue
            raise
        exp_dir = Path(out['dir'])
        summary_path = exp_dir / 'summary.json'
        if not summary_path.exists():
            raise FileNotFoundError(f"Missing summary at {summary_path}")
        with summary_path.open('r') as f:
            summary = json.load(f)
        # Prefer aggregate mean metrics over a single split.
        metrics = summary.get('mean', {}) or {}
        results.append(SweepRun(tag=tag, params=params, summary_path=summary_path, metrics=metrics, exp_dir=exp_dir))

    if not results:
        raise RuntimeError(f'No sweep runs executed. Dataset {dataset} may be unavailable or all jobs failed.')

    def rank_key(run: SweepRun):
        m = run.metrics or {}
        if dataset in {"roman_empire", "amazon_ratings"}:
            primary = m.get("test_acc")
        else:
            primary = m.get("test_roc_auc")
        if primary is None:
            primary = m.get("test_acc", 0.0)
        return (-float(primary or 0.0), -(m.get("test_f1") or 0.0))

    ranked = sorted(results, key=rank_key)
    best = ranked[0]

    sweep_root = Path(get_results_dir()) / dataset / tag_prefix
    sweep_root.mkdir(parents=True, exist_ok=True)
    report_path = sweep_root / f'sweep_summary_{timestamp}.json'

    report = {
        'dataset': dataset,
        'module': module_name,
        'config': str(config_path),
        'timestamp': timestamp,
        'runs': [
            {
                'tag': r.tag,
                'params': r.params,
                'metrics': r.metrics,
                'summary': str(r.summary_path),
                'exp_dir': str(r.exp_dir),
            }
            for r in ranked
        ],
        'best': {
            'tag': best.tag,
            'params': best.params,
            'metrics': best.metrics,
            'summary': str(best.summary_path),
            'exp_dir': str(best.exp_dir),
        },
    }

    with report_path.open('w') as f:
        json.dump(report, f, indent=2)

    return {'report': str(report_path), 'best': report['best']}


def main() -> None:
    parser = argparse.ArgumentParser(description='Run a grid sweep for new_hero based on a JSON config.')
    parser.add_argument('--config', default='/Volumes/DATI/GitHub/HERO/configs/new_hero_roman_empire_best.json', help='Path to sweep config JSON.')
    parser.add_argument('--limit', type=int, default=None, help='Optional cap on number of grid combinations to run.')
    args = parser.parse_args()
    config_path = Path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f'Config not found: {config_path}')
    cfg = load_config(config_path)
    datasets = cfg.get('datasets')
    if isinstance(datasets, list) and datasets:
        infos = []
        for ds in datasets:
            info = run_sweep(config_path, limit=args.limit, dataset_override=str(ds))
            infos.append(info)
            print('\nSweep summary saved to:', info['report'])
            print('Best run:')
            print(json.dumps(info['best'], indent=2))
    else:
        info = run_sweep(config_path, limit=args.limit)
        print('\nSweep summary saved to:', info['report'])
        print('Best run:')
        print(json.dumps(info['best'], indent=2))


if __name__ == '__main__':
    main()
