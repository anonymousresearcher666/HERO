import argparse
import json
import os
from datetime import datetime


def _import_local_router():
    try:
        # Absolute import (works with -m)
        from hero.runners.local_router import local_router  # type: ignore
        return local_router
    except Exception:  # pragma: no cover
        # Fallback to relative
        from .local_router import local_router  # type: ignore
        return local_router


def run_sweep(dataset: str, Ks, betas, quick: bool = True):
    local_router = _import_local_router()
    results = []
    for K in Ks:
        for beta in betas:
            try:
                out = local_router(dataset, K=K, beta=beta, quick=quick)
                # local_router returns (out, rn, clusters, centroids)
                if isinstance(out, tuple):
                    summary = out[0]
                else:
                    summary = out
                acc = float(summary.get('metrics', {}).get('acc', 0.0))
                f1 = float(summary.get('metrics', {}).get('f1', 0.0))
                regimes = summary.get('regimes', [])
                results.append({
                    'K': K,
                    'beta': beta,
                    'acc': acc,
                    'f1': f1,
                    'regimes': regimes,
                    'diagnostics': summary.get('diagnostics', []),
                })
                print(f"K={K}, beta={beta} -> acc={acc:.4f}, f1={f1:.4f}")
            except Exception as e:
                print(f"K={K}, beta={beta} -> error: {e}")
    # Pick best by accuracy then f1
    results_sorted = sorted(results, key=lambda x: (-x['acc'], -x['f1']))
    best = results_sorted[0] if results_sorted else None
    return {'dataset': dataset, 'quick': quick, 'grid': results, 'best': best}


def main():
    parser = argparse.ArgumentParser(description='Sweep local router over K and beta, report blended accuracy and regimes')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--Ks', default='4,5,6', help='Comma-separated Ks (e.g., 4,5,6)')
    parser.add_argument('--betas', default='5.0,7.5', help='Comma-separated betas (e.g., 3.0,5.0,7.5)')
    parser.add_argument('--quick', action='store_true', help='Reduced epochs for faster sweep')
    args = parser.parse_args()

    # Support symbolic Ks with L (number of labels), e.g., 'L', 'L-6', 'L+6'
    raw_Ks = [k.strip() for k in args.Ks.split(',') if k.strip()]
    Ks = []
    if any('L' in k for k in raw_Ks):
        # Load dataset to get number of classes
        try:
            from hero.core.dataset import DatasetLoader
            X, A, y, masks = DatasetLoader.load_dataset(args.dataset)
            C = int(y.max() + 1)
        except Exception:
            C = None
        for token in raw_Ks:
            if 'L' in token and C is not None:
                try:
                    expr = token.replace('L', str(C))
                    Ks.append(int(eval(expr)))
                except Exception:
                    pass
            else:
                try:
                    Ks.append(int(token))
                except Exception:
                    pass
        Ks = [k for k in Ks if k and k > 1]
    else:
        Ks = [int(k) for k in raw_Ks]
    betas = [float(b.strip()) for b in args.betas.split(',') if b.strip()]

    sweep = run_sweep(args.dataset, Ks, betas, quick=args.quick)
    # Save under results/<dataset>/local_router/sweep_<ts>.json
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    base_dir = os.path.join('results', args.dataset, 'local_router')
    os.makedirs(base_dir, exist_ok=True)
    out_path = os.path.join(base_dir, f'sweep_{ts}.json')
    with open(out_path, 'w') as f:
        json.dump(sweep, f, indent=2)
    print('\nBest configuration:')
    print(json.dumps(sweep.get('best', {}), indent=2))
    print('Saved sweep summary to:', out_path)


if __name__ == '__main__':
    main()
