"""
Generic Affinity Computation Framework
Supports multiple model types and training strategies
"""

import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any, Optional, List

import numpy as np
import pandas as pd

from hero.calculators import homophily as homophily_calculator

try:
    import mlx.core as mx
    import mlx.nn as nn
    from mlx.optimizers import AdamW, SGD, Adam
except Exception as e:
    raise ImportError("MLX backend requires the `mlx` package") from e

from hero.utils import set_seeds, get_params
from hero.data.torch_loader import load_torch_dataset


@dataclass
class ModelConfig:
    """Configuration for different affinity models."""
    model_type: str = "basic"  # basic, multi_head, hierarchical, graph_aware, learnable_sim
    num_heads: int = 8
    head_dim: Optional[int] = None
    scales: List[int] = None
    structure_weight: float = 0.3
    similarity_type: str = "cosine"  # cosine, mlp, bilinear

    def __post_init__(self):
        if self.scales is None:
            self.scales = [1, 2, 4]


@dataclass
class TrainingConfig:
    """Configuration for training strategies."""
    loss_type: str = "bpr"  # bpr, infonce, margin
    negative_sampling: str = "random"  # random, hard, mixed
    optimizer_type: str = "adamw"  # adamw, adam, sgd
    lr: float = 1e-3
    weight_decay: float = 1e-4
    epochs: int = 100
    num_negatives: int = 5
    eval_every: int = 10
    curriculum_learning: bool = False
    curriculum_stages: int = 3
    batch_size: Optional[int] = None
    temperature: float = 0.1  # For InfoNCE loss

    # Early stopping parameters
    early_stopping: bool = True
    patience: int = 10
    min_delta: float = 1e-4
    monitor_metric: str = "loss"  # "loss" or "affinity"


@dataclass
class ExperimentConfig:
    """Configuration for the entire experiment."""
    model_config: ModelConfig
    training_config: TrainingConfig
    datasets: List[str]
    root: str = "."
    data_folder: str = "data"
    seed: int = 13
    save_results: bool = True
    compute_comparisons: bool = False


class BaseAffinityModel(nn.Module, ABC):
    """Abstract base class for all affinity models."""

    def __init__(self, features: mx.array):
        super().__init__()
        self._features = features
        self.n, self.d = features.shape

    @abstractmethod
    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        """Compute affinity scores between nodes."""
        pass

    @abstractmethod
    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        """Compute self-affinity for all nodes."""
        pass


class BasicAffinityModel(BaseAffinityModel):
    """Basic single-vector affinity model."""

    def __init__(self, features: mx.array):
        super().__init__(features)
        self.affinity = mx.random.normal(shape=(self.n, self.d)) * 0.02

    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        f = self._features[i_idx]
        a = self.affinity[j_idx]
        eps = 1e-12
        f = f / (mx.linalg.norm(f, axis=1, keepdims=True) + eps)
        a = a / (mx.linalg.norm(a, axis=1, keepdims=True) + eps)
        s = mx.sum(f * a, axis=1)
        return 0.5 * (s + 1.0) if scaled else s

    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        idx = mx.arange(self.n)
        return self.cosine(idx, idx, scaled=scaled)


class MultiHeadAffinityModel(BaseAffinityModel):
    """Multi-head affinity model."""

    def __init__(self, features: mx.array, num_heads: int = 8, head_dim: Optional[int] = None):
        super().__init__(features)
        self.num_heads = num_heads
        self.head_dim = head_dim or self.d // num_heads

        # Multiple affinity vectors per node
        self.affinity_heads = mx.random.normal(shape=(num_heads, self.n, self.head_dim)) * 0.02
        self.head_weights = mx.random.normal(shape=(num_heads,)) * 0.1

        # Feature projections for each head
        self.feature_projections = []
        for _ in range(num_heads):
            self.feature_projections.append(
                mx.random.normal(shape=(self.d, self.head_dim)) * 0.02
            )

    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        f = self._features[i_idx]
        head_scores = []

        for h in range(self.num_heads):
            # Project features for this head
            f_proj = mx.matmul(f, self.feature_projections[h])
            a_h = self.affinity_heads[h][j_idx]

            # Cosine similarity for this head
            eps = 1e-12
            f_norm = f_proj / (mx.linalg.norm(f_proj, axis=1, keepdims=True) + eps)
            a_norm = a_h / (mx.linalg.norm(a_h, axis=1, keepdims=True) + eps)

            cos_sim = mx.sum(f_norm * a_norm, axis=1)
            head_scores.append(cos_sim)

        # Weighted combination of heads
        head_scores = mx.stack(head_scores, axis=0)
        weights = mx.softmax(self.head_weights, axis=0).reshape(-1, 1)

        combined_score = mx.sum(weights * head_scores, axis=0)
        return 0.5 * (combined_score + 1.0) if scaled else combined_score

    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        idx = mx.arange(self.n)
        return self.cosine(idx, idx, scaled=scaled)


class HierarchicalAffinityModel(BaseAffinityModel):
    """Multi-scale hierarchical affinity model."""

    def __init__(self, features: mx.array, scales: List[int] = [1, 2, 4]):
        super().__init__(features)
        self.scales = scales

        # Affinity at different scales
        self.affinity_scales = {}
        self.scale_weights = {}
        self.feature_transforms = {}

        for scale in scales:
            scale_dim = max(self.d // scale, 16)
            self.affinity_scales[scale] = mx.random.normal(shape=(self.n, scale_dim)) * 0.02
            self.scale_weights[scale] = mx.random.normal(shape=(1,)) * 0.1
            self.feature_transforms[scale] = mx.random.normal(shape=(self.d, scale_dim)) * 0.02

    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        f = self._features[i_idx]
        scale_scores = []

        for scale in self.scales:
            # Transform features for this scale
            f_transform = mx.matmul(f, self.feature_transforms[scale])
            a_scale = self.affinity_scales[scale][j_idx]

            # Cosine similarity at this scale
            eps = 1e-12
            f_norm = f_transform / (mx.linalg.norm(f_transform, axis=1, keepdims=True) + eps)
            a_norm = a_scale / (mx.linalg.norm(a_scale, axis=1, keepdims=True) + eps)

            cos_sim = mx.sum(f_norm * a_norm, axis=1)
            weighted_sim = self.scale_weights[scale] * cos_sim
            scale_scores.append(weighted_sim)

        # Combine scales
        combined_score = mx.sum(mx.stack(scale_scores), axis=0)
        return 0.5 * (combined_score + 1.0) if scaled else combined_score

    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        idx = mx.arange(self.n)
        return self.cosine(idx, idx, scaled=scaled)


class LearnableSimilarityModel(BaseAffinityModel):
    """Model with learnable similarity functions."""

    def __init__(self, features: mx.array, similarity_type: str = "mlp"):
        super().__init__(features)
        self.similarity_type = similarity_type
        self.affinity = mx.random.normal(shape=(self.n, self.d)) * 0.02

        if similarity_type == "mlp":
            self.sim_mlp_w1 = mx.random.normal(shape=(self.d*2, self.d)) * 0.02
            self.sim_mlp_w2 = mx.random.normal(shape=(self.d, 1)) * 0.02
        elif similarity_type == "bilinear":
            self.bilinear_matrix = mx.random.normal(shape=(self.d, self.d)) * 0.02

    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        f = self._features[i_idx]
        a = self.affinity[j_idx]

        if self.similarity_type == "mlp":
            concat_features = mx.concatenate([f, a], axis=1)
            hidden = mx.tanh(mx.matmul(concat_features, self.sim_mlp_w1))
            similarity = mx.matmul(hidden, self.sim_mlp_w2).flatten()
        elif self.similarity_type == "bilinear":
            similarity = mx.sum(f * mx.matmul(a, self.bilinear_matrix.T), axis=1)
        else:  # fallback to cosine
            eps = 1e-12
            f = f / (mx.linalg.norm(f, axis=1, keepdims=True) + eps)
            a = a / (mx.linalg.norm(a, axis=1, keepdims=True) + eps)
            similarity = mx.sum(f * a, axis=1)

        return mx.sigmoid(similarity) if scaled else similarity

    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        idx = mx.arange(self.n)
        return self.cosine(idx, idx, scaled=scaled)


class ModelFactory:
    """Factory for creating different types of affinity models."""

    @staticmethod
    def create_model(features: mx.array, config: ModelConfig) -> BaseAffinityModel:
        """Create an affinity model based on configuration."""
        if config.model_type == "basic":
            return BasicAffinityModel(features)
        elif config.model_type == "multi_head":
            return MultiHeadAffinityModel(features, config.num_heads, config.head_dim)
        elif config.model_type == "hierarchical":
            return HierarchicalAffinityModel(features, config.scales)
        elif config.model_type == "learnable_sim":
            return LearnableSimilarityModel(features, config.similarity_type)
        else:
            raise ValueError(f"Unknown model type: {config.model_type}")


class EarlyStopping:
    """Early stopping utility class."""

    def __init__(self, patience: int = 10, min_delta: float = 1e-4, monitor: str = "loss"):
        self.patience = patience
        self.min_delta = min_delta
        self.monitor = monitor
        self.wait = 0
        self.best_score = None
        self.should_stop = False
        self.best_epoch = 0

    def __call__(self, current_score: float, epoch: int) -> bool:
        """Check if training should stop early."""
        if self.best_score is None:
            self.best_score = current_score
            self.best_epoch = epoch
            return False

        # For loss, lower is better; for affinity, higher is better
        if self.monitor == "loss":
            improved = (self.best_score - current_score) > self.min_delta
        else:  # affinity or other metrics where higher is better
            improved = (current_score - self.best_score) > self.min_delta

        if improved:
            self.best_score = current_score
            self.best_epoch = epoch
            self.wait = 0
        else:
            self.wait += 1

        if self.wait >= self.patience:
            self.should_stop = True
            return True

        return False

    def get_info(self) -> dict:
        """Get early stopping information."""
        return {
            'best_score': self.best_score,
            'best_epoch': self.best_epoch,
            'stopped_early': self.should_stop,
            'patience_used': self.wait
        }


class GenericAffinityTrainer:
    """Generic trainer that works with any affinity model."""

    def __init__(self, model: BaseAffinityModel, config: TrainingConfig):
        self.model = model
        self.config = config
        self.optimizer = self._create_optimizer()
        self.loss_history = []
        self.affinity_history = []
        self.early_stopping = None
        if config.early_stopping:
            self.early_stopping = EarlyStopping(
                patience=config.patience,
                min_delta=config.min_delta,
                monitor=config.monitor_metric
            )

    def _create_optimizer(self):
        """Create optimizer based on configuration."""
        if self.config.optimizer_type == "adamw":
            return AdamW(learning_rate=self.config.lr, weight_decay=self.config.weight_decay)
        elif self.config.optimizer_type == "adam":
            return Adam(learning_rate=self.config.lr)
        elif self.config.optimizer_type == "sgd":
            return SGD(learning_rate=self.config.lr)
        else:
            raise ValueError(f"Unknown optimizer: {self.config.optimizer_type}")

    def _compute_loss(self, pos_scores: mx.array, neg_scores: mx.array) -> mx.array:
        """Compute loss based on configuration."""
        if self.config.loss_type == "bpr":
            return mx.mean(nn.softplus(neg_scores - pos_scores))
        elif self.config.loss_type == "infonce":
            pos_scores = pos_scores / self.config.temperature
            neg_scores = neg_scores / self.config.temperature
            all_scores = mx.concatenate([pos_scores.reshape(-1, 1), neg_scores.reshape(-1, 1)], axis=1)
            # MLX: log_softmax is provided under nn, not core
            log_probs = nn.log_softmax(all_scores, axis=1)
            return -mx.mean(log_probs[:, 0])
        elif self.config.loss_type == "margin":
            margin = 0.5
            return mx.mean(mx.maximum(0.0, margin - (pos_scores - neg_scores)))
        else:
            raise ValueError(f"Unknown loss type: {self.config.loss_type}")

    def sample_negatives(self, edge_data: mx.array, num_negatives: int, rng) -> mx.array:
        """Sample negative pairs based on strategy."""
        num_edges = edge_data.shape[0]

        if self.config.negative_sampling == "random":
            neg_pairs = []
            for _ in range(num_negatives):
                i_neg = rng.integers(0, self.model.n, size=num_edges)
                j_neg = rng.integers(0, self.model.n, size=num_edges)
                neg_pairs.append(mx.stack([mx.array(i_neg), mx.array(j_neg)], axis=1))
            return mx.stack(neg_pairs, axis=0)
        else:
            # Could implement hard negative sampling here
            return self._random_negative_sampling(edge_data, num_negatives, rng)

    def _random_negative_sampling(self, edge_data: mx.array, num_negatives: int, rng) -> mx.array:
        """Random negative sampling."""
        num_edges = edge_data.shape[0]
        neg_pairs = []
        for _ in range(num_negatives):
            i_neg = rng.integers(0, self.model.n, size=num_edges)
            j_neg = rng.integers(0, self.model.n, size=num_edges)
            neg_pairs.append(mx.stack([mx.array(i_neg), mx.array(j_neg)], axis=1))
        return mx.stack(neg_pairs, axis=0)

    def train_step(self, edge_data: mx.array, rng=None) -> float:
        """Single training step."""
        if rng is None:
            rng = np.random.default_rng()

        # Positive pairs
        i_pos = edge_data[:, 0]
        j_pos = edge_data[:, 1]
        pos_scores = self.model.cosine(i_pos, j_pos, scaled=True)

        # Negative pairs
        neg_pairs = self.sample_negatives(edge_data, self.config.num_negatives, rng)
        neg_scores_list = []

        for k in range(self.config.num_negatives):
            i_neg = neg_pairs[k, :, 0]
            j_neg = neg_pairs[k, :, 1]
            neg_scores_list.append(self.model.cosine(i_neg, j_neg, scaled=True))

        neg_scores = mx.mean(mx.stack(neg_scores_list), axis=0)

        # Compute loss and gradients
        def loss_fn(model):
            pos_pred = model.cosine(i_pos, j_pos, scaled=True)
            return self._compute_loss(pos_pred, neg_scores)

        loss_val, grads = nn.value_and_grad(self.model, loss_fn)(self.model)
        self.optimizer.update(self.model, grads)
        mx.eval(self.model.parameters(), self.optimizer.state)

        return float(loss_val.item())

    def train(self, X: mx.array, edge_data: mx.array, rng=None) -> tuple:
        """Train the model."""
        print(f"Training {self.config.__class__.__name__} model for {self.config.epochs} epochs...")

        if self.config.curriculum_learning:
            return self._curriculum_train(X, edge_data, rng)
        else:
            return self._standard_train(X, edge_data, rng)

    def _standard_train(self, X: mx.array, edge_data: mx.array, rng=None) -> tuple:
        """Standard training loop with early stopping."""
        print(f"Training with early stopping: {self.config.early_stopping}")
        if self.config.early_stopping:
            print(f"  Patience: {self.config.patience}, Monitor: {self.config.monitor_metric}")

        for epoch in range(1, self.config.epochs + 1):
            loss = self.train_step(edge_data, rng)
            self.loss_history.append(loss)

            if epoch % self.config.eval_every == 0:
                affinity_score = self.get_affinity_score()
                self.affinity_history.append(affinity_score)

                # Check early stopping
                if self.early_stopping:
                    monitor_value = loss if self.config.monitor_metric == "loss" else affinity_score
                    should_stop = self.early_stopping(monitor_value, epoch)

                    print(f"Epoch {epoch:3d} | Loss: {loss:.4f} | Affinity: {affinity_score:.4f} | "
                          f"Best {self.config.monitor_metric}: {self.early_stopping.best_score:.4f} "
                          f"(wait: {self.early_stopping.wait}/{self.early_stopping.patience})")

                    if should_stop:
                        print(f"Early stopping triggered at epoch {epoch}")
                        print(f"Best {self.config.monitor_metric}: {self.early_stopping.best_score:.4f} "
                              f"at epoch {self.early_stopping.best_epoch}")
                        break
                else:
                    print(f"Epoch {epoch:3d} | Loss: {loss:.4f} | Affinity: {affinity_score:.4f}")

            # Log loss even on non-evaluation epochs for early stopping
            elif self.early_stopping and self.config.monitor_metric == "loss":
                monitor_value = loss
                should_stop = self.early_stopping(monitor_value, epoch)
                if should_stop:
                    print(f"Early stopping triggered at epoch {epoch} (loss monitoring)")
                    break

        return self.loss_history, self.affinity_history

    def _curriculum_train(self, X: mx.array, edge_data: mx.array, rng=None) -> tuple:
        """Curriculum learning training with early stopping."""
        stage_epochs = self.config.epochs // self.config.curriculum_stages

        # Initialize early stopping for curriculum learning
        curriculum_early_stopping = None
        if self.config.early_stopping:
            curriculum_early_stopping = EarlyStopping(
                patience=max(3, self.config.patience // 2),  # Shorter patience per stage
                min_delta=self.config.min_delta,
                monitor=self.config.monitor_metric
            )

        for stage in range(self.config.curriculum_stages):
            print(f"Curriculum stage {stage + 1}/{self.config.curriculum_stages}")

            # Increase difficulty each stage
            old_negatives = self.config.num_negatives
            self.config.num_negatives = 1 + stage * 2

            stage_stopped_early = False
            for epoch in range(stage_epochs):
                global_epoch = stage * stage_epochs + epoch + 1
                loss = self.train_step(edge_data, rng)
                self.loss_history.append(loss)

                eval_freq = max(1, stage_epochs // 5)
                if epoch % eval_freq == 0:
                    affinity_score = self.get_affinity_score()
                    self.affinity_history.append(affinity_score)

                    # Check early stopping for this stage
                    if curriculum_early_stopping:
                        monitor_value = loss if self.config.monitor_metric == "loss" else affinity_score
                        should_stop = curriculum_early_stopping(monitor_value, global_epoch)

                        print(f"  Stage {stage+1}, Epoch {epoch}: Loss {loss:.4f}, Affinity: {affinity_score:.4f} "
                              f"(wait: {curriculum_early_stopping.wait})")

                        if should_stop:
                            print(f"  Early stopping in stage {stage+1} at epoch {epoch}")
                            stage_stopped_early = True
                            break
                    else:
                        print(f"  Stage {stage+1}, Epoch {epoch}: Loss {loss:.4f}, Affinity: {affinity_score:.4f}")

                # Check loss-based early stopping even on non-eval epochs
                elif curriculum_early_stopping and self.config.monitor_metric == "loss":
                    monitor_value = loss
                    should_stop = curriculum_early_stopping(monitor_value, global_epoch)
                    if should_stop:
                        print(f"  Early stopping in stage {stage+1} at epoch {epoch} (loss monitoring)")
                        stage_stopped_early = True
                        break

            # Restore original setting
            self.config.num_negatives = old_negatives

            # If we stopped early in this stage, break from curriculum
            if stage_stopped_early:
                print(f"Curriculum learning stopped early at stage {stage+1}")
                break

        return self.loss_history, self.affinity_history

    def get_affinity_score(self) -> float:
        """Compute affinity-based homophily score."""
        self_affinity = self.model.full_self_affinity(scaled=True)
        return float(mx.mean(self_affinity).item())

    def get_training_info(self) -> dict:
        """Get comprehensive training information."""
        info = {
            'total_epochs': len(self.loss_history),
            'final_loss': self.loss_history[-1] if self.loss_history else None,
            'final_affinity': self.affinity_history[-1] if self.affinity_history else None,
            'loss_history': self.loss_history,
            'affinity_history': self.affinity_history
        }

        if self.early_stopping:
            info.update(self.early_stopping.get_info())

        return info


class AffinityExperiment:
    """Main experiment class that orchestrates everything."""

    def __init__(self, config: ExperimentConfig):
        self.config = config
        self.results_df = None
        self.problem_datasets = []
        self._setup_environment()

    def _setup_environment(self):
        """Setup directories and random seeds."""
        set_seeds(self.config.seed)
        self.rng = np.random.default_rng(self.config.seed)

        self.results_folder = f"{self.config.root}/results/"
        os.makedirs(self.results_folder, exist_ok=True)
        os.makedirs(f"{self.results_folder}hist", exist_ok=True)
        os.makedirs(f"{self.results_folder}aff_plots", exist_ok=True)

        # Create model-specific results filename
        model_type = self.config.model_config.model_type
        self.results_filename = f"{model_type}_results.csv"
        self.results_path = os.path.join(self.results_folder, self.results_filename)

        # Load or create results DataFrame
        result_cols = [
            'dataset', 'nodes', 'features', 'classes', 'directed', 'model_type',
            'emb_ratio', 'max_nodes', 'k', 'init_lr', 'lr_decay', 'epochs',
            'actual_epochs', 'early_stopped', 'best_epoch', 'best_score',
            'node_homophily', 'edge_homophily', 'adjusted_homophily',
            'label_informativeness', 'affinity_h', 'elapsed', 'seed'
        ]

        try:
            self.results_df = pd.read_csv(self.results_path)
            print(f"Loaded existing results from: {self.results_path}")
        except:
            self.results_df = pd.DataFrame(columns=result_cols)
            print(f"Created new results file: {self.results_path}")

    def run_single_dataset(self, dataset_name: str) -> Dict[str, Any]:
        """Run experiment on a single dataset."""
        print(f"\nProcessing dataset: {dataset_name}")

        # Initialize metrics with defaults
        metrics = {
            'node_h': 0.0, 'edge_h': 0.0, 'adjusted_edge_h': 0.0,
            'label_informativeness': 0.0, 'affinity_h': 0.0
        }

        try:
            # Load dataset
            X, E, n_classes, labels = load_torch_dataset(dataset_name)

            # Convert to proper format
            if hasattr(E, 'src') and hasattr(E, 'dst') and hasattr(E, 'm'):
                n_edges = E.m
                edge_array = np.stack([np.array(E.src), np.array(E.dst)], axis=1)
            else:
                edge_array = self._convert_edges_to_array(E)
                n_edges = edge_array.shape[0]

            n_nodes, n_features = X.shape

            # Validate data
            if len(labels) != n_nodes:
                print(f"Warning: Label count mismatch, adjusting...")
                labels = labels[:n_nodes] if len(labels) > n_nodes else np.pad(labels, (0, n_nodes - len(labels)))

            print(f'{dataset_name:<12} #nodes: {n_nodes:>5} #features: {n_features:>5} #classes: {n_classes:>2} #edges: {n_edges:>5}')

            # Calculate homophily metrics
            metrics.update(self._calculate_homophily_metrics(edge_array, labels))

            # Get training parameters
            training_params = self._get_training_parameters(dataset_name, n_features)

            # Train affinity model
            start_time = time.time()
            affinity_result = self._train_affinity_model(X, edge_array, training_params)
            elapsed = int(time.time() - start_time)

            metrics['affinity_h'] = affinity_result['affinity_score']
            training_info = affinity_result['training_info']

            # Save results
            self._save_results(dataset_name, n_nodes, n_features, n_classes,
                             training_params, metrics, elapsed, training_info)

            print(f"Final Results for {dataset_name}:")
            for key, value in metrics.items():
                print(f"  {key}: {value:.4f}")

            if training_info.get('stopped_early', False):
                print(f"  Training stopped early at epoch {training_info['best_epoch']}")
                print(f"  Best {self.config.training_config.monitor_metric}: {training_info['best_score']:.4f}")

            return {
                'success': True,
                'dataset': dataset_name,
                'metrics': metrics,
                'training_params': training_params,
                'training_info': training_info,
                'elapsed': elapsed
            }

        except Exception as e:
            print(f"Error processing dataset {dataset_name}: {e}")
            import traceback
            traceback.print_exc()
            self.problem_datasets.append([dataset_name, f'error: {e}'])
            return {'success': False, 'dataset': dataset_name, 'error': str(e)}

    def _calculate_homophily_metrics(self, edge_array: np.ndarray, labels: np.ndarray) -> Dict[str, float]:
        """Calculate all homophily metrics."""
        try:
            print("Calculating homophily measures...")
            node_h = homophily_calculator.HomophilyCalculator.node_homophily(edge_array, labels)
            edge_h = homophily_calculator.HomophilyCalculator.edge_homophily(edge_array, labels)
            adjusted_edge_h = homophily_calculator.HomophilyCalculator.adjusted_homophily(edge_array, labels)
            label_informativeness = homophily_calculator.HomophilyCalculator.label_informativeness(edge_array, labels)

            return {
                'node_h': node_h,
                'edge_h': edge_h,
                'adjusted_edge_h': adjusted_edge_h,
                'label_informativeness': label_informativeness
            }
        except Exception as e:
            print(f"Error calculating homophily: {e}")
            return {'node_h': 0.0, 'edge_h': 0.0, 'adjusted_edge_h': 0.0, 'label_informativeness': 0.0}

    def _get_training_parameters(self, dataset_name: str, n_features: int) -> Dict[str, Any]:
        """Get training parameters for dataset."""
        try:
            emb_ratio, max_nodes, k, init_lr, lr_decay, epochs = get_params(dataset_name, self.config.root)
        except:
            emb_ratio, max_nodes, k, init_lr, lr_decay, epochs = 2, 5000, 50, 0.001, 0.96, 500

        return {
            'emb_ratio': emb_ratio,
            'max_nodes': max_nodes,
            'k': k,
            'init_lr': init_lr,
            'lr_decay': lr_decay,
            'epochs': int(epochs),
            'n_emb_features': int(n_features / emb_ratio)
        }

    def _train_affinity_model(self, X: np.ndarray, edge_array: np.ndarray,
                            training_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train the affinity model."""
        # Convert to MLX format
        X_mlx = mx.array(X)
        edge_data_mlx = mx.array(edge_array)

        # Create model
        model = ModelFactory.create_model(X_mlx, self.config.model_config)

        # Update training config with dataset-specific parameters
        training_config = self.config.training_config
        training_config.lr = float(training_params['init_lr'])
        training_config.epochs = int(training_params['epochs'])
        # Ensure integer for range() usage in sampling
        training_config.num_negatives = int(training_params['k'])

        # Create trainer
        trainer = GenericAffinityTrainer(model, training_config)

        # Train
        print(f"Training {self.config.model_config.model_type} model...")
        hist_loss, hist_aff = trainer.train(X_mlx, edge_data_mlx, self.rng)

        # Get final affinity score and training info
        affinity_score = trainer.get_affinity_score()
        training_info = trainer.get_training_info()

        # Cleanup
        del model, trainer

        return {
            'affinity_score': affinity_score,
            'loss_history': hist_loss,
            'affinity_history': hist_aff,
            'training_info': training_info
        }

    def _save_results(self, dataset_name: str, n_nodes: int, n_features: int,
                     n_classes: int, training_params: Dict[str, Any],
                     metrics: Dict[str, float], elapsed: int, training_info: Dict[str, Any]):
        """Save results to DataFrame with model-specific filename."""
        if not self.config.save_results:
            return

        # Extract early stopping information
        actual_epochs = training_info.get('total_epochs', training_params['epochs'])
        early_stopped = training_info.get('stopped_early', False)
        best_epoch = training_info.get('best_epoch', actual_epochs)
        best_score = training_info.get('best_score', metrics['affinity_h'])

        new_row = [
            dataset_name, n_nodes, n_features, n_classes, True,  # directed
            self.config.model_config.model_type,
            training_params['emb_ratio'], training_params['max_nodes'], training_params['k'],
            training_params['init_lr'], training_params['lr_decay'], training_params['epochs'],
            actual_epochs, early_stopped, best_epoch, best_score,
            metrics['node_h'], metrics['edge_h'], metrics['adjusted_edge_h'],
            metrics['label_informativeness'], metrics['affinity_h'], elapsed, self.config.seed
        ]

        self.results_df.loc[len(self.results_df)] = new_row
        self.results_df.to_csv(self.results_path, index=False)
        print(f"Results saved to: {self.results_path}")

    def _convert_edges_to_array(self, E) -> np.ndarray:
        """Convert edge data to numpy array format."""
        if hasattr(E, 'src') and hasattr(E, 'dst'):
            src = np.array(E.src)
            dst = np.array(E.dst)
            return np.stack([src, dst], axis=1)
        elif hasattr(E, 'edge_index'):
            return E.edge_index.T.numpy()
        else:
            return np.array(E)

    def run_experiment(self) -> Dict[str, Any]:
        """Run the complete experiment."""
        print("="*80)
        print(f"GENERIC AFFINITY EXPERIMENT")
        print(f"Model Type: {self.config.model_config.model_type}")
        print(f"Loss Type: {self.config.training_config.loss_type}")
        print(f"Datasets: {self.config.datasets}")
        print("="*80)

        results = []
        for dataset_name in self.config.datasets:
            result = self.run_single_dataset(dataset_name)
            results.append(result)

        # Print summary
        self._print_summary(results)

        return {
            'results': results,
            'problem_datasets': self.problem_datasets,
            'results_df': self.results_df
        }

    def _print_summary(self, results: List[Dict[str, Any]]):
        """Print experiment summary."""
        print("\n" + "="*80)
        print(f"EXPERIMENT SUMMARY - {self.config.model_config.model_type.upper()} MODEL")
        print("="*80)

        successful_results = [r for r in results if r['success']]

        if successful_results:
            print(f"\nSuccessful experiments: {len(successful_results)}")

            # Summary statistics
            early_stopped_count = sum(1 for r in successful_results
                                    if r.get('training_info', {}).get('stopped_early', False))

            if early_stopped_count > 0:
                print(f"Early stopping triggered: {early_stopped_count}/{len(successful_results)} experiments")

            for result in successful_results:
                metrics = result['metrics']
                training_info = result.get('training_info', {})

                print(f"\nDataset: {result['dataset']}")
                print(f"  Node Homophily:        {metrics['node_h']:.4f}")
                print(f"  Edge Homophily:        {metrics['edge_h']:.4f}")
                print(f"  Adjusted Homophily:    {metrics['adjusted_edge_h']:.4f}")
                print(f"  Label Informativeness: {metrics['label_informativeness']:.4f}")
                print(f"  Affinity Homophily:    {metrics['affinity_h']:.4f}")

                # Training information
                actual_epochs = training_info.get('total_epochs', 'Unknown')
                max_epochs = result['training_params']['epochs']
                print(f"  Training: {actual_epochs}/{max_epochs} epochs")

                if training_info.get('stopped_early', False):
                    print(f"  Early stopped at epoch {training_info['best_epoch']} "
                          f"(best {self.config.training_config.monitor_metric}: {training_info['best_score']:.4f})")

        if self.problem_datasets:
            print(f"\nProblematic datasets: {len(self.problem_datasets)}")
            for name, reason in self.problem_datasets:
                print(f"  {name}: {reason}")

        print(f"\nResults saved to: {self.results_path}")
        print(f"Model type: {self.config.model_config.model_type}")

        # Training configuration summary
        tc = self.config.training_config
        print(f"\nTraining Configuration:")
        print(f"  Loss: {tc.loss_type}, Optimizer: {tc.optimizer_type}")
        print(f"  Early stopping: {tc.early_stopping}")
        if tc.early_stopping:
            print(f"  Patience: {tc.patience}, Monitor: {tc.monitor_metric}")
        if tc.curriculum_learning:
            print(f"  Curriculum learning: {tc.curriculum_stages} stages")


# Usage Examples and Convenience Functions
def create_basic_config(datasets: List[str], early_stopping: bool = True, patience: int = 10, **kwargs) -> ExperimentConfig:
    """Create basic experiment configuration."""
    training_config = TrainingConfig(
        early_stopping=early_stopping,
        patience=patience,
        **{k: v for k, v in kwargs.items() if k in TrainingConfig.__annotations__}
    )
    model_config = ModelConfig(model_type="basic", **{k: v for k, v in kwargs.items() if k in ModelConfig.__annotations__})

    return ExperimentConfig(
        model_config=model_config,
        training_config=training_config,
        datasets=datasets
    )

def create_multi_head_config(datasets: List[str], num_heads: int = 8, temperature: float = 0.1,
                           early_stopping: bool = True, patience: int = 15, **kwargs) -> ExperimentConfig:
    """Create multi-head experiment configuration."""
    training_config = TrainingConfig(
        loss_type="infonce",
        temperature=temperature,
        early_stopping=early_stopping,
        patience=patience,
        **{k: v for k, v in kwargs.items() if k in TrainingConfig.__annotations__}
    )
    model_config = ModelConfig(
        model_type="multi_head",
        num_heads=num_heads,
        **{k: v for k, v in kwargs.items() if k in ModelConfig.__annotations__}
    )

    return ExperimentConfig(
        model_config=model_config,
        training_config=training_config,
        datasets=datasets
    )

def create_hierarchical_config(datasets: List[str], scales: List[int] = [1, 2, 4],
                             early_stopping: bool = True, patience: int = 12, **kwargs) -> ExperimentConfig:
    """Create hierarchical experiment configuration."""
    training_config = TrainingConfig(
        early_stopping=early_stopping,
        patience=patience,
        **{k: v for k, v in kwargs.items() if k in TrainingConfig.__annotations__}
    )
    model_config = ModelConfig(
        model_type="hierarchical",
        scales=scales,
        **{k: v for k, v in kwargs.items() if k in ModelConfig.__annotations__}
    )

    return ExperimentConfig(
        model_config=model_config,
        training_config=training_config,
        datasets=datasets
    )

def create_learnable_sim_config(datasets: List[str], similarity_type: str = "mlp",
                               early_stopping: bool = True, patience: int = 8, **kwargs) -> ExperimentConfig:
    """Create learnable similarity experiment configuration."""
    training_config = TrainingConfig(
        early_stopping=early_stopping,
        patience=patience,
        **{k: v for k, v in kwargs.items() if k in TrainingConfig.__annotations__}
    )
    model_config = ModelConfig(
        model_type="learnable_sim",
        similarity_type=similarity_type,
        **{k: v for k, v in kwargs.items() if k in ModelConfig.__annotations__}
    )

    return ExperimentConfig(
        model_config=model_config,
        training_config=training_config,
        datasets=datasets
    )

def create_custom_config(datasets: List[str], model_type: str, early_stopping: bool = True,
                        patience: int = 10, **kwargs) -> ExperimentConfig:
    """Create custom experiment configuration."""
    training_config = TrainingConfig(
        early_stopping=early_stopping,
        patience=patience,
        **{k: v for k, v in kwargs.items() if k in TrainingConfig.__annotations__}
    )
    model_config = ModelConfig(
        model_type=model_type,
        **{k: v for k, v in kwargs.items() if k in ModelConfig.__annotations__}
    )

    return ExperimentConfig(
        model_config=model_config,
        training_config=training_config,
        datasets=datasets
    )


if __name__ == "__main__":
    # Example usage with early stopping and model-specific filenames
    datasets = [
        'roman_empire', 'amazon_ratings', 'minesweeper', 'tolokers', 'questions',
        'chameleon', 'squirrel',
        'cora', 'citeseer', 'pubmed', 'karate'
    ]

    print("Running experiments with early stopping and model-specific result files...")

    # Example 1: Basic model with early stopping
    print("\n1. Running Basic Affinity Model with early stopping...")
    config = create_basic_config(
        datasets,
        epochs=100,
        lr=1e-3,
        early_stopping=True,
        patience=10,
        monitor_metric="loss"
    )
    experiment = AffinityExperiment(config)
    results = experiment.run_experiment()
    print(f"Results saved to: basic_results.csv")

    # Example 2: Multi-head model with affinity monitoring
    print("\n2. Running Multi-Head Affinity Model with affinity monitoring...")
    config_multi = create_multi_head_config(
        datasets,
        num_heads=4,
        temperature=0.1,
        epochs=100,
        early_stopping=True,
        patience=15,
        monitor_metric="affinity"  # Monitor affinity score instead of loss
    )
    experiment_multi = AffinityExperiment(config_multi)
    results_multi = experiment_multi.run_experiment()
    print(f"Results saved to: multi_head_results.csv")

    # Example 3: Hierarchical with curriculum learning and early stopping
    print("\n3. Running Hierarchical Model with curriculum learning...")
    config_hier = create_hierarchical_config(
        datasets,
        scales=[1, 2, 4],
        epochs=90,
        early_stopping=True,
        patience=12,
        curriculum_learning=True,
        curriculum_stages=3
    )
    experiment_hier = AffinityExperiment(config_hier)
    results_hier = experiment_hier.run_experiment()
    print(f"Results saved to: hierarchical_results.csv")

    # Example 4: Custom configuration with no early stopping
    print("\n4. Running Custom Configuration without early stopping...")
    config_custom = create_custom_config(
        datasets=datasets[:2],  # Just first 2 datasets for speed
        model_type="learnable_sim",
        similarity_type="bilinear",
        loss_type="margin",
        epochs=50,
        num_negatives=3,
        lr=5e-4,
        early_stopping=False  # Disable early stopping
    )
    experiment_custom = AffinityExperiment(config_custom)
    results_custom = experiment_custom.run_experiment()
    print(f"Results saved to: learnable_sim_results.csv")

    print("\n" + "="*80)
    print("ALL EXPERIMENTS COMPLETED!")
    print("="*80)
    print("Check the results/ directory for model-specific CSV files:")
    print("  - basic_results.csv")
    print("  - multi_head_results.csv")
    print("  - hierarchical_results.csv")
    print("  - learnable_sim_results.csv")
    print("\nEach file contains training details including early stopping information!")
