import argparse
import json
import os
from dataclasses import asdict
from typing import Dict, List, Tuple

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from hero.utils.metrics import compute_standard_metrics

from hero.core.dataset import DatasetLoader
from hero.core.config import ExperimentConfig, DEVICE
from hero.core.model import ProfileModel
from hero.core.trainer import ProfileTrainer
from hero.profiler.router import (
    correct_and_smooth,
    _propagate_scores,
)
from hero.profiler.hierarchical import (
    AdaptiveThresholds,
    SharedEstimators,
    HierarchicalProfiler,
    compute_graph_stats,
)
from hero.paths import get_results_dir


def _normalize(X: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(X, axis=1, keepdims=True) + 1e-8
    return X / n


def _build_edge_index(A: np.ndarray) -> np.ndarray:
    ei = np.vstack(np.nonzero(A)).astype(np.int64)
    return ei


def _train_lr_Z(Z: np.ndarray, y: np.ndarray, mask: np.ndarray) -> LogisticRegression:
    lr = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
    lr.fit(Z[mask], y[mask])
    return lr


def _train_lr_subset(Z: np.ndarray, y: np.ndarray, mask: np.ndarray) -> LogisticRegression:
    if mask.sum() == 0:
        return _train_lr_Z(Z, y, np.ones_like(mask, dtype=bool))
    lr = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
    lr.fit(Z[mask], y[mask])
    return lr


def _local_guarded_pl(Z: np.ndarray, y: np.ndarray, train_mask: np.ndarray,
                      conf_thr: float = 0.85, global_cap: float = 0.10) -> LogisticRegression:
    # Train base LR
    lr = _train_lr_Z(Z, y, train_mask)
    proba = lr.predict_proba(Z)
    conf = proba.max(axis=1)
    pred = lr.classes_[np.argmax(proba, axis=1)]
    # Candidates not in train
    cand = ~train_mask
    order = np.argsort(-conf[cand])
    cand_idx = np.where(cand)[0][order]
    sel = []
    cap = int(global_cap * train_mask.sum())
    for u in cand_idx:
        if conf[u] < conf_thr:
            break
        sel.append(u)
        if len(sel) >= cap:
            break
    if sel:
        tm = train_mask.copy()
        y_aug = y.copy()
        tm[sel] = True
        y_aug[sel] = pred[sel]
        lr = _train_lr_Z(Z, y_aug, tm)
    return lr


def local_router(dataset: str, K: int | List[int] = 5, beta: float = 5.0, quick: bool = True,
                 cov_thr: float = 0.08, kappa_thr: float = 0.6,
                 unsup_overrides: Dict | None = None,
                 cluster_strict: bool = False,
                 cluster_head: str = 'global_lr',
                 threshold_weights: Dict[str, List[float]] | None = None,
                 utility_params: List[float] | None = None,
                 safety_params: List[float] | None = None,
                 bootstrap_samples: int = 64,
                 validation_threshold: float = 0.02,
                 utility_unc: float = 0.05,
                 safety_unc: float = 0.05) -> Dict:
    # Load dataset
    X, A, y, masks = DatasetLoader.load_dataset(dataset)
    n, d = X.shape
    edge_index = _build_edge_index(A)
    # Masks to 1D
    train_mask = masks['train_mask'][:, 0] if masks['train_mask'].ndim == 2 else masks['train_mask']
    val_mask = masks.get('val_mask', train_mask)
    if getattr(val_mask, 'ndim', 1) == 2:
        val_mask = val_mask[:, 0]
    test_mask = masks['test_mask'][:, 0] if masks['test_mask'].ndim == 2 else masks['test_mask']

    # Train request-profile model (paper-mode)
    epochs = 6 if quick else 150
    overrides = unsup_overrides or {}
    profile_dim = int(overrides.get('profile_dim', 128))
    neg_ratio = float(overrides.get('neg_ratio', 1.0))
    hard_neg_frac = float(overrides.get('hard_neg_frac', 0.5))
    eic_temperature = float(overrides.get('eic_temperature', 0.2))
    contrastive_weight = float(overrides.get('contrastive_weight', 1.0))
    edge_batch_size = int(overrides.get('edge_batch_size', 4096))
    epochs = int(overrides.get('epochs', epochs))
    label_weight = float(overrides.get('label_weight', 0.0))
    balance_losses = bool(overrides.get('balance_losses', True))
    strategy = str(overrides.get('strategy', 'contrastive_proto'))
    cfg = ExperimentConfig(datasets=['custom'], profile_dim=profile_dim, epochs=epochs,
                           edge_loss_mode='paper', neg_ratio=neg_ratio, hard_neg_frac=hard_neg_frac,
                           eic_temperature=eic_temperature, balance_losses=balance_losses,
                           edge_batch_size=edge_batch_size, unsupervised=True,
                           contrastive_weight=contrastive_weight, label_weight=label_weight,
                           strategy=strategy)
    model = ProfileModel(n, d, cfg.affinity_dim, DEVICE)
    trainer = ProfileTrainer(model, cfg)
    trainer.train(X, A, y, train_mask)
    with torch.no_grad():
        ft = torch.tensor(X, dtype=torch.float32, device=DEVICE)
        q = model.proj_head(model.feature_projection(ft)).detach().cpu().numpy()
        a = model.profile_vectors.detach().cpu().numpy()
    qn = _normalize(q)
    rn = _normalize(a)  # request profiles (formerly: affinity vectors)
    Z = np.concatenate([qn, rn], axis=1)

    # Prepare cluster resolutions (allow multi-resolution)
    if isinstance(K, (list, tuple, set)):
        K_list = sorted({int(k) for k in K if int(k) > 0})
    elif isinstance(K, str):
        K_list = sorted({int(s) for part in K.split(',') for s in [part.strip()] if s})
    else:
        K_list = [int(K)]
    if not K_list:
        raise ValueError('At least one positive cluster count must be provided')

    # Stage 2: hierarchical profiling
    A_dense = A.toarray() if hasattr(A, 'toarray') else np.asarray(A)
    graph_stats = compute_graph_stats(X, A_dense, y, train_mask)
    thresholds = AdaptiveThresholds(threshold_weights)
    estimators = SharedEstimators(utility_params, safety_params, utility_unc, safety_unc)
    profiler = HierarchicalProfiler(graph_stats, thresholds, estimators,
                                    bootstrap_samples=bootstrap_samples,
                                    validation_threshold=validation_threshold)
    diag_list, clustering_info = profiler.profile(K_list, rn, qn, X, y, Z,
                                                  train_mask, val_mask, edge_index, A_dense)
    diag_map = {(d.resolution, d.cluster): d for d in diag_list}

    # Global baselines and smoothing
    lrX = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
    lrX.fit(Z[train_mask], y[train_mask])
    proba_global = lrX.predict_proba(Z)
    classes = lrX.classes_.astype(int)
    logits_raw = lrX.decision_function(Z)
    if logits_raw.ndim == 1:
        logits_raw = np.stack([-logits_raw, logits_raw], axis=1)
    logits = np.zeros((Z.shape[0], proba_global.shape[1]))
    logits[:, classes] = logits_raw
    cs_logits = correct_and_smooth(edge_index, logits, y, train_mask)
    ap_logits = _propagate_scores(edge_index, logits)
    y_cs_val = np.argmax(cs_logits, axis=1)
    y_ap_val = np.argmax(ap_logits, axis=1)
    acc_cs_val = accuracy_score(y[val_mask], y_cs_val[val_mask])
    acc_ap_val = accuracy_score(y[val_mask], y_ap_val[val_mask])
    use_cs = acc_cs_val >= acc_ap_val
    smoothed_logits = cs_logits if use_cs else ap_logits
    proba_smooth = np.exp(smoothed_logits - smoothed_logits.max(axis=1, keepdims=True))
    proba_smooth = proba_smooth / (proba_smooth.sum(axis=1, keepdims=True) + 1e-8)

    C = proba_global.shape[1]
    proba_total: np.ndarray | None = None
    regimes_out: List[str] = []
    diagnostics_out: List[Dict] = []
    final_labels: np.ndarray | None = None
    final_centroids: np.ndarray | None = None

    for resolution, labels_k, centroids in clustering_info:
        cluster_probs: List[np.ndarray] = []
        cluster_masks: List[np.ndarray] = []
        cluster_nodes: List[np.ndarray] = []

        for cluster_id in range(resolution):
            diag = diag_map.get((resolution, cluster_id))
            if diag is None:
                regimes_out.append(f'R{resolution}_C{cluster_id}:empty')
                diagnostics_out.append({'resolution': resolution, 'cluster': cluster_id, 'cluster_size': 0,
                                        'empty': True})
                cluster_probs.append(np.zeros((n, C)))
                cluster_masks.append(np.zeros(n, dtype=bool))
                cluster_nodes.append(np.array([], dtype=int))
                continue

            mask_nodes = np.zeros(n, dtype=bool)
            mask_nodes[diag.nodes] = True
            cluster_nodes.append(diag.nodes)
            cluster_masks.append(mask_nodes)

            tm_cluster = train_mask & mask_nodes
            enough_local = tm_cluster.sum() >= max(5, C)

            proba_candidates: Dict[str, np.ndarray | None] = {
                'A': proba_global,
                'C': proba_smooth,
            }

            if cluster_head == 'cluster_lr' and enough_local:
                lr_cluster = _train_lr_subset(Z, y, tm_cluster)
                raw = lr_cluster.predict_proba(Z)
                proba_A = np.zeros((n, C))
                proba_A[:, lr_cluster.classes_.astype(int)] = raw
                proba_candidates['A'] = proba_A

            if diag.probabilities.get('B', 0.0) > 0.0 and enough_local:
                lrB = _local_guarded_pl(Z[diag.nodes], y[diag.nodes], tm_cluster[diag.nodes])
                rawB = lrB.predict_proba(Z)
                proba_B = np.zeros((n, C))
                proba_B[:, lrB.classes_.astype(int)] = rawB
                proba_candidates['B'] = proba_B
            else:
                proba_candidates['B'] = None

            cluster_mix = np.zeros((n, C))
            for regime, weight in diag.probabilities.items():
                cand = proba_candidates.get(regime)
                if cand is None or weight <= 0:
                    continue
                if cluster_strict:
                    cand = cand.copy()
                    cand[~mask_nodes] = 0.0
                cluster_mix += weight * cand
            if cluster_strict:
                cluster_mix[~mask_nodes] = 0.0

            cluster_probs.append(cluster_mix)

            regimes_out.append(f"R{resolution}_C{cluster_id}:{max(diag.probabilities, key=diag.probabilities.get)}")
            diagnostics_out.append({
                'resolution': resolution,
                'cluster': cluster_id,
                'cluster_size': int(diag.nodes.size),
                'diagnostics': {k: float(v) for k, v in diag.diagnostics.items()},
                'ci95': {k: float(v) for k, v in diag.ci95.items()},
                'scores': {k: float(v) for k, v in diag.scores.items()},
                'probabilities': {k: float(v) for k, v in diag.probabilities.items()},
                'metadata': {k: float(v) for k, v in diag.metadata.items()},
            })

        if not cluster_probs:
            continue

        diffs = np.stack([rn - centroids[k] for k in range(len(cluster_probs))], axis=0)
        d2 = np.sum(diffs ** 2, axis=2)
        w = np.exp(-beta * d2)
        if cluster_strict:
            for k in range(len(cluster_probs)):
                w[k, ~cluster_masks[k]] = 0.0
        w_sum = np.sum(w, axis=0, keepdims=True)
        w = w / (w_sum + (w_sum == 0))
        P_res = np.zeros((n, C))
        for k in range(len(cluster_probs)):
            P_res += w[k][:, None] * cluster_probs[k]

        if proba_total is None:
            proba_total = P_res.copy()
        else:
            mask_update = np.zeros(n, dtype=bool)
            for nodes in cluster_nodes:
                mask = np.zeros(n, dtype=bool)
                mask[nodes] = True
                mask_update |= mask
            proba_total[mask_update] = P_res[mask_update]

        final_labels = labels_k
        final_centroids = centroids

    if proba_total is None:
        proba_total = np.zeros((n, C))

    proba_total = np.clip(proba_total, 1e-9, None)
    proba_total /= proba_total.sum(axis=1, keepdims=True) + 1e-8
    y_pred = np.argmax(proba_total, axis=1)
    m = compute_standard_metrics(y[test_mask], y_pred[test_mask], proba_total[test_mask])

    out = {
        'dataset': dataset,
        'resolutions': K_list,
        'beta': beta,
        'regimes': regimes_out,
        'diagnostics': diagnostics_out,
        'metrics': m
    }
    return out, rn, final_labels if final_labels is not None else np.zeros(n, dtype=int), \
        final_centroids if final_centroids is not None else np.zeros((1, rn.shape[1])), proba_total


def main():
    parser = argparse.ArgumentParser(description='Local router: subgraph profiling and per-cluster regimes with blending')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--K', type=int, default=5)
    parser.add_argument('--beta', type=float, default=10.0)
    parser.add_argument('--quick', action='store_true', default=False, help='Reduced epochs for faster runs')
    parser.add_argument('--cov-thr', type=float, default=0.08, help='Coverage threshold to allow local regime B')
    parser.add_argument('--kappa-thr', type=float, default=0.6, help='Kappa threshold to allow local regime B')
    args = parser.parse_args()
    out, rn, clusters, centroids, proba = local_router(args.dataset, K=args.K, beta=args.beta, quick=args.quick,
                                                      cov_thr=args.cov_thr, kappa_thr=args.kappa_thr)
    out_dir = os.path.join(get_results_dir(), args.dataset, 'local_router')
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, 'summary.json'), 'w') as f:
        json.dump(out, f, indent=2)
    # Save artifacts for plotting
    try:
        import numpy as _np
        _np.save(os.path.join(out_dir, 'request_profiles.npy'), rn)
        _np.save(os.path.join(out_dir, 'clusters.npy'), clusters)
        _np.save(os.path.join(out_dir, 'centroids.npy'), centroids)
    except Exception:
        pass
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
