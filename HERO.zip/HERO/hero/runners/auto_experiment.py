"""Auto experiment runner.

Profiles a dataset and launches the recommended module automatically.
Allows override via CLI/env and supports JSON config to pin params.
"""

import argparse
import json
import os
from datetime import datetime

from hero.paths import get_results_dir
from hero.profiler import DatasetProfiler
from hero.runners.experiment import run as run_module, _make_module


def main():
    parser = argparse.ArgumentParser(description='HERO auto experiment runner')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--override', default=None, help='Override recommended module')
    parser.add_argument('--no-run', action='store_true', help='Only profile, do not run experiment')
    parser.add_argument('--config', default=None, help='Optional JSON with params for the chosen module')
    args = parser.parse_args()

    # Profile dataset
    prof = DatasetProfiler(results_root=get_results_dir())
    tag = args.tag or datetime.now().strftime('%Y%m%d_%H%M%S')
    report = prof.profile(args.dataset, tag)
    rec = report.get('recommended_module', 'affinity_contrastive')
    module_name = (args.override or rec)
    print(f"Recommended module: {rec} | Using: {module_name}")

    if args.no_run:
        print("Auto-run disabled. Use --override/--config and re-run to execute.")
        return

    cfg = None
    params = {}
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r') as f:
            cfg = json.load(f)
        params = cfg.get('params', {}) if isinstance(cfg, dict) else {}

    module = _make_module(module_name, params)
    run_module(module, args.dataset, tag, cfg or {'params': params, 'source': 'auto'})


if __name__ == '__main__':
    main()
