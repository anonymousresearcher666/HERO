"""Aggregate best results across modules for a dataset and plot comparison.

Scans results/<dataset>/<module>/*/summary.json, picks best run by a metric,
and generates a comparative bar plot and an index linking to each run.
"""

import argparse
import json
import os
from datetime import datetime
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt

from hero.paths import get_results_dir
from hero.plotting.plots import write_root_index, _try_save_tex


def _collect_runs(dataset: str) -> Dict[str, List[Tuple[str, Dict]]]:
    base = os.path.join(get_results_dir(), dataset)
    out: Dict[str, List[Tuple[str, Dict]]] = {}
    if not os.path.isdir(base):
        return out
    for module in os.listdir(base):
        mod_dir = os.path.join(base, module)
        if not os.path.isdir(mod_dir):
            continue
        runs = []
        for tag in os.listdir(mod_dir):
            run_dir = os.path.join(mod_dir, tag)
            sum_path = os.path.join(run_dir, 'summary.json')
            if os.path.isfile(sum_path):
                try:
                    with open(sum_path, 'r') as f:
                        summary = json.load(f)
                    runs.append((tag, summary))
                except Exception:
                    continue
        if runs:
            out[module] = runs
    return out


def _best_by_metric(runs: List[Tuple[str, Dict]], metric: str) -> Tuple[str, Dict]:
    best_tag = None
    best_sum = None
    best_val = float('-inf')
    for tag, s in runs:
        v = s.get('mean', {}).get(metric)
        if isinstance(v, (int, float)) and v > best_val:
            best_val = float(v); best_tag = tag; best_sum = s
    return best_tag or runs[0][0], best_sum or runs[0][1]


def main():
    parser = argparse.ArgumentParser(description='HERO aggregate results')
    parser.add_argument('--dataset', default='roman_empire')
    parser.add_argument('--metric', default=None, help='Metric key to compare (e.g., affinity_unsup_acc, pl_acc)')
    parser.add_argument('--tag', default=None)
    parser.add_argument('--tex', action='store_true')
    args = parser.parse_args()

    runs = _collect_runs(args.dataset)
    if not runs:
        print('No runs found for dataset', args.dataset)
        return
    # Pick metric if not provided: choose any float key from first run
    metric = args.metric
    if metric is None:
        for mod, mod_runs in runs.items():
            if mod_runs:
                _, s = mod_runs[0]
                for k, v in s.get('mean', {}).items():
                    if isinstance(v, (int, float)):
                        metric = k; break
            if metric: break
    if metric is None:
        print('No numeric metric found in summaries')
        return

    # Determine best run per module
    best = {}
    for mod, mod_runs in runs.items():
        tag, s = _best_by_metric(mod_runs, metric)
        best[mod] = (tag, s)

    # Plot comparison
    labels = list(best.keys())
    vals = [float(best[m][1]['mean'].get(metric, 0.0)) for m in labels]
    out_root = os.path.join(get_results_dir(), args.dataset, 'aggregate', args.tag or datetime.now().strftime('%Y%m%d_%H%M%S'))
    os.makedirs(out_root, exist_ok=True)
    plt.figure(figsize=(4.5, 4))
    plt.bar(labels, vals, color=['#4e79a7','#f28e2b','#e15759','#76b7b2','#59a14f'][:len(labels)])
    plt.ylim(0,1)
    plt.ylabel(metric)
    plt.title(f'Best per module ({args.dataset})')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    comp_path = os.path.join(out_root, 'comparison')
    plt.savefig(comp_path + '.png', dpi=150)
    _try_save_tex(comp_path, args.tex)
    plt.close()

    # Write aggregate index linking best runs
    links = [('comparison.png', 'comparison.png')]
    for mod, (tag, _) in best.items():
        links.append((f'{mod}/{tag}', f"../{mod}/{tag}/plots/index.html"))
    write_root_index(out_root, f"Aggregate – {args.dataset} (metric: {metric})", links)
    print('Saved aggregate to', out_root)


if __name__ == '__main__':
    main()

