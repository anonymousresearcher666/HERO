"""Apple MLX implementation of the AffinityModel."""
from __future__ import annotations

try:
    import mlx.core as mx
    import mlx.nn as nn
except Exception as e:  # pragma: no cover - library not installed
    raise ImportError("MLX backend requires the `mlx` package") from e


class AffinityModel(nn.Module):
    """Learns an affinity vector a_j per node using MLX tensors.

    MLX note:
      - Public mx.array fields on an nn.Module are trainable parameters.
      - Keep non-parameter buffers private (prefix with '_').
    """

    def __init__(self, features: mx.array):
        super().__init__()
        assert features.ndim == 2, "features must be a [n, d] array"
        self._features = features  # buffer, not a parameter
        n, d = features.shape
        # Trainable parameter: one affinity vector per node (initialized small)
        self.affinity = mx.random.normal(shape=(n, d)) * 0.02

    @property
    def n(self) -> int:
        return int(self._features.shape[0])

    @property
    def d(self) -> int:
        return int(self._features.shape[1])

    def cosine(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        """Cosine similarity between feature f_i and affinity a_j."""
        f = self._features[i_idx]
        a = self.affinity[j_idx]
        eps = 1e-12
        f = f / (mx.linalg.norm(f, axis=1, keepdims=True) + eps)
        a = a / (mx.linalg.norm(a, axis=1, keepdims=True) + eps)
        s = mx.sum(f * a, axis=1)
        return 0.5 * (s + 1.0) if scaled else s

    def full_self_affinity(self, scaled: bool = True) -> mx.array:
        """Return cosine(f_i, a_i) for all nodes i."""
        idx = mx.arange(self.n)
        return self.cosine(idx, idx, scaled=scaled)


class MultiHeadAffinityModel(nn.Module):
    """Multi-head affinity model for capturing different types of relationships."""

    def __init__(self, features: mx.array, num_heads: int = 8, head_dim: int = None):
        super().__init__()
        self._features = features
        n, d = features.shape
        self.num_heads = num_heads
        self.head_dim = head_dim or d // num_heads

        # Multiple affinity vectors per node (like multi-head attention)
        self.affinity_heads = mx.random.normal(shape=(num_heads, n, self.head_dim)) * 0.02

        # Learnable combination weights
        self.head_weights = mx.random.normal(shape=(num_heads,)) * 0.1

        # Feature projection for each head
        self.feature_projections = [
            mx.random.normal(shape=(d, self.head_dim)) * 0.02
            for _ in range(num_heads)
        ]

    def cosine_multi_head(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        """Compute multi-head cosine similarity."""
        f = self._features[i_idx]  # [batch, d]

        head_scores = []
        for h in range(self.num_heads):
            # Project features for this head
            f_proj = mx.matmul(f, self.feature_projections[h])  # [batch, head_dim]
            a_h = self.affinity_heads[h][j_idx]  # [batch, head_dim]

            # Cosine similarity for this head
            eps = 1e-12
            f_norm = f_proj / (mx.linalg.norm(f_proj, axis=1, keepdims=True) + eps)
            a_norm = a_h / (mx.linalg.norm(a_h, axis=1, keepdims=True) + eps)

            cos_sim = mx.sum(f_norm * a_norm, axis=1)
            head_scores.append(cos_sim)

        # Weighted combination of heads
        head_scores = mx.stack(head_scores, axis=0)  # [num_heads, batch]
        weights = mx.softmax(self.head_weights, axis=0).reshape(-1, 1)

        combined_score = mx.sum(weights * head_scores, axis=0)
        return 0.5 * (combined_score + 1.0) if scaled else combined_score


class GraphAwareAffinityModel(nn.Module):
    """Incorporates graph structure into affinity learning without dense n×n ops.

    Avoids allocating dense adjacency matrices; aggregates neighbor features
    directly from the edge list.
    """

    def __init__(self, features: mx.array, edges: mx.array, structure_weight: float = 0.3):
        super().__init__()
        self._features = features
        if not isinstance(edges, mx.array):
            edges = mx.array(edges)
        self._edges = edges  # shape [m, 2]
        # Keep a NumPy copy for simple neighbor lookups (no n×n memory)
        import numpy as _np
        self._edges_np = _np.array(edges)
        self.structure_weight = structure_weight
        n, d = features.shape

        # Standard affinity vectors
        self.affinity = mx.random.normal(shape=(n, d)) * 0.02

        # Structural embedding (e.g., positional encoding)
        self.structural_emb = mx.random.normal(shape=(n, max(1, d // 4))) * 0.02

    def _neighbors_numpy(self, i: int):
        """Return neighbors of node i (NumPy indices)."""
        e = self._edges_np
        mask_src = e[:, 0] == i
        mask_dst = e[:, 1] == i
        nbrs = _np.concatenate([e[mask_src, 1], e[mask_dst, 0]], axis=0)
        if nbrs.size == 0:
            return nbrs
        # Unique neighbors
        return _np.unique(nbrs)

    def structure_aware_features(self, node_idx: mx.array) -> mx.array:
        """Aggregate neighbor features per node using the edge list (no n×n).

        For each node in node_idx, compute mean of neighbor features; if no
        neighbors, use zeros. Concatenate base features, neighbor mean, and a
        small structural embedding.
        """
        import numpy as _np
        idx_np = _np.array(node_idx)
        feat = self._features
        out = []
        for i in idx_np.tolist():
            nbrs = self._neighbors_numpy(int(i))
            if nbrs.size == 0:
                nbr_mean = mx.zeros((feat.shape[1],))
            else:
                nbr_feat = feat[mx.array(nbrs)]
                nbr_mean = mx.mean(nbr_feat, axis=0)
            enhanced = mx.concatenate([
                feat[int(i)],
                nbr_mean,
                self.structural_emb[int(i)],
            ], axis=0)
            out.append(enhanced)
        return mx.stack(out, axis=0)


class HierarchicalAffinityModel(nn.Module):
    """Multi-scale hierarchical affinity model."""

    def __init__(self, features: mx.array, scales: list = [1, 2, 4]):
        super().__init__()
        self._features = features
        self.scales = scales
        n, d = features.shape

        # Affinity at different scales
        self.affinity_scales = {}
        self.scale_weights = {}

        for scale in scales:
            scale_dim = max(d // scale, 16)  # Ensure minimum dimension
            self.affinity_scales[scale] = mx.random.normal(shape=(n, scale_dim)) * 0.02
            self.scale_weights[scale] = mx.random.normal(shape=(1,)) * 0.1

        # Feature transformations for each scale
        self.feature_transforms = {
            scale: mx.random.normal(shape=(d, max(d // scale, 16))) * 0.02
            for scale in scales
        }

    def cosine_hierarchical(self, i_idx: mx.array, j_idx: mx.array, scaled: bool = True) -> mx.array:
        """Compute hierarchical cosine similarity."""
        f = self._features[i_idx]

        scale_scores = []
        for scale in self.scales:
            # Transform features for this scale
            f_transform = mx.matmul(f, self.feature_transforms[scale])
            a_scale = self.affinity_scales[scale][j_idx]

            # Cosine similarity at this scale
            eps = 1e-12
            f_norm = f_transform / (mx.linalg.norm(f_transform, axis=1, keepdims=True) + eps)
            a_norm = a_scale / (mx.linalg.norm(a_scale, axis=1, keepdims=True) + eps)

            cos_sim = mx.sum(f_norm * a_norm, axis=1)
            weighted_sim = self.scale_weights[scale] * cos_sim
            scale_scores.append(weighted_sim)

        # Combine scales
        combined_score = mx.sum(mx.stack(scale_scores), axis=0)
        return 0.5 * (combined_score + 1.0) if scaled else combined_score


class SmartNegativeSampler:
    """Intelligent negative sampling for better training."""

    def __init__(self, edges: mx.array, features: mx.array, strategy: str = "hard"):
        self.edges = edges
        self.features = features
        self.strategy = strategy
        self.n_nodes = features.shape[0]

        # Build adjacency for avoiding positive pairs
        self.positive_pairs = set()
        for edge in edges:
            i, j = int(edge[0]), int(edge[1])
            self.positive_pairs.add((i, j))
            self.positive_pairs.add((j, i))

    def sample_negatives(self, pos_edges: mx.array, num_negatives: int, rng) -> mx.array:
        """Sample negatives using different strategies."""
        if self.strategy == "random":
            return self._random_sampling(pos_edges, num_negatives, rng)
        elif self.strategy == "hard":
            return self._hard_negative_sampling(pos_edges, num_negatives, rng)
        elif self.strategy == "mixed":
            return self._mixed_sampling(pos_edges, num_negatives, rng)

    def _hard_negative_sampling(self, pos_edges: mx.array, num_negatives: int, rng) -> mx.array:
        """Sample hard negatives (similar nodes that aren't connected)."""
        negatives = []

        for edge in pos_edges:
            i = int(edge[0])
            edge_negatives = []

            # Find nodes similar to i but not connected
            i_features = self.features[i:i + 1]
            similarities = mx.matmul(i_features, self.features.T).flatten()

            # Sort by similarity (descending) and filter out positive connections
            sorted_indices = mx.argsort(similarities)[::-1]

            candidates = []
            for j in sorted_indices:
                j = int(j)
                if (i, j) not in self.positive_pairs and j != i:
                    candidates.append(j)
                if len(candidates) >= num_negatives * 2:  # Get extra candidates
                    break

            # Randomly sample from top candidates
            selected = rng.choice(candidates[:num_negatives * 2], size=num_negatives, replace=False)
            edge_negatives = [[i, j] for j in selected]
            negatives.extend(edge_negatives)

        return mx.array(negatives)




class LearnableSimilarityModel(nn.Module):
    """Learn custom similarity functions beyond cosine."""

    def __init__(self, features: mx.array, similarity_type: str = "mlp"):
        super().__init__()
        self._features = features
        self.similarity_type = similarity_type
        n, d = features.shape

        self.affinity = mx.random.normal(shape=(n, d)) * 0.02

        if similarity_type == "mlp":
            # MLP-based similarity
            self.sim_mlp_w1 = mx.random.normal(shape=(d * 2, d)) * 0.02
            self.sim_mlp_w2 = mx.random.normal(shape=(d, 1)) * 0.02
        elif similarity_type == "bilinear":
            # Bilinear similarity
            self.bilinear_matrix = mx.random.normal(shape=(d, d)) * 0.02

    def learnable_similarity(self, i_idx: mx.array, j_idx: mx.array) -> mx.array:
        """Compute learnable similarity."""
        f = self._features[i_idx]
        a = self.affinity[j_idx]

        if self.similarity_type == "mlp":
            # Concatenate and pass through MLP
            concat_features = mx.concatenate([f, a], axis=1)
            hidden = mx.tanh(mx.matmul(concat_features, self.sim_mlp_w1))
            similarity = mx.matmul(hidden, self.sim_mlp_w2).flatten()

        elif self.similarity_type == "bilinear":
            # Bilinear similarity: f^T W a
            similarity = mx.sum(f * mx.matmul(a, self.bilinear_matrix.T), axis=1)

        return mx.sigmoid(similarity)  # Ensure [0,1] range
