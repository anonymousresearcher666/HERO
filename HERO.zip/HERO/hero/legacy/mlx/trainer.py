"""
program: compute affinity matrix for dataset using MLX backend
version: sparse version, single headed-affinity
adapted for MLX framework

"""
try:
    # Preferred path via new package
    from hero.calculators.homophily import HomophilyCalculator as homophily_calculator
except Exception:
    try:
        from .HomophilyCalculator import HomophilyCalculator as homophily_calculator
    except Exception:
        # Fallback for running as a script
        from HomophilyCalculator import HomophilyCalculator as homophily_calculator
# setup environment
root = '.'
data_folder = "data"

# import libraries, including utils
import os
import sys

sys.path.append(root)

try:
    import mlx.core as mx
    import mlx.nn as nn
    from mlx.optimizers import AdamW
except Exception as e:
    raise ImportError("MLX backend requires the `mlx` package") from e

import pandas as pd
import numpy as np
import time
try:
    from hero.utils import set_seeds, plot_hist, get_params
    from hero.legacy.mlx.model import AffinityModel  # Your MLX AffinityModel
    from hero.data.torch_loader import load_torch_dataset
    from hero.calculators.metrics import estimate_ah
except Exception:
    # Fallback if run as a script
    from utils import set_seeds, plot_hist, get_params
    from model import AffinityModel
    from data import load_torch_dataset
    from metrics import estimate_ah

class MLXAffinityTrainer:
    """MLX-based affinity model trainer"""

    def __init__(self, model, lr=1e-3, wd=1e-4):
        self.model = model
        self.optimizer = AdamW(learning_rate=lr, weight_decay=wd)
        self.loss_history = []
        self.affinity_history = []

    def bpr_loss(self, pos_scores, neg_scores):
        """BPR loss for affinity training"""
        return mx.mean(nn.softplus(neg_scores - pos_scores))

    def sample_negatives(self, edge_data, n_nodes, num_negatives, rng):
        """Sample negative pairs for training"""
        num_edges = edge_data.shape[0]
        neg_pairs = []

        for _ in range(num_negatives):
            # Sample random pairs
            i_neg = rng.integers(0, n_nodes, size=num_edges)
            j_neg = rng.integers(0, n_nodes, size=num_edges)
            neg_pairs.append(mx.stack([mx.array(i_neg), mx.array(j_neg)], axis=1))

        return mx.stack(neg_pairs, axis=0)  # [num_negatives, num_edges, 2]

    def train_step(self, edge_data, num_negatives=5, rng=None):
        """Single training step"""
        if rng is None:
            rng = np.random.default_rng()

        # Positive pairs
        i_pos = edge_data[:, 0]
        j_pos = edge_data[:, 1]
        pos_scores = self.model.cosine(i_pos, j_pos, scaled=True)

        # Negative pairs
        neg_pairs = self.sample_negatives(edge_data, self.model.n, num_negatives, rng)
        neg_scores_list = []

        for k in range(num_negatives):
            i_neg = neg_pairs[k, :, 0]
            j_neg = neg_pairs[k, :, 1]
            neg_scores_list.append(self.model.cosine(i_neg, j_neg, scaled=True))

        neg_scores = mx.mean(mx.stack(neg_scores_list), axis=0)

        # Compute loss
        loss = self.bpr_loss(pos_scores, neg_scores)

        # Backward pass
        loss_fn = lambda model: self.bpr_loss(
            model.cosine(i_pos, j_pos, scaled=True),
            neg_scores
        )

        loss_val, grads = nn.value_and_grad(self.model, loss_fn)(self.model)
        self.optimizer.update(self.model, grads)
        mx.eval(self.model.parameters(), self.optimizer.state)

        return float(loss_val.item())

    def train(self, X, edge_data, epochs=100, num_negatives=5, eval_every=10, rng=None):
        """Train the affinity model"""
        print(f"Training affinity model for {epochs} epochs...")

        for epoch in range(1, epochs + 1):
            loss = self.train_step(edge_data, num_negatives, rng)
            self.loss_history.append(loss)

            if epoch % eval_every == 0:
                # Compute affinity score
                affinity_score = self.get_affinity_score(X)
                self.affinity_history.append(affinity_score)
                print(f"Epoch {epoch:3d} | Loss: {loss:.4f} | Affinity: {affinity_score:.4f}")

        return self.loss_history, self.affinity_history

    def get_affinity_score(self, X):
        """Compute affinity-based homophily score"""
        # Get self-affinity scores for all nodes
        self_affinity = self.model.full_self_affinity(scaled=True)
        return float(mx.mean(self_affinity).item())

    def plot_affinity(self, X, edge_data, save_flag=True, results_folder=""):
        """Plot affinity matrix (simplified version)"""
        # This is a placeholder - implement visualization as needed
        if save_flag:
            print(f"Affinity plot saved to {results_folder}")
        pass

def convert_edges_to_array(E):
    """Convert edge data to numpy array format"""
    if hasattr(E, 'src') and hasattr(E, 'dst'):
        # Your custom Edges class
        src = np.array(E.src)
        dst = np.array(E.dst)
        return np.stack([src, dst], axis=1)
    elif hasattr(E, 'edge_index'):
        # PyTorch Geometric format
        return E.edge_index.T.numpy()
    else:
        # Assume it's already in array format
        return np.array(E)


def main_cli():
    seed = 13
    set_seeds(seed)
    rng = np.random.default_rng(seed)

    results_folder = f"{root}/results/"
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)
    if not os.path.exists(results_folder+'hist'):
        os.makedirs(results_folder+'hist')
    if not os.path.exists(results_folder+'aff_plots'):
        os.makedirs(results_folder+'aff_plots')

    # Fixed dataset names - some need lowercase for HeterophilousGraphDataset
    # Default to a single dataset focused run
    datasets = ['amazon_ratings']

    results = []
    result_cols = ['dataset', 'nodes', 'features', 'classes', 'directed', 'emb_ratio',
                   'max_nodes', 'k', 'init_lr', 'lr_decay', 'epochs',
                   'node_homophily', 'edge_homophily', 'adjusted_homophily',
                   'label_informativeness', 'affinity_h', 'elapsed', 'seed']

    try:
       results_df = pd.read_csv(results_folder+'results.csv')
    except:
        results_df = pd.DataFrame(columns = result_cols)

    problem_datasets = []

    for dataset_name in datasets:
        print()
        print(f"Processing dataset: {dataset_name}")

        # Initialize homophily variables with defaults
        node_h = 0.0
        edge_h = 0.0
        adjusted_edge_h = 0.0
        label_informativeness = 0.0
        affinity_h = 0.0

        # load entire dataset
        try:
            X, E, n_classes, labels = load_torch_dataset(dataset_name)

            # Convert to proper format and extract basic info
            if hasattr(E, 'src') and hasattr(E, 'dst') and hasattr(E, 'm'):
                n_edges = E.m
                edge_array = np.stack([np.array(E.src), np.array(E.dst)], axis=1)
            else:
                # Handle other formats (shouldn't happen with fixed load function)
                edge_array = convert_edges_to_array(E)
                n_edges = edge_array.shape[0]

            # Always treat as directed initially (can make undirected later if needed)
            is_directed = True

            # Get dataset dimensions
            n_nodes, n_features = X.shape

            # Validate data consistency
            if len(labels) != n_nodes:
                print(f"Warning: Label count ({len(labels)}) doesn't match node count ({n_nodes})")
                labels = labels[:n_nodes] if len(labels) > n_nodes else np.pad(labels, (0, n_nodes - len(labels)))

            print(f'{dataset_name:<12} #nodes: {n_nodes:>5} #features: {n_features:>5} #classes: {n_classes:>2} #edges: {n_edges:>5} Directed: {is_directed}')

        except Exception as e:
            print(f"Error loading dataset {dataset_name}: {e}")
            print(f"Exception type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            problem_datasets.append([dataset_name, f'loading error: {e}'])
            continue

        # Calculate homophily metrics - AFTER successful data loading
        try:
            print("Calculating homophily measures...")
            # Pass edge_array (not E) and labels to HomophilyCalculator
            node_h = homophily_calculator.HomophilyCalculator.node_homophily(edge_array, labels)
            edge_h = homophily_calculator.HomophilyCalculator.edge_homophily(edge_array, labels)
            adjusted_edge_h = homophily_calculator.HomophilyCalculator.adjusted_homophily(edge_array, labels)
            label_informativeness = homophily_calculator.HomophilyCalculator.label_informativeness(edge_array, labels)

            print(f"Homophily measures:")
            print(f"  Node Homophily: {node_h:.4f}")
            print(f"  Edge Homophily: {edge_h:.4f}")
            print(f"  Adjusted Homophily: {adjusted_edge_h:.4f}")
            print(f"  Label Informativeness: {label_informativeness:.4f}")

        except Exception as e:
            print(f"Error calculating homophily measures: {e}")
            print("Using default values (0.0)")
            # Keep default values

        # get best parameters
        try:
            emb_ratio, max_nodes, k, init_lr, lr_decay, epochs = get_params(dataset_name, root)
        except:
            # Default parameters
            emb_ratio, max_nodes, k, init_lr, lr_decay, epochs = 2, 5000, 50, 0.001, 0.96, 500

        n_emb_features = int(n_features/emb_ratio)
        epochs = int(epochs)

        start = time.time()

        # Handle large datasets by processing in chunks
        if n_nodes > max_nodes:
            print(f"Dataset too large ({n_nodes} nodes), processing in chunks of {max_nodes}")
            # For now, process the full dataset - you can implement chunking if needed

        try:
            # Convert data to MLX format
            X_mlx = mx.array(X) if not isinstance(X, mx.array) else X

            # Create edge array
            if hasattr(E, 'src'):
                edge_array = np.stack([np.array(E.src), np.array(E.dst)], axis=1)
            else:
                edge_array = convert_edges_to_array(E)

            edge_data_mlx = mx.array(edge_array)

            # Create affinity model
            affinity_model = AffinityModel(X_mlx)

            # Create trainer
            trainer = MLXAffinityTrainer(affinity_model, lr=init_lr)

            # Train model
            hist_loss, hist_aff = trainer.train(
                X_mlx, edge_data_mlx,
                epochs=epochs,
                num_negatives=k,
                eval_every=max(1, epochs//10),
                rng=rng
            )

            # Plot affinity matrix against adjacency
            trainer.plot_affinity(X_mlx, edge_data_mlx, save_flag=True, results_folder=results_folder)

            # Compute final affinity score
            affinity_h = trainer.get_affinity_score(X_mlx)

            print(f"Final Results:")
            print(f"  Affinity Homophily: {affinity_h:.4f}")
            print(f"  Node Homophily: {node_h:.4f}")
            print(f"  Edge Homophily: {edge_h:.4f}")
            print(f"  Adjusted Homophily: {adjusted_edge_h:.4f}")
            print(f"  Label Informativeness: {label_informativeness:.4f}")

            # Plot training history
            try:
                plot_hist(hist_loss, hist_aff, dataset_name, results_folder)
            except:
                print("Could not plot training history")

        except Exception as e:
            print(f'... cannot compute affinity score: {e}')
            import traceback
            traceback.print_exc()
            problem_datasets.append([dataset_name, f'computation error: {e}'])
            continue

        stop = time.time()
        elapsed = int(stop-start)

        # Save results with all homophily measures
        results_df.loc[len(results_df)] = [
            dataset_name, n_nodes, n_features, n_classes, is_directed,
            emb_ratio, max_nodes, k, init_lr, lr_decay, epochs,
            node_h, edge_h, adjusted_edge_h, label_informativeness,
            affinity_h, elapsed, seed
        ]

        # save results
        results_df.to_csv(results_folder+'results.csv', index=False)
        del affinity_model, trainer

    # report logs
    if len(problem_datasets)>0:
        print("\nProblem encountered with following datasets:")
        for name, reason in problem_datasets:
            print(f"{name:<20} {reason:<50}")

    print("\nProcessing complete!")
    print(f"Results saved to: {results_folder}results.csv")

    # Display final summary
    print("\n" + "="*80)
    print("FINAL HOMOPHILY MEASURES SUMMARY")
    print("="*80)
    if len(results_df) > 0:
        for idx, row in results_df.tail(len(datasets)).iterrows():
            print(f"\nDataset: {row['dataset']}")
            print(f"  Node Homophily:        {row['node_homophily']:.4f}")
            print(f"  Edge Homophily:        {row['edge_homophily']:.4f}")
            print(f"  Adjusted Homophily:    {row['adjusted_homophily']:.4f}")
            print(f"  Label Informativeness: {row['label_informativeness']:.4f}")
            print(f"  Affinity Homophily:    {row['affinity_h']:.4f}")
            print(f"  Dataset size: {int(row['nodes'])} nodes, {int(row['features'])} features")


if __name__ == '__main__':
    main_cli()
