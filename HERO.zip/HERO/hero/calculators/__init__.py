"""Calculators and metrics for HERO."""

