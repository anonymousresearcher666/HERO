"""MLX implementation of AH metrics."""
from __future__ import annotations

import math
import random
from typing import Tuple

try:
    import mlx.core as mx
except Exception as e:  # pragma: no cover - library not installed
    raise ImportError("MLX backend requires the `mlx` package") from e


def estimate_mu_nd(model, K: int = 200_000, scaled: bool = True, seed: int = 0) -> float:
    """Estimate mean off-diagonal similarity via uniform pair sampling."""
    rng = random.Random(seed)
    n = model.n
    if K > n * (n - 1):
        K = n * (n - 1)
    i_idx = []
    j_idx = []
    for _ in range(K):
        i = rng.randrange(n)
        j = rng.randrange(n - 1)
        if j >= i:
            j += 1
        i_idx.append(i)
        j_idx.append(j)
    i = mx.array(i_idx, dtype=mx.int64)
    j = mx.array(j_idx, dtype=mx.int64)
    s = model.cosine(i, j, scaled=scaled)
    mu_nd = float(mx.mean(s).item())
    return mu_nd


def estimate_ah(model, e: int, K: int = 200_000, scaled: bool = True, seed: int = 0) -> Tuple[float, float, float]:
    """Return (AH, mu_d, mu_nd) using MLX operations."""
    n = model.n
    mu_d = float(mx.mean(model.full_self_affinity(scaled=scaled)).item())
    mu_nd = estimate_mu_nd(model, K=K, scaled=scaled, seed=seed)
    eps = 1e-9
    ratio = (mu_d + eps) / max(mu_nd, eps)
    denom = math.log1p((n * n - n) / max(2 * e, 1))
    ah = math.log1p(ratio) / max(denom, eps)
    ah = max(0.0, min(1.0, ah))
    return ah, mu_d, mu_nd
