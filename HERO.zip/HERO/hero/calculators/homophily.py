"""Homophily calculations.

This file contains the HomophilyCalculator with common homophily metrics.
"""

from collections import Counter

import numpy as np


class HomophilyCalculator:
    """Calculate various homophily measures for graph datasets"""

    @staticmethod
    def node_homophily(edge_index, labels):
        """
        Calculate Node Homophily (H_n): ratio of same-class neighbor nodes to all neighbors
        H_n = (1/|V|) * Σ_{v∈V} |{y_j|y_j ∈ N_i, Y_j = Y_i}| / |N_i|
        """
        labels = np.array(labels)
        n_nodes = len(labels)

        # Create adjacency information
        adj_dict = {i: set() for i in range(n_nodes)}

        # Build adjacency list
        for edge in edge_index:
            u, v = int(edge[0]), int(edge[1])
            if u < n_nodes and v < n_nodes:
                adj_dict[u].add(v)
                adj_dict[v].add(u)  # Assuming undirected

        total_ratio = 0.0
        valid_nodes = 0

        for node in range(n_nodes):
            neighbors = adj_dict[node]
            if len(neighbors) > 0:
                same_class_neighbors = sum(1 for neighbor in neighbors if labels[neighbor] == labels[node])
                total_ratio += same_class_neighbors / len(neighbors)
                valid_nodes += 1

        return total_ratio / valid_nodes if valid_nodes > 0 else 0.0

    @staticmethod
    def edge_homophily(edge_index, labels):
        """
        Calculate Edge Homophily (H_e): ratio of intra-class edges to total edges
        H_e = |{(u,v)|(u,v) ∈ E, Y_u = Y_v}| / |E|
        """
        labels = np.array(labels)
        total_edges = len(edge_index)
        same_class_edges = 0

        for edge in edge_index:
            u, v = int(edge[0]), int(edge[1])
            if u < len(labels) and v < len(labels):
                if labels[u] == labels[v]:
                    same_class_edges += 1

        return same_class_edges / total_edges if total_edges > 0 else 0.0

    @staticmethod
    def adjusted_homophily(edge_index, labels):
        """
        Calculate Adjusted Homophily: accounts for class imbalance
        h_adj = (h_edge - Σ_{k=1}^C D_k^2/(2|E|)^2) / (1 - Σ_{k=1}^C D_k^2/(2|E|)^2)
        where D_k = Σ_{v: y_v=k} d(v) and d(v) is the degree of node v
        """
        labels = np.array(labels)
        n_nodes = len(labels)

        # Calculate basic edge homophily
        h_edge = HomophilyCalculator.edge_homophily(edge_index, labels)

        # Calculate node degrees
        degrees = np.zeros(n_nodes)
        for edge in edge_index:
            u, v = int(edge[0]), int(edge[1])
            if u < n_nodes:
                degrees[u] += 1
            if v < n_nodes:
                degrees[v] += 1

        # Calculate D_k for each class
        unique_labels = np.unique(labels)
        D_k_squared_sum = 0.0
        total_edges = len(edge_index)

        for label in unique_labels:
            # Sum of degrees for nodes with this label
            D_k = np.sum(degrees[labels == label])
            D_k_squared_sum += D_k ** 2

        denominator_term = D_k_squared_sum / (2 * total_edges) ** 2

        if denominator_term >= 1.0:
            return 0.0  # Avoid division by zero or negative denominator

        h_adj = (h_edge - denominator_term) / (1 - denominator_term)
        return h_adj

    @staticmethod
    def label_informativeness(edge_index, labels):
        """
        Calculate Label Informativeness (LI): I(y_ξ, y_η) / H(y_ξ)
        where I is mutual information and H is entropy
        """
        from scipy.stats import entropy

        labels = np.array(labels)

        # Calculate label distribution
        label_counts = Counter(labels)
        label_probs = np.array([count for count in label_counts.values()]) / len(labels)

        # Calculate entropy H(y_ξ)
        H_y = entropy(label_probs, base=2)

        if H_y == 0:
            return 0.0

        # Calculate joint distribution of edge labels
        edge_label_pairs = []
        for edge in edge_index:
            u, v = int(edge[0]), int(edge[1])
            if u < len(labels) and v < len(labels):
                edge_label_pairs.append((labels[u], labels[v]))

        if not edge_label_pairs:
            return 0.0

        # Count joint occurrences
        joint_counts = Counter(edge_label_pairs)
        total_edges = len(edge_label_pairs)

        # Calculate mutual information
        mutual_info = 0.0
        unique_labels = list(label_counts.keys())

        for label_u in unique_labels:
            for label_v in unique_labels:
                pair = (label_u, label_v)
                joint_prob = joint_counts.get(pair, 0) / total_edges

                if joint_prob > 0:
                    marginal_u = label_counts[label_u] / len(labels)
                    marginal_v = label_counts[label_v] / len(labels)

                    mutual_info += joint_prob * np.log2(joint_prob / (marginal_u * marginal_v))

        # Label informativeness
        LI = mutual_info / H_y
        return LI

    @staticmethod
    def calculate_all_homophily_measures(edge_index, labels):
        """Calculate all homophily measures and return as dictionary"""
        try:
            node_h = HomophilyCalculator.node_homophily(edge_index, labels)
        except Exception:
            node_h = 0.0

        try:
            edge_h = HomophilyCalculator.edge_homophily(edge_index, labels)
        except Exception:
            edge_h = 0.0

        try:
            adj_h = HomophilyCalculator.adjusted_homophily(edge_index, labels)
        except Exception:
            adj_h = 0.0

        try:
            li = HomophilyCalculator.label_informativeness(edge_index, labels)
        except Exception:
            li = 0.0

        return {
            'node_homophily': node_h,
            'edge_homophily': edge_h,
            'adjusted_homophily': adj_h,
            'label_informativeness': li
        }

__all__ = ["HomophilyCalculator"]

