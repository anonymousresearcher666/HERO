"""Dataset loader with in-memory and on-disk caching to avoid repeated reads."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
from torch_geometric.datasets import WikipediaNetwork, Planetoid, HeterophilousGraphDataset

from hero.data.external_loaders import (
    load_webkb_split,
    load_actor_split,
    load_twitch_split,
    load_custom_cached,
)
from hero.paths import get_data_dir


DatasetPayload = Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]


class DatasetLoader:
    """Utility helper making dataset access fast within sweep runs."""

    _memory_cache: Dict[str, DatasetPayload] = {}
    _CACHE_VERSION: int = 1
    _EDGE_INDEX_ONLY_DATASETS: set[str] = {"arxiv-year"}
    _DEFAULT_SPLIT_COUNT = 10

    @classmethod
    def load_dataset(
        cls,
        name: str,
        root: str = "data",
        use_cache: bool = True,
        refresh: bool = False,
    ) -> DatasetPayload:
        name_lower = name.lower()
        cache_key = cls._cache_key(name_lower)

        if use_cache and not refresh:
            payload = cls._memory_cache.get(cache_key)
            if payload is not None:
                print(f"🔁 Using cached in-memory copy of {name_lower} ({cls._describe_payload(payload)})")
                return payload

            disk_payload = cls._try_load_disk_cache(name_lower)
            if disk_payload is not None:
                features, adjacency, labels, masks = disk_payload
                ext = cls._maybe_load_external_splits(name_lower, labels.shape[0])
                if ext and "train_mask" in ext:
                    cur_train = masks.get("train_mask")
                    cur_splits = cur_train.shape[1] if cur_train is not None and cur_train.ndim == 2 else 1
                    ext_train = ext["train_mask"]
                    ext_splits = ext_train.shape[1] if ext_train.ndim == 2 else 1
                    if ext_splits > cur_splits:
                        masks = dict(masks)
                        masks.update(ext)
                        disk_payload = (features, adjacency, labels, masks)
                print(f"💾 Loaded {name_lower} from disk cache ({cls._describe_payload(disk_payload)})")
                cls._memory_cache[cache_key] = disk_payload
                return disk_payload

        payload = cls._load_dataset_uncached(name_lower, root)
        feats, adj, labels, masks = payload
        if feats is None:
            return payload

        if use_cache:
            cls._memory_cache[cache_key] = payload
            cls._store_disk_cache(name_lower, payload)

        return payload

    # ------------------------------------------------------------------
    @classmethod
    def _load_dataset_uncached(cls, name_lower: str, root: str) -> DatasetPayload:
        print(f"📚 Loading {name_lower} from source...")
        try:
            base_root = get_data_dir()
            root = base_root
            if name_lower == "arxiv-year":
                return cls._load_arxiv_year(root)
            if name_lower in {"chameleon", "squirrel", "crocodile"}:
                dataset = WikipediaNetwork(root=root, name=name_lower.capitalize())
            elif name_lower in {"cora", "citeseer", "pubmed"}:
                dataset = Planetoid(root=root, name=name_lower.capitalize())
            elif name_lower in {"roman_empire", "amazon_ratings", "minesweeper", "tolokers", "questions"}:
                dataset = HeterophilousGraphDataset(root=root, name=name_lower)
            elif name_lower in {"cornell", "texas", "wisconsin"}:
                return load_webkb_split(name_lower, root)
            elif name_lower == "actor":
                return load_actor_split(root)
            elif name_lower.startswith("twitch_"):
                lang = name_lower.split("_", 1)[1].upper()
                return load_twitch_split(lang, root)
            elif name_lower in {"penn94", "genius", "deezer_europe", "wiki-cooc", "snap_patents"}:
                return load_custom_cached(name_lower, root)
            else:
                print(f"❌ Unknown dataset: {name_lower}")
                return None, None, None, {}

            data = dataset[0]
            features = data.x.numpy().astype(np.float32)
            labels = data.y.numpy().astype(np.int64)
            edge_index = data.edge_index.numpy()
            n_nodes = len(features)
            if name_lower in cls._EDGE_INDEX_ONLY_DATASETS or n_nodes > 100_000:
                adjacency_matrix = edge_index
            else:
                adjacency_matrix = np.zeros((n_nodes, n_nodes), dtype=np.uint8)
                adjacency_matrix[edge_index[0], edge_index[1]] = 1

            masks = cls._resolve_masks(data, name_lower, labels, n_nodes)
            if "train_mask" not in masks or "test_mask" not in masks:
                print("❌ Missing required masks")
                return None, None, None, {}

            print(
                f"✅ Loaded: {n_nodes:,} nodes, {features.shape[1]} features, "
                f"{len(np.unique(labels))} classes, {len(edge_index[0]):,} edges"
            )
            print(f"   Train: {masks['train_mask'].sum():,}, Test: {masks['test_mask'].sum():,}")

            return features, adjacency_matrix, labels, masks
        except Exception as e:
            print(f"❌ Error loading {name_lower}: {e}")
            return None, None, None, {}

    @classmethod
    def _resolve_masks(
        cls,
        data,
        name_lower: str,
        labels: np.ndarray,
        n_nodes: int,
    ) -> Dict[str, np.ndarray]:
        masks: Dict[str, np.ndarray] = {}
        for mask_name in ["train_mask", "val_mask", "test_mask"]:
            mask_data = getattr(data, mask_name, None)
            if mask_data is None:
                continue
            try:
                mask_np = mask_data.cpu().numpy() if hasattr(mask_data, "cpu") else mask_data.numpy()
            except AttributeError:
                mask_np = np.asarray(mask_data)
            masks[mask_name] = mask_np

        external_masks = cls._maybe_load_external_splits(name_lower, n_nodes)
        if external_masks:
            # Prefer external splits when they provide more splits than built-ins.
            ext_train = external_masks.get("train_mask")
            cur_train = masks.get("train_mask")
            ext_splits = ext_train.shape[1] if ext_train is not None and ext_train.ndim == 2 else 1
            cur_splits = cur_train.shape[1] if cur_train is not None and cur_train.ndim == 2 else 0
            if ext_splits > cur_splits:
                masks.update(external_masks)
        if not cls._has_required_masks(masks):
            for key, value in external_masks.items():
                if key not in masks and value is not None:
                    masks[key] = value

        if not cls._has_required_masks(masks):
            print("⚠️ Falling back to stratified masks (60/20/20) for missing splits")
            masks = cls._stratified_masks(labels, n_nodes, splits=cls._DEFAULT_SPLIT_COUNT)

        return cls._align_masks(masks, n_nodes)

    @staticmethod
    def _has_required_masks(masks: Dict[str, np.ndarray]) -> bool:
        return "train_mask" in masks and "test_mask" in masks

    @classmethod
    def _maybe_load_external_splits(cls, name_lower: str, n_nodes: int) -> Dict[str, np.ndarray]:
        splits_path = Path(get_data_dir()) / name_lower / f"{name_lower}-splits.npy"
        if not splits_path.exists():
            return {}
        try:
            with open(splits_path, "rb") as fh:
                header = fh.read(6)
            if not header.startswith(b"\x93NUMPY"):
                print(f"⚠️ Ignoring invalid splits file for {name_lower} (unexpected header)")
                return {}
            splits_obj = np.load(splits_path, allow_pickle=True)
            if isinstance(splits_obj, np.ndarray) and splits_obj.dtype == object:
                splits_data = splits_obj.item()
            else:
                splits_data = splits_obj
            if isinstance(splits_data, dict):
                result: Dict[str, np.ndarray] = {}
                for key, value in splits_data.items():
                    if key.endswith("_mask"):
                        arr = np.asarray(value, dtype=bool)
                        result[key] = arr
                return result
            print(f"⚠️ External splits for {name_lower} have unexpected format ({type(splits_data)})")
        except Exception as exc:
            print(f"⚠️ Failed to load external splits for {name_lower}: {exc}")
        return {}

    @staticmethod
    def _align_masks(masks: Dict[str, np.ndarray], n_nodes: int) -> Dict[str, np.ndarray]:
        aligned: Dict[str, np.ndarray] = {}
        if "train_mask" not in masks:
            return aligned
        train_mask = DatasetLoader._ensure_2d_bool(masks["train_mask"], n_nodes)
        n_splits = train_mask.shape[1]
        aligned["train_mask"] = train_mask
        for key in ["val_mask", "test_mask"]:
            mask = masks.get(key)
            if mask is None:
                mask = np.zeros((n_nodes, n_splits), dtype=bool)
            else:
                mask = DatasetLoader._ensure_2d_bool(mask, n_nodes)
                if mask.shape[1] != n_splits:
                    if mask.shape[1] == 1:
                        mask = np.repeat(mask, n_splits, axis=1)
                    else:
                        mask = mask[:, :n_splits]
            aligned[key] = mask.astype(bool)
        aligned["test_mask"] = aligned["test_mask"].astype(bool)
        return aligned

    @staticmethod
    def _ensure_2d_bool(mask: np.ndarray, n_nodes: int) -> np.ndarray:
        arr = np.asarray(mask, dtype=bool)
        if arr.ndim == 1:
            arr = arr.reshape(n_nodes, 1)
        return arr

    @staticmethod
    def _stratified_masks(labels: np.ndarray, n_nodes: int, splits: int = 10,
                          train_frac: float = 0.6, val_frac: float = 0.2,
                          seed: int = 42) -> Dict[str, np.ndarray]:
        rng = np.random.default_rng(seed)
        classes = np.unique(labels)
        train = np.zeros((n_nodes, splits), dtype=bool)
        val = np.zeros((n_nodes, splits), dtype=bool)
        test = np.zeros((n_nodes, splits), dtype=bool)
        for s in range(splits):
            for cls_val in classes:
                cls_idx = np.where(labels == cls_val)[0]
                if cls_idx.size == 0:
                    continue
                rng.shuffle(cls_idx)
                n_train = max(1, int(train_frac * cls_idx.size))
                n_val = max(1, int(val_frac * cls_idx.size))
                n_train = min(n_train, cls_idx.size)
                n_val = min(n_val, cls_idx.size - n_train)
                n_test = cls_idx.size - n_train - n_val
                if n_test <= 0:
                    n_test = cls_idx.size - n_train
                    n_val = 0
                train[cls_idx[:n_train], s] = True
                val[cls_idx[n_train:n_train + n_val], s] = True
                test[cls_idx[n_train + n_val:n_train + n_val + n_test], s] = True
            # ensure disjoint partitions
            val[:, s] &= ~train[:, s]
            test[:, s] &= ~(train[:, s] | val[:, s])
        return {"train_mask": train, "val_mask": val, "test_mask": test}

    # ------------------------------------------------------------------
    @classmethod
    def _cache_dir(cls) -> Path:
        base_root = Path(get_data_dir())
        cache_dir = base_root / "_processed_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir

    @classmethod
    def _cache_key(cls, name_lower: str) -> str:
        if name_lower == "actor":
            platonov = Path(get_data_dir()) / "actor" / "actor_platonov.npz"
            if platonov.exists():
                return f"{name_lower}_platonov_v{cls._CACHE_VERSION}"
        return f"{name_lower}_v{cls._CACHE_VERSION}"

    @classmethod
    def _cache_path(cls, name_lower: str) -> Path:
        return cls._cache_dir() / f"{cls._cache_key(name_lower)}.npz"

    @classmethod
    def _store_disk_cache(cls, name_lower: str, payload: DatasetPayload) -> None:
        cache_path = cls._cache_path(name_lower)
        features, adjacency, labels, masks = payload
        if features is None or adjacency is None or labels is None:
            return
        try:
            payload_dict = {
                "features": features,
                "adjacency": adjacency,
                "labels": labels,
            }
            for mask_name, mask in masks.items():
                payload_dict[mask_name] = mask
            np.savez_compressed(cache_path, **payload_dict)
        except Exception as exc:
            print(f"⚠️ Failed to persist cache for {name_lower}: {exc}")

    @classmethod
    def _try_load_disk_cache(cls, name_lower: str) -> Optional[DatasetPayload]:
        cache_path = cls._cache_path(name_lower)
        if not cache_path.exists():
            return None
        try:
            with np.load(cache_path, allow_pickle=False) as npz:
                features = npz["features"]
                adjacency = npz["adjacency"]
                labels = npz["labels"]
                masks: Dict[str, np.ndarray] = {}
                for mask_name in ["train_mask", "val_mask", "test_mask"]:
                    if mask_name in npz:
                        masks[mask_name] = npz[mask_name]
            return features, adjacency, labels, masks
        except Exception as exc:
            print(f"⚠️ Cache for {name_lower} is unreadable, skipping ({exc})")
            return None

    @staticmethod
    def _describe_payload(payload: DatasetPayload) -> str:
        features, adjacency, labels, masks = payload
        if features is None:
            return "unavailable"
        n_nodes = features.shape[0]
        feat_dim = features.shape[1] if features.ndim > 1 else 0
        edge_estimate = 0
        if adjacency is not None:
            if isinstance(adjacency, np.ndarray):
                if adjacency.ndim == 2 and adjacency.shape[0] == 2:
                    edge_estimate = adjacency.shape[1]
                else:
                    edge_estimate = int(adjacency.sum())
            elif hasattr(adjacency, "nnz"):
                edge_estimate = int(adjacency.nnz)
        return f"{n_nodes} nodes, {feat_dim} feats, ~{edge_estimate} edges"

    # ------------------------------------------------------------------
    @classmethod
    def _load_arxiv_year(cls, root: str) -> DatasetPayload:
        """Load arxiv-year using OGB and cached split masks."""
        processed_dir = Path(get_data_dir()) / "arxiv-year" / "processed"
        cls._ensure_arxiv_processed_from_raw()
        npy_features = processed_dir / "node_feat.npy"
        npy_edges = processed_dir / "edge_index.npy"
        npy_labels = processed_dir / "node_year.npy"
        if npy_features.exists() and npy_edges.exists() and npy_labels.exists():
            return cls._load_arxiv_year_from_numpy(npy_features, npy_edges, npy_labels)

        try:
            from ogb.nodeproppred import NodePropPredDataset
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "The ogb package is required to load arxiv-year. Install it with `pip install ogb`."
            ) from exc

        base_root = Path(get_data_dir())
        ogb_root = base_root / "_ogb"

        import torch

        original_load = torch.load

        def patched_torch_load(*args, **kwargs):
            kwargs.setdefault('weights_only', False)
            return original_load(*args, **kwargs)

        torch.load = patched_torch_load
        try:
            dataset = NodePropPredDataset(name="ogbn-arxiv", root=str(ogb_root))
        finally:
            torch.load = original_load
        graph, labels = dataset[0]

        features = np.asarray(graph["node_feat"], dtype=np.float32)
        edge_index = np.asarray(graph["edge_index"], dtype=np.int64)
        if edge_index.ndim != 2:
            raise RuntimeError(f"Unexpected edge_index shape for arxiv-year: {edge_index.shape}")
        if edge_index.shape[0] != 2 and edge_index.shape[1] == 2:
            edge_index = edge_index.T
        if edge_index.shape[0] != 2:
            raise RuntimeError(f"Failed to coerce edge_index to shape [2, m]; got {edge_index.shape}")

        labels = np.asarray(labels, dtype=np.int64).reshape(-1)
        n_nodes = features.shape[0]
        if labels.shape[0] != n_nodes:
            raise RuntimeError(
                f"Label count mismatch for arxiv-year ({labels.shape[0]} vs {n_nodes})"
            )

        masks = cls._load_arxiv_masks(n_nodes, labels)
        masks = cls._align_masks(masks, n_nodes)
        cls._persist_arxiv_masks(masks, n_nodes)

        print(
            f"✅ Loaded arxiv-year from OGB: {n_nodes:,} nodes, {features.shape[1]} features, "
            f"{edge_index.shape[1]:,} edges"
        )

        return features, edge_index, labels, masks

    @classmethod
    def _ensure_arxiv_processed_from_raw(cls) -> None:
        base_dir = Path(get_data_dir()) / "arxiv-year"
        raw_dir = base_dir / "raw"
        processed_dir = base_dir / "processed"

        if not raw_dir.exists():
            return

        processed_dir.mkdir(parents=True, exist_ok=True)

        feat_path = processed_dir / "node_feat.npy"
        edge_path = processed_dir / "edge_index.npy"
        label_path = processed_dir / "node_year.npy"

        def _read_expected_int(path: Path) -> Optional[int]:
            try:
                return int(path.read_text().strip())
            except Exception:
                return None

        expected_nodes = _read_expected_int(raw_dir / "num-node-list.csv")
        expected_edges = _read_expected_int(raw_dir / "num-edge-list.csv")

        def _processed_is_valid() -> bool:
            if not (feat_path.exists() and edge_path.exists() and label_path.exists()):
                return False
            try:
                feats = np.load(feat_path, mmap_mode="r")
                labels = np.load(label_path, mmap_mode="r")
                edges = np.load(edge_path, mmap_mode="r")
                feats_nodes = feats.shape[0]
                labels_nodes = labels.shape[0]
                if expected_nodes is not None and (
                    feats_nodes != expected_nodes or labels_nodes != expected_nodes
                ):
                    return False

                if expected_edges is not None:
                    if edges.ndim != 2:
                        return False
                    if edges.shape[0] == 2:
                        edge_cols = edges.shape[1]
                    elif edges.shape[1] == 2:
                        edge_cols = edges.shape[0]
                    else:
                        return False
                    if edge_cols != expected_edges:
                        return False
                return True
            except Exception:
                return False

        if _processed_is_valid():
            n_nodes_for_masks = expected_nodes
            if n_nodes_for_masks is None:
                try:
                    n_nodes_for_masks = int(np.load(feat_path, mmap_mode="r").shape[0])
                except Exception:
                    n_nodes_for_masks = None
            if n_nodes_for_masks is not None:
                official_masks = cls._official_arxiv_masks(n_nodes_for_masks, base_dir)
                if official_masks is not None:
                    labels_arr = np.load(label_path, mmap_mode="r")
                    combined = cls._append_random_splits(
                        official_masks,
                        labels_arr,
                        n_nodes_for_masks,
                        extra_splits=10,
                    )
                    cls._persist_arxiv_masks(combined, n_nodes_for_masks)
            return

        feat_csv = raw_dir / "node-feat.csv"
        edge_csv = raw_dir / "edge.csv"
        label_csv = raw_dir / "node-label.csv"

        if not (feat_csv.exists() and edge_csv.exists() and label_csv.exists()):
            return

        features = np.loadtxt(feat_csv, delimiter=",", dtype=np.float32)
        labels = np.loadtxt(label_csv, dtype=np.int64)
        edges = np.loadtxt(edge_csv, delimiter=",", dtype=np.int64)
        if edges.ndim == 1:
            edges = edges.reshape(-1, 2)
        if edges.shape[1] != 2:
            raise RuntimeError(
                f"Unexpected edge.csv shape {edges.shape}; expected two columns"
            )
        edge_index = edges.T

        np.save(feat_path, features.astype(np.float32, copy=False))
        np.save(label_path, labels.astype(np.int64, copy=False))
        np.save(edge_path, edge_index.astype(np.int64, copy=False))

        n_nodes = features.shape[0]
        official_masks = cls._official_arxiv_masks(n_nodes, base_dir)
        if official_masks is not None:
            mask_dict = cls._append_random_splits(official_masks, labels, n_nodes, extra_splits=10)
        else:
            mask_dict = cls._stratified_masks(labels, n_nodes, splits=10)
        cls._persist_arxiv_masks(mask_dict, n_nodes)

    @classmethod
    def _load_arxiv_year_from_numpy(
        cls,
        features_path: Path,
        edges_path: Path,
        labels_path: Path,
    ) -> DatasetPayload:
        features = np.load(features_path).astype(np.float32)
        edge_index = np.load(edges_path).astype(np.int64)
        labels = np.load(labels_path).reshape(-1).astype(np.int64)

        if edge_index.ndim != 2:
            raise RuntimeError(f"Unexpected edge_index shape for arxiv-year: {edge_index.shape}")
        if edge_index.shape[0] != 2 and edge_index.shape[1] == 2:
            edge_index = edge_index.T
        if edge_index.shape[0] != 2:
            raise RuntimeError(
                f"Failed to coerce edge_index to shape [2, m]; got {edge_index.shape}"
            )

        n_nodes = features.shape[0]
        if labels.shape[0] != n_nodes:
            raise RuntimeError(
                f"Label count mismatch for arxiv-year ({labels.shape[0]} vs {n_nodes})"
            )

        masks = cls._load_arxiv_masks(n_nodes, labels, base_dir=Path(get_data_dir()) / "arxiv-year")
        masks = cls._align_masks(masks, n_nodes)
        cls._persist_arxiv_masks(masks, n_nodes)

        print(
            f"✅ Loaded arxiv-year from processed NumPy arrays: {n_nodes:,} nodes, "
            f"{features.shape[1]} features, {edge_index.shape[1]:,} edges"
        )

        return features, edge_index, labels, masks

        if edge_index.ndim != 2:
            raise RuntimeError(f"Unexpected edge_index shape for arxiv-year: {edge_index.shape}")
        if edge_index.shape[0] != 2 and edge_index.shape[1] == 2:
            edge_index = edge_index.T
        if edge_index.shape[0] != 2:
            raise RuntimeError(f"Failed to coerce edge_index to shape [2, m]; got {edge_index.shape}")

        n_nodes = features.shape[0]
        if labels.shape[0] != n_nodes:
            raise RuntimeError(
                f"Label count mismatch for arxiv-year processed artifact ({labels.shape[0]} vs {n_nodes})"
            )
        masks = cls._load_arxiv_masks(n_nodes, labels, base_dir=Path(get_data_dir()) / "arxiv-year")
        masks = cls._align_masks(masks, n_nodes)
        cls._persist_arxiv_masks(masks, n_nodes)

        print(
            f"✅ Loaded arxiv-year from processed PyG artifact: {n_nodes:,} nodes, "
            f"{features.shape[1]} features, {edge_index.shape[1]:,} edges"
        )

        return features, edge_index, labels, masks

    @classmethod
    def _load_arxiv_masks(
        cls,
        n_nodes: int,
        labels: Optional[np.ndarray] = None,
        base_dir: Optional[Path] = None,
    ) -> Dict[str, np.ndarray]:
        base_dir = base_dir or Path(get_data_dir()) / "arxiv-year"
        processed_dir = base_dir / "processed"
        processed_dir.mkdir(parents=True, exist_ok=True)

        mask_files = {
            "train_mask": processed_dir / "train_mask.npy",
            "val_mask": processed_dir / "val_mask.npy",
            "test_mask": processed_dir / "test_mask.npy",
        }

        loaded: Dict[str, np.ndarray] = {}
        processed_ok = True
        for name, path in mask_files.items():
            if not path.exists():
                processed_ok = False
                break
            arr = np.load(path)
            arr = cls._ensure_2d_bool(arr, n_nodes)
            if arr.shape[0] != n_nodes:
                processed_ok = False
                break
            loaded[name] = arr

        if processed_ok and len(loaded) == len(mask_files):
            return loaded

        splits_path = base_dir / "arxiv-year-splits.npy"
        if splits_path.exists():
            try:
                masks = cls._read_arxiv_split_file(splits_path, n_nodes)
                return masks
            except Exception as exc:
                print(f"⚠️ Ignoring arxiv-year split file at {splits_path}: {exc}")

        official_masks = cls._official_arxiv_masks(n_nodes, base_dir)
        if official_masks is not None:
            if labels is not None:
                return cls._append_random_splits(official_masks, labels, n_nodes, extra_splits=10)
            return official_masks

        if labels is None:
            raise RuntimeError(
                "Unable to construct arxiv-year masks (missing processed masks and split file)."
            )

        return cls._stratified_masks(labels, n_nodes, splits=10)

    @classmethod
    def _official_arxiv_masks(
        cls, n_nodes: int, base_dir: Path
    ) -> Optional[Dict[str, np.ndarray]]:
        try:
            from ogb.nodeproppred import NodePropPredDataset
        except ImportError:
            return None

        ogb_root = base_dir.parent / "_ogb"
        try:
            import torch
        except ImportError:
            return None

        original_load = torch.load

        def patched_torch_load(*args, **kwargs):
            kwargs.setdefault("weights_only", False)
            return original_load(*args, **kwargs)

        torch.load = patched_torch_load
        try:
            dataset = NodePropPredDataset(name="ogbn-arxiv", root=str(ogb_root))
            split_idx = dataset.get_idx_split()
        except Exception as exc:
            print(f"⚠️ Failed to obtain official arxiv-year splits via OGB: {exc}")
            return None
        finally:
            torch.load = original_load

        def _to_mask(indices_key: str, target: str) -> np.ndarray:
            idx = split_idx.get(indices_key)
            if idx is None:
                raise KeyError(indices_key)
            if hasattr(idx, "numpy"):
                idx = idx.numpy()
            arr = np.asarray(idx, dtype=np.int64).reshape(-1)
            mask = np.zeros((n_nodes, 1), dtype=bool)
            mask[arr, 0] = True
            return mask

        masks: Dict[str, np.ndarray] = {
            "train_mask": _to_mask("train", "train_mask"),
            "val_mask": _to_mask("valid", "val_mask"),
            "test_mask": _to_mask("test", "test_mask"),
        }
        return masks

    @classmethod
    def _append_random_splits(
        cls,
        base_masks: Dict[str, np.ndarray],
        labels: Optional[np.ndarray],
        n_nodes: int,
        extra_splits: int = 10,
    ) -> Dict[str, np.ndarray]:
        if labels is None or extra_splits <= 0:
            return base_masks

        random_masks = cls._stratified_masks(labels, n_nodes, splits=extra_splits)
        combined: Dict[str, np.ndarray] = {}
        for name, base_mask in base_masks.items():
            base_2d = cls._ensure_2d_bool(base_mask, n_nodes)
            extra = random_masks.get(name)
            if extra is None:
                combined[name] = base_2d
            else:
                combined[name] = np.concatenate([base_2d, extra], axis=1)
        return combined

    @classmethod
    def _persist_arxiv_masks(cls, masks: Dict[str, np.ndarray], n_nodes: int) -> None:
        processed_dir = Path(get_data_dir()) / "arxiv-year" / "processed"
        processed_dir.mkdir(parents=True, exist_ok=True)
        for name, mask in masks.items():
            mask_2d = cls._ensure_2d_bool(mask, n_nodes)
            out_path = processed_dir / f"{name}.npy"
            try:
                if out_path.exists():
                    existing = np.load(out_path)
                    if existing.shape == mask_2d.shape and existing.dtype == mask_2d.dtype:
                        continue
                np.save(out_path, mask_2d.astype(bool, copy=False))
            except Exception as exc:
                print(f"⚠️ Failed to persist arxiv-year {name} mask to {out_path}: {exc}")

    @staticmethod
    def _read_arxiv_split_file(path: Path, n_nodes: int) -> Dict[str, np.ndarray]:
        if not path.exists():
            raise FileNotFoundError(
                f"Expected arxiv-year splits at {path}. Provide the official split file before running."
            )
        try:
            with open(path, "rb") as fh:
                header = fh.read(6)
            if not header.startswith(b"\x93NUMPY"):
                raise RuntimeError(
                    "arxiv-year split file appears to be an HTML download or otherwise invalid. "
                    f"Please place the NumPy file at {path} (download the raw artifact)."
                )
            payload = np.load(path, allow_pickle=True)
            if isinstance(payload, np.ndarray) and payload.dtype == object:
                # Handle arrays of dicts (multiple splits)
                if payload.ndim == 1 and all(isinstance(item, dict) for item in payload):
                    merged: Dict[str, list] = {}
                    for entry in payload:
                        for key, value in entry.items():
                            merged.setdefault(key, []).append(np.asarray(value, dtype=np.int64))
                    payload = {k: np.stack(v, axis=0) for k, v in merged.items()}
                elif payload.size == 1:
                    payload = payload.item(0)
            if not isinstance(payload, dict):
                raise RuntimeError(
                    f"Unexpected arxiv-year splits payload type {type(payload)}; expected a dict with mask arrays."
                )
            masks: Dict[str, np.ndarray] = {}
            key_map = {
                "train_mask": "train_mask",
                "train_masks": "train_mask",
                "train": "train_mask",
                "train_idx": "train_mask",
                "train_indices": "train_mask",
                "valid_mask": "val_mask",
                "valid_masks": "val_mask",
                "valid": "val_mask",
                "val": "val_mask",
                "val_mask": "val_mask",
                "test_mask": "test_mask",
                "test_masks": "test_mask",
                "test": "test_mask",
                "test_idx": "test_mask",
                "test_indices": "test_mask",
            }
            for raw_key, target_key in key_map.items():
                if raw_key not in payload:
                    continue
                mask = DatasetLoader._coerce_mask_array(payload[raw_key], n_nodes)
                if mask is not None:
                    masks[target_key] = mask
            if "train_mask" not in masks or "test_mask" not in masks:
                raise RuntimeError(
                    "arxiv-year splits file does not contain the required train/test information."
                )
            return masks
        except Exception as exc:
            raise RuntimeError(f"Failed to read arxiv-year splits from {path}: {exc}") from exc

    @staticmethod
    def _coerce_mask_array(value: np.ndarray | list, n_nodes: int) -> Optional[np.ndarray]:
        if value is None:
            return None
        arr = np.asarray(value)
        if arr.dtype == bool:
            mask = arr.astype(bool, copy=False)
            if mask.ndim == 1:
                if mask.shape[0] != n_nodes:
                    raise RuntimeError(
                        f"Boolean split mask has length {mask.shape[0]}, expected {n_nodes}."
                    )
                mask = mask.reshape(n_nodes, 1)
            elif mask.shape[0] != n_nodes and mask.shape[-1] == n_nodes:
                mask = mask.reshape((-1, n_nodes)).T
            elif mask.shape[0] != n_nodes:
                raise RuntimeError(
                    f"Boolean split mask has incompatible shape {mask.shape} (expected n_nodes rows)."
                )
            return mask.astype(bool)

        if arr.dtype == object:
            splits = len(arr)
            mask = np.zeros((n_nodes, splits), dtype=bool)
            for split_idx, idx_vals in enumerate(arr):
                idx = np.asarray(idx_vals, dtype=np.int64).reshape(-1)
                idx = idx[idx >= 0]
                mask[idx, split_idx] = True
            return mask

        arr_int = np.asarray(value, dtype=np.int64)
        if arr_int.ndim == 1:
            idx = arr_int.reshape(-1)
            idx = idx[idx >= 0]
            mask = np.zeros((n_nodes, 1), dtype=bool)
            mask[idx, 0] = True
            return mask
        if arr_int.ndim == 2:
            splits = arr_int.shape[0]
            mask = np.zeros((n_nodes, splits), dtype=bool)
            for split_idx in range(splits):
                idx = arr_int[split_idx].reshape(-1)
                idx = idx[idx >= 0]
                mask[idx, split_idx] = True
            return mask
        raise RuntimeError(f"Unsupported split mask representation with shape {arr_int.shape}.")


__all__ = ["DatasetLoader"]
