"""Classifier utilities (request-profile)."""

import numpy as np
import torch
import torch.nn.functional as F

from .config import ExperimentConfig
from .model import ProfileModel


class ProfileClassifier:
    """Classifier using learned embedding space (request-profile, projected, or concat)."""

    def __init__(self, model: ProfileModel, config: ExperimentConfig, features):
        self.model = model
        self.config = config
        self.features = features

    def predict(self, train_labels, train_mask, test_mask):
        print(f"🎯 Classifying with k={self.config.k_neighbors} neighbors using {getattr(self.config,'embedding_type','projected')} embedding...")
        emb_type = getattr(self.config, 'embedding_type', 'projected')
        profile_vectors = self.model.get_profile_vectors()
        if emb_type == 'profile':
            embeddings = profile_vectors
        else:
            with torch.no_grad():
                ft = torch.tensor(self.features, dtype=torch.float32, device=self.model.device)
                proj = self.model.proj_head(self.model.feature_projection(ft))
                proj = F.normalize(proj, dim=1, eps=1e-8).detach().cpu().numpy()
            if emb_type == 'projected':
                embeddings = proj
            elif emb_type == 'concat':
                embeddings = np.concatenate([proj, profile_vectors], axis=1)
            else:
                embeddings = profile_vectors
        train_indices = np.where(train_mask)[0]
        test_indices = np.where(test_mask)[0]
        predictions = {}
        for test_node in test_indices:
            test_vec = embeddings[test_node]
            similarities = []
            for train_node in train_indices:
                train_vec = embeddings[train_node]
                sim = np.dot(test_vec, train_vec) / (
                    np.linalg.norm(test_vec) * np.linalg.norm(train_vec) + 1e-8
                )
                similarities.append(sim)
            similarities = np.array(similarities)
            top_k_idx = np.argsort(similarities)[-self.config.k_neighbors:]
            neighbor_nodes = train_indices[top_k_idx]
            neighbor_labels = train_labels[neighbor_nodes]
            if self.config.use_weighted_voting:
                weights = similarities[top_k_idx]
                weights = weights / (weights.sum() + 1e-8)
                unique_labels = np.unique(neighbor_labels)
                label_scores = {}
                for label in unique_labels:
                    mask = (neighbor_labels == label)
                    label_scores[label] = weights[mask].sum()
                predicted_label = max(label_scores.keys(), key=lambda x: label_scores[x])
            else:
                predicted_label = np.bincount(neighbor_labels).argmax()
            predictions[test_node] = predicted_label
        return predictions


__all__ = ["ProfileClassifier"]
