"""Thin re-export module for backward compatibility.

All core classes are now defined in split modules under `hero.core`.
Importing from this module remains supported temporarily but may be
removed in a future release.
"""

from .baselines import BaselineClassifiers  # noqa: F401
from .classifier import AffinityClassifier  # noqa: F401
from .config import ExperimentConfig, DEVICE  # noqa: F401
from .dataset import DatasetLoader  # noqa: F401
from .model import AffinityModel  # noqa: F401
from .trainer import AffinityTrainer  # noqa: F401

__all__ = [
    "ExperimentConfig",
    "DEVICE",
    "AffinityModel",
    "AffinityTrainer",
    "AffinityClassifier",
    "BaselineClassifiers",
    "DatasetLoader",
]

