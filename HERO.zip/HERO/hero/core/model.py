"""Request-profile model definitions."""

from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class ProfileModel(nn.Module):
    """PyTorch request-profile learning model with edge-only optimization."""

    def __init__(self, n_nodes: int, feature_dim: int, affinity_dim: int, device: str = "cpu"):
        super().__init__()
        self.n_nodes = n_nodes
        self.feature_dim = feature_dim
        self.affinity_dim = affinity_dim
        self.device = device

        # Learnable request-profile vectors for each node
        self.profile_vectors = nn.Parameter(
            torch.randn(n_nodes, affinity_dim, device=device) * 0.1
        )

        # Feature projection layer (+ identity projection head for extensibility)
        self.feature_projection = nn.Linear(feature_dim, affinity_dim).to(device)
        self.proj_head = nn.Identity()

        # Optional prototypes for prototype regularization
        self.prototypes = nn.Parameter(
            torch.randn(32, affinity_dim, device=device) * 0.1
        )

    def forward(self, features: torch.Tensor, edge_list: torch.Tensor | None = None):
        if edge_list is not None:
            return self.compute_edge_profiles(features, edge_list)
        else:
            print("DO NOT COMPUTE FULL MATRIX in ProfileModel line 38 circa")
            #return self.compute_profile_matrix(features)

    def compute_edge_profiles(self, features: torch.Tensor, edge_list: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        projected_features = self.proj_head(self.feature_projection(features))
        projected_features_norm = F.normalize(projected_features, dim=1, eps=1e-8)
        profile_vectors_norm = F.normalize(self.profile_vectors, dim=1, eps=1e-8)

        src_nodes = edge_list[:, 0].long()
        dst_nodes = edge_list[:, 1].long()
        src_features = projected_features_norm[src_nodes]
        dst_profiles = profile_vectors_norm[dst_nodes]
        edge_scores = torch.sum(src_features * dst_profiles, dim=1)
        return edge_scores, src_nodes, dst_nodes

    def compute_profile_matrix(self, features: torch.Tensor) -> torch.Tensor:
        projected_features = self.proj_head(self.feature_projection(features))
        projected_features_norm = F.normalize(projected_features, dim=1, eps=1e-8)
        profile_vectors_norm = F.normalize(self.profile_vectors, dim=1, eps=1e-8)
        return torch.mm(projected_features_norm, profile_vectors_norm.t())

    def prototype_uniformity_loss(self, sample_nodes: torch.Tensor, weight: float = 0.2) -> torch.Tensor:
        a = F.normalize(self.profile_vectors[sample_nodes], dim=1, eps=1e-8)
        p = F.normalize(self.prototypes, dim=1, eps=1e-8)
        logits = a @ p.t()
        assign = torch.softmax(logits, dim=1)
        p_bar = assign.mean(dim=0)
        entropy = -torch.sum(p_bar * torch.log(p_bar + 1e-8)) / p_bar.shape[0]
        return weight * (-entropy)

    def get_profile_vectors(self):
        return self.profile_vectors.detach().cpu().numpy()

    # Structure and label losses are used by the trainer
    def compute_structure_loss_optimized(self, edge_scores, edge_list, n_nodes, features):
        # Positive edge loss on observed edges
        affinity_probs = torch.sigmoid(edge_scores)
        target_probs = torch.ones_like(affinity_probs)
        pos_loss = F.binary_cross_entropy(affinity_probs, target_probs)

        # Sample a small number of non-edges for negative term
        n_pos_edges = int(edge_scores.shape[0])
        n_neg_samples = min(n_pos_edges // 2, 500)
        if n_neg_samples > 10:
            try:
                neg_src = torch.randint(0, n_nodes, (n_neg_samples * 2,), device=self.device)
                neg_dst = torch.randint(0, n_nodes, (n_neg_samples * 2,), device=self.device)
                mask = neg_src != neg_dst
                neg_src = neg_src[mask][:n_neg_samples]
                neg_dst = neg_dst[mask][:n_neg_samples]
                if len(neg_src) > 0:
                    projected_features = self.feature_projection(features.detach())
                    projected_norm = F.normalize(projected_features, dim=1, eps=1e-8)
                    prof_norm = F.normalize(self.profile_vectors, dim=1, eps=1e-8)
                    neg_scores = torch.sum(projected_norm[neg_src] * prof_norm[neg_dst], dim=1)
                    neg_probs = torch.sigmoid(neg_scores)
                    neg_targets = torch.zeros_like(neg_probs)
                    neg_loss = F.binary_cross_entropy(neg_probs, neg_targets)
                    return pos_loss + 0.05 * neg_loss
            except Exception:
                pass
        return pos_loss

    def compute_structure_loss_full(self, profile_matrix, adjacency_matrix):
        n_nodes = profile_matrix.shape[0]
        mask = ~torch.eye(n_nodes, dtype=torch.bool, device=self.device)
        affinity_probs = torch.sigmoid(profile_matrix)
        affinity_flat = affinity_probs[mask]
        adjacency_flat = adjacency_matrix[mask]
        pos_weight = torch.sum(adjacency_flat == 0) / (torch.sum(adjacency_flat == 1) + 1e-8)
        weights = torch.where(adjacency_flat == 1, pos_weight, 1.0)
        return F.binary_cross_entropy(affinity_flat, adjacency_flat, weight=weights)

    def compute_label_loss(self, labels, train_mask):
        train_count = torch.sum(train_mask.float())
        if train_count < 2:
            return torch.tensor(0.0, device=self.device)
        train_indices = torch.where(train_mask)[0]
        train_affinities = self.profile_vectors[train_indices]
        train_labels = labels[train_indices]
        n_train = len(train_indices)
        if n_train <= 150:
            selected_affinities = train_affinities
            selected_labels = train_labels
        else:
            target_samples = 150
            unique_labels = torch.unique(train_labels)
            sampled_indices = []
            samples_per_class = max(1, target_samples // len(unique_labels))
            for label in unique_labels:
                label_mask = train_labels == label
                label_indices = torch.where(label_mask)[0]
                if len(label_indices) <= samples_per_class:
                    sampled_indices.extend(label_indices.tolist())
                else:
                    perm = torch.randperm(len(label_indices))[:samples_per_class]
                    sampled_indices.extend(label_indices[perm].tolist())
            sampled_tensor_indices = torch.tensor(sampled_indices, device=self.device)
            selected_affinities = train_affinities[sampled_tensor_indices]
            selected_labels = train_labels[sampled_tensor_indices]
        n_selected = len(selected_affinities)
        if n_selected < 2:
            return torch.tensor(0.0, device=self.device)
        diff = selected_affinities.unsqueeze(1) - selected_affinities.unsqueeze(0)
        dist = torch.sum(diff * diff, dim=2)
        same_label = (selected_labels.unsqueeze(1) == selected_labels.unsqueeze(0)).float()
        pos_loss = torch.mean(dist * same_label)
        neg_loss = torch.mean(torch.clamp(1.0 - dist, min=0.0) * (1.0 - same_label))
        return 0.1 * pos_loss + 0.05 * neg_loss
