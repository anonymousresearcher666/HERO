"""Trainer definitions for the Affinity model."""

import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim

from .config import ExperimentConfig
from .model import ProfileModel


class ProfileTrainer:
    """Clean PyTorch trainer with automatic optimization selection and debugging."""

    def __init__(self, model: ProfileModel, config: ExperimentConfig):
        self.model = model
        self.config = config
        self.optimizer = optim.Adam(model.parameters(), lr=config.learning_rate)

    def _to_tensor(self, data, dtype=None):
        if not isinstance(data, torch.Tensor):
            if dtype is not None:
                data = torch.tensor(data, dtype=dtype, device=self.model.device)
            else:
                data = torch.tensor(data, device=self.model.device)
        else:
            data = data.to(device=self.model.device)
            if dtype is not None:
                data = data.to(dtype=dtype)
        return data

    def _adjacency_to_edge_list(self, adjacency_matrix):
        edges = np.where(adjacency_matrix > 0)
        return np.column_stack([edges[0], edges[1]])

    def _augment_features(self, features: torch.Tensor, p: float) -> torch.Tensor:
        mask = (torch.rand_like(features) > p).float()
        return features * mask

    def _augment_edges(self, edge_list: torch.Tensor, p: float) -> torch.Tensor:
        if p <= 0:
            return edge_list
        n = edge_list.shape[0]
        k = int((1.0 - p) * n)
        idx = torch.randperm(n, device=self.model.device)[:max(k, 1)]
        return edge_list[idx]

    def _edge_contrastive_loss(self, features, edge_list, batch_size=4096, temperature=0.2):
        # Subsample a manageable batch of edges to avoid O(m^2) logits
        num_edges = edge_list.shape[0]
        if batch_size is not None and num_edges > batch_size:
            idx = torch.randint(0, num_edges, (int(batch_size),), device=self.model.device)
            pair = edge_list[idx]
        else:
            pair = edge_list
        i = pair[:, 0].long()
        j = pair[:, 1].long()
        z = self.model.feature_projection(features)
        z_i = F.normalize(z[i], dim=1, eps=1e-8)
        a_j = F.normalize(self.model.profile_vectors[j], dim=1, eps=1e-8)
        logits = (z_i @ a_j.t()) / max(temperature, 1e-6)
        targets = torch.arange(logits.shape[0], device=self.model.device)
        return F.cross_entropy(logits, targets)

    def _edge_contrastive_loss_two_hop(self, features, edge_list, n_nodes, batch_size=4096, temperature=0.2):
        # Simplified: reuse base loss
        return self._edge_contrastive_loss(features, edge_list, batch_size, temperature)

    def _edge_contrastive_loss_teacher(self, features, edge_list, ema_affinity, batch_size=4096, temperature=0.2):
        return self._edge_contrastive_loss(features, edge_list, batch_size, temperature)

    def train(self, features, adjacency_matrix, labels, train_mask):
        return self._train_edge_optimized(features, adjacency_matrix, labels, train_mask)

    def _train_edge_optimized(self, features, adjacency_matrix, labels, train_mask):
        try:
            edge_list = self._adjacency_to_edge_list(adjacency_matrix)
            features = self._to_tensor(features, torch.float32)
            edge_list = self._to_tensor(edge_list, torch.long)
            labels = self._to_tensor(labels, torch.long)
            train_mask = self._to_tensor(train_mask, torch.bool)
            return self._training_loop(features, labels, train_mask, edge_list=edge_list)
        except Exception:
            return self._train_full_matrix(features, adjacency_matrix, labels, train_mask)

    def _train_full_matrix(self, features, adjacency_matrix, labels, train_mask):
        features = self._to_tensor(features, torch.float32)
        adjacency_matrix = self._to_tensor(adjacency_matrix, torch.float32)
        labels = self._to_tensor(labels, torch.long)
        train_mask = self._to_tensor(train_mask, torch.bool)
        return self._training_loop(features, labels, train_mask, adjacency_matrix=adjacency_matrix)

    def _training_loop(self, features, labels, train_mask, edge_list=None, adjacency_matrix=None):
        # Paper-mode training with symmetric edge loss, hard negatives, and EIC
        if getattr(self.config, 'edge_loss_mode', 'legacy') == 'paper' and edge_list is not None:
            return self._training_loop_paper(features, labels, train_mask, edge_list)
        history = {'total_loss': [], 'structure_loss': [], 'label_loss': [], 'contrastive_loss': []}
        best_loss = float('inf')
        patience_counter = 0
        ema_profile = None
        if getattr(self.config, 'strategy', 'contrastive') == 'contrastive_ema':
            ema_profile = self.model.profile_vectors.detach().clone()
        self.model.train()
        for epoch in range(self.config.epochs):
            self.optimizer.zero_grad()
            if edge_list is not None:
                edge_scores, _, _ = self.model(features, edge_list)
                structure_loss = self.model.compute_structure_loss_optimized(edge_scores, edge_list, self.model.n_nodes, features)
            else:
                profile_matrix = self.model(features)
                structure_loss = self.model.compute_structure_loss_full(profile_matrix, adjacency_matrix)
            if self.config.label_weight > 0:
                label_loss = self.model.compute_label_loss(labels, train_mask)
            else:
                label_loss = torch.tensor(0.0, device=self.model.device)
            contr_loss = torch.tensor(0.0, device=self.model.device)
            strategy = getattr(self.config, 'strategy', 'contrastive')
            if edge_list is not None and self.config.contrastive_weight > 0:
                if strategy == 'contrastive':
                    contr_loss = self._edge_contrastive_loss(features, edge_list, batch_size=4096, temperature=self.config.temperature)
                elif strategy == 'contrastive_aug':
                    f1 = self._augment_features(features, self.config.feature_dropout)
                    f2 = self._augment_features(features, self.config.feature_dropout)
                    e1 = self._augment_edges(edge_list, self.config.edge_dropout)
                    e2 = self._augment_edges(edge_list, self.config.edge_dropout)
                    l1 = self._edge_contrastive_loss(f1, e1, batch_size=4096, temperature=self.config.temperature)
                    l2 = self._edge_contrastive_loss(f2, e2, batch_size=4096, temperature=self.config.temperature)
                    contr_loss = 0.5 * (l1 + l2)
                elif strategy == 'contrastive_proto':
                    base = self._edge_contrastive_loss(features, edge_list, batch_size=4096, temperature=self.config.temperature)
                    b = min(4096, self.model.n_nodes)
                    sample_nodes = torch.randint(0, self.model.n_nodes, (b,), device=self.model.device)
                    proto = self.model.prototype_uniformity_loss(sample_nodes, weight=self.config.proto_weight)
                    contr_loss = base + proto
                elif strategy == 'contrastive_ema':
                    contr_loss = self._edge_contrastive_loss_teacher(features, edge_list, ema_affinity, batch_size=4096, temperature=self.config.temperature)
                elif strategy == 'contrastive_2hop':
                    contr_loss = self._edge_contrastive_loss_two_hop(features, edge_list, self.model.n_nodes, batch_size=4096, temperature=self.config.temperature)
            total_loss = (self.config.structure_weight * structure_loss +
                          self.config.label_weight * label_loss +
                          self.config.contrastive_weight * contr_loss)
            total_loss.backward()
            self.optimizer.step()
            if ema_profile is not None:
                tau = float(getattr(self.config, 'ema_tau', 0.99))
                with torch.no_grad():
                    ema_profile.mul_(tau).add_((1.0 - tau) * self.model.profile_vectors)
            total_val = float(total_loss.cpu())
            history['total_loss'].append(total_val)
            if total_val < best_loss - 1e-8:
                best_loss = total_val
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= int(getattr(self.config, 'early_stopping_patience', 20)):
                    break
        return history

    # ---------------- Paper-mode methods -----------------
    def _normalize_embeddings(self, features):
        z = self.model.feature_projection(features)
        z = F.normalize(z, dim=1, eps=1e-8)
        a = F.normalize(self.model.profile_vectors, dim=1, eps=1e-8)
        return z, a

    def _sample_non_edges_uniform(self, n_nodes: int, num_samples: int, edge_set: set) -> torch.Tensor:
        # Uniformly sample non-edge pairs (i!=j and not in edge_set)
        device = self.model.device
        pairs = []
        tries = 0
        max_tries = num_samples * 10
        while len(pairs) < num_samples and tries < max_tries:
            i = torch.randint(0, n_nodes, (num_samples,), device=device)
            j = torch.randint(0, n_nodes, (num_samples,), device=device)
            mask = (i != j)
            for ii, jj in zip(i[mask].tolist(), j[mask].tolist()):
                if (ii, jj) not in edge_set and (jj, ii) not in edge_set:
                    pairs.append((ii, jj))
                if len(pairs) >= num_samples:
                    break
            tries += 1
        if not pairs:
            return torch.empty((0, 2), dtype=torch.long, device=device)
        return torch.tensor(pairs[:num_samples], dtype=torch.long, device=device)

    def _sample_non_edges_hard(self, z: torch.Tensor, a: torch.Tensor, n_nodes: int, num_samples: int, edge_set: set, degree: torch.Tensor, power: float = 0.75) -> torch.Tensor:
        # Degree-biased proposals for j, pick top compat per i among non-neighbors
        device = self.model.device
        pairs = []
        deg_probs = (degree.float() + 1e-8) ** power
        deg_probs = (deg_probs / deg_probs.sum()).detach().cpu().numpy()
        import numpy as _np
        # Sample anchors i uniformly
        batch_i = torch.randint(0, n_nodes, (num_samples,), device=device).tolist()
        k = 5  # candidates per i
        for ii in batch_i:
            cand_js = _np.random.choice(n_nodes, size=k, replace=True, p=deg_probs)
            # Filter out self and neighbors
            cand_js = [int(jj) for jj in cand_js if jj != ii and (ii, jj) not in edge_set and (jj, ii) not in edge_set]
            if not cand_js:
                continue
            # Score compatibilities using current normalized embeddings
            zi = z[ii]
            scores = torch.mv(a[cand_js], zi)
            jj = cand_js[int(torch.argmax(scores).item())]
            pairs.append((ii, jj))
        if not pairs:
            return torch.empty((0, 2), dtype=torch.long, device=device)
        return torch.tensor(pairs[:num_samples], dtype=torch.long, device=device)

    def _paper_edge_bce_symmetric(self, z: torch.Tensor, a: torch.Tensor, pos_pairs: torch.Tensor,
                                  neg_pairs: torch.Tensor, alpha: float = 1.0) -> torch.Tensor:
        def prob_sym(pairs):
            i = pairs[:, 0].long();
            j = pairs[:, 1].long()
            s1 = torch.sum(z[i] * a[j], dim=1)
            s2 = torch.sum(z[j] * a[i], dim=1)
            p = 0.5 * (torch.sigmoid(alpha * s1) + torch.sigmoid(alpha * s2))
            return p

        p_pos = prob_sym(pos_pairs) if pos_pairs.numel() > 0 else torch.empty(0, device=self.model.device)
        p_neg = prob_sym(neg_pairs) if neg_pairs.numel() > 0 else torch.empty(0, device=self.model.device)

        # Balanced weighting as specified in HERO
        w_pos = 1.0 / max(pos_pairs.size(0), 1)  # w^+ = 1/|E^+|
        w_neg = 1.0 / max(neg_pairs.size(0), 1)  # w^- = 1/|E^-|

        loss_pos = w_pos * F.binary_cross_entropy(p_pos, torch.ones_like(p_pos)) if p_pos.numel() > 0 else torch.tensor(
            0.0, device=self.model.device)
        loss_neg = w_neg * F.binary_cross_entropy(p_neg,
                                                  torch.zeros_like(p_neg)) if p_neg.numel() > 0 else torch.tensor(0.0,
                                                                                                                  device=self.model.device)

        return loss_pos + loss_neg  # No additional 0.5 factor

    def _edge_instance_contrast(self, z: torch.Tensor, a: torch.Tensor, pos_pairs: torch.Tensor, temperature: float = 0.2) -> torch.Tensor:
        # Two noisy views: dropout on z, gaussian on a
        i = pos_pairs[:, 0].long(); j = pos_pairs[:, 1].long()
        drop_p = 0.2
        noise_std = 0.02
        mask1 = (torch.rand_like(z) > drop_p).float()
        mask2 = (torch.rand_like(z) > drop_p).float()
        z1 = F.normalize(z * mask1, dim=1, eps=1e-8)
        z2 = F.normalize(z * mask2, dim=1, eps=1e-8)
        a1 = F.normalize(a + noise_std * torch.randn_like(a), dim=1, eps=1e-8)
        a2 = F.normalize(a + noise_std * torch.randn_like(a), dim=1, eps=1e-8)
        # Scores for positives
        s11 = torch.sum(z1[i] * a1[j], dim=1)  # view1
        s22 = torch.sum(z2[i] * a2[j], dim=1)  # view2
        # Build logits matrix: view1 positives against view2 negatives (other edges in batch)
        v1 = z1[i]  # [B,p]
        v2j = a2[j]  # [B,p]
        logits = (v1 @ v2j.t()) / max(temperature, 1e-6)  # [B,B]
        targets = torch.arange(logits.size(0), device=self.model.device)
        loss12 = F.cross_entropy(logits, targets)
        # Symmetric term: swap roles
        v1b = z2[i]
        v2jb = a1[j]
        logits_b = (v1b @ v2jb.t()) / max(temperature, 1e-6)
        loss21 = F.cross_entropy(logits_b, targets)
        return 0.5 * (loss12 + loss21)

    def _training_loop_paper(self, features, labels, train_mask, edge_list):
        history = {'total_loss': [], 'edge_bce': [], 'eic': []}
        device = self.model.device
        n_nodes = self.model.n_nodes
        # Build edge set and degrees
        e = edge_list.detach().cpu().numpy()
        edge_set = set((int(u), int(v)) for u, v in e.tolist())
        # Degree as float to avoid dtype issues with index_add on some backends (e.g., MPS)
        deg = torch.zeros(n_nodes, device=device, dtype=torch.float32)
        deg.index_add_(0, edge_list[:, 0].long(), torch.ones(edge_list.size(0), device=device, dtype=torch.float32))
        deg.index_add_(0, edge_list[:, 1].long(), torch.ones(edge_list.size(0), device=device, dtype=torch.float32))

        batch_size = int(getattr(self.config, 'edge_batch_size', 4096))
        neg_ratio = float(getattr(self.config, 'neg_ratio', 1.0))
        hard_frac = float(getattr(self.config, 'hard_neg_frac', 0.5))
        eic_temp = float(getattr(self.config, 'eic_temperature', 0.2))
        balance = bool(getattr(self.config, 'balance_losses', False))
        lambda_eic = 1.0
        num_edges = edge_list.size(0)
        # Precompute projected/normalized features once per epoch (updated every epoch by optimizer)
        for epoch in range(self.config.epochs):
            self.optimizer.zero_grad()
            z, a = self._normalize_embeddings(features)
            # Sample positive edges
            idx = torch.randint(0, num_edges, (min(batch_size, num_edges),), device=device)
            pos = edge_list[idx]
            # Sample negatives
            num_neg = int(max(1, neg_ratio * pos.size(0)))
            num_hard = int(hard_frac * num_neg)
            num_uni = num_neg - num_hard
            neg_uni = self._sample_non_edges_uniform(n_nodes, num_uni, edge_set)
            neg_hard = self._sample_non_edges_hard(z, a, n_nodes, num_hard, edge_set, deg)
            if neg_uni.numel() == 0 and neg_hard.numel() == 0:
                neg = torch.empty((0, 2), dtype=torch.long, device=device)
            else:
                neg = torch.cat([x for x in [neg_uni, neg_hard] if x.numel() > 0], dim=0)
            # Compute losses
            edge_bce = self._paper_edge_bce_symmetric(z, a, pos, neg)
            eic_loss = self._edge_instance_contrast(z, a, pos, temperature=eic_temp)
            total = edge_bce + lambda_eic * eic_loss
            # Automatic loss balancing (first epoch)
            if balance and epoch == 0:
                # Compute grad norms for each loss
                self.optimizer.zero_grad(); edge_bce.backward(retain_graph=True)
                g1 = torch.sqrt(sum((p.grad.data**2).sum() for p in self.model.parameters() if p.grad is not None) + 1e-12)
                self.optimizer.zero_grad(); eic_loss.backward(retain_graph=True)
                g2 = torch.sqrt(sum((p.grad.data**2).sum() for p in self.model.parameters() if p.grad is not None) + 1e-12)
                lambda_eic = float(torch.clamp(g1 / (g2 + 1e-12), min=0.1, max=10.0).item())
                self.optimizer.zero_grad(); total = edge_bce + lambda_eic * eic_loss
            total.backward(); self.optimizer.step()
            history['total_loss'].append(float(total.detach().cpu()))
            history['edge_bce'].append(float(edge_bce.detach().cpu()))
            history['eic'].append(float(eic_loss.detach().cpu()))
        return history


__all__ = ["ProfileTrainer"]
