"""Config and device selection for HERO core (request-profile)."""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass
from typing import List

import torch

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')


def _mps_available() -> bool:
    return bool(getattr(torch.backends, 'mps', None) and torch.backends.mps.is_available())


def resolve_device(preferred: str | None = None) -> str:
    """Resolve a canonical device string.

    Supported values are ``cpu``, ``cuda``, and ``mps``. The CLI also accepts
    ``mpw`` as a compatibility alias for Apple Silicon GPU runs.
    """

    if preferred is None or str(preferred).strip() == "":
        if _mps_available():
            return "mps"
        if torch.cuda.is_available():
            return "cuda"
        return "cpu"

    normalized = str(preferred).strip().lower()
    if normalized == "mpw":
        normalized = "mps"
    if normalized not in {"cpu", "cuda", "mps"}:
        raise ValueError(f"Unsupported device override: {preferred!r}")

    if normalized == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available in this environment.")
    if normalized == "mps" and not _mps_available():
        raise RuntimeError("MPS was requested but is not available in this environment.")
    return normalized


DEVICE = resolve_device(os.environ.get("HERO_DEVICE"))
if DEVICE == "mps":
    print("🔥 Using Apple Silicon GPU (MPS)")
elif DEVICE == "cuda":
    print("🚀 Using CUDA GPU")
else:
    print("💻 Using CPU")


@dataclass
class ExperimentConfig:
    """Configuration for request-profile experiments."""
    datasets: List[str] = None
    profile_dim: int = 64  # request-profile dimension
    affinity_dim: int | None = None  # deprecated alias
    learning_rate: float = 0.01
    epochs: int = 200
    early_stopping_patience: int = 20
    structure_weight: float = 1.0
    label_weight: float = 1.0
    contrastive_weight: float = 1.0
    unsupervised: bool = True
    temperature: float = 0.2
    # Strategy: baseline | contrastive | contrastive_aug | contrastive_proto | contrastive_ema | contrastive_2hop
    strategy: str = "contrastive"
    # Augmentations
    feature_dropout: float = 0.2
    edge_dropout: float = 0.2
    # Prototypes (for contrastive_proto)
    proto_count: int = 32
    proto_weight: float = 0.2
    # EMA teacher (for contrastive_ema)
    ema_tau: float = 0.99
    k_neighbors: int = 5
    embedding_type: str = 'projected'  # 'affinity' | 'projected' | 'concat'
    use_weighted_voting: bool = True
    autotune: bool = True
    # Pseudo-labeling options
    pl_enabled: bool = False
    pl_threshold: float = 0.85
    pl_max_rounds: int = 1
    pl_include_val: bool = True
    test_runs: int = 5
    save_results: bool = True
    results_dir: str = "profile_experiments_pytorch"
    # Paper-specific options
    edge_loss_mode: str = "legacy"  # "legacy" | "paper"
    neg_ratio: float = 1.0          # r in r*|E| negatives per batch (paper)
    hard_neg_frac: float = 0.5      # fraction of negatives from hard near-misses
    eic_temperature: float = 0.2    # temperature for EIC InfoNCE
    balance_losses: bool = False    # automatic loss balancing (lambda_eic)
    edge_batch_size: int = 4096     # positive edges per batch in paper mode

    def __post_init__(self):
        if self.datasets is None:
            self.datasets = ['chameleon', 'squirrel', 'roman_empire', 'amazon_ratings']
        # Backwards compatibility: allow affinity_dim to set profile_dim
        if self.affinity_dim is not None and (not hasattr(self, 'profile_dim') or self.profile_dim is None):
            self.profile_dim = int(self.affinity_dim)
        # Ensure affinity_dim mirrors profile_dim for any legacy code
        if self.affinity_dim is None:
            self.affinity_dim = int(self.profile_dim)
        if self.unsupervised:
            self.label_weight = 0.0


__all__ = ["ExperimentConfig", "DEVICE", "resolve_device"]
