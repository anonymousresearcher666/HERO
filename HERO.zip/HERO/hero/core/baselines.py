"""Baseline classifiers."""

import numpy as np

try:  # pragma: no cover - optional dependency
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.preprocessing import StandardScaler
except Exception:  # pragma: no cover - fallback when scikit-learn is unavailable
    class StandardScaler:
        def fit_transform(self, features):
            features = np.asarray(features, dtype=np.float64)
            self.mean_ = features.mean(axis=0, keepdims=True)
            self.scale_ = features.std(axis=0, keepdims=True)
            self.scale_[self.scale_ < 1e-12] = 1.0
            return (features - self.mean_) / self.scale_

    class _NearestCentroidClassifier:
        def __init__(self, *args, **kwargs):
            self.classes_ = None
            self.centroids_ = None
            self.majority_class_ = None

        def fit(self, X, y):
            X = np.asarray(X, dtype=np.float64)
            y = np.asarray(y)
            self.classes_ = np.unique(y)
            self.majority_class_ = int(np.bincount(y.astype(int)).argmax()) if y.size else 0
            centroids = []
            for cls in self.classes_:
                cls_mask = y == cls
                centroids.append(X[cls_mask].mean(axis=0) if cls_mask.any() else np.zeros(X.shape[1]))
            self.centroids_ = np.asarray(centroids, dtype=np.float64)
            return self

        def predict(self, X):
            X = np.asarray(X, dtype=np.float64)
            if self.centroids_ is None or self.classes_ is None or self.classes_.size == 0:
                return np.zeros(X.shape[0], dtype=int)
            dists = ((X[:, None, :] - self.centroids_[None, :, :]) ** 2).sum(axis=-1)
            return self.classes_[dists.argmin(axis=1)]

    LogisticRegression = _NearestCentroidClassifier
    RandomForestClassifier = _NearestCentroidClassifier
    KNeighborsClassifier = _NearestCentroidClassifier

from .config import ExperimentConfig


class BaselineClassifiers:
    def __init__(self, config: ExperimentConfig):
        self.config = config

    def classify_graph_neighbors(self, adjacency_matrix, train_labels, train_mask, test_mask):
        print("📊 Graph neighbors classification...")
        train_indices = np.where(train_mask)[0]
        test_indices = np.where(test_mask)[0]
        predictions = {}
        for test_node in test_indices:
            neighbors = np.where(adjacency_matrix[test_node] > 0)[0]
            train_neighbors = np.intersect1d(neighbors, train_indices)
            if len(train_neighbors) == 0:
                predicted_label = np.bincount(train_labels[train_mask]).argmax()
            else:
                neighbor_labels = train_labels[train_neighbors]
                predicted_label = np.bincount(neighbor_labels).argmax()
            predictions[test_node] = predicted_label
        return predictions

    def classify_feature_similarity(self, features, train_labels, train_mask, test_mask):
        print("📊 Feature similarity classification...")
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        train_indices = np.where(train_mask)[0]
        test_indices = np.where(test_mask)[0]
        predictions = {}
        for test_node in test_indices:
            test_features = features_scaled[test_node]
            similarities = []
            for train_node in train_indices:
                train_features = features_scaled[train_node]
                sim = np.dot(test_features, train_features) / (
                    np.linalg.norm(test_features) * np.linalg.norm(train_features) + 1e-8
                )
                similarities.append(sim)
            similarities = np.array(similarities)
            top_k_idx = np.argsort(similarities)[-self.config.k_neighbors:]
            neighbor_labels = train_labels[train_indices[top_k_idx]]
            predicted_label = np.bincount(neighbor_labels).argmax()
            predictions[test_node] = predicted_label
        return predictions

    def classify_sklearn(self, features, train_labels, train_mask, test_mask, method='logistic'):
        print(f"📊 {method.title()} classification...")
        X_train = features[train_mask]
        y_train = train_labels[train_mask]
        X_test = features[test_mask]
        if method == 'logistic':
            clf = LogisticRegression(max_iter=1000, random_state=42)
        elif method == 'random_forest':
            clf = RandomForestClassifier(n_estimators=100, random_state=42)
        elif method == 'knn':
            clf = KNeighborsClassifier(n_neighbors=self.config.k_neighbors)
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        test_indices = np.where(test_mask)[0]
        return {test_indices[i]: y_pred[i] for i in range(len(test_indices))}


__all__ = ["BaselineClassifiers"]
