"""Core pipeline API for HERO.

Split modules re-exported here for convenience.
"""

from .baselines import BaselineClassifiers
from .classifier import ProfileClassifier
from .config import ExperimentConfig, DEVICE
from .dataset import DatasetLoader
from .model import ProfileModel
from .trainer import ProfileTrainer

__all__ = [
    "ExperimentConfig",
    "DEVICE",
    "DatasetLoader",
    "ProfileModel",
    "ProfileTrainer",
    "ProfileClassifier",
    "BaselineClassifiers",
]
