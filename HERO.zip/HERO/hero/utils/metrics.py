from __future__ import annotations

from typing import Optional, Dict

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


ACC_DATASETS = {"roman_empire", "amazon_ratings"}


def wants_auc(dataset: str) -> bool:
    return dataset.lower() not in ACC_DATASETS


def safe_roc_auc(y_true: np.ndarray, proba: Optional[np.ndarray]) -> Optional[float]:
    """Compute macro ROC-AUC where possible. Returns None if not computable.

    - For binary: expects proba with shape [n, 2] or [n], uses positive class probability.
    - For multiclass: uses one-vs-rest with macro averaging.
    """
    if proba is None:
        return None
    try:
        y_true = np.asarray(y_true)
        if proba.ndim == 1:
            # Binary scores for positive class
            return float(roc_auc_score(y_true, proba))
        C = proba.shape[1]
        if C == 2:
            return float(roc_auc_score(y_true, proba[:, 1]))
        # Multiclass OVR macro
        return float(roc_auc_score(y_true, proba, multi_class="ovr", average="macro"))
    except Exception:
        return None


def compute_standard_metrics(y_true: np.ndarray,
                             y_pred: np.ndarray,
                             proba: Optional[np.ndarray] = None) -> Dict[str, Optional[float]]:
    acc = float(accuracy_score(y_true, y_pred))
    f1 = float(f1_score(y_true, y_pred, average='weighted'))
    auc = safe_roc_auc(y_true, proba)
    return {"acc": acc, "f1": f1, "auc": auc}


def get_primary_metric(metrics: Dict[str, Optional[float]], dataset: str) -> float:
    """Return the score to use for model selection based on the dataset.

    - roman_empire/amazon_ratings: use accuracy.
    - others: prefer ROC-AUC when available; else fall back to accuracy.
    """
    if wants_auc(dataset):
        if metrics.get("auc") is not None:
            return float(metrics["auc"])  # type: ignore[arg-type]
    return float(metrics.get("acc", 0.0))
