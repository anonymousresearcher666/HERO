from __future__ import annotations

import numpy as np
from typing import Tuple
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, cohen_kappa_score


def _normalize_rows(X: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(X, axis=1, keepdims=True) + 1e-8
    return X / n


def compute_profile_effect_size(Z_q: np.ndarray, Z_r: np.ndarray, num_samples: int = 100_000) -> float:
    q = _normalize_rows(Z_q)
    a = _normalize_rows(Z_r)
    n = q.shape[0]
    diag = 0.5 * (1.0 + np.sum(q * a, axis=1))
    rs = np.random.default_rng(42)
    i = rs.integers(0, n, size=num_samples)
    j = rs.integers(0, n, size=num_samples)
    mask = i != j
    i = i[mask]
    j = j[mask]
    off = 0.5 * (1.0 + np.sum(q[i] * a[j], axis=1))
    mu_diag = float(np.mean(diag))
    mu_off = float(np.mean(off))
    s_off = float(np.std(off) + 1e-8)
    return (mu_diag - mu_off) / s_off


def compute_affinity_effect_size(Z_q: np.ndarray, Z_r: np.ndarray, num_samples: int = 100_000) -> float:
    return compute_profile_effect_size(Z_q, Z_r, num_samples)


def _propagate_scores(edge_index: np.ndarray, scores: np.ndarray, alpha: float = 0.1, steps: int = 10) -> np.ndarray:
    n, C = scores.shape
    src, dst = edge_index
    deg = np.bincount(src, minlength=n) + 1e-8
    Y0 = scores.copy()
    Y = scores.copy()
    for _ in range(steps):
        agg = np.zeros_like(Y)
        np.add.at(agg, src, Y[dst])
        Y = (1 - alpha) * Y0 + alpha * (agg / deg[:, None])
    return Y


def _normalize_edge_index(edge_index: np.ndarray, n: int) -> Tuple[np.ndarray, np.ndarray]:
    src, dst = edge_index
    deg = np.bincount(src, minlength=n) + 1e-8
    return deg, (src, dst)


def correct_and_smooth(edge_index: np.ndarray, logits: np.ndarray, y: np.ndarray, train_mask: np.ndarray,
                       alpha_c: float = 0.8, alpha_s: float = 0.8, steps_c: int = 50, steps_s: int = 50) -> np.ndarray:
    n, C = logits.shape
    deg, (src, dst) = _normalize_edge_index(edge_index, n)
    Y_true = np.zeros((n, C))
    Y_true[train_mask, y[train_mask]] = 1.0
    R = np.zeros_like(logits)
    R[train_mask] = Y_true[train_mask] - logits[train_mask]
    R_prop = R.copy()
    for _ in range(steps_c):
        agg = np.zeros_like(R_prop)
        np.add.at(agg, src, R_prop[dst])
        R_prop = (1 - alpha_c) * R + alpha_c * (agg / deg[:, None])
        R_prop[train_mask] = R[train_mask]
    Lc = logits + R_prop
    Y = Lc.copy()
    for _ in range(steps_s):
        agg = np.zeros_like(Y)
        np.add.at(agg, src, Y[dst])
        Y = (1 - alpha_s) * Lc + alpha_s * (agg / deg[:, None])
        Y[train_mask] = Y_true[train_mask]
    return Y


def empirical_propagation_lift(X: np.ndarray, edge_index: np.ndarray, y: np.ndarray,
                               train_mask: np.ndarray, val_mask: np.ndarray) -> float:
    lr = LogisticRegression(max_iter=200, multi_class='auto', n_jobs=1)
    lr.fit(X[train_mask], y[train_mask])
    logits_raw = lr.decision_function(X)
    classes = lr.classes_.astype(int)
    C = int(np.max(y) + 1)
    if logits_raw.ndim == 1:
        logits_raw = np.stack([-logits_raw, logits_raw], axis=1)
        if classes.size == 2 and (set(classes) != {0, 1}):
            mapped = np.zeros((X.shape[0], C))
            mapped[:, classes[0]] = logits_raw[:, 0]
            mapped[:, classes[1]] = logits_raw[:, 1]
            logits = mapped
        else:
            mapped = np.zeros((X.shape[0], C))
            mapped[:, :2] = logits_raw
            logits = mapped
    else:
        logits = np.zeros((X.shape[0], C))
        logits[:, classes] = logits_raw
    smoothed_appnp = _propagate_scores(edge_index, logits)
    y_lr = np.argmax(logits, axis=1)
    y_pp = np.argmax(smoothed_appnp, axis=1)
    acc_lr = accuracy_score(y[val_mask], y_lr[val_mask])
    acc_pp = accuracy_score(y[val_mask], y_pp[val_mask])
    lift_appnp = float(acc_pp - acc_lr)
    smoothed_cs = correct_and_smooth(edge_index, logits, y, train_mask)
    y_cs = np.argmax(smoothed_cs, axis=1)
    acc_cs = accuracy_score(y[val_mask], y_cs[val_mask])
    lift_cs = float(acc_cs - acc_lr)
    return max(lift_appnp, lift_cs)


def pseudo_label_safety(Z: np.ndarray, edge_index: np.ndarray, y: np.ndarray, train_mask: np.ndarray,
                        conf_thr: float = 0.9, k: int = 15) -> Tuple[float, float]:
    lr = LogisticRegression(max_iter=200, multi_class='auto', n_jobs=1)
    lr.fit(Z[train_mask], y[train_mask])
    proba = lr.predict_proba(Z)
    pred_lr = lr.classes_[np.argmax(proba, axis=1)]
    conf_lr = np.max(proba, axis=1)
    ZN = _normalize_rows(Z)
    idx_tr = np.where(train_mask)[0]
    sims = ZN @ ZN[idx_tr].T
    nn_idx = np.argpartition(-sims, kth=min(k, sims.shape[1] - 1), axis=1)[:, :k]
    preds_knn = []
    for i in range(Z.shape[0]):
        neigh = idx_tr[nn_idx[i]]
        labs = y[neigh]
        preds_knn.append(np.bincount(labs, minlength=np.max(y) + 1).argmax())
    pred_knn = np.array(preds_knn)
    n = Z.shape[0]
    src, dst = edge_index
    deg = np.bincount(src, minlength=n) + 1e-8
    C = int(np.max(y) + 1)
    Y = np.zeros((n, C))
    Y[idx_tr, y[idx_tr]] = 1.0
    for _ in range(5):
        agg = np.zeros_like(Y)
        np.add.at(agg, src, Y[dst])
        Y = agg / deg[:, None]
        Y[idx_tr, :] = 0.0
        Y[idx_tr, y[idx_tr]] = 1.0
    pred_lp = np.argmax(Y, axis=1)
    agree = (pred_lr == pred_knn) & (pred_lr == pred_lp) & (conf_lr >= conf_thr)
    coverage = float(np.mean(agree))
    kappa = float(cohen_kappa_score(pred_lr, pred_knn))
    return coverage, kappa


def route_regime(d_aff: float, lift: float, coverage: float, kappa: float) -> str:
    if d_aff < 0 and lift <= 0:
        return 'A'
    if 0 <= d_aff <= 0.2 and coverage >= 0.15:
        return 'B'
    if d_aff > 0.2 and lift > 0:
        return 'C'
    if d_aff > 0.2 and lift <= 0 and coverage >= 0.12 and kappa >= 0.6:
        return 'B'
    return 'undecided'


def route_regime_local(d_aff: float, lift: float, coverage: float, kappa: float,
                       cov_thr: float = 0.08, kappa_thr: float = 0.6, lift_thr: float = 0.0) -> str:
    if d_aff < 0 and lift <= lift_thr:
        return 'A'
    if d_aff > 0.2 and lift > lift_thr:
        return 'C'
    if coverage >= cov_thr and kappa >= kappa_thr:
        return 'B'
    return 'undecided'


__all__ = [
    'compute_profile_effect_size',
    'compute_affinity_effect_size',
    '_propagate_scores',
    'correct_and_smooth',
    'empirical_propagation_lift',
    'pseudo_label_safety',
    'route_regime',
    'route_regime_local',
]

