"""Hierarchical evidence-based profiling utilities for HERO."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

from .router import pseudo_label_safety, empirical_propagation_lift


@dataclass
class ClusterDiagnostics:
    resolution: int
    cluster: int
    nodes: np.ndarray
    diagnostics: Dict[str, float]
    ci95: Dict[str, Tuple[float, float]]
    scores: Dict[str, float]
    probabilities: Dict[str, float]
    metadata: Dict[str, float] = field(default_factory=dict)


def compute_graph_stats(X: np.ndarray, A: np.ndarray, y: np.ndarray, train_mask: np.ndarray) -> Dict[str, float]:
    degrees = np.asarray(A.sum(axis=1)).reshape(-1)
    degree_mean = float(np.mean(degrees))
    degree_std = float(np.std(degrees) + 1e-8)
    density = float(np.count_nonzero(A) / (A.shape[0] * A.shape[0]))
    unique, counts = np.unique(y[train_mask], return_counts=True)
    label_probs = counts / counts.sum() if counts.sum() else np.ones_like(counts) / len(counts)
    label_entropy = float(-(label_probs * np.log(label_probs + 1e-12)).sum())
    return {
        'nodes': float(A.shape[0]),
        'degree_mean': degree_mean,
        'degree_std': degree_std,
        'density': density,
        'label_entropy': label_entropy,
    }


class AdaptiveThresholds:
    def __init__(self, weights: Dict[str, Sequence[float]] | None = None) -> None:
        defaults = {
            'tau_A': [0.05, 0.02, -0.01, 0.1, 0.01, 0.1],
            'tau_B': [0.08, 0.01, 0.0, 0.05, 0.0, 0.15],
            'tau_C': [0.6, -0.05, 0.02, 0.0, 0.1, 0.2],
        }
        self.weights = weights or defaults

    def _linear(self, key: str, stats_vec: Sequence[float]) -> float:
        coeffs = self.weights.get(key, [])
        bias = coeffs[-1] if coeffs else 0.0
        return float(np.dot(coeffs[:-1], stats_vec)) + bias if coeffs else 0.0

    def __call__(self, stats: Dict[str, float]) -> Dict[str, float]:
        vec = np.array([
            math.log1p(stats.get('nodes', 1.0)),
            stats.get('degree_mean', 0.0),
            stats.get('degree_std', 0.0),
            stats.get('density', 0.0),
            stats.get('label_entropy', 0.0),
        ], dtype=float)
        tau_A = max(0.05, self._linear('tau_A', vec))
        tau_B = max(tau_A + 0.05, self._linear('tau_B', vec))
        tau_C = min(0.95, max(0.1, self._linear('tau_C', vec)))
        return {'A': tau_A, 'B': tau_B, 'C': tau_C}


class SharedEstimators:
    def __init__(self, util_params: Sequence[float] | None = None, safety_params: Sequence[float] | None = None,
                 util_unc: float = 0.05, safety_unc: float = 0.05) -> None:
        self.util_params = np.array(util_params or [0.0, 0.02, -0.01, -0.03, 0.15])
        self.safety_params = np.array(safety_params or [0.6, 0.05, 0.02, -0.01, 0.0])
        self.util_unc = util_unc
        self.safety_unc = safety_unc

    def _feature_vec(self, features: Dict[str, float]) -> np.ndarray:
        return np.array([
            features.get('size', 1.0),
            features.get('density', 0.0),
            features.get('boundary_ratio', 0.0),
            features.get('emb_variance', 0.0),
        ], dtype=float)

    def predict_utility(self, features: Dict[str, float]) -> Tuple[float, float]:
        vec = self._feature_vec(features)
        value = float(np.dot(self.util_params[:-1], vec) + self.util_params[-1])
        return value, self.util_unc

    def predict_safety(self, features: Dict[str, float]) -> Tuple[float, float]:
        vec = self._feature_vec(features)
        logits = float(np.dot(self.safety_params[:-1], vec) + self.safety_params[-1])
        value = 1.0 / (1.0 + math.exp(-logits))
        return value, self.safety_unc

    def needs_validation(self, variance: float, threshold: float = 0.02) -> bool:
        return variance > threshold


def _bootstrap_mean_diff(sample_a: np.ndarray, sample_b: np.ndarray, num_samples: int = 64) -> Tuple[float, float]:
    base = float(sample_a.mean() - sample_b.mean())
    if sample_a.size == 0 or sample_b.size == 0:
        return base, 0.0
    diffs = []
    rng = np.random.default_rng(42)
    for _ in range(num_samples):
        samp_a = rng.choice(sample_a, size=sample_a.size, replace=True)
        samp_b = rng.choice(sample_b, size=sample_b.size, replace=True)
        diffs.append(samp_a.mean() - samp_b.mean())
    diffs = np.sort(diffs)
    lower = float(diffs[int(0.025 * len(diffs))])
    upper = float(diffs[int(0.975 * len(diffs))])
    return base, (upper - lower) / 2.0


class HierarchicalProfiler:
    def __init__(self, stats: Dict[str, float], thresholds: AdaptiveThresholds,
                 estimators: SharedEstimators, bootstrap_samples: int = 64,
                 validation_threshold: float = 0.02) -> None:
        self.stats = stats
        self.thresholds = thresholds(stats)
        self.estimators = estimators
        self.bootstrap_samples = bootstrap_samples
        self.validation_threshold = validation_threshold

    def _compatibility(self, qn: np.ndarray, rn: np.ndarray) -> np.ndarray:
        return (qn @ rn.T + 1.0) * 0.5

    def profile(self, resolutions: Sequence[int], rn: np.ndarray, qn: np.ndarray,
                X: np.ndarray, y: np.ndarray, Z: np.ndarray,
                train_mask: np.ndarray, val_mask: np.ndarray,
                edge_index: np.ndarray, adjacency: np.ndarray) -> Tuple[List[ClusterDiagnostics], List[Tuple[int, np.ndarray, np.ndarray]]]:
        compat_matrix = self._compatibility(qn, rn)
        diag_list: List[ClusterDiagnostics] = []
        clustering_info: List[Tuple[int, np.ndarray, np.ndarray]] = []
        rng = np.random.default_rng(0)

        for resolution in resolutions:
            km = KMeans(n_clusters=resolution, n_init=10, random_state=42)
            labels = km.fit_predict(rn)
            centroids = km.cluster_centers_
            clustering_info.append((resolution, labels, centroids))
            for cluster_id in range(resolution):
                idx = np.where(labels == cluster_id)[0]
                if idx.size == 0:
                    continue
                mask_nodes = np.zeros(rn.shape[0], dtype=bool)
                mask_nodes[idx] = True
                inside = compat_matrix[np.ix_(idx, idx)].reshape(-1)
                outside_idx = np.where(~mask_nodes)[0]
                if outside_idx.size == 0:
                    outside = np.zeros_like(inside)
                else:
                    outside = compat_matrix[np.ix_(idx, rng.choice(outside_idx, size=min(len(outside_idx), len(idx)), replace=True))].reshape(-1)

                d_value, d_ci = _bootstrap_mean_diff(inside, outside, self.bootstrap_samples)
                coverage = float(np.mean(train_mask[idx]))

                # cluster features
                edges_within = adjacency[np.ix_(idx, idx)].sum() / 2
                possible_edges = idx.size * max(1, idx.size - 1) / 2
                density = float(edges_within / (possible_edges + 1e-8))
                boundary_edges = adjacency[np.ix_(idx, ~mask_nodes)].sum()
                boundary_ratio = float(boundary_edges / (edges_within + boundary_edges + 1e-8))
                emb_var = float(np.var(Z[idx], axis=0).mean())

                features = {
                    'size': float(idx.size),
                    'density': density,
                    'boundary_ratio': boundary_ratio,
                    'emb_variance': emb_var,
                }

                g_pred, g_var = self.estimators.predict_utility(features)
                if self.estimators.needs_validation(g_var, self.validation_threshold):
                    g_value = empirical_propagation_lift(X, edge_index, y, train_mask & mask_nodes, val_mask & mask_nodes)
                else:
                    g_value = g_pred

                c_pred, c_var = self.estimators.predict_safety(features)
                if self.estimators.needs_validation(c_var, self.validation_threshold):
                    mask_edges = mask_nodes[edge_index[0]] & mask_nodes[edge_index[1]]
                    ei_sub = edge_index[:, mask_edges]
                    remap = -np.ones(rn.shape[0], dtype=int)
                    remap[idx] = np.arange(idx.size)
                    ei_loc = np.vstack([remap[ei_sub[0]], remap[ei_sub[1]]])
                    _, c_value = pseudo_label_safety(Z[idx], ei_loc, y[idx], (train_mask & mask_nodes)[idx])
                    if isinstance(c_value, float) and (math.isnan(c_value) or math.isinf(c_value)):
                        c_value = c_pred
                else:
                    c_value = c_pred

                tau = self.thresholds
                score_A = -(d_value - tau['A'])
                score_B = -(abs(d_value - tau['B'])) + c_value - tau['C']
                score_C = (d_value - tau['B']) + g_value
                scores = np.array([score_A, score_B, score_C], dtype=float)
                uncertainty = max(1e-3, d_ci + g_var + c_var)
                scaled = scores / (1.0 + uncertainty)
                scaled = scaled - scaled.max()
                probs = np.exp(scaled)
                total = probs.sum()
                if total <= 0 or not np.isfinite(total):
                    probs = np.array([1.0, 0.0, 0.0], dtype=float)
                else:
                    probs = probs / total
                regimes = ['A', 'B', 'C']
                regime_probs = {r: float(p) for r, p in zip(regimes, probs)}
                regime_scores = {r: float(s) for r, s in zip(regimes, scores)}

                diagnostics = {
                    'd_nrp': d_value,
                    'g': g_value,
                    'c': c_value,
                    'coverage': coverage,
                    'density': density,
                    'boundary_ratio': boundary_ratio,
                    'emb_variance': emb_var,
                }
                ci95 = {'d_nrp': d_ci}

                diag_list.append(ClusterDiagnostics(
                    resolution=resolution,
                    cluster=cluster_id,
                    nodes=idx,
                    diagnostics=diagnostics,
                    ci95=ci95,
                    scores=regime_scores,
                    probabilities=regime_probs,
                    metadata={'g_var': g_var, 'c_var': c_var}
                ))
        return diag_list, clustering_info


# Lazy import to avoid circular dependency inside module
from sklearn.cluster import KMeans  # noqa: E402
