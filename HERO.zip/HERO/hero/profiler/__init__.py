"""Dataset profiling utilities to assess homophily/heterophily.

Use `hero.runners.profiler` to run and save a profile report.
"""

from .profile import DatasetProfiler  # noqa: F401

