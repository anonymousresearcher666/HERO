"""Dataset profiler: computes homophily/heterophily profile.

Metrics use structure, features, and training labels to inform strategy.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Dict, Any, Tuple

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from hero.core.dataset import DatasetLoader


def _edge_homophily_train(adj: np.ndarray, labels: np.ndarray, train_mask: np.ndarray) -> float:
    edges = np.where(adj > 0)
    same = 0
    total = 0
    for i, j in zip(edges[0], edges[1]):
        if train_mask[i] and train_mask[j]:
            total += 1
            if labels[i] == labels[j]:
                same += 1
    return float(same / total) if total > 0 else 0.0


def _node_homophily_train(adj: np.ndarray, labels: np.ndarray, train_mask: np.ndarray) -> float:
    vals = []
    for i in np.where(train_mask)[0]:
        neigh = np.where(adj[i] > 0)[0]
        neigh = neigh[train_mask[neigh]]
        if len(neigh) == 0:
            continue
        same = np.sum(labels[neigh] == labels[i])
        vals.append(same / len(neigh))
    return float(np.mean(vals)) if vals else 0.0


def _train_val_split(train_mask: np.ndarray, val_mask: np.ndarray | None, seed: int = 42) -> Tuple[np.ndarray, np.ndarray]:
    if val_mask is not None and val_mask.any():
        return train_mask, val_mask
    rng = np.random.default_rng(seed)
    idx = np.where(train_mask)[0]
    if idx.size < 5:
        return train_mask, np.zeros_like(train_mask, dtype=bool)
    rng.shuffle(idx)
    k = max(1, int(0.2 * len(idx)))
    val = np.zeros_like(train_mask, dtype=bool)
    val[idx[:k]] = True
    tr = train_mask.copy()
    tr[val] = False
    return tr, val


def _feature_logistic_acc(X: np.ndarray, y: np.ndarray, tr: np.ndarray, va: np.ndarray) -> float:
    if not va.any() or not tr.any():
        return 0.0
    clf = LogisticRegression(max_iter=1000)
    clf.fit(X[tr], y[tr])
    return float((clf.predict(X[va]) == y[va]).mean())


def _feature_knn_acc(X: np.ndarray, y: np.ndarray, tr: np.ndarray, va: np.ndarray, k: int = 25) -> float:
    if not va.any() or not tr.any():
        return 0.0
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    tr_idx = np.where(tr)[0]
    va_idx = np.where(va)[0]
    acc = []
    for i in va_idx:
        sims = Xs[tr_idx] @ Xs[i]
        sims = sims / (np.linalg.norm(Xs[tr_idx], axis=1) * (np.linalg.norm(Xs[i]) + 1e-8) + 1e-8)
        kk = min(k, len(tr_idx))
        nn = tr_idx[np.argsort(sims)[-kk:]]
        pred = np.bincount(y[nn]).argmax()
        acc.append(int(pred == y[i]))
    return float(np.mean(acc)) if acc else 0.0


def _graph_neighbor_acc(adj: np.ndarray, y: np.ndarray, tr: np.ndarray, va: np.ndarray) -> float:
    va_idx = np.where(va)[0]
    tr_idx = np.where(tr)[0]
    tr_set = set(tr_idx.tolist())
    if not va_idx.size or not tr_idx.size:
        return 0.0
    ok = []
    for i in va_idx:
        neigh = np.where(adj[i] > 0)[0]
        train_neigh = [j for j in neigh if j in tr_set]
        if len(train_neigh) == 0:
            pred = np.bincount(y[tr_idx]).argmax()
        else:
            pred = np.bincount(y[train_neigh]).argmax()
        ok.append(int(pred == y[i]))
    return float(np.mean(ok))


def _adjusted_homophily_train(adj: np.ndarray, y: np.ndarray, tr: np.ndarray) -> float:
    idx = np.where(tr)[0]
    if idx.size == 0:
        return 0.0
    A = adj[np.ix_(idx, idx)]
    labels = y[idx]
    # edge homophily on train subgraph
    edges = np.where(A > 0)
    total_edges = len(edges[0])
    if total_edges == 0:
        return 0.0
    same = 0
    for i, j in zip(edges[0], edges[1]):
        if labels[i] == labels[j]:
            same += 1
    h_edge = same / total_edges
    # adjusted term
    degrees = A.sum(axis=1)
    Dk2 = 0.0
    for c in np.unique(labels):
        Dk = float(degrees[labels == c].sum())
        Dk2 += Dk * Dk
    denom = (2 * total_edges) ** 2
    term = Dk2 / denom if denom > 0 else 0.0
    if term >= 1.0:
        return 0.0
    return float((h_edge - term) / (1.0 - term))


def _label_informativeness_train(adj: np.ndarray, y: np.ndarray, tr: np.ndarray) -> float:
    # Mutual information of endpoint labels over train edges divided by entropy of labels
    idx = np.where(tr)[0]
    if idx.size == 0:
        return 0.0
    A = adj[np.ix_(idx, idx)]
    labels = y[idx]
    from collections import Counter
    # Entropy of labels
    counts = Counter(labels.tolist())
    total = sum(counts.values())
    probs = [c / total for c in counts.values()]
    import math
    H_y = -sum(p * math.log(p + 1e-12, 2) for p in probs) if total > 0 else 0.0
    if H_y == 0.0:
        return 0.0
    # Joint distribution over edges (undirected treated once)
    pairs = []
    edges = np.where(A > 0)
    for i, j in zip(edges[0], edges[1]):
        if i <= j:
            continue
        pairs.append((int(labels[i]), int(labels[j])))
    if not pairs:
        return 0.0
    joint = Counter(pairs)
    m = sum(joint.values())
    mi = 0.0
    for (a, b), c in joint.items():
        p_ab = c / m
        p_a = counts.get(a, 0) / total
        p_b = counts.get(b, 0) / total
        if p_ab > 0 and p_a > 0 and p_b > 0:
            mi += p_ab * math.log(p_ab / (p_a * p_b + 1e-12) + 1e-12, 2)
    return float(mi / H_y)


class DatasetProfiler:
    """Compute a profile for a dataset and save it to results/..../profiler."""

    def __init__(self, results_root: str = 'results') -> None:
        self.results_root = results_root

    def profile(self, dataset: str, tag: str | None = None, seed: int = 42) -> Dict[str, Any]:
        X, adj, y, masks = DatasetLoader.load_dataset(dataset)
        if X is None:
            raise RuntimeError(f"Failed to load dataset: {dataset}")

        tm = masks['train_mask'][:, 0] if masks['train_mask'].ndim == 2 else masks['train_mask']
        vm = masks.get('val_mask')
        if vm is not None:
            vm = vm[:, 0] if vm.ndim == 2 else vm
        tr, va = _train_val_split(tm, vm, seed=seed)

        # Structure metrics (train-label aware)
        edge_h_train = _edge_homophily_train(adj, y, tr)
        node_h_train = _node_homophily_train(adj, y, tr)
        adj_h_train = _adjusted_homophily_train(adj, y, tr)
        li_train = _label_informativeness_train(adj, y, tr)

        # Feature metrics
        feat_lr_acc = _feature_logistic_acc(X, y, tr, va)
        feat_knn_acc = _feature_knn_acc(X, y, tr, va, k=25)
        graph_nb_acc = _graph_neighbor_acc(adj, y, tr, va)

        # Simple structure stats
        n_nodes = X.shape[0]
        n_edges = int(adj.sum())
        density = n_edges / max(1, (n_nodes * (n_nodes - 1)))
        degs = adj.sum(axis=1)
        avg_deg = float(np.mean(degs))
        class_dist = {int(c): int(cnt) for c, cnt in zip(*np.unique(y, return_counts=True))}
        train_frac = float(tr.mean())

        # Heuristic recommendation (refined)
        d_feat_graph = feat_lr_acc - graph_nb_acc
        d_knn_graph = feat_knn_acc - graph_nb_acc
        rec = "affinity_contrastive"
        reason = []
        if (edge_h_train >= 0.55 or adj_h_train >= 0.50) and graph_nb_acc >= feat_lr_acc + 0.02:
            rec = "spectral_lp"
            reason.append("high homophily + graph neighbors >= features")
        elif (edge_h_train <= 0.25 or adj_h_train <= 0.20) and (feat_lr_acc >= 0.65 or d_feat_graph >= 0.05):
            rec = "affinity_pl"
            reason.append("heterophily + features strong vs graph")
        else:
            reason.append("balanced; defaulting to affinity_contrastive")
        if li_train < 0.03 and rec == "spectral_lp":
            rec = "affinity_contrastive"
            reason.append("low label informativeness; avoid spectral")

        report = {
            'dataset': dataset,
            'n_nodes': n_nodes,
            'n_edges': n_edges,
            'density': float(density),
            'avg_degree': avg_deg,
            'class_distribution': class_dist,
            'train_fraction': train_frac,
            'edge_homophily_train': edge_h_train,
            'node_homophily_train': node_h_train,
            'feature_logistic_acc_val': feat_lr_acc,
            'feature_knn_acc_val': feat_knn_acc,
            'graph_neighbor_acc_val': graph_nb_acc,
            'adjusted_edge_homophily_train': adj_h_train,
            'label_informativeness_train': li_train,
            'delta_feature_vs_graph': d_feat_graph,
            'delta_knn_vs_graph': d_knn_graph,
            'recommended_module': rec,
            'recommendation_reason': "; ".join(reason),
        }

        # Save report
        tag = tag or datetime.now().strftime('%Y%m%d_%H%M%S')
        out_dir = os.path.join(self.results_root, dataset, 'profiler', tag)
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, 'profile.json'), 'w') as f:
            json.dump(report, f, indent=2)
        return report
