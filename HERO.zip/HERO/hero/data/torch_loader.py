import os

import numpy as np
from torch_geometric.datasets import WikipediaNetwork, Planetoid, KarateClub, HeterophilousGraphDataset


class Edges:
    def __init__(self, src, dst, n_nodes=None):
        assert len(src) == len(dst)
        self.src = np.asarray(src, dtype=np.int64)
        self.dst = np.asarray(dst, dtype=np.int64)
        self.m = len(self.src)
        if n_nodes is None:
            self.n = int(max(self.src.max(initial=0), self.dst.max(initial=0)) + 1)
        else:
            self.n = int(n_nodes)

    def to_undirected(self):
        return Edges(
            np.concatenate([self.src, self.dst]),
            np.concatenate([self.dst, self.src]),
            n_nodes=self.n
        )

    def neighbors_sets(self):
        neigh = [set() for _ in range(self.n)]
        for i,j in zip(self.src, self.dst):
            neigh[int(i)].add(int(j))
        return neigh

def load_features(path: str) -> np.ndarray:
    X = np.load(path).astype(np.float32, copy=False)
    assert X.ndim == 2
    return X

def load_edges(path: str) -> Edges:
    src, dst = [], []
    with open(path, "r") as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith("#"):
                continue
            a,b = line.split()
            src.append(int(a)); dst.append(int(b))
    return Edges(np.array(src), np.array(dst))


def load_torch_dataset(name: str, root: str = "data"):
    """Load a named dataset via torch_geometric.

    Parameters
    ----------
    name: str
        Dataset name such as "squirrel" or "chameleon".
    root: str
        Directory where the dataset should be stored/downloaded.

    Returns
    -------
    tuple[np.ndarray, Edges, int, np.ndarray]
        The feature matrix X, edge list Edges, number of classes, and labels for the dataset.
    """
    print(f"Loading dataset: {name}")

    name_lc = name.lower()

    try:
        # Create root directory if it doesn't exist
        os.makedirs(root, exist_ok=True)

        # Load appropriate dataset
        if name_lc in {"chameleon", "squirrel", "crocodile"}:
            ds = WikipediaNetwork(root=root, name=name_lc.capitalize())
        elif name_lc in {"cora", "citeseer", "pubmed"}:
            ds = Planetoid(root=root, name=name_lc.capitalize())
        elif name_lc in {"karate", "karateclub"}:
            ds = KarateClub()
        elif name_lc in {'roman_empire', 'amazon_ratings', 'minesweeper', 'tolokers', 'questions'}:
            # Handle potential corrupted downloads for HeterophilousGraphDataset
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    if attempt > 0:
                        print(f"Retry attempt {attempt} for {name_lc}")
                        # Clear potentially corrupted files
                        import glob
                        dataset_files = glob.glob(os.path.join(root, f"{name_lc}*"))
                        for file_path in dataset_files:
                            try:
                                if os.path.isfile(file_path):
                                    os.remove(file_path)
                                    print(f"Removed corrupted file: {file_path}")
                            except:
                                pass

                    ds = HeterophilousGraphDataset(root=root, name=name_lc)
                    break  # Success, exit retry loop

                except Exception as e:
                    if "zip file" in str(e).lower() or "corrupted" in str(e).lower():
                        if attempt < max_retries - 1:
                            print(f"Download corrupted for {name_lc}, retrying...")
                            continue
                        else:
                            raise ValueError(f"Failed to download {name_lc} after {max_retries} attempts. "
                                             f"Please check your internet connection or try manually clearing "
                                             f"the {root} directory.")
                    else:
                        raise e
        else:
            raise ValueError(f"Unknown dataset: {name}. Supported datasets: "
                             f"chameleon, squirrel, crocodile, cora, citeseer, pubmed, "
                             f"karate, roman_empire, amazon_ratings, minesweeper, tolokers, questions")

        # Get the first (and usually only) graph from the dataset
        data = ds[0]

        print(f"Data object attributes: {[attr for attr in dir(data) if not attr.startswith('_')]}")
        print(f"Data object: {data}")

        # Extract features (x attribute)
        if hasattr(data, 'x') and data.x is not None:
            X = np.asarray(data.x.detach().cpu(), dtype=np.float32)
            print(f"Features shape: {X.shape}")
        else:
            print(f"Warning: No features found for {name}, creating identity matrix")
            num_nodes = data.num_nodes if hasattr(data, 'num_nodes') else len(data.y)
            X = np.eye(num_nodes, dtype=np.float32)

        # Extract labels (y attribute)
        if hasattr(data, 'y') and data.y is not None:
            labels = np.asarray(data.y.detach().cpu(), dtype=np.int64)
            n_classes = int(labels.max()) + 1
            print(f"Labels shape: {labels.shape}, Classes: {n_classes}")
        else:
            print(f"Warning: No labels found for {name}, creating random labels")
            n_classes = 2  # Default to binary classification
            num_nodes = X.shape[0] if X is not None else data.num_nodes
            labels = np.random.randint(0, n_classes, num_nodes)

        # Extract edges (edge_index attribute)
        if hasattr(data, 'edge_index') and data.edge_index is not None:
            edge_index = np.asarray(data.edge_index.detach().cpu(), dtype=np.int64)
            print(f"Edge index shape: {edge_index.shape}")

            # Ensure edge_index is [2, num_edges]
            if edge_index.shape[0] != 2:
                if edge_index.shape[1] == 2:
                    edge_index = edge_index.T
                else:
                    raise ValueError(f"Invalid edge_index shape: {edge_index.shape}")
        else:
            raise ValueError(f"No edge_index found for dataset {name}")

        # Validate edge indices
        num_nodes = X.shape[0]
        max_node_idx = max(edge_index[0].max(), edge_index[1].max())
        if max_node_idx >= num_nodes:
            raise ValueError(f"Edge indices contain invalid node IDs. Max: {max_node_idx}, "
                             f"but only {num_nodes} nodes exist.")

        # Validate labels length
        if len(labels) != num_nodes:
            print(f"Warning: Label count ({len(labels)}) != node count ({num_nodes})")
            if len(labels) > num_nodes:
                labels = labels[:num_nodes]
            else:
                # Pad with most common label
                most_common_label = np.bincount(labels).argmax()
                labels = np.pad(labels, (0, num_nodes - len(labels)),
                                constant_values=most_common_label)

        print(f"Successfully loaded {name}: {num_nodes} nodes, {X.shape[1]} features, "
              f"{edge_index.shape[1]} edges, {n_classes} classes")

        # Create Edges object
        edges = Edges(edge_index[0], edge_index[1], n_nodes=num_nodes)

        return X, edges, n_classes, labels

    except Exception as e:
        print(f"Error loading dataset {name}: {e}")
        import traceback
        traceback.print_exc()
        raise RuntimeError(f"Failed to load dataset {name}: {e}")