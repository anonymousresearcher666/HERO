"""External dataset loaders for heterophilous benchmarks.

These loaders place files under HERO/data and convert them to the standard
format: (features np.ndarray [n,d], adjacency as dense np.ndarray [n,n],
labels as np.ndarray [n], masks dict with boolean arrays for train/val/test).

Where available, they use PyG dataset classes; otherwise they expect cached
files under HERO/data/<dataset>/ and provide guidance if missing.
"""

from __future__ import annotations

import os
from typing import Tuple, Dict, List, Optional
import numpy as np
from hero.paths import get_data_dir


def _dense_adj(edge_index: np.ndarray, n: int) -> np.ndarray:
    A = np.zeros((n, n), dtype=np.float32)
    if edge_index is not None and edge_index.size > 0:
        A[edge_index[0], edge_index[1]] = 1.0
    return A


def _stratified_masks(y: np.ndarray, train_frac=0.6, val_frac=0.2, seed=42) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    n = len(y)
    idxs = np.arange(n)
    train = np.zeros(n, dtype=bool)
    val = np.zeros(n, dtype=bool)
    test = np.zeros(n, dtype=bool)
    for c in np.unique(y):
        cls_idx = idxs[y == c]
        rng.shuffle(cls_idx)
        n_train = int(train_frac * len(cls_idx))
        n_val = int(val_frac * len(cls_idx))
        train[cls_idx[:n_train]] = True
        val[cls_idx[n_train:n_train+n_val]] = True
        test[cls_idx[n_train+n_val:]] = True
    return {'train_mask': train, 'val_mask': val, 'test_mask': test}


def load_webkb_split(name_lower: str, root: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    from torch_geometric.datasets import WebKB
    base = get_data_dir()
    ds = WebKB(root=base, name=name_lower.capitalize())
    data = ds[0]
    X = data.x.numpy().astype(np.float32)
    y = data.y.numpy().astype(np.int64)
    ei = data.edge_index.numpy()
    A = _dense_adj(ei, X.shape[0])
    masks = {}
    for k in ['train_mask','val_mask','test_mask']:
        if hasattr(data, k):
            masks[k] = getattr(data, k).numpy().astype(bool)
    if not masks:
        masks = _stratified_masks(y)
    return X, A, y, masks


def load_actor_split(root: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    base = get_data_dir()
    platonov_path = os.path.join(base, "actor", "actor_platonov.npz")
    if os.path.isfile(platonov_path):
        data = np.load(platonov_path)
        X = data["node_features"].astype(np.float32)
        y = data["node_labels"].astype(np.int64)
        edges = data["edges"].astype(np.int64)
        edge_index = edges.T
        # Platonov stores one undirected edge once; mirror it for directed message passing.
        edge_index = np.concatenate([edge_index, edge_index[::-1]], axis=1)
        A = _dense_adj(edge_index, X.shape[0])
        masks = {
            "train_mask": data["train_masks"].T.astype(bool),
            "val_mask": data["val_masks"].T.astype(bool),
            "test_mask": data["test_masks"].T.astype(bool),
        }
        print(f"✅ Using Platonov Actor splits from {platonov_path}")
        return X, A, y, masks

    from torch_geometric.datasets import Actor
    ds = Actor(root=base)
    data = ds[0]
    X = data.x.numpy().astype(np.float32)
    y = data.y.numpy().astype(np.int64)
    ei = data.edge_index.numpy()
    A = _dense_adj(ei, X.shape[0])
    masks = {}
    for k in ['train_mask','val_mask','test_mask']:
        if hasattr(data, k):
            masks[k] = getattr(data, k).numpy().astype(bool)
    if not masks:
        masks = _stratified_masks(y)
    return X, A, y, masks


def load_twitch_split(lang_code: str, root: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    from torch_geometric.datasets import Twitch
    base = get_data_dir()
    ds = Twitch(root=base, name=lang_code)
    data = ds[0]
    X = data.x.numpy().astype(np.float32)
    y = data.y.numpy().astype(np.int64)
    ei = data.edge_index.numpy()
    A = _dense_adj(ei, X.shape[0])
    masks = {}
    for k in ['train_mask','val_mask','test_mask']:
        if hasattr(data, k):
            masks[k] = getattr(data, k).numpy().astype(bool)
    if not masks:
        masks = _stratified_masks(y)
    return X, A, y, masks


def load_custom_cached(name_lower: str, root: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    """Load datasets not available in PyG (e.g., penn94, genius, deezer_europe) from HERO/data.

    Expects files under HERO/data/<name>/:
    - features.npy (n,d), labels.npy (n,), edge_index.npy (2, m)
    Optional:
    - train_mask.npy, val_mask.npy, test_mask.npy (n,)

    If masks are absent, creates stratified masks.
    """
    base = get_data_dir()
    ddir = os.path.join(base, name_lower)
    fx = os.path.join(ddir, 'features.npy')
    fy = os.path.join(ddir, 'labels.npy')
    fe = os.path.join(ddir, 'edge_index.npy')
    if not (os.path.isfile(fx) and os.path.isfile(fy) and os.path.isfile(fe)):
        _maybe_download_and_convert(name_lower)
    if not (os.path.isfile(fx) and os.path.isfile(fy) and os.path.isfile(fe)):
        raise FileNotFoundError(
            f"Missing converted files under {ddir}. Place features.npy, labels.npy, edge_index.npy or a raw NPZ "
            f"({name_lower}.npz) and run a fetch step or retry loading."
        )
    X = np.load(fx).astype(np.float32)
    y = np.load(fy).astype(np.int64)
    ei = np.load(fe).astype(np.int64)
    if ei.shape[0] != 2:
        ei = ei.T
    A = ei  # keep edge index to avoid dense expansion
    masks = {}
    mask_sets = [
        ('train_mask', 'val_mask', 'test_mask'),
        ('train_masks', 'val_masks', 'test_masks'),
    ]
    for train_key, val_key, test_key in mask_sets:
        train_fp = os.path.join(ddir, f'{train_key}.npy')
        val_fp = os.path.join(ddir, f'{val_key}.npy')
        test_fp = os.path.join(ddir, f'{test_key}.npy')
        if os.path.isfile(train_fp) and os.path.isfile(val_fp) and os.path.isfile(test_fp):
            masks[train_key] = np.load(train_fp).astype(bool)
            masks[val_key] = np.load(val_fp).astype(bool)
            masks[test_key] = np.load(test_fp).astype(bool)
            # keep searching so the plural masks can also be loaded
    # ensure single-mask keys exist even if only plural versions were found
    if 'train_mask' not in masks and 'train_masks' in masks:
        masks['train_mask'] = masks['train_masks'][:, 0]
    if 'val_mask' not in masks and 'val_masks' in masks:
        masks['val_mask'] = masks['val_masks'][:, 0]
    if 'test_mask' not in masks and 'test_masks' in masks:
        masks['test_mask'] = masks['test_masks'][:, 0]
    if not masks:
        masks = _stratified_masks(y)
    return X, A, y, masks


# Download/Convert helpers
DOWNLOAD_LINKS = {
    # LINKX (Facebook100) Penn94 MAT from CUAI repo
    'penn94': 'https://github.com/CUAI/Non-Homophily-Large-Scale/raw/master/data/facebook100/Penn94.mat',
    # LINKX Genius MAT from CUAI repo
    'genius': 'https://github.com/CUAI/Non-Homophily-Large-Scale/raw/master/data/genius.mat',
    # PyG Deezer Europe NPZ
    'deezer_europe': 'https://graphmining.ai/datasets/ptg/deezer_europe.npz',
}


def _download_file(url: str, dst: str) -> bool:
    try:
        import urllib.request
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        urllib.request.urlretrieve(url, dst)
        return True
    except Exception as e:
        print(f"Could not download {url}: {e}")
        return False


def _convert_npz_to_npy(npz_path: str, out_dir: str) -> bool:
    try:
        data = np.load(npz_path, allow_pickle=True)
        candidates = [
            ('features', 'labels', 'edge_index'),
            ('X', 'y', 'edge_index'),
            ('x', 'y', 'edge_index'),
            # PyG DeezerEurope keys
            ('features', 'target', 'edges'),
            # Custom wiki-cooc bundle keys
            ('node_features', 'node_labels', 'edges'),
        ]
        for kx, ky, ke in candidates:
            if kx in data and ky in data and ke in data:
                X = data[kx].astype(np.float32)
                y = data[ky].astype(np.int64)
                ei = data[ke].astype(np.int64)
                if ei.shape[0] != 2:
                    ei = ei.T
                np.save(os.path.join(out_dir, 'features.npy'), X)
                np.save(os.path.join(out_dir, 'labels.npy'), y)
                np.save(os.path.join(out_dir, 'edge_index.npy'), ei)

                mask_candidates = [
                    ('train_mask', 'val_mask', 'test_mask'),
                    ('train_masks', 'val_masks', 'test_masks'),
                ]
                masks = None
                for mk_train, mk_val, mk_test in mask_candidates:
                    if mk_train in data and mk_val in data and mk_test in data:
                        train_raw = np.asarray(data[mk_train])
                        val_raw = np.asarray(data[mk_val])
                        test_raw = np.asarray(data[mk_test])

                        def _align_mask(arr: np.ndarray) -> np.ndarray:
                            arr = np.asarray(arr, dtype=bool)
                            if arr.ndim == 1:
                                return arr.reshape(-1, 1)
                            if arr.shape[0] == X.shape[0]:
                                return arr
                            if arr.shape[1] == X.shape[0]:
                                return arr.T
                            raise ValueError(
                                f"Mask array has unexpected shape {arr.shape}; expected (*, {X.shape[0]})"
                            )

                        try:
                            masks = {
                                'train_mask': _align_mask(train_raw),
                                'val_mask': _align_mask(val_raw),
                                'test_mask': _align_mask(test_raw),
                            }
                        except ValueError as err:
                            print(f"Warning: could not align masks for {out_dir}: {err}")
                            masks = None
                        break

                if masks:
                    _ensure_masks_saved(y, out_dir, masks={k: v for k, v in masks.items()})
                return True
        print(f"NPZ at {npz_path} missing expected keys; available: {list(data.keys())}")
        return False
    except Exception as e:
        print(f"Failed to convert {npz_path}: {e}")
        return False


def _convert_mat_to_npy(name_lower: str, mat_path: str, out_dir: str) -> bool:
    try:
        from scipy.io import loadmat
        mat = loadmat(mat_path)
        if name_lower == 'penn94':
            # Follow PyG LINKX processing: labels from metadata[:,1]-1, features as one-hot of all other columns
            import scipy.sparse as sp
            A = mat['A']
            if not sp.issparse(A):
                A = sp.csr_matrix(A)
            coo = A.tocsr().tocoo()
            edge_index = np.vstack([coo.row, coo.col]).astype(np.int64)

            metadata = mat.get('local_info')
            if metadata is None:
                raise KeyError('local_info missing in Penn94.mat')
            metadata = metadata.astype(np.int64)
            y = metadata[:, 1] - 1  # gender (1/2 -> 0/1), -1 unlabeled may exist

            # Build one-hot features for each categorical column except label col (1)
            cols = [0] + list(range(2, metadata.shape[1]))
            xs = []
            for ci in cols:
                col = metadata[:, ci]
                uniq, inv = np.unique(col, return_inverse=True)
                # one-hot encode inv
                oh = np.zeros((len(col), len(uniq)), dtype=np.float32)
                oh[np.arange(len(col)), inv] = 1.0
                xs.append(oh)
            X = np.concatenate(xs, axis=1).astype(np.float32, copy=False)

            np.save(os.path.join(out_dir, 'features.npy'), X)
            np.save(os.path.join(out_dir, 'labels.npy'), y.astype(np.int64))
            np.save(os.path.join(out_dir, 'edge_index.npy'), edge_index)
            return True
        elif name_lower == 'genius':
            edge_index = mat['edge_index'].astype(np.int64)
            node_feat = mat['node_feat'].astype(np.float32)
            label = mat['label'].squeeze().astype(np.int64)
            if edge_index.shape[0] != 2:
                edge_index = edge_index.T
            np.save(os.path.join(out_dir, 'features.npy'), node_feat)
            np.save(os.path.join(out_dir, 'labels.npy'), label)
            np.save(os.path.join(out_dir, 'edge_index.npy'), edge_index)
            return True
        else:
            print(f"MAT conversion not implemented for dataset: {name_lower}")
            return False
    except Exception as e:
        print(f"Failed to convert MAT {mat_path}: {e}")
        return False


def _maybe_download_and_convert(name_lower: str) -> None:
    base = get_data_dir()
    ddir = os.path.join(base, name_lower)
    os.makedirs(ddir, exist_ok=True)
    fx = os.path.join(ddir, 'features.npy')
    if os.path.isfile(fx):
        return
    url = DOWNLOAD_LINKS.get(name_lower)
    raw_npz = os.path.join(ddir, f'{name_lower}.npz')
    alt_npz = os.path.join(ddir, f"{name_lower.replace('-', '_')}.npz")
    raw_mat = os.path.join(ddir, f'{name_lower}.mat')
    if url:
        print(f"Downloading {name_lower} from {url}...")
        # Determine extension from URL
        ext = os.path.splitext(url)[1].lower()
        if ext == '.npz':
            ok = _download_file(url, raw_npz)
            if ok:
                print("Converting downloaded NPZ to .npy files...")
                if _convert_npz_to_npy(raw_npz, ddir):
                    return
        elif ext == '.mat':
            ok = _download_file(url, raw_mat)
            if ok:
                print("Converting downloaded MAT to .npy files...")
                if _convert_mat_to_npy(name_lower, raw_mat, ddir):
                    return
        else:
            print(f"Unknown extension '{ext}' for URL {url}; expecting .npz or .mat")
    # Try existing raw files
    if os.path.isfile(raw_npz):
        print(f"Converting existing raw NPZ {raw_npz}...")
        _convert_npz_to_npy(raw_npz, ddir)
    elif os.path.isfile(alt_npz):
        print(f"Converting existing raw NPZ {alt_npz}...")
        _convert_npz_to_npy(alt_npz, ddir)
    elif os.path.isfile(raw_mat):
        print(f"Converting existing raw MAT {raw_mat}...")
        _convert_mat_to_npy(name_lower, raw_mat, ddir)
    else:
        print(
            f"No automatic download link configured for {name_lower}. Place a raw NPZ at {raw_npz} "
            f"with keys (features/X, labels/y, edge_index) or a raw MAT at {raw_mat} (Penn94/Genius formats), "
            f"or directly provide features.npy, labels.npy, edge_index.npy."
        )


# -------- CLI utilities ---------
def _ensure_masks_saved(y: np.ndarray, out_dir: str, masks: Optional[Dict[str, np.ndarray]] = None,
                        train_frac: float = 0.6, val_frac: float = 0.2, seed: int = 42) -> Dict[str, np.ndarray]:
    os.makedirs(out_dir, exist_ok=True)
    if masks is None or not masks:
        masks = _stratified_masks(y, train_frac=train_frac, val_frac=val_frac, seed=seed)
    for k, v in masks.items():
        np.save(os.path.join(out_dir, f"{k}.npy"), v.astype(bool, copy=False))
    return masks


def _save_standardized_dataset(name_lower: str, X: np.ndarray, y: np.ndarray,
                               edge_index: np.ndarray, masks: Optional[Dict[str, np.ndarray]] = None,
                               overwrite: bool = False, train_frac: float = 0.6, val_frac: float = 0.2,
                               seed: int = 42) -> None:
    base = get_data_dir()
    ddir = os.path.join(base, name_lower)
    os.makedirs(ddir, exist_ok=True)

    # Normalize edge_index to [2, m]
    ei = np.asarray(edge_index, dtype=np.int64)
    if ei.ndim != 2:
        raise ValueError(f"edge_index must be 2D, got shape {ei.shape}")
    if ei.shape[0] != 2 and ei.shape[1] == 2:
        ei = ei.T
    if ei.shape[0] != 2:
        raise ValueError(f"edge_index must have shape [2, m], got {ei.shape}")

    fx = os.path.join(ddir, 'features.npy')
    fy = os.path.join(ddir, 'labels.npy')
    fe = os.path.join(ddir, 'edge_index.npy')

    if overwrite or not os.path.isfile(fx):
        np.save(fx, np.asarray(X, dtype=np.float32))
    if overwrite or not os.path.isfile(fy):
        np.save(fy, np.asarray(y, dtype=np.int64))
    if overwrite or not os.path.isfile(fe):
        np.save(fe, ei)

    # Write masks (generate if absent)
    masks = _ensure_masks_saved(np.asarray(y, dtype=np.int64), ddir, masks,
                                train_frac=train_frac, val_frac=val_frac, seed=seed)


def _prepare_from_pyg(name_lower: str, overwrite: bool = False, train_frac: float = 0.6,
                      val_frac: float = 0.2, seed: int = 42) -> None:
    """Fetch via PyG and save standardized files under data/<name>."""
    # Defer imports to avoid requiring torch_geometric unless used
    if name_lower in {'cornell', 'texas', 'wisconsin'}:
        X, A, y, masks = load_webkb_split(name_lower, get_data_dir())
        # Recover edge_index from adjacency
        ei = np.vstack(np.nonzero(A))
    elif name_lower == 'actor':
        X, A, y, masks = load_actor_split(get_data_dir())
        ei = np.vstack(np.nonzero(A))
    elif name_lower.startswith('twitch'):
        # Accept twitch_<LANG> or twitch-<LANG>
        lang = name_lower.split('_', 1)[1] if '_' in name_lower else name_lower.split('-', 1)[1]
        lang = lang.upper()
        X, A, y, masks = load_twitch_split(lang, get_data_dir())
        ei = np.vstack(np.nonzero(A))
        name_lower = f"twitch_{lang.lower()}"
    else:
        raise ValueError(f"Unsupported PyG dataset for preparation: {name_lower}")

    _save_standardized_dataset(name_lower, X, y, ei, masks,
                               overwrite=overwrite, train_frac=train_frac, val_frac=val_frac, seed=seed)


def _prepare_from_npz_or_links(name_lower: str, overwrite: bool = False, train_frac: float = 0.6,
                               val_frac: float = 0.2, seed: int = 42) -> None:
    """Prepare datasets that are expected as NPZ or via direct links.

    Creates features.npy, labels.npy, edge_index.npy and masks under data/<name>.
    """
    base = get_data_dir()
    ddir = os.path.join(base, name_lower)
    os.makedirs(ddir, exist_ok=True)

    fx = os.path.join(ddir, 'features.npy')
    fy = os.path.join(ddir, 'labels.npy')
    fe = os.path.join(ddir, 'edge_index.npy')

    if overwrite:
        # Remove old standardized files to force conversion
        for fp in (fx, fy, fe):
            try:
                if os.path.isfile(fp):
                    os.remove(fp)
            except Exception:
                pass

    # Download and/or convert if missing
    if not (os.path.isfile(fx) and os.path.isfile(fy) and os.path.isfile(fe)):
        _maybe_download_and_convert(name_lower)

    if not (os.path.isfile(fx) and os.path.isfile(fy) and os.path.isfile(fe)):
        raise FileNotFoundError(
            f"Failed to prepare {name_lower}. Ensure {name_lower}.npz exists under {ddir} or set DOWNLOAD_LINKS.")

    # Ensure masks
    y = np.load(fy).astype(np.int64)
    _ensure_masks_saved(y, ddir, masks=None, train_frac=train_frac, val_frac=val_frac, seed=seed)


def prepare_datasets(datasets: List[str], overwrite: bool = False, train_frac: float = 0.6,
                     val_frac: float = 0.2, seed: int = 42) -> None:
    """Prepare one or more datasets into standardized .npy format under HERO/data.

    - For PyG-available datasets (cornell/texas/wisconsin/actor/twitch_LANG), fetch via PyG and save .npy files.
    - For custom ones (penn94/genius/deezer_europe), download/convert from NPZ and save .npy files.
    - Always ensure train/val/test masks are present (create stratified if absent).
    """
    for name in datasets:
        name_lc = name.lower()
        try:
            if name_lc in {'cornell', 'texas', 'wisconsin', 'actor'} or name_lc.startswith('twitch'):
                print(f"Preparing PyG dataset: {name_lc}")
                _prepare_from_pyg(name_lc, overwrite=overwrite, train_frac=train_frac, val_frac=val_frac, seed=seed)
            elif name_lc in {'penn94', 'genius', 'deezer_europe'}:
                print(f"Preparing external dataset: {name_lc}")
                _prepare_from_npz_or_links(name_lc, overwrite=overwrite, train_frac=train_frac, val_frac=val_frac, seed=seed)
            else:
                print(f"Skipping unknown dataset: {name}")
        except Exception as e:
            print(f"❌ Failed to prepare {name}: {e}")


def _available_names() -> List[str]:
    return [
        # PyG-backed
        'cornell', 'texas', 'wisconsin', 'actor', 'twitch_en', 'twitch_de', 'twitch_ru',
        # External (via NPZ or links)
        'penn94', 'genius', 'deezer_europe',
    ]


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Download/prepare datasets into standardized HERO/data format (.npy + masks).')
    parser.add_argument('datasets', nargs='*', help='Dataset names (e.g., cornell texas actor twitch_de penn94)')
    parser.add_argument('--list', action='store_true', help='List supported dataset names and exit')
    parser.add_argument('--overwrite', action='store_true', help='Overwrite existing standardized files')
    parser.add_argument('--train-frac', type=float, default=0.6, help='Train fraction for autogenerated masks')
    parser.add_argument('--val-frac', type=float, default=0.2, help='Validation fraction for autogenerated masks')
    parser.add_argument('--seed', type=int, default=42, help='Random seed for mask generation')
    parser.add_argument('--all', action='store_true', help='Prepare a curated default set of datasets')

    args = parser.parse_args()

    if args.list:
        print("Supported datasets:")
        for n in _available_names():
            print(f" - {n}")
        raise SystemExit(0)

    names: List[str]
    if args.all and not args.datasets:
        names = _available_names()
    else:
        if not args.datasets:
            parser.error('Provide dataset names or use --all or --list')
        names = args.datasets

    prepare_datasets(names, overwrite=args.overwrite, train_frac=args.train_frac,
                     val_frac=args.val_frac, seed=args.seed)
