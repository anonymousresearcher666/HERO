"""Synthetic dataset utilities for unit tests and quick sanity checks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np


@dataclass
class SyntheticGraph:
    features: np.ndarray
    edge_index: np.ndarray
    adjacency: np.ndarray
    labels: np.ndarray
    masks: Dict[str, np.ndarray]


def generate_synthetic_dataset(
    num_nodes: int = 48,
    num_classes: int = 3,
    feature_dim: int = 16,
    heterophily: float = 0.55,
    seed: int = 42,
) -> SyntheticGraph:
    """Generate a tiny asymmetric synthetic graph satisfying the data contract."""
    rng = np.random.default_rng(seed)

    class_centers = rng.normal(loc=0.0, scale=1.0, size=(num_classes, feature_dim)).astype(np.float32)
    labels = rng.integers(low=0, high=num_classes, size=num_nodes, endpoint=False)
    features = class_centers[labels] + 0.25 * rng.normal(size=(num_nodes, feature_dim)).astype(np.float32)

    edges = set()
    for src in range(num_nodes):
        preferred_degree = rng.integers(low=3, high=min(8, num_nodes))
        candidates = np.setdiff1d(np.arange(num_nodes), np.array([src]))
        rng.shuffle(candidates)
        added = 0
        for dst in candidates:
            same_label = labels[src] == labels[dst]
            connect_prob = 1.0 - heterophily if same_label else heterophily
            if rng.random() < connect_prob:
                edges.add((int(src), int(dst)))
                added += 1
            if added >= preferred_degree:
                break
        if added == 0:
            fallback = int(rng.choice(candidates))
            edges.add((int(src), fallback))

    if not edges:
        edges = {(i, (i + 1) % num_nodes) for i in range(num_nodes)}

    edge_index = np.array(sorted(edges), dtype=np.int64).T
    adjacency = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    adjacency[edge_index[0], edge_index[1]] = 1.0

    indices = np.arange(num_nodes)
    rng.shuffle(indices)
    n_train = max(3, int(0.2 * num_nodes))
    n_val = max(3, int(0.2 * num_nodes))
    train_idx = indices[:n_train]
    val_idx = indices[n_train:n_train + n_val]
    test_idx = indices[n_train + n_val:]

    train_mask = np.zeros(num_nodes, dtype=bool)
    val_mask = np.zeros(num_nodes, dtype=bool)
    test_mask = np.zeros(num_nodes, dtype=bool)
    train_mask[train_idx] = True
    val_mask[val_idx] = True
    test_mask[test_idx] = True

    masks = {
        "train_mask": train_mask,
        "val_mask": val_mask,
        "test_mask": test_mask,
    }

    return SyntheticGraph(
        features=features,
        edge_index=edge_index,
        adjacency=adjacency,
        labels=labels.astype(np.int64),
        masks=masks,
    )


def _upper_tri_from_flat(idx: np.ndarray, n: int) -> Tuple[np.ndarray, np.ndarray]:
    counts = np.arange(n - 1, 0, -1, dtype=np.int64)
    cum = np.cumsum(counts)
    i = np.searchsorted(cum, idx, side="right")
    prev = np.concatenate(([0], cum[:-1]))
    j = idx - prev[i] + i + 1
    return i, j


def generate_sbm_dataset(
    num_nodes: int = 1000,
    num_classes: int = 5,
    feature_dim: int = 128,
    homophily: float = 0.5,
    avg_degree: float = 10.0,
    p_total: Optional[float] = None,
    p_in: Optional[float] = None,
    p_out: Optional[float] = None,
    class_probs: Optional[np.ndarray] = None,
    feature_noise: float = 1.0,
    center_radius: float = 1.0,
    seed: int = 42,
    self_loops: bool = False,
    directed: bool = False,
    dense_adjacency: bool = True,
    train_ratio: float = 0.2,
    val_ratio: float = 0.1,
    num_splits: int = 1,
) -> SyntheticGraph:
    """Generate an SBM graph with controllable homophily and Gaussian features."""
    rng = np.random.default_rng(seed)
    n = int(num_nodes)
    c = int(num_classes)
    if c < 2:
        raise ValueError("num_classes must be >= 2")
    if class_probs is None:
        class_probs = np.full(c, 1.0 / c, dtype=np.float64)
    else:
        class_probs = np.asarray(class_probs, dtype=np.float64)
        class_probs = class_probs / class_probs.sum()

    labels = rng.choice(np.arange(c, dtype=np.int64), size=n, p=class_probs)
    centers = rng.normal(size=(c, feature_dim)).astype(np.float32)
    centers /= np.linalg.norm(centers, axis=1, keepdims=True) + 1e-8
    centers *= float(center_radius)
    features = centers[labels] + float(feature_noise) * rng.normal(size=(n, feature_dim)).astype(np.float32)

    if p_in is None or p_out is None:
        if p_total is None:
            p_total = float(avg_degree) / max(1, n - 1)
        p_in = float(homophily) * p_total
        p_out = (p_total - p_in) / max(1, c - 1)
    p_in = float(p_in)
    p_out = float(p_out)
    if not (0.0 <= p_in <= 1.0 and 0.0 <= p_out <= 1.0):
        raise ValueError("p_in and p_out must be in [0, 1]")

    class_indices = [np.where(labels == k)[0] for k in range(c)]
    edges = []

    for k in range(c):
        idx = class_indices[k]
        nk = idx.size
        if nk < 2 or p_in <= 0.0:
            continue
        num_pairs = nk * (nk - 1) // 2
        m = rng.binomial(num_pairs, p_in)
        if m <= 0:
            continue
        choice = rng.choice(num_pairs, size=m, replace=False) if m < num_pairs else np.arange(num_pairs)
        i, j = _upper_tri_from_flat(choice.astype(np.int64), nk)
        u = idx[i]
        v = idx[j]
        edges.extend(zip(u.tolist(), v.tolist()))
        if not directed:
            edges.extend(zip(v.tolist(), u.tolist()))

    for a in range(c):
        for b in range(a + 1, c):
            idx_a = class_indices[a]
            idx_b = class_indices[b]
            na, nb = idx_a.size, idx_b.size
            if na == 0 or nb == 0 or p_out <= 0.0:
                continue
            num_pairs = na * nb
            m = rng.binomial(num_pairs, p_out)
            if m <= 0:
                continue
            choice = rng.choice(num_pairs, size=m, replace=False) if m < num_pairs else np.arange(num_pairs)
            u = idx_a[choice // nb]
            v = idx_b[choice % nb]
            edges.extend(zip(u.tolist(), v.tolist()))
            if not directed:
                edges.extend(zip(v.tolist(), u.tolist()))

    if self_loops:
        edges.extend((i, i) for i in range(n))

    if edges:
        edge_index = np.array(edges, dtype=np.int64).T
        edge_index = np.unique(edge_index, axis=1)
    else:
        edge_index = np.array([(i, (i + 1) % n) for i in range(n)], dtype=np.int64).T

    if dense_adjacency:
        adjacency = np.zeros((n, n), dtype=np.float32)
        adjacency[edge_index[0], edge_index[1]] = 1.0
    else:
        adjacency = edge_index

    def _stratified_masks(labels: np.ndarray, splits: int) -> Dict[str, np.ndarray]:
        classes = np.unique(labels)
        train = np.zeros((n, splits), dtype=bool)
        val = np.zeros((n, splits), dtype=bool)
        test = np.zeros((n, splits), dtype=bool)
        for s in range(splits):
            for cls_val in classes:
                cls_idx = np.where(labels == cls_val)[0]
                if cls_idx.size == 0:
                    continue
                rng.shuffle(cls_idx)
                n_train = max(1, int(train_ratio * cls_idx.size))
                n_val = max(1, int(val_ratio * cls_idx.size))
                n_train = min(n_train, cls_idx.size)
                n_val = min(n_val, cls_idx.size - n_train)
                n_test = cls_idx.size - n_train - n_val
                if n_test <= 0:
                    n_test = cls_idx.size - n_train
                    n_val = 0
                train[cls_idx[:n_train], s] = True
                val[cls_idx[n_train:n_train + n_val], s] = True
                test[cls_idx[n_train + n_val:n_train + n_val + n_test], s] = True
            val[:, s] &= ~train[:, s]
            test[:, s] &= ~(train[:, s] | val[:, s])
        return {"train_mask": train, "val_mask": val, "test_mask": test}

    masks = _stratified_masks(labels, max(1, int(num_splits)))

    return SyntheticGraph(
        features=features,
        edge_index=edge_index,
        adjacency=adjacency,
        labels=labels.astype(np.int64),
        masks=masks,
    )


__all__ = ["SyntheticGraph", "generate_synthetic_dataset", "generate_sbm_dataset"]
