"""
Heterophily Comparison & Node Classification Framework
Compare exact vs approximate heterophily measures and evaluate node classification performance
"""

import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans, SpectralClustering, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

from hero.calculators.homophily import HomophilyCalculator
from hero.core import ExperimentConfig, AffinityModel, AffinityTrainer
from hero.core.config import DEVICE

try:
    import mlx.core as mx
    import mlx.nn as nn
except ImportError:
    print("MLX not available - some features will be limited")


@dataclass
class ComparisonConfig:
    """Configuration for heterophily comparison experiments."""
    # Affinity-to-labels conversion methods
    clustering_methods: List[str] = None  # ['kmeans', 'spectral', 'hierarchical', 'threshold']
    n_clusters_range: List[int] = None  # [2, 3, 4, 5, 8, 10]
    threshold_percentiles: List[float] = None  # [0.1, 0.2, 0.3, 0.5, 0.7]

    # Node classification settings
    classifiers: List[str] = None  # ['logistic', 'random_forest', 'svm']
    test_size: float = 0.3
    cv_folds: int = 5

    # Evaluation settings
    save_plots: bool = True
    plot_correlations: bool = True
    detailed_analysis: bool = True

    def __post_init__(self):
        if self.clustering_methods is None:
            self.clustering_methods = ['kmeans', 'spectral', 'threshold']
        if self.n_clusters_range is None:
            self.n_clusters_range = [2, 3, 4, 5, 8]
        if self.threshold_percentiles is None:
            self.threshold_percentiles = [0.1, 0.2, 0.3, 0.5, 0.7]
        if self.classifiers is None:
            self.classifiers = ['logistic', 'random_forest']


class AffinityToLabelsConverter:
    """Convert affinity vectors/scores to pseudo-labels using various methods."""

    def __init__(self, config: ComparisonConfig):
        self.config = config

    def affinity_vectors_to_labels(self, affinity_vectors: np.ndarray,
                                   true_n_classes: int) -> Dict[str, np.ndarray]:
        """Convert affinity vectors to pseudo-labels using clustering methods."""
        results = {}

        print(f"Converting affinity vectors to labels (shape: {affinity_vectors.shape})")

        # Try different number of clusters around the true number
        cluster_candidates = [true_n_classes] + [n for n in self.config.n_clusters_range if n != true_n_classes]

        for method in self.config.clustering_methods:
            if method == 'threshold':
                # Threshold-based labeling
                results.update(self._threshold_labeling(affinity_vectors))
            else:
                # Clustering-based methods
                for n_clusters in cluster_candidates[:3]:  # Try top 3 cluster numbers
                    key = f"{method}_{n_clusters}"
                    try:
                        if method == 'kmeans':
                            clusterer = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
                        elif method == 'spectral':
                            clusterer = SpectralClustering(n_clusters=n_clusters, random_state=42)
                        elif method == 'hierarchical':
                            clusterer = AgglomerativeClustering(n_clusters=n_clusters)
                        else:
                            continue

                        labels = clusterer.fit_predict(affinity_vectors)
                        results[key] = labels
                        print(f"  {key}: {len(np.unique(labels))} clusters")

                    except Exception as e:
                        print(f"  Failed {key}: {e}")
                        continue

        return results

    def _threshold_labeling(self, affinity_vectors: np.ndarray) -> Dict[str, np.ndarray]:
        """Create labels based on affinity similarity thresholds."""
        results = {}

        # Compute pairwise affinities (cosine similarity)
        affinities = np.dot(affinity_vectors, affinity_vectors.T)
        norms = np.linalg.norm(affinity_vectors, axis=1)
        affinities = affinities / (norms[:, None] * norms[None, :] + 1e-12)

        for percentile in self.config.threshold_percentiles:
            threshold = np.percentile(affinities, percentile * 100)

            # Create labels based on similarity threshold
            labels = np.zeros(len(affinity_vectors), dtype=int)
            label_id = 0
            assigned = np.zeros(len(affinity_vectors), dtype=bool)

            for i in range(len(affinity_vectors)):
                if assigned[i]:
                    continue

                # Find all nodes similar to node i
                similar_nodes = np.where(affinities[i] > threshold)[0]
                similar_nodes = similar_nodes[~assigned[similar_nodes]]

                if len(similar_nodes) > 0:
                    labels[similar_nodes] = label_id
                    assigned[similar_nodes] = True
                    label_id += 1

            # Assign remaining nodes to individual clusters
            for i in range(len(affinity_vectors)):
                if not assigned[i]:
                    labels[i] = label_id
                    label_id += 1

            results[f"threshold_{percentile}"] = labels
            print(f"  threshold_{percentile}: {len(np.unique(labels))} clusters")

        return results


class HeterophilyComparisonFramework:
    """Run a complete heterophily analysis using HERO core components.

    - Trains a lightweight AffinityModel (unless provided)
    - Converts affinity vectors to pseudo-labels
    - Compares pseudo-labels to true labels via NMI/ARI
    - Evaluates a simple feature-based classifier with pseudo labels
    """

    def __init__(self, config: ComparisonConfig):
        self.config = config
        self.converter = AffinityToLabelsConverter(config)

    @staticmethod
    def _build_adj(n: int, edges: np.ndarray) -> np.ndarray:
        A = np.zeros((n, n), dtype=np.float32)
        if edges is None or edges.size == 0:
            return A
        A[edges[:, 0], edges[:, 1]] = 1.0
        return A

    def _train_affinity(self, X: np.ndarray, A: np.ndarray) -> AffinityModel:
        n, d = X.shape
        cfg = ExperimentConfig(
            datasets=['custom'], affinity_dim=32, learning_rate=0.01, epochs=20,
            early_stopping_patience=5, structure_weight=0.0, label_weight=0.0,
            contrastive_weight=1.0, unsupervised=True, temperature=0.1,
            strategy='contrastive', feature_dropout=0.2, edge_dropout=0.2,
            k_neighbors=15, embedding_type='projected', use_weighted_voting=True,
            test_runs=1, save_results=False
        )
        model = AffinityModel(n, d, cfg.affinity_dim, DEVICE)
        AffinityTrainer(model, cfg).train(X, A, np.zeros(n, dtype=np.int64), np.zeros(n, dtype=bool))
        return model

    @staticmethod
    def _mask_split(masks: Dict[str, np.ndarray]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        tm = masks.get('train_mask')
        vm = masks.get('val_mask')
        sm = masks.get('test_mask')
        if tm is None:
            tm = np.zeros_like(sm) if sm is not None else None
        if vm is None:
            vm = np.zeros_like(tm) if tm is not None else None
        if sm is None:
            sm = np.zeros_like(tm) if tm is not None else None
        return tm, vm, sm

    def run_complete_analysis(self, X: np.ndarray, edge_array: np.ndarray, labels: np.ndarray,
                               affinity_model: Optional[AffinityModel], dataset_name: str,
                               dataset_masks: Optional[Dict[str, np.ndarray]],
                               output_dir: Optional[str] = None,
                               save_tex: bool = False) -> Dict[str, any]:
        n = X.shape[0]
        A = self._build_adj(n, edge_array)
        # Homophily measures
        node_h = HomophilyCalculator.node_homophily(edge_array, labels)
        edge_h = HomophilyCalculator.edge_homophily(edge_array, labels)
        adj_h = HomophilyCalculator.adjusted_homophily(edge_array, labels)

        # Train affinity model if not provided
        if affinity_model is None:
            affinity_model = self._train_affinity(X, A)
        aff = affinity_model.get_affinity_vectors()

        # Convert to pseudo labels
        n_classes = int(labels.max()) + 1
        label_sets = self.converter.affinity_vectors_to_labels(aff, n_classes)

        # Evaluate conversion quality
        conv_results = {}
        best_key = None
        best_score = -1.0
        for key, pseudo in label_sets.items():
            try:
                nmi = normalized_mutual_info_score(labels, pseudo)
                ari = adjusted_rand_score(labels, pseudo)
                score = 0.5 * (nmi + ari)
                conv_results[key] = {'nmi': float(nmi), 'ari': float(ari), 'score': float(score)}
                if score > best_score:
                    best_score, best_key = score, key
            except Exception:
                continue

        best_approximation = {
            'method': best_key or 'none',
            'overall_score': float(best_score if best_score >= 0 else 0.0),
            'overall_correlation': float(best_score if best_score >= 0 else 0.0)
        }

        # Classification evaluation
        baseline = {}
        pseudo_eval = {}
        tm, vm, sm = self._mask_split(dataset_masks or {})
        try:
            # Baseline: logistic on features using train->test
            clf = LogisticRegression(max_iter=1000)
            tr_idx = np.where(tm)[0]
            te_idx = np.where(sm)[0]
            if tr_idx.size > 0 and te_idx.size > 0:
                clf.fit(X[tr_idx], labels[tr_idx])
                yhat = clf.predict(X[te_idx])
                acc = accuracy_score(labels[te_idx], yhat)
                f1 = f1_score(labels[te_idx], yhat, average='weighted')
                baseline['logistic'] = {'accuracy': float(acc), 'f1': float(f1)}
        except Exception:
            baseline['logistic'] = {'accuracy': 0.0, 'f1': 0.0}

        for key, pseudo in label_sets.items():
            try:
                tr_idx = np.where(tm)[0]
                te_idx = np.where(sm)[0]
                if tr_idx.size == 0 or te_idx.size == 0:
                    continue
                clf = LogisticRegression(max_iter=1000)
                clf.fit(X[tr_idx], pseudo[tr_idx])
                yhat = clf.predict(X[te_idx])
                acc = accuracy_score(labels[te_idx], yhat)
                f1 = f1_score(labels[te_idx], yhat, average='weighted')
                pseudo_eval.setdefault(key, {})['logistic'] = {'accuracy': float(acc), 'f1': float(f1)}
            except Exception:
                continue

        report = {
            'heterophily_comparison': {
                'node_h': float(node_h),
                'edge_h': float(edge_h),
                'adjusted_edge_h': float(adj_h),
                'label_conversion_results': {
                    'n_methods': len(conv_results),
                    'methods': conv_results,
                },
                'best_approximation': best_approximation,
            },
            'classification_evaluation': {
                'baseline_performance': baseline,
                'pseudo_label_performance': pseudo_eval,
            }
        }

        # Optional plotting and artifact saving
        if output_dir:
            plots_dir = os.path.join(output_dir, 'plots')
            os.makedirs(plots_dir, exist_ok=True)
            # 1) Homophily bars
            try:
                vals = [float(node_h), float(edge_h), float(adj_h)]
                labels_h = ['node_h', 'edge_h', 'adj_edge_h']
                plt.figure(figsize=(4.5, 4))
                plt.bar(labels_h, vals, color=['#4e79a7','#f28e2b','#e15759'])
                plt.ylim(0,1)
                plt.title(f'Homophily ({dataset_name})')
                plt.tight_layout()
                out_base = os.path.join(plots_dir, 'homophily_bars')
                plt.savefig(out_base + '.png', dpi=150)
                if save_tex:
                    try:
                        import tikzplotlib
                        tikzplotlib.save(out_base + '.tex')
                    except Exception:
                        pass
                plt.close()
            except Exception:
                pass
            # 2) Label conversion scores (NMI/ARI/score)
            try:
                methods = list(conv_results.keys())
                scores = [conv_results[m]['score'] for m in methods]
                plt.figure(figsize=(4.5, 4))
                plt.bar(methods, scores, color='#76b7b2')
                plt.xticks(rotation=45, ha='right')
                plt.ylabel('Score (avg NMI/ARI)')
                plt.title('Label conversion quality')
                plt.tight_layout()
                out_base = os.path.join(plots_dir, 'label_conversion_scores')
                plt.savefig(out_base + '.png', dpi=150)
                if save_tex:
                    try:
                        import tikzplotlib
                        tikzplotlib.save(out_base + '.tex')
                    except Exception:
                        pass
                plt.close()
            except Exception:
                pass
            # 3) Classification bars
            try:
                base_acc = baseline.get('logistic',{}).get('accuracy',0.0)
                # take best pseudo logistic acc
                best_pseudo_acc = 0.0
                for m in pseudo_eval.values():
                    best_pseudo_acc = max(best_pseudo_acc, m.get('logistic',{}).get('accuracy',0.0))
                names = ['baseline_logistic','pseudo_logistic_best']
                vals = [base_acc, best_pseudo_acc]
                plt.figure(figsize=(4.5, 4))
                plt.bar(names, vals, color=['#59a14f','#edc948'])
                plt.ylim(0,1)
                plt.title('Classification (accuracy)')
                plt.tight_layout()
                out_base = os.path.join(plots_dir, 'classification_bars')
                plt.savefig(out_base + '.png', dpi=150)
                if save_tex:
                    try:
                        import tikzplotlib
                        tikzplotlib.save(out_base + '.tex')
                    except Exception:
                        pass
                plt.close()
            except Exception:
                pass
            # 4) Affinity PCA scatter (true vs best pseudo)
            try:
                pca = PCA(n_components=2, random_state=42)
                Z = pca.fit_transform(aff)
                # true labels
                plt.figure(figsize=(4.5, 4))
                plt.scatter(Z[:,0], Z[:,1], c=labels, s=4, cmap='tab20')
                plt.title('Affinity PCA (true labels)')
                plt.tight_layout()
                out_base = os.path.join(plots_dir, 'affinity_pca_true')
                plt.savefig(out_base + '.png', dpi=150)
                if save_tex:
                    try:
                        import tikzplotlib
                        tikzplotlib.save(out_base + '.tex')
                    except Exception:
                        pass
                plt.close()
                # best pseudo
                if best_key in label_sets:
                    pseudo = label_sets[best_key]
                    plt.figure(figsize=(4.5, 4))
                    plt.scatter(Z[:,0], Z[:,1], c=pseudo, s=4, cmap='tab20')
                    plt.title(f'Affinity PCA ({best_key})')
                    plt.tight_layout()
                    out_base = os.path.join(plots_dir, 'affinity_pca_pseudo')
                    plt.savefig(out_base + '.png', dpi=150)
                    if save_tex:
                        try:
                            import tikzplotlib
                            tikzplotlib.save(out_base + '.tex')
                        except Exception:
                            pass
                    plt.close()
                # Save numpy artifacts
                np.save(os.path.join(output_dir, 'affinity_vectors.npy'), aff)
                np.save(os.path.join(output_dir, 'pca_coords.npy'), Z)
            except Exception:
                pass

        return report

    def affinity_scores_to_labels(self, affinity_matrix: np.ndarray) -> Dict[str, np.ndarray]:
        """Convert full affinity matrix to pseudo-labels."""
        results = {}

        # Spectral clustering on affinity matrix
        for n_clusters in self.config.n_clusters_range:
            try:
                spectral = SpectralClustering(
                    n_clusters=n_clusters,
                    affinity='precomputed',
                    random_state=42
                )
                labels = spectral.fit_predict(affinity_matrix)
                results[f"affinity_spectral_{n_clusters}"] = labels
            except:
                continue

        return results


class HeterophilyComparator:
    """Compare heterophily measures between exact (real labels) and approximate (affinity-derived) methods."""

    def __init__(self, config: ComparisonConfig):
        self.config = config
        self.converter = AffinityToLabelsConverter(config)

    def compute_all_heterophily_measures(self, edge_array: np.ndarray,
                                         labels: np.ndarray) -> Dict[str, float]:
        """Compute all heterophily measures for given labels."""
        try:
            node_h = HomophilyCalculator.node_homophily(edge_array, labels)
            edge_h = HomophilyCalculator.edge_homophily(edge_array, labels)
            adjusted_h = HomophilyCalculator.adjusted_homophily(edge_array, labels)
            label_info = HomophilyCalculator.label_informativeness(edge_array, labels)

            return {
                'node_homophily': node_h,
                'edge_homophily': edge_h,
                'adjusted_homophily': adjusted_h,
                'label_informativeness': label_info
            }
        except Exception as e:
            print(f"Error computing heterophily measures: {e}")
            return {
                'node_homophily': 0.0,
                'edge_homophily': 0.0,
                'adjusted_homophily': 0.0,
                'label_informativeness': 0.0
            }

    def compare_heterophily_approximations(self, edge_array: np.ndarray,
                                           true_labels: np.ndarray,
                                           affinity_model,
                                           dataset_name: str) -> Dict[str, any]:
        """Complete comparison between exact and approximate heterophily measures."""

        print(f"\n{'=' * 60}")
        print(f"HETEROPHILY COMPARISON: {dataset_name}")
        print(f"{'=' * 60}")

        results = {
            'dataset': dataset_name,
            'exact_measures': {},
            'approximate_measures': {},
            'comparison_metrics': {},
            'best_approximation': {},
            'label_conversion_results': {}
        }

        # 1. Compute exact heterophily measures using true labels
        print("1. Computing exact heterophily measures...")
        exact_measures = self.compute_all_heterophily_measures(edge_array, true_labels)
        results['exact_measures'] = exact_measures

        print("Exact measures:")
        for metric, value in exact_measures.items():
            print(f"  {metric}: {value:.4f}")

        # 2. Extract affinity information from model
        print("\n2. Extracting affinity information...")
        try:
            # Get affinity vectors (learned embeddings)
            if hasattr(affinity_model, 'affinity'):
                affinity_vectors = np.array(affinity_model.affinity)
                print(f"  Affinity vectors shape: {affinity_vectors.shape}")
            else:
                print("  No affinity vectors found in model")
                return results

            # Optionally get full affinity matrix for small graphs
            affinity_matrix = None
            if affinity_model.n <= 1000:  # Only for small graphs
                try:
                    full_matrix = affinity_model.compute_full_affinity_matrix()
                    affinity_matrix = np.array(full_matrix)
                    print(f"  Full affinity matrix shape: {affinity_matrix.shape}")
                except:
                    print("  Could not compute full affinity matrix")

        except Exception as e:
            print(f"  Error extracting affinity information: {e}")
            return results

        # 3. Convert affinity to pseudo-labels
        print("\n3. Converting affinity to pseudo-labels...")
        true_n_classes = len(np.unique(true_labels))
        pseudo_labels_dict = self.converter.affinity_vectors_to_labels(affinity_vectors, true_n_classes)

        if affinity_matrix is not None:
            matrix_labels = self.converter.affinity_scores_to_labels(affinity_matrix)
            pseudo_labels_dict.update(matrix_labels)

        results['label_conversion_results'] = {
            'n_methods': len(pseudo_labels_dict),
            'true_n_classes': true_n_classes,
            'methods': list(pseudo_labels_dict.keys())
        }

        # 4. Compute approximate heterophily measures
        print("\n4. Computing approximate heterophily measures...")
        approximate_measures = {}
        label_quality_metrics = {}

        for method_name, pseudo_labels in pseudo_labels_dict.items():
            # Compute heterophily with pseudo-labels
            approx_measures = self.compute_all_heterophily_measures(edge_array, pseudo_labels)
            approximate_measures[method_name] = approx_measures

            # Compute label quality metrics
            ari = adjusted_rand_score(true_labels, pseudo_labels)
            nmi = normalized_mutual_info_score(true_labels, pseudo_labels)

            label_quality_metrics[method_name] = {
                'ari': ari,
                'nmi': nmi,
                'n_clusters': len(np.unique(pseudo_labels))
            }

            print(f"  {method_name}: ARI={ari:.3f}, NMI={nmi:.3f}, "
                  f"clusters={len(np.unique(pseudo_labels))}")

        results['approximate_measures'] = approximate_measures
        results['label_quality_metrics'] = label_quality_metrics

        # 5. Compare exact vs approximate measures
        print("\n5. Analyzing approximation quality...")
        comparison_metrics = self._analyze_approximation_quality(
            exact_measures, approximate_measures, label_quality_metrics
        )
        results['comparison_metrics'] = comparison_metrics

        # 6. Find best approximation method
        best_method = self._find_best_approximation_method(
            exact_measures, approximate_measures, label_quality_metrics
        )
        results['best_approximation'] = best_method

        print(f"\nBest approximation method: {best_method['method']}")
        print(f"  Overall correlation: {best_method['overall_correlation']:.4f}")
        print(f"  Best metric: {best_method['best_metric']} (corr: {best_method['best_correlation']:.4f})")

        return results

    def _analyze_approximation_quality(self, exact_measures: Dict[str, float],
                                       approximate_measures: Dict[str, Dict[str, float]],
                                       label_quality_metrics: Dict[str, Dict[str, float]]) -> Dict[str, any]:
        """Analyze how well different methods approximate exact heterophily measures."""

        analysis = {
            'correlations': {},
            'absolute_errors': {},
            'relative_errors': {},
            'method_rankings': {}
        }

        metric_names = list(exact_measures.keys())

        for metric in metric_names:
            exact_value = exact_measures[metric]

            correlations = []
            abs_errors = []
            rel_errors = []
            methods = []

            for method_name, approx_measures in approximate_measures.items():
                approx_value = approx_measures[metric]

                # Store values for correlation later
                methods.append(method_name)

                # Absolute error
                abs_error = abs(exact_value - approx_value)
                abs_errors.append(abs_error)

                # Relative error (handle division by zero)
                if abs(exact_value) > 1e-10:
                    rel_error = abs_error / abs(exact_value)
                else:
                    rel_error = abs_error
                rel_errors.append(rel_error)

            analysis['absolute_errors'][metric] = dict(zip(methods, abs_errors))
            analysis['relative_errors'][metric] = dict(zip(methods, rel_errors))

            # Rank methods by absolute error for this metric
            method_error_pairs = list(zip(methods, abs_errors))
            method_error_pairs.sort(key=lambda x: x[1])
            analysis['method_rankings'][metric] = [pair[0] for pair in method_error_pairs]

        return analysis

    def _find_best_approximation_method(self, exact_measures: Dict[str, float],
                                        approximate_measures: Dict[str, Dict[str, float]],
                                        label_quality_metrics: Dict[str, Dict[str, float]]) -> Dict[str, any]:
        """Find the best overall approximation method."""

        method_scores = {}
        metric_names = list(exact_measures.keys())

        for method_name in approximate_measures.keys():
            # Compute correlations and errors for each metric
            correlations = []
            abs_errors = []

            for metric in metric_names:
                exact_val = exact_measures[metric]
                approx_val = approximate_measures[method_name][metric]

                abs_error = abs(exact_val - approx_val)
                abs_errors.append(abs_error)

            # Overall score: combine low error with high label quality
            avg_abs_error = np.mean(abs_errors)
            ari = label_quality_metrics[method_name]['ari']
            nmi = label_quality_metrics[method_name]['nmi']

            # Score: high ARI/NMI, low error (normalize to 0-1)
            label_quality_score = (ari + nmi) / 2
            error_score = 1 / (1 + avg_abs_error)  # Lower error = higher score

            overall_score = 0.6 * label_quality_score + 0.4 * error_score

            method_scores[method_name] = {
                'overall_score': overall_score,
                'label_quality_score': label_quality_score,
                'error_score': error_score,
                'avg_abs_error': avg_abs_error,
                'ari': ari,
                'nmi': nmi
            }

        # Find best method
        best_method_name = max(method_scores.keys(), key=lambda x: method_scores[x]['overall_score'])

        # Find best individual metric correlation
        best_metric_corr = 0
        best_metric = None

        for metric in metric_names:
            exact_val = exact_measures[metric]
            approx_val = approximate_measures[best_method_name][metric]
            correlation = 1 - abs(exact_val - approx_val) / (abs(exact_val) + 1e-10)

            if correlation > best_metric_corr:
                best_metric_corr = correlation
                best_metric = metric

        return {
            'method': best_method_name,
            'overall_score': method_scores[best_method_name]['overall_score'],
            'overall_correlation': method_scores[best_method_name]['label_quality_score'],
            'best_metric': best_metric,
            'best_correlation': best_metric_corr,
            'all_scores': method_scores
        }


class NodeClassificationEvaluator:
    """Evaluate node classification performance using real vs affinity-derived labels."""

    def __init__(self, config: ComparisonConfig):
        self.config = config

    def evaluate_classification_performance(self, features: np.ndarray,
                                            true_labels: np.ndarray,
                                            pseudo_labels_dict: Dict[str, np.ndarray],
                                            edge_array: Optional[np.ndarray] = None,
                                            dataset_masks: Optional[Dict[str, np.ndarray]] = None) -> Dict[str, any]:
        """Evaluate node classification using REAL dataset splits when available."""

        print(f"\n{'=' * 60}")
        print("NODE CLASSIFICATION EVALUATION")
        print(f"{'=' * 60}")

        # CRITICAL: Validate and use dataset splits
        train_mask, val_mask, test_mask = self._validate_and_extract_splits(dataset_masks, len(true_labels))

        if train_mask is None or test_mask is None:
            print("❌ ERROR: No valid dataset splits available!")
            print("❌ Cannot proceed without real train/test splits")
            return {'error': 'No valid dataset splits available'}

        # Extract indices from masks
        train_indices = np.where(train_mask)[0]
        test_indices = np.where(test_mask)[0]
        val_indices = np.where(val_mask)[0] if val_mask is not None else None

        print(f"✅ Using REAL dataset splits:")
        print(f"   Train: {len(train_indices)} nodes")
        print(f"   Test:  {len(test_indices)} nodes")
        if val_indices is not None:
            print(f"   Val:   {len(val_indices)} nodes")

        # Validate splits don't overlap
        self._validate_split_integrity(train_indices, test_indices, val_indices)

        results = {
            'baseline_performance': {},
            'pseudo_label_performance': {},
            'semi_supervised_performance': {},
            'heterophily_impact': {},
            'split_info': {
                'using_real_splits': True,
                'train_size': len(train_indices),
                'test_size': len(test_indices),
                'val_size': len(val_indices) if val_indices is not None else 0,
                'total_nodes': len(true_labels)
            }
        }

        # 1. Baseline: Classification with true labels
        print("\n1. Baseline classification with TRUE LABELS and REAL SPLITS...")
        baseline_results = self._evaluate_with_real_splits(
            features, true_labels, true_labels, train_indices, test_indices, val_indices, "baseline"
        )
        results['baseline_performance'] = baseline_results

        # 2. Classification with pseudo-labels
        print("\n2. Classification with PSEUDO-LABELS and REAL SPLITS...")
        pseudo_results = {}

        for method_name, pseudo_labels in pseudo_labels_dict.items():
            print(f"  📊 Evaluating {method_name} with REAL splits...")
            method_results = self._evaluate_with_real_splits(
                features, true_labels, pseudo_labels, train_indices, test_indices, val_indices, method_name
            )
            pseudo_results[method_name] = method_results

        results['pseudo_label_performance'] = pseudo_results

        # 3. Semi-supervised: Combine real + pseudo labels
        print("\n3. Semi-supervised classification with REAL SPLITS...")
        semi_supervised_results = self._evaluate_semi_supervised_with_real_splits(
            features, true_labels, pseudo_labels_dict, train_indices, test_indices, val_indices
        )
        results['semi_supervised_performance'] = semi_supervised_results

        # 4. Analyze heterophily impact
        if edge_array is not None:
            print("\n4. Analyzing heterophily impact on classification...")
            heterophily_impact = self._analyze_heterophily_impact(
                features, true_labels, pseudo_labels_dict, edge_array
            )
            results['heterophily_impact'] = heterophily_impact

        return results

    def _validate_and_extract_splits(self, dataset_masks: Optional[Dict[str, np.ndarray]],
                                     n_nodes: int) -> tuple:
        """Validate and extract train/val/test splits from dataset masks."""

        if dataset_masks is None:
            print("❌ No dataset_masks provided")
            return None, None, None

        print(f"📋 Available masks: {list(dataset_masks.keys())}")

        # Look for standard mask names
        train_mask = None
        val_mask = None
        test_mask = None

        # Priority order for finding masks
        train_candidates = ['train_mask', 'training_mask', 'train_idx']
        val_candidates = ['val_mask', 'validation_mask', 'val_idx', 'valid_mask']
        test_candidates = ['test_mask', 'testing_mask', 'test_idx']

        # Find train mask
        for candidate in train_candidates:
            if candidate in dataset_masks:
                mask = dataset_masks[candidate]
                if self._validate_mask(mask, n_nodes, candidate):
                    train_mask = mask
                    print(f"✅ Found train mask: {candidate} ({mask.sum()} nodes)")
                    break

        # Find test mask
        for candidate in test_candidates:
            if candidate in dataset_masks:
                mask = dataset_masks[candidate]
                if self._validate_mask(mask, n_nodes, candidate):
                    test_mask = mask
                    print(f"✅ Found test mask: {candidate} ({mask.sum()} nodes)")
                    break

        # Find val mask (optional)
        for candidate in val_candidates:
            if candidate in dataset_masks:
                mask = dataset_masks[candidate]
                if self._validate_mask(mask, n_nodes, candidate):
                    val_mask = mask
                    print(f"✅ Found val mask: {candidate} ({mask.sum()} nodes)")
                    break

        if train_mask is None:
            print("❌ No valid train mask found!")
        if test_mask is None:
            print("❌ No valid test mask found!")
        if val_mask is None:
            print("⚠️ No validation mask found (optional)")

        return train_mask, val_mask, test_mask

    def _validate_mask(self, mask: np.ndarray, n_nodes: int, mask_name: str) -> bool:
        """Validate that a mask is properly formatted."""

        if mask is None:
            return False

        if len(mask) != n_nodes:
            print(f"❌ {mask_name}: length {len(mask)} != {n_nodes} nodes")
            return False

        if mask.dtype != bool:
            print(f"❌ {mask_name}: not boolean mask (dtype: {mask.dtype})")
            return False

        if mask.sum() == 0:
            print(f"❌ {mask_name}: empty mask (0 nodes)")
            return False

        return True

    def _validate_split_integrity(self, train_indices: np.ndarray, test_indices: np.ndarray,
                                  val_indices: Optional[np.ndarray]):
        """Validate that train/val/test splits don't overlap."""

        # Check train-test overlap
        train_test_overlap = np.intersect1d(train_indices, test_indices)
        if len(train_test_overlap) > 0:
            print(f"❌ WARNING: {len(train_test_overlap)} nodes overlap between train and test!")

        # Check train-val overlap
        if val_indices is not None:
            train_val_overlap = np.intersect1d(train_indices, val_indices)
            if len(train_val_overlap) > 0:
                print(f"❌ WARNING: {len(train_val_overlap)} nodes overlap between train and val!")

            # Check val-test overlap
            val_test_overlap = np.intersect1d(val_indices, test_indices)
            if len(val_test_overlap) > 0:
                print(f"❌ WARNING: {len(val_test_overlap)} nodes overlap between val and test!")

        print("✅ Split integrity validated")

    def _evaluate_with_real_splits(self, features: np.ndarray, true_labels: np.ndarray,
                                   train_labels: np.ndarray, train_indices: np.ndarray,
                                   test_indices: np.ndarray, val_indices: Optional[np.ndarray],
                                   method_name: str) -> Dict[str, any]:
        """Evaluate classification using REAL dataset splits."""

        results = {}

        # Extract train/test data using REAL splits
        X_train = features[train_indices]
        X_test = features[test_indices]
        y_train_true = true_labels[train_indices]
        y_test_true = true_labels[test_indices]
        y_train_method = train_labels[train_indices]  # These are the labels we train with

        print(f"    🎯 {method_name}: Training with REAL splits")
        print(f"       Train shape: {X_train.shape}, Test shape: {X_test.shape}")
        print(f"       Train labels: {len(np.unique(y_train_method))} classes")
        print(f"       Test labels: {len(np.unique(y_test_true))} classes")

        # Evaluate different classifiers
        for clf_name in self.config.classifiers:
            try:
                if clf_name == 'logistic':
                    clf = LogisticRegression(random_state=42, max_iter=1000)
                elif clf_name == 'random_forest':
                    clf = RandomForestClassifier(n_estimators=100, random_state=42)
                elif clf_name == 'svm':
                    clf = SVC(random_state=42)
                else:
                    continue

                # Train on method labels (could be true or pseudo), test on true labels
                clf.fit(X_train, y_train_method)
                y_pred = clf.predict(X_test)

                # Evaluate against TRUE test labels
                accuracy = accuracy_score(y_test_true, y_pred)
                f1 = f1_score(y_test_true, y_pred, average='weighted')

                # Additional metrics
                unique_train_labels = len(np.unique(y_train_method))
                unique_test_labels = len(np.unique(y_test_true))

                results[clf_name] = {
                    'accuracy': accuracy,
                    'f1_score': f1,
                    'train_classes': unique_train_labels,
                    'test_classes': unique_test_labels,
                    'train_size': len(train_indices),
                    'test_size': len(test_indices),
                    'using_real_splits': True
                }

                print(f"        {clf_name}: Acc={accuracy:.3f}, F1={f1:.3f} "
                      f"(train_cls={unique_train_labels}, test_cls={unique_test_labels})")

            except Exception as e:
                print(f"        {clf_name}: ❌ Failed - {e}")
                continue

        return results

    def _evaluate_semi_supervised_with_real_splits(self, features: np.ndarray, true_labels: np.ndarray,
                                                   pseudo_labels_dict: Dict[str, np.ndarray],
                                                   train_indices: np.ndarray, test_indices: np.ndarray,
                                                   val_indices: Optional[np.ndarray]) -> Dict[str, any]:
        """Evaluate semi-supervised learning using REAL dataset splits."""

        results = {}

        # Use a subset of REAL training data as "labeled" data
        labeled_ratio = 0.1  # Use 10% of training set as labeled
        n_labeled = max(1, int(len(train_indices) * labeled_ratio))

        print(f"    🎯 Semi-supervised: Using {n_labeled}/{len(train_indices)} training nodes as labeled")

        # Stratified sampling within the REAL training set
        train_labels_subset = true_labels[train_indices]

        try:
            labeled_idx_relative, unlabeled_idx_relative = train_test_split(
                range(len(train_indices)),
                train_size=labeled_ratio,
                stratify=train_labels_subset,
                random_state=42
            )

            # Convert back to absolute indices within the REAL training set
            labeled_idx_absolute = train_indices[labeled_idx_relative]
            unlabeled_idx_absolute = train_indices[unlabeled_idx_relative]

        except ValueError:
            # If stratification fails, use random sampling within training set
            np.random.seed(42)
            shuffled_train_indices = np.random.permutation(train_indices)
            labeled_idx_absolute = shuffled_train_indices[:n_labeled]
            unlabeled_idx_absolute = shuffled_train_indices[n_labeled:]

        print(f"       Labeled subset: {len(labeled_idx_absolute)} nodes")
        print(f"       Unlabeled subset: {len(unlabeled_idx_absolute)} nodes")

        for method_name, pseudo_labels in pseudo_labels_dict.items():
            print(f"    📊 Semi-supervised with {method_name}...")

            # Create combined labels: TRUE labels for labeled subset, PSEUDO for unlabeled subset
            combined_labels = pseudo_labels.copy()
            combined_labels[labeled_idx_absolute] = true_labels[labeled_idx_absolute]

            # Evaluate using REAL train/test splits
            method_results = self._evaluate_with_real_splits(
                features, true_labels, combined_labels, train_indices, test_indices, val_indices,
                f"semi_{method_name}"
            )
            results[method_name] = method_results

        return results

    def _analyze_heterophily_impact(self, features: np.ndarray, true_labels: np.ndarray,
                                    pseudo_labels_dict: Dict[str, np.ndarray],
                                    edge_array: np.ndarray) -> Dict[str, any]:
        """Analyze how heterophily affects classification performance."""

        analysis = {}

        # Compute heterophily measures for true labels
        try:
            true_node_h = HomophilyCalculator.node_homophily(edge_array, true_labels)
            true_edge_h = HomophilyCalculator.edge_homophily(edge_array, true_labels)

            analysis['true_heterophily'] = {
                'node_homophily': true_node_h,
                'edge_homophily': true_edge_h
            }

            print(f"    📊 True heterophily: node={true_node_h:.3f}, edge={true_edge_h:.3f}")

        except Exception as e:
            print(f"    ❌ Failed to compute true heterophily: {e}")
            return {}

        # For each pseudo-label method, analyze relationship between heterophily and performance
        method_analysis = {}

        for method_name, pseudo_labels in pseudo_labels_dict.items():
            try:
                # Compute heterophily for pseudo labels
                pseudo_node_h = HomophilyCalculator.node_homophily(edge_array, pseudo_labels)
                pseudo_edge_h = HomophilyCalculator.edge_homophily(edge_array, pseudo_labels)

                method_analysis[method_name] = {
                    'pseudo_node_homophily': pseudo_node_h,
                    'pseudo_edge_homophily': pseudo_edge_h,
                    'node_homophily_diff': abs(true_node_h - pseudo_node_h),
                    'edge_homophily_diff': abs(true_edge_h - pseudo_edge_h)
                }

                print(f"       {method_name}: node={pseudo_node_h:.3f}, edge={pseudo_edge_h:.3f}")

            except Exception as e:
                print(f"       ❌ {method_name}: Failed to compute heterophily - {e}")

        analysis['method_analysis'] = method_analysis
        return analysis


class HeterophilyComparisonFramework:
    """Main framework orchestrating all heterophily comparisons and evaluations."""

    def __init__(self, config: ComparisonConfig):
        self.config = config
        self.comparator = HeterophilyComparator(config)
        self.evaluator = NodeClassificationEvaluator(config)

    def run_complete_analysis(self, features: np.ndarray, edge_array: np.ndarray,
                              true_labels: np.ndarray, affinity_model,
                              dataset_name: str, dataset_masks: Optional[Dict[str, np.ndarray]] = None) -> Dict[
        str, any]:
        """Run complete heterophily comparison and node classification analysis."""

        print(f"\n{'=' * 80}")
        print(f"COMPLETE HETEROPHILY ANALYSIS: {dataset_name}")
        if dataset_masks:
            print(f"Using dataset splits: {list(dataset_masks.keys())}")
        print(f"{'=' * 80}")

        # 1. Compare heterophily measures (exact vs approximate)
        heterophily_comparison = self.comparator.compare_heterophily_approximations(
            edge_array, true_labels, affinity_model, dataset_name
        )

        # 2. Get pseudo-labels from affinity model
        converter = AffinityToLabelsConverter(self.config)
        affinity_vectors = np.array(affinity_model.affinity)
        true_n_classes = len(np.unique(true_labels))
        pseudo_labels_dict = converter.affinity_vectors_to_labels(affinity_vectors, true_n_classes)

        # 3. Evaluate node classification performance with dataset masks
        classification_evaluation = self.evaluator.evaluate_classification_performance(
            features, true_labels, pseudo_labels_dict, edge_array, dataset_masks
        )

        # 4. Combine results and create summary
        complete_results = {
            'dataset': dataset_name,
            'heterophily_comparison': heterophily_comparison,
            'classification_evaluation': classification_evaluation,
            'summary': self._create_summary(heterophily_comparison, classification_evaluation),
            'dataset_masks_used': dataset_masks is not None
        }

        # 5. Generate visualizations if requested
        if self.config.save_plots:
            self._generate_visualizations(complete_results, dataset_name)

        return complete_results

    def _create_summary(self, heterophily_comparison: Dict, classification_evaluation: Dict) -> Dict[str, any]:
        """Create a summary of key findings."""

        summary = {}

        # Best heterophily approximation
        if 'best_approximation' in heterophily_comparison:
            best_approx = heterophily_comparison['best_approximation']
            summary['best_heterophily_approximation'] = {
                'method': best_approx['method'],
                'overall_score': best_approx['overall_score'],
                'recommendation': f"Use {best_approx['method']} for heterophily approximation"
            }

        # Best classification performance with pseudo-labels
        if 'pseudo_label_performance' in classification_evaluation:
            best_performance = 0
            best_method = None

            for method, results in classification_evaluation['pseudo_label_performance'].items():
                for classifier, metrics in results.items():
                    if metrics.get('accuracy', 0) > best_performance:
                        best_performance = metrics['accuracy']
                        best_method = f"{method}_{classifier}"

            summary['best_classification_performance'] = {
                'method': best_method,
                'accuracy': best_performance,
                'recommendation': f"Use {best_method} for node classification"
            }

        # Overall recommendation
        summary['overall_recommendation'] = self._generate_overall_recommendation(
            heterophily_comparison, classification_evaluation
        )

        return summary

    def _generate_overall_recommendation(self, heterophily_comparison: Dict,
                                         classification_evaluation: Dict) -> str:
        """Generate overall recommendation based on analysis."""

        recommendations = []

        # Check if affinity is good proxy for heterophily
        if 'best_approximation' in heterophily_comparison:
            best_score = heterophily_comparison['best_approximation']['overall_score']
            if best_score > 0.7:
                recommendations.append("✅ Affinity coefficients are a good proxy for heterophily measures")
            elif best_score > 0.5:
                recommendations.append("⚠️ Affinity coefficients provide moderate approximation of heterophily")
            else:
                recommendations.append("❌ Affinity coefficients poorly approximate heterophily measures")

        # Check classification performance
        baseline_acc = 0
        best_pseudo_acc = 0

        if 'baseline_performance' in classification_evaluation:
            baseline_results = classification_evaluation['baseline_performance']
            baseline_acc = max([metrics.get('accuracy', 0) for metrics in baseline_results.values()])

        if 'pseudo_label_performance' in classification_evaluation:
            for method_results in classification_evaluation['pseudo_label_performance'].values():
                for metrics in method_results.values():
                    best_pseudo_acc = max(best_pseudo_acc, metrics.get('accuracy', 0))

        if best_pseudo_acc > 0.8 * baseline_acc:
            recommendations.append("✅ Affinity-derived labels achieve good classification performance")
        elif best_pseudo_acc > 0.6 * baseline_acc:
            recommendations.append("⚠️ Affinity-derived labels achieve moderate classification performance")
        else:
            recommendations.append("❌ Affinity-derived labels achieve poor classification performance")

        return " | ".join(recommendations)

    def _generate_visualizations(self, results: Dict, dataset_name: str):
        """Generate visualizations for the analysis."""

        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle(f'Heterophily Analysis: {dataset_name}', fontsize=16)

            # Plot 1: Heterophily measure comparison
            if 'heterophily_comparison' in results:
                heterophily_data = results['heterophily_comparison']
                if 'exact_measures' in heterophily_data and 'approximate_measures' in heterophily_data:
                    self._plot_heterophily_comparison(axes[0, 0], heterophily_data)

            # Plot 2: Classification performance comparison
            if 'classification_evaluation' in results:
                self._plot_classification_performance(axes[0, 1], results['classification_evaluation'])

            # Plot 3: Method rankings
            if 'heterophily_comparison' in results:
                self._plot_method_rankings(axes[1, 0], results['heterophily_comparison'])

            # Plot 4: Summary scores
            self._plot_summary_scores(axes[1, 1], results)

            plt.tight_layout()
            plt.savefig(f'heterophily_analysis_{dataset_name}.png', dpi=300, bbox_inches='tight')
            plt.show()

        except Exception as e:
            print(f"Could not generate visualizations: {e}")

    def _plot_heterophily_comparison(self, ax, heterophily_data):
        """Plot comparison of exact vs approximate heterophily measures."""
        ax.set_title('Exact vs Approximate Heterophily')
        ax.text(0.5, 0.5, 'Heterophily Comparison\n(Implementation needed)',
                ha='center', va='center', transform=ax.transAxes)

    def _plot_classification_performance(self, ax, classification_data):
        """Plot classification performance comparison."""
        ax.set_title('Classification Performance')
        ax.text(0.5, 0.5, 'Classification Performance\n(Implementation needed)',
                ha='center', va='center', transform=ax.transAxes)

    def _plot_method_rankings(self, ax, heterophily_data):
        """Plot method rankings."""
        ax.set_title('Method Rankings')
        ax.text(0.5, 0.5, 'Method Rankings\n(Implementation needed)',
                ha='center', va='center', transform=ax.transAxes)

    def _plot_summary_scores(self, ax, results):
        """Plot summary scores."""
        ax.set_title('Summary Scores')
        ax.text(0.5, 0.5, 'Summary Scores\n(Implementation needed)',
                ha='center', va='center', transform=ax.transAxes)


# Convenience function for quick analysis
def run_heterophily_analysis(features: np.ndarray, edge_array: np.ndarray,
                             true_labels: np.ndarray, affinity_model,
                             dataset_name: str, config: Optional[ComparisonConfig] = None,
                             dataset_masks: Optional[Dict[str, np.ndarray]] = None) -> Dict[str, any]:
    """Quick function to run complete heterophily analysis."""

    if config is None:
        config = ComparisonConfig()

    framework = HeterophilyComparisonFramework(config)
    return framework.run_complete_analysis(
        features, edge_array, true_labels, affinity_model, dataset_name, dataset_masks
    )


if __name__ == "__main__":
    # Example usage
    print("Heterophily Comparison Framework")
    print("================================")
    print("This framework compares exact vs approximate heterophily measures")
    print("and evaluates node classification performance in heterophilous settings.")
    print()
    print("Key capabilities:")
    print("1. Convert affinity vectors to pseudo-labels using multiple methods")
    print("2. Compare heterophily measures between real and pseudo labels")
    print("3. Evaluate node classification performance")
    print("4. Provide recommendations on using affinity as heterophily proxy")
    print("5. ENFORCE use of real dataset train/val/test splits")
    print()
    print("Usage:")
    print("from HeterophilyComparison import run_heterophily_analysis")
    print("results = run_heterophily_analysis(features, edges, labels, model, 'dataset_name', dataset_masks=masks)")
