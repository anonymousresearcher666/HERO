"""
Integrated Experiment Framework with Heterophily Comparison
Extends the generic affinity framework with heterophily analysis and node classification evaluation
"""

import os
import time
from dataclasses import dataclass
from typing import Dict, List, Any, Optional

import numpy as np
import pandas as pd
# Import the new heterophily comparison framework
from HeterophilyComparison import (
    ComparisonConfig, HeterophilyComparisonFramework,
    run_heterophily_analysis
)
# Import your existing framework
from experimentRunner import (
    ExperimentConfig, ModelConfig, TrainingConfig,
    AffinityExperiment, ModelFactory, GenericAffinityTrainer
)

from hero.data.torch_loader import load_torch_dataset

try:
    import mlx.core as mx
    import mlx.nn as nn
except ImportError:
    print("MLX not available")


@dataclass
class ExtendedExperimentConfig:
    """Extended configuration that includes heterophily comparison."""

    # Original affinity experiment config
    affinity_config: ExperimentConfig

    # Heterophily comparison config
    comparison_config: ComparisonConfig

    # Extended analysis options
    run_heterophily_comparison: bool = True
    run_node_classification: bool = True
    save_detailed_results: bool = True
    compare_with_baselines: bool = True

    # Result organization
    experiment_name: str = "heterophily_analysis"
    results_subdir: str = "heterophily_experiments"


class ExtendedAffinityExperiment(AffinityExperiment):
    """Extended experiment class that includes heterophily comparison and node classification."""

    def __init__(self, config: ExtendedExperimentConfig):
        # Initialize base affinity experiment
        super().__init__(config.affinity_config)

        self.extended_config = config
        self.comparison_framework = HeterophilyComparisonFramework(config.comparison_config)

        # Update results organization
        self.experiment_name = config.experiment_name
        self._setup_extended_results_structure()

    def _setup_extended_results_structure(self):
        """Setup extended results directory structure."""

        # Create subdirectory for this experiment
        self.extended_results_folder = os.path.join(
            self.results_folder,
            self.extended_config.results_subdir,
            self.experiment_name
        )
        os.makedirs(self.extended_results_folder, exist_ok=True)
        os.makedirs(os.path.join(self.extended_results_folder, "plots"), exist_ok=True)
        os.makedirs(os.path.join(self.extended_results_folder, "detailed"), exist_ok=True)

        # Update results filename to include experiment name
        model_type = self.config.model_config.model_type
        self.extended_results_filename = f"{self.experiment_name}_{model_type}_results.csv"
        self.extended_results_path = os.path.join(
            self.extended_results_folder,
            self.extended_results_filename
        )

        # Extended result columns
        extended_cols = [
            'dataset', 'nodes', 'features', 'classes', 'directed', 'model_type',
            'emb_ratio', 'max_nodes', 'k', 'init_lr', 'lr_decay', 'epochs',
            'actual_epochs', 'early_stopped', 'best_epoch', 'best_score',

            # Original homophily measures
            'node_homophily', 'edge_homophily', 'adjusted_homophily', 'label_informativeness', 'affinity_h',

            # Heterophily comparison results
            'best_approximation_method', 'approximation_quality_score', 'approximation_correlation',
            'heterophily_proxy_usable', 'n_conversion_methods_tested',

            # Node classification results
            'baseline_classification_accuracy', 'best_pseudo_classification_accuracy',
            'best_pseudo_method', 'classification_performance_ratio',
            'semi_supervised_improvement', 'heterophily_classification_impact',

            # Overall recommendations
            'overall_recommendation_score', 'use_for_heterophily_proxy', 'use_for_node_classification',

            'elapsed', 'comparison_elapsed', 'seed'
        ]

        try:
            self.extended_results_df = pd.read_csv(self.extended_results_path)
            print(f"Loaded existing extended results from: {self.extended_results_path}")
        except:
            self.extended_results_df = pd.DataFrame(columns=extended_cols)
            print(f"Created new extended results file: {self.extended_results_path}")

    def run_single_dataset_extended(self, dataset_name: str) -> Dict[str, Any]:
        """Run extended experiment on a single dataset including heterophily comparison."""

        print(f"\n{'=' * 80}")
        print(f"EXTENDED EXPERIMENT: {dataset_name}")
        print(f"Experiment: {self.experiment_name}")
        print(f"Model: {self.config.model_config.model_type}")
        print(f"{'=' * 80}")

        # 1. Run standard affinity experiment
        print("PHASE 1: Running standard affinity experiment...")
        standard_result = self.run_single_dataset(dataset_name)

        if not standard_result['success']:
            print(f"Standard experiment failed for {dataset_name}")
            return standard_result

        # 2. Run heterophily comparison if requested
        comparison_result = None
        comparison_elapsed = 0

        if self.extended_config.run_heterophily_comparison:
            print("\nPHASE 2: Running heterophily comparison analysis...")
            comparison_start = time.time()

            try:
                # Load dataset again to get features
                X, E, n_classes, labels = load_torch_dataset(dataset_name)

                # Convert edges to array format
                if hasattr(E, 'src') and hasattr(E, 'dst'):
                    edge_array = np.stack([np.array(E.src), np.array(E.dst)], axis=1)
                else:
                    edge_array = self._convert_edges_to_array(E)

                # Create the trained affinity model (we need to recreate it)
                X_mlx = mx.array(X)
                affinity_model = ModelFactory.create_model(X_mlx, self.config.model_config)

                # We would need to retrain or load the model here
                # For now, let's create a fresh model (in practice, you'd save/load the trained model)
                training_config = self.config.training_config
                trainer = GenericAffinityTrainer(affinity_model, training_config)

                # Quick training (or load pre-trained weights)
                edge_data_mlx = mx.array(edge_array)
                hist_loss, hist_aff = trainer.train(X_mlx, edge_data_mlx, self.rng)

                # Run heterophily comparison
                comparison_result = self.comparison_framework.run_complete_analysis(
                    X, edge_array, labels, affinity_model, dataset_name
                )

                comparison_elapsed = int(time.time() - comparison_start)
                print(f"Heterophily comparison completed in {comparison_elapsed}s")

                # Save detailed comparison results
                if self.extended_config.save_detailed_results:
                    self._save_detailed_comparison_results(comparison_result, dataset_name)

            except Exception as e:
                print(f"Heterophily comparison failed: {e}")
                import traceback
                traceback.print_exc()
                comparison_result = {'error': str(e)}

        # 3. Combine and save extended results
        extended_result = self._create_extended_result(
            standard_result, comparison_result, comparison_elapsed
        )

        # 4. Save to extended results CSV
        self._save_extended_results(extended_result)

        # 5. Print extended summary
        self._print_extended_summary(extended_result)

        return extended_result

    def _create_extended_result(self, standard_result: Dict[str, Any],
                                comparison_result: Optional[Dict[str, Any]],
                                comparison_elapsed: int) -> Dict[str, Any]:
        """Create extended result combining standard and comparison results."""

        extended = standard_result.copy()
        extended['comparison_result'] = comparison_result
        extended['comparison_elapsed'] = comparison_elapsed

        # Extract key metrics from comparison
        if comparison_result and 'error' not in comparison_result:

            # Heterophily approximation metrics
            heterophily_comp = comparison_result.get('heterophily_comparison', {})
            best_approx = heterophily_comp.get('best_approximation', {})

            extended['best_approximation_method'] = best_approx.get('method', 'unknown')
            extended['approximation_quality_score'] = best_approx.get('overall_score', 0.0)
            extended['approximation_correlation'] = best_approx.get('overall_correlation', 0.0)
            extended['heterophily_proxy_usable'] = best_approx.get('overall_score', 0.0) > 0.6

            conversion_results = heterophily_comp.get('label_conversion_results', {})
            extended['n_conversion_methods_tested'] = conversion_results.get('n_methods', 0)

            # Node classification metrics
            classification_eval = comparison_result.get('classification_evaluation', {})

            # Baseline performance
            baseline_perf = classification_eval.get('baseline_performance', {})
            if baseline_perf:
                baseline_accs = [metrics['accuracy'] for metrics in baseline_perf.values()]
                extended['baseline_classification_accuracy'] = max(baseline_accs) if baseline_accs else 0.0
            else:
                extended['baseline_classification_accuracy'] = 0.0

            # Best pseudo-label performance
            pseudo_perf = classification_eval.get('pseudo_label_performance', {})
            best_pseudo_acc = 0.0
            best_pseudo_method = 'none'

            for method_name, method_results in pseudo_perf.items():
                for clf_name, metrics in method_results.items():
                    if metrics['accuracy'] > best_pseudo_acc:
                        best_pseudo_acc = metrics['accuracy']
                        best_pseudo_method = f"{method_name}_{clf_name}"

            extended['best_pseudo_classification_accuracy'] = best_pseudo_acc
            extended['best_pseudo_method'] = best_pseudo_method

            # Performance ratio
            baseline_acc = extended['baseline_classification_accuracy']
            if baseline_acc > 0:
                extended['classification_performance_ratio'] = best_pseudo_acc / baseline_acc
            else:
                extended['classification_performance_ratio'] = 0.0

            # Semi-supervised improvement
            semi_perf = classification_eval.get('semi_supervised_performance', {})
            if semi_perf:
                # Calculate improvement over pure pseudo-label methods
                extended['semi_supervised_improvement'] = 0.1  # Placeholder
            else:
                extended['semi_supervised_improvement'] = 0.0

            # Heterophily impact on classification
            heterophily_impact = classification_eval.get('heterophily_impact', {})
            extended['heterophily_classification_impact'] = len(heterophily_impact) > 0

            # Overall recommendations
            summary = comparison_result.get('summary', {})
            overall_rec = summary.get('overall_recommendation', '')

            # Score based on recommendation content
            if '✅' in overall_rec:
                recommendation_score = len([x for x in overall_rec.split('|') if '✅' in x]) / 2.0
            else:
                recommendation_score = 0.0

            extended['overall_recommendation_score'] = min(recommendation_score, 1.0)
            extended['use_for_heterophily_proxy'] = extended['approximation_quality_score'] > 0.6
            extended['use_for_node_classification'] = extended['classification_performance_ratio'] > 0.7

        else:
            # Fill with defaults if comparison failed
            extended.update({
                'best_approximation_method': 'failed',
                'approximation_quality_score': 0.0,
                'approximation_correlation': 0.0,
                'heterophily_proxy_usable': False,
                'n_conversion_methods_tested': 0,
                'baseline_classification_accuracy': 0.0,
                'best_pseudo_classification_accuracy': 0.0,
                'best_pseudo_method': 'failed',
                'classification_performance_ratio': 0.0,
                'semi_supervised_improvement': 0.0,
                'heterophily_classification_impact': False,
                'overall_recommendation_score': 0.0,
                'use_for_heterophily_proxy': False,
                'use_for_node_classification': False
            })

        return extended

    def _save_detailed_comparison_results(self, comparison_result: Dict[str, Any], dataset_name: str):
        """Save detailed comparison results to separate files."""

        detailed_dir = os.path.join(self.extended_results_folder, "detailed")

        # Save as JSON for full detail
        import json

        # Convert numpy arrays to lists for JSON serialization
        def convert_for_json(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, dict):
                return {k: convert_for_json(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_for_json(item) for item in obj]
            else:
                return obj

        json_result = convert_for_json(comparison_result)

        json_path = os.path.join(detailed_dir, f"{dataset_name}_detailed_results.json")
        with open(json_path, 'w') as f:
            json.dump(json_result, f, indent=2)

        print(f"Detailed results saved to: {json_path}")

    def _save_extended_results(self, extended_result: Dict[str, Any]):
        """Save extended results to CSV."""

        if not self.extended_config.save_detailed_results:
            return

        # Extract values for CSV row
        metrics = extended_result.get('metrics', {})
        training_info = extended_result.get('training_info', {})
        training_params = extended_result.get('training_params', {})

        new_row = [
            extended_result['dataset'],
            training_params.get('n_nodes', 0),
            training_params.get('n_features', 0),
            training_params.get('n_classes', 0),
            True,  # directed
            self.config.model_config.model_type,
            training_params.get('emb_ratio', 0),
            training_params.get('max_nodes', 0),
            training_params.get('k', 0),
            training_params.get('init_lr', 0),
            training_params.get('lr_decay', 0),
            training_params.get('epochs', 0),
            training_info.get('total_epochs', 0),
            training_info.get('stopped_early', False),
            training_info.get('best_epoch', 0),
            training_info.get('best_score', 0),

            # Original homophily measures
            metrics.get('node_h', 0),
            metrics.get('edge_h', 0),
            metrics.get('adjusted_edge_h', 0),
            metrics.get('label_informativeness', 0),
            metrics.get('affinity_h', 0),

            # Extended metrics
            extended_result.get('best_approximation_method', ''),
            extended_result.get('approximation_quality_score', 0),
            extended_result.get('approximation_correlation', 0),
            extended_result.get('heterophily_proxy_usable', False),
            extended_result.get('n_conversion_methods_tested', 0),
            extended_result.get('baseline_classification_accuracy', 0),
            extended_result.get('best_pseudo_classification_accuracy', 0),
            extended_result.get('best_pseudo_method', ''),
            extended_result.get('classification_performance_ratio', 0),
            extended_result.get('semi_supervised_improvement', 0),
            extended_result.get('heterophily_classification_impact', False),
            extended_result.get('overall_recommendation_score', 0),
            extended_result.get('use_for_heterophily_proxy', False),
            extended_result.get('use_for_node_classification', False),

            extended_result.get('elapsed', 0),
            extended_result.get('comparison_elapsed', 0),
            self.config.seed
        ]

        self.extended_results_df.loc[len(self.extended_results_df)] = new_row
        self.extended_results_df.to_csv(self.extended_results_path, index=False)
        print(f"Extended results saved to: {self.extended_results_path}")

    def _print_extended_summary(self, extended_result: Dict[str, Any]):
        """Print extended summary including heterophily comparison results."""

        print(f"\n{'=' * 80}")
        print(f"EXTENDED SUMMARY: {extended_result['dataset']}")
        print(f"{'=' * 80}")

        # Standard metrics
        metrics = extended_result.get('metrics', {})
        print("\nStandard Homophily Measures:")
        print(f"  Node Homophily:        {metrics.get('node_h', 0):.4f}")
        print(f"  Edge Homophily:        {metrics.get('edge_h', 0):.4f}")
        print(f"  Adjusted Homophily:    {metrics.get('adjusted_edge_h', 0):.4f}")
        print(f"  Label Informativeness: {metrics.get('label_informativeness', 0):.4f}")
        print(f"  Affinity Homophily:    {metrics.get('affinity_h', 0):.4f}")

        # Extended analysis
        print("\nHeterophily Approximation Analysis:")
        print(f"  Best Method:           {extended_result.get('best_approximation_method', 'N/A')}")
        print(f"  Quality Score:         {extended_result.get('approximation_quality_score', 0):.4f}")
        print(
            f"  Usable as Proxy:       {'✅ Yes' if extended_result.get('heterophily_proxy_usable', False) else '❌ No'}")

        print("\nNode Classification Analysis:")
        print(f"  Baseline Accuracy:     {extended_result.get('baseline_classification_accuracy', 0):.4f}")
        print(f"  Best Pseudo Accuracy:  {extended_result.get('best_pseudo_classification_accuracy', 0):.4f}")
        print(f"  Performance Ratio:     {extended_result.get('classification_performance_ratio', 0):.4f}")
        print(f"  Best Pseudo Method:    {extended_result.get('best_pseudo_method', 'N/A')}")
        print(
            f"  Usable for Classification: {'✅ Yes' if extended_result.get('use_for_node_classification', False) else '❌ No'}")

        print("\nOverall Recommendation:")
        overall_score = extended_result.get('overall_recommendation_score', 0)
        if overall_score > 0.8:
            print("  🎯 EXCELLENT: Affinity coefficients work very well as heterophily proxy")
        elif overall_score > 0.6:
            print("  ✅ GOOD: Affinity coefficients provide good heterophily approximation")
        elif overall_score > 0.4:
            print("  ⚠️ MODERATE: Affinity coefficients provide moderate heterophily approximation")
        else:
            print("  ❌ POOR: Affinity coefficients are not suitable as heterophily proxy")

        # Timing info
        print(f"\nTiming:")
        print(f"  Affinity Training:     {extended_result.get('elapsed', 0)}s")
        print(f"  Heterophily Analysis:  {extended_result.get('comparison_elapsed', 0)}s")
        print(
            f"  Total:                 {extended_result.get('elapsed', 0) + extended_result.get('comparison_elapsed', 0)}s")

    def run_extended_experiment(self) -> Dict[str, Any]:
        """Run the complete extended experiment on all datasets."""

        print(f"\n{'=' * 100}")
        print(f"EXTENDED HETEROPHILY EXPERIMENT: {self.experiment_name}")
        print(f"Model: {self.config.model_config.model_type}")
        print(f"Datasets: {self.config.datasets}")
        print(f"{'=' * 100}")

        results = []
        for dataset_name in self.config.datasets:
            result = self.run_single_dataset_extended(dataset_name)
            results.append(result)

        # Generate extended summary report
        self._generate_extended_experiment_report(results)

        return {
            'experiment_name': self.experiment_name,
            'model_type': self.config.model_config.model_type,
            'results': results,
            'extended_results_path': self.extended_results_path,
            'summary': self._create_experiment_summary(results)
        }

    def _generate_extended_experiment_report(self, results: List[Dict[str, Any]]):
        """Generate comprehensive experiment report."""

        print(f"\n{'=' * 100}")
        print(f"EXTENDED EXPERIMENT REPORT: {self.experiment_name}")
        print(f"{'=' * 100}")

        successful_results = [r for r in results if r['success']]

        if not successful_results:
            print("❌ No successful experiments")
            return

        print(f"\nSuccessful experiments: {len(successful_results)}/{len(results)}")

        # Aggregate statistics
        proxy_usable_count = sum(1 for r in successful_results if r.get('heterophily_proxy_usable', False))
        classification_usable_count = sum(1 for r in successful_results if r.get('use_for_node_classification', False))

        print(f"\nAggregate Results:")
        print(f"  Usable as Heterophily Proxy:     {proxy_usable_count}/{len(successful_results)} datasets")
        print(f"  Usable for Node Classification:  {classification_usable_count}/{len(successful_results)} datasets")

        # Average performance metrics
        avg_approx_quality = np.mean([r.get('approximation_quality_score', 0) for r in successful_results])
        avg_classification_ratio = np.mean([r.get('classification_performance_ratio', 0) for r in successful_results])

        print(f"  Average Approximation Quality:   {avg_approx_quality:.4f}")
        print(f"  Average Classification Ratio:   {avg_classification_ratio:.4f}")

        # Dataset-specific results
        print(f"\nDataset-Specific Results:")
        for result in successful_results:
            dataset = result['dataset']
            proxy_usable = "✅" if result.get('heterophily_proxy_usable', False) else "❌"
            classif_usable = "✅" if result.get('use_for_node_classification', False) else "❌"
            quality_score = result.get('approximation_quality_score', 0)
            classif_ratio = result.get('classification_performance_ratio', 0)

            print(f"  {dataset:15} | Proxy: {proxy_usable} ({quality_score:.3f}) | "
                  f"Classification: {classif_usable} ({classif_ratio:.3f})")

        print(f"\nDetailed results saved to: {self.extended_results_path}")

    def _create_experiment_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create overall experiment summary."""

        successful_results = [r for r in results if r['success']]

        if not successful_results:
            return {'status': 'failed', 'message': 'No successful experiments'}

        return {
            'status': 'success',
            'total_datasets': len(results),
            'successful_datasets': len(successful_results),
            'heterophily_proxy_usable_count': sum(
                1 for r in successful_results if r.get('heterophily_proxy_usable', False)),
            'node_classification_usable_count': sum(
                1 for r in successful_results if r.get('use_for_node_classification', False)),
            'average_approximation_quality': np.mean(
                [r.get('approximation_quality_score', 0) for r in successful_results]),
            'average_classification_ratio': np.mean(
                [r.get('classification_performance_ratio', 0) for r in successful_results]),
            'experiment_name': self.experiment_name,
            'model_type': self.config.model_config.model_type
        }


# Convenience functions for easy experiment setup
def create_heterophily_experiment_config(
        datasets: List[str],
        model_type: str = "basic",
        experiment_name: str = "heterophily_proxy_evaluation",
        **kwargs
) -> ExtendedExperimentConfig:
    """Create configuration for heterophily comparison experiment."""

    # Affinity experiment configuration
    if model_type == "basic":
        from experimentRunner import create_basic_config
        affinity_config = create_basic_config(datasets, **kwargs)
    elif model_type == "multi_head":
        from experimentRunner import create_multi_head_config
        affinity_config = create_multi_head_config(datasets, **kwargs)
    elif model_type == "hierarchical":
        from experimentRunner import create_hierarchical_config
        affinity_config = create_hierarchical_config(datasets, **kwargs)
    else:
        from experimentRunner import create_custom_config
        affinity_config = create_custom_config(datasets, model_type=model_type, **kwargs)

    # Comparison configuration
    comparison_config = ComparisonConfig(
        clustering_methods=['kmeans', 'spectral', 'threshold'],
        n_clusters_range=[2, 3, 4, 5, 8],
        classifiers=['logistic', 'random_forest'],
        save_plots=True,
        detailed_analysis=True
    )

    return ExtendedExperimentConfig(
        affinity_config=affinity_config,
        comparison_config=comparison_config,
        experiment_name=experiment_name,
        run_heterophily_comparison=True,
        run_node_classification=True,
        save_detailed_results=True
    )


def run_heterophily_proxy_evaluation(
        datasets: List[str],
        model_types: List[str] = ["basic", "multi_head"],
        experiment_name: str = "heterophily_proxy_evaluation"
) -> Dict[str, Any]:
    """Run comprehensive evaluation of affinity models as heterophily proxies."""

    all_results = {}

    for model_type in model_types:
        print(f"\n{'=' * 120}")
        print(f"EVALUATING {model_type.upper()} MODEL AS HETEROPHILY PROXY")
        print(f"{'=' * 120}")

        # Create configuration
        config = create_heterophily_experiment_config(
            datasets=datasets,
            model_type=model_type,
            experiment_name=f"{experiment_name}_{model_type}",
            epochs=100,
            early_stopping=True,
            patience=15
        )

        # Run experiment
        experiment = ExtendedAffinityExperiment(config)
        results = experiment.run_extended_experiment()

        all_results[model_type] = results

    # Generate comparative report
    _generate_comparative_report(all_results, experiment_name)

    return all_results


def _generate_comparative_report(all_results: Dict[str, Any], experiment_name: str):
    """Generate comparative report across different model types."""

    print(f"\n{'=' * 120}")
    print(f"COMPARATIVE REPORT: {experiment_name}")
    print(f"{'=' * 120}")

    # Compare model types
    model_comparison = {}

    for model_type, results in all_results.items():
        summary = results['summary']
        if summary['status'] == 'success':
            model_comparison[model_type] = {
                'heterophily_proxy_success_rate': summary['heterophily_proxy_usable_count'] / summary[
                    'successful_datasets'],
                'classification_success_rate': summary['node_classification_usable_count'] / summary[
                    'successful_datasets'],
                'avg_approximation_quality': summary['average_approximation_quality'],
                'avg_classification_ratio': summary['average_classification_ratio']
            }

    print("\nModel Type Comparison:")
    print(
        f"{'Model Type':<15} | {'Proxy Success':<12} | {'Classif Success':<14} | {'Avg Quality':<11} | {'Avg Ratio':<10}")
    print("-" * 80)

    for model_type, metrics in model_comparison.items():
        print(f"{model_type:<15} | {metrics['heterophily_proxy_success_rate']:<12.1%} | "
              f"{metrics['classification_success_rate']:<14.1%} | "
              f"{metrics['avg_approximation_quality']:<11.3f} | "
              f"{metrics['avg_classification_ratio']:<10.3f}")

    # Recommendations
    print("\nRecommendations:")

    best_proxy_model = max(model_comparison.keys(),
                           key=lambda x: model_comparison[x]['heterophily_proxy_success_rate'])
    best_classification_model = max(model_comparison.keys(),
                                    key=lambda x: model_comparison[x]['classification_success_rate'])

    print(f"🏆 Best for Heterophily Proxy: {best_proxy_model}")
    print(f"🏆 Best for Node Classification: {best_classification_model}")

    if model_comparison[best_proxy_model]['heterophily_proxy_success_rate'] > 0.7:
        print("✅ Strong evidence that affinity models can serve as heterophily proxies")
    elif model_comparison[best_proxy_model]['heterophily_proxy_success_rate'] > 0.5:
        print("⚠️ Moderate evidence for using affinity models as heterophily proxies")
    else:
        print("❌ Limited evidence for using affinity models as heterophily proxies")


if __name__ == "__main__":
    # Example usage
    datasets = ['roman_empire', 'amazon_ratings', 'minesweeper', 'tolokers']

    print("Running Heterophily Proxy Evaluation...")

    # Run comprehensive evaluation
    results = run_heterophily_proxy_evaluation(
        datasets=datasets,
        model_types=["basic", "multi_head"],
        experiment_name="heterophily_proxy_study"
    )

    print(f"\nEvaluation complete! Check results/ directory for detailed outputs.")
