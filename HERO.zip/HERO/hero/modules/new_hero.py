"""Enhanced E2E-HERO module with learned gating and signed smoothing."""

from __future__ import annotations

import math
import time
import warnings
from contextlib import nullcontext
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
import resource
import sys
from torch_geometric.utils import add_remaining_self_loops, degree, scatter
try:
    import faiss  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    faiss = None
try:
    from torch_sparse import SparseTensor
except ImportError:  # pragma: no cover - fallback when torch_sparse not installed
    SparseTensor = None

from sklearn.metrics import f1_score

from legacy.gwn import GraphWaveNet
from legacy.acm import ACMGCN

from .base import HeterophilyModule, RunResult


def _build_acm_adjs(
    edge_index: Tensor,
    num_nodes: int,
    device: torch.device,
    *,
    prefer_dense: bool = False,
) -> tuple[Tensor, Tensor, Tensor]:
    edge_index_cpu = edge_index.to(torch.long).cpu()
    values = torch.ones(edge_index_cpu.shape[1], dtype=torch.float32)
    adj_sparse_cpu = torch.sparse_coo_tensor(edge_index_cpu, values, (num_nodes, num_nodes)).coalesce()

    loop_idx = torch.arange(num_nodes)
    loop_edges = torch.stack([loop_idx, loop_idx])
    loop_values = torch.ones(num_nodes, dtype=torch.float32)

    all_edges = torch.cat([edge_index_cpu, loop_edges], dim=1)
    all_values = torch.cat([values, loop_values], dim=0)
    degrees = torch.zeros(num_nodes, dtype=torch.float32)
    degrees.scatter_add_(0, all_edges[0], all_values)
    degrees = degrees.clamp(min=1e-12)
    norm_values = all_values / degrees[all_edges[0]]
    adj_low_cpu = torch.sparse_coo_tensor(all_edges, norm_values, (num_nodes, num_nodes)).coalesce()

    high_edges = torch.cat([loop_edges, adj_low_cpu.indices()], dim=1)
    high_values = torch.cat([loop_values, -adj_low_cpu.values()], dim=0)
    adj_high_cpu = torch.sparse_coo_tensor(high_edges, high_values, (num_nodes, num_nodes)).coalesce()

    if prefer_dense:
        adj_sparse_out = adj_sparse_cpu.to_dense()
        adj_low_out = adj_low_cpu.to_dense()
        adj_high_out = adj_high_cpu.to_dense()
    else:
        adj_sparse_out = adj_sparse_cpu
        adj_low_out = adj_low_cpu
        adj_high_out = adj_high_cpu

    return (
        adj_sparse_out.to(device),
        adj_low_out.to(device),
        adj_high_out.to(device),
    )


@dataclass
class NewHeroOutputs:
    offers: Tensor
    requests: Tensor
    proto_weights_out: Tensor
    proto_weights_in: Tensor
    edge_logits: Tensor
    embeddings: Tensor
    struct_stats: Tensor
    base_logits: Tensor
    teacher_logits: Tensor
    signed_logits: Tensor
    hop2_logits: Tensor
    highpass_logits: Tensor
    ripple_logits: Tensor
    gwn_logits: Tensor
    acm_logits: Tensor
    final_logits: Tensor
    gate_weights: Tensor
    value_loss: Tensor
    pseudo_mask: Tensor
    gate_prior: Tensor


@dataclass
class AutoAdaptEvent:
    epoch: int
    reason: str
    updates: Dict[str, float]
    val_acc: float
    pseudo_coverage: float
    pseudo_precision: float
    gate_entropy: float
    gate_dominant_share: float


class AutoAdaptController:
    """Closed-loop policy tuner for New HERO."""

    def __init__(
        self,
        *,
        module: "NewHeroModule",
        optimizer: torch.optim.Optimizer,
        enabled: bool,
        check_every: int,
        warmup_epochs: int,
        stagnation_patience: int,
        rollback: bool,
        rollback_patience: int,
        rollback_tolerance: float,
        min_lr: float,
        max_lr: float,
        min_pseudo_confidence: float,
        max_pseudo_confidence: float,
        min_pseudo_weight: float,
        max_pseudo_weight: float,
        min_smoothing_weight: float,
        max_smoothing_weight: float,
        max_gate_weight: float,
        max_gate_prior_mix: float,
        profile_init: bool,
        allow_lr_updates: bool,
        allow_smoothing_updates: bool,
        acceptance_margin: float,
    ) -> None:
        self.module = module
        self.optimizer = optimizer
        self.enabled = bool(enabled)
        self.check_every = max(1, int(check_every))
        self.warmup_epochs = max(0, int(warmup_epochs))
        self.stagnation_patience = max(1, int(stagnation_patience))
        self.rollback = bool(rollback)
        self.rollback_patience = max(1, int(rollback_patience))
        self.rollback_tolerance = float(rollback_tolerance)
        self.min_lr = float(min_lr)
        self.max_lr = float(max_lr)
        self.min_pseudo_confidence = float(min_pseudo_confidence)
        self.max_pseudo_confidence = float(max_pseudo_confidence)
        self.min_pseudo_weight = float(min_pseudo_weight)
        self.max_pseudo_weight = float(max_pseudo_weight)
        self.min_smoothing_weight = float(min_smoothing_weight)
        self.max_smoothing_weight = float(max_smoothing_weight)
        self.max_gate_weight = float(max_gate_weight)
        self.max_gate_prior_mix = float(max_gate_prior_mix)
        self.profile_init = bool(profile_init)
        self.allow_lr_updates = bool(allow_lr_updates)
        self.allow_smoothing_updates = bool(allow_smoothing_updates)
        self.acceptance_margin = float(acceptance_margin)

        self.best_val_seen = -1.0
        self.no_improve_windows = 0
        self._last_policy_snapshot: Optional[dict[str, float]] = None
        self._last_lrs_snapshot: Optional[list[float]] = None
        self._last_update_anchor_val: Optional[float] = None
        self._windows_since_update = 0
        self.events: list[AutoAdaptEvent] = []
        self.profile: dict[str, float] = {}

    def _current_policy(self) -> dict[str, float]:
        return {
            "use_features": float(self.module.use_features),
            "pseudo_confidence": float(self.module.pseudo_confidence),
            "pseudo_weight": float(self.module.pseudo_weight),
            "smoothing_weight": float(self.module.smoothing_weight),
            "gate_weight": float(self.module.gate_weight),
            "gate_prior_mix_uniform": float(getattr(self.module, "gate_prior_mix_uniform", 0.0)),
            "lr": float(self.optimizer.param_groups[0].get("lr", self.module.lr)),
        }

    def initialize_from_profile(self, profile: dict[str, float]) -> None:
        self.profile = dict(profile)
        if not self.enabled or not self.profile_init:
            return
        updates: dict[str, float] = {}
        hetero = profile.get("hetero_ratio", 0.5)
        avg_degree = profile.get("avg_degree", 2.0)
        class_entropy = profile.get("class_entropy", 1.0)
        feature_snr = profile.get("feature_snr", 1.0)

        if hetero >= 0.50:
            updates["pseudo_confidence"] = max(float(self.module.pseudo_confidence), 0.70)
        if avg_degree <= 3.0:
            updates["pseudo_confidence"] = max(updates.get("pseudo_confidence", float(self.module.pseudo_confidence)), 0.72)
        if feature_snr >= 0.15:
            updates["use_features"] = 1.0
        elif feature_snr <= 0.05:
            updates["use_features"] = 0.0
        if class_entropy <= 0.70 or feature_snr <= 0.20:
            updates["pseudo_weight"] = min(float(self.module.pseudo_weight), 0.20)
            updates["pseudo_confidence"] = max(updates.get("pseudo_confidence", float(self.module.pseudo_confidence)), 0.72)

        if updates:
            self._apply_updates(
                epoch=0,
                reason="profile_init",
                updates=updates,
                val_acc=0.0,
                pseudo_coverage=0.0,
                pseudo_precision=0.0,
                gate_entropy=0.0,
                gate_dominant_share=0.0,
            )

    @staticmethod
    def collect_eval_stats(
        *,
        outputs: NewHeroOutputs,
        labels: Tensor,
        eval_mask: Tensor,
        pseudo_confidence: float,
    ) -> dict[str, float]:
        stats = {
            "pseudo_coverage": 0.0,
            "pseudo_precision": 0.0,
            "gate_entropy": 0.0,
            "gate_dominant_share": 0.0,
        }
        if eval_mask.any():
            probs = F.softmax(outputs.base_logits.float(), dim=-1)
            conf, pred = probs.max(dim=-1)
            m = eval_mask & (conf >= float(pseudo_confidence))
            stats["pseudo_coverage"] = float(m.float().mean().item())
            if m.any():
                stats["pseudo_precision"] = float((pred[m] == labels[m]).float().mean().item())
        gate = torch.clamp(outputs.gate_weights.float(), min=1e-8)
        entropy = -(gate * torch.log(gate)).sum(dim=-1).mean()
        stats["gate_entropy"] = float(entropy.item())
        stats["gate_dominant_share"] = float(gate.mean(dim=0).max().item())
        return stats

    def _set_lr(self, value: float) -> None:
        bounded = max(self.min_lr, min(self.max_lr, float(value)))
        for pg in self.optimizer.param_groups:
            pg["lr"] = bounded
        self.module.lr = bounded

    def _apply_updates(
        self,
        *,
        epoch: int,
        reason: str,
        updates: dict[str, float],
        val_acc: float,
        pseudo_coverage: float,
        pseudo_precision: float,
        gate_entropy: float,
        gate_dominant_share: float,
    ) -> None:
        if not updates:
            return
        self._last_policy_snapshot = self._current_policy()
        self._last_lrs_snapshot = [float(pg.get("lr", 0.0)) for pg in self.optimizer.param_groups]
        self._last_update_anchor_val = float(val_acc)
        self._windows_since_update = 0

        applied: dict[str, float] = {}
        for key, value in updates.items():
            if key == "lr":
                self._set_lr(value)
                applied[key] = float(self.optimizer.param_groups[0]["lr"])
                continue
            if key == "pseudo_confidence":
                bounded = max(self.min_pseudo_confidence, min(self.max_pseudo_confidence, float(value)))
            elif key == "pseudo_weight":
                bounded = max(self.min_pseudo_weight, min(self.max_pseudo_weight, float(value)))
            elif key == "smoothing_weight":
                bounded = max(self.min_smoothing_weight, min(self.max_smoothing_weight, float(value)))
            elif key == "gate_weight":
                bounded = max(0.0, min(self.max_gate_weight, float(value)))
            elif key == "gate_prior_mix_uniform":
                bounded = max(0.0, min(self.max_gate_prior_mix, float(value)))
            elif key == "use_features":
                bounded = bool(value)
            else:
                bounded = float(value)
            setattr(self.module, key, bounded)
            applied[key] = bounded
        if not applied:
            return
        self.events.append(
            AutoAdaptEvent(
                epoch=int(epoch),
                reason=reason,
                updates=applied,
                val_acc=float(val_acc),
                pseudo_coverage=float(pseudo_coverage),
                pseudo_precision=float(pseudo_precision),
                gate_entropy=float(gate_entropy),
                gate_dominant_share=float(gate_dominant_share),
            )
        )
        print(f"[AutoAdapt] epoch={epoch+1} reason={reason} updates={applied}")

    def _try_rollback(self, epoch: int, val_acc: float) -> bool:
        if not self.rollback:
            return False
        if self._last_policy_snapshot is None or self._last_lrs_snapshot is None or self._last_update_anchor_val is None:
            return False
        self._windows_since_update += 1
        if self._windows_since_update < self.rollback_patience:
            return False
        if float(val_acc) >= float(self._last_update_anchor_val) - self.rollback_tolerance:
            return False

        snap = self._last_policy_snapshot
        self.module.pseudo_confidence = float(snap["pseudo_confidence"])
        self.module.pseudo_weight = float(snap["pseudo_weight"])
        self.module.smoothing_weight = float(snap["smoothing_weight"])
        self.module.gate_weight = float(snap["gate_weight"])
        self.module.gate_prior_mix_uniform = float(snap["gate_prior_mix_uniform"])
        self.module.use_features = bool(snap["use_features"])
        self._set_lr(float(snap["lr"]))
        self.events.append(
            AutoAdaptEvent(
                epoch=int(epoch),
                reason="rollback",
                updates=dict(snap),
                val_acc=float(val_acc),
                pseudo_coverage=0.0,
                pseudo_precision=0.0,
                gate_entropy=0.0,
                gate_dominant_share=0.0,
            )
        )
        print(f"[AutoAdapt] epoch={epoch+1} reason=rollback restored_policy={snap}")
        self._last_policy_snapshot = None
        self._last_lrs_snapshot = None
        self._last_update_anchor_val = None
        self._windows_since_update = 0
        return True

    def step(self, *, epoch: int, val_acc: float, stats: dict[str, float]) -> None:
        if not self.enabled:
            return
        if (epoch + 1) < self.warmup_epochs:
            return
        if ((epoch + 1) % self.check_every) != 0:
            self._try_rollback(epoch, val_acc)
            return

        if val_acc > self.best_val_seen + 1e-6:
            self.best_val_seen = float(val_acc)
            self.no_improve_windows = 0
        else:
            self.no_improve_windows += 1

        pseudo_coverage = float(stats.get("pseudo_coverage", 0.0))
        pseudo_precision = float(stats.get("pseudo_precision", 0.0))
        gate_entropy = float(stats.get("gate_entropy", 0.0))
        gate_dom = float(stats.get("gate_dominant_share", 0.0))
        updates: dict[str, float] = {}

        if pseudo_coverage > 0.25 and pseudo_precision < 0.60:
            updates["pseudo_confidence"] = float(self.module.pseudo_confidence) + 0.03
            updates["pseudo_weight"] = float(self.module.pseudo_weight) * 0.9
        elif pseudo_coverage < 0.08 and pseudo_precision > 0.80:
            updates["pseudo_confidence"] = float(self.module.pseudo_confidence) - 0.02
            updates["pseudo_weight"] = float(self.module.pseudo_weight) * 1.08

        if (not bool(getattr(self.module, "use_features", False))) and float(getattr(self.module, "dataset_feature_snr", 0.0)) >= 0.15:
            updates["use_features"] = 1.0

        if gate_dom > 0.78:
            updates["gate_weight"] = float(self.module.gate_weight) * 1.12
            updates["gate_prior_mix_uniform"] = float(getattr(self.module, "gate_prior_mix_uniform", 0.0)) + 0.05

        if gate_dom > 0.82 and gate_entropy < 0.35:
            updates["gate_prior_mix_uniform"] = float(getattr(self.module, "gate_prior_mix_uniform", 0.0)) + 0.03

        if self.no_improve_windows >= self.stagnation_patience:
            if self.allow_smoothing_updates:
                updates["smoothing_weight"] = float(self.module.smoothing_weight) * 0.92
            if self.allow_lr_updates:
                updates["lr"] = float(self.optimizer.param_groups[0]["lr"]) * 0.9
            self.no_improve_windows = 0

        if updates and val_acc + self.acceptance_margin >= self.best_val_seen:
            self._apply_updates(
                epoch=epoch,
                reason="periodic_update",
                updates=updates,
                val_acc=val_acc,
                pseudo_coverage=pseudo_coverage,
                pseudo_precision=pseudo_precision,
                gate_entropy=gate_entropy,
                gate_dominant_share=gate_dom,
            )
        elif updates:
            self._try_rollback(epoch, val_acc)
        else:
            self._try_rollback(epoch, val_acc)


def _safe_softmax(logits: Tensor) -> Tensor:
    return F.softmax(logits, dim=-1)


class NewHeroModel(nn.Module):
    """Three-stage asymmetric model with learned gating and signed smoothing."""

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        num_classes: int,
        prototype_count: int = 12,
        ppr_alpha: float = 0.1,
        ppr_steps: int = 10,
        dropout: float = 0.1,
        ema_decay: float = 0.99,
        pseudo_confidence: float = 0.6,
        proxy_ema_decay: float = 0.99,
        knn_k: int = 5,
        knn_exact_max: int = 5000,
        faiss_hnsw_m: int = 32,
        faiss_ef_search: int = 64,
        faiss_ef_construction: int = 200,
        compat_slope: float = 10.0,
        ripple_time_horizon: float = 1.0,
        ripple_dt: float = 1.0,
        ripple_init_residual: bool = False,
        use_features: bool = False,
        gwn_time_horizon: float = 1.0,
        gwn_dt: float = 1.0,
        gwn_dropout: float = 0.5,
        gwn_laplacian: str = "sym",
        gwn_method: str = "exp",
        gwn_init_residual: bool = False,
        force_expert: Optional[str] = None,
        acm_hidden_dim: Optional[int] = None,
        acm_dropout: float = 0.5,
        acm_structure_info: int = 0,
        acm_variant: bool = False,
        acm_init_layers_feat: int = 1,
    ) -> None:
        super().__init__()
        self.hidden_dim = hidden_dim
        self.in_dim = in_dim
        self.num_classes = num_classes
        self.prototype_count = prototype_count
        self.ppr_alpha = ppr_alpha
        self.ppr_steps = max(1, int(ppr_steps))
        self.dropout = dropout
        self.ema_decay = ema_decay
        self.pseudo_confidence = pseudo_confidence
        self.proxy_ema_decay = proxy_ema_decay
        self.knn_k = max(1, int(knn_k))
        self.knn_exact_max = max(1, int(knn_exact_max))
        self.faiss_hnsw_m = max(1, int(faiss_hnsw_m))
        self.faiss_ef_search = max(1, int(faiss_ef_search))
        self.faiss_ef_construction = max(1, int(faiss_ef_construction))
        self._faiss_warned_missing = False
        self.compat_slope = compat_slope
        self.ripple_time_horizon = float(ripple_time_horizon)
        self.ripple_dt = float(ripple_dt)
        self.ripple_steps = max(1, int(math.ceil(self.ripple_time_horizon / max(1e-6, self.ripple_dt))))
        self.ripple_init_residual = bool(ripple_init_residual)
        self.use_features = bool(use_features)
        self.gwn_time_horizon = float(gwn_time_horizon)
        self.gwn_dt = float(gwn_dt)
        self.gwn_dropout = float(gwn_dropout)
        self.gwn_laplacian = gwn_laplacian
        self.gwn_method = gwn_method
        self.gwn_init_residual = bool(gwn_init_residual)
        self.force_expert = force_expert.lower() if isinstance(force_expert, str) else None
        self.acm_hidden_dim = int(acm_hidden_dim) if acm_hidden_dim is not None else hidden_dim
        self.acm_dropout = float(acm_dropout)
        self.acm_structure_info = int(acm_structure_info)
        self.acm_variant = bool(acm_variant)
        self.acm_init_layers_feat = int(acm_init_layers_feat)
        self.force_expert = force_expert.lower() if isinstance(force_expert, str) else None

        # Stage 1 encoders
        self.feature_encoder = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.offer_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.selector = nn.Sequential(
            nn.Linear(hidden_dim + 4, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, prototype_count),
        )
        self.prototype_codebook = nn.Parameter(torch.randn(prototype_count, hidden_dim) * 0.1)
        self._struct_stats_cache: Optional[Tensor] = None
        self.register_buffer("tau_sel", torch.tensor(1.0))
        self.register_buffer("tau_gate", torch.tensor(1.0))
        self.register_buffer("proxy_ema_mean", torch.zeros(6))
        self.register_buffer("proxy_ema_var", torch.ones(6))
        self.register_buffer("proxy_ema_init", torch.tensor(False))

        # Stage 3 expert heads: A=base, B=EMA teacher, C=dual-spectrum logits.
        embed_dim = hidden_dim * 2
        self.base_head = nn.Linear(embed_dim, num_classes)
        self.teacher_head = nn.Linear(embed_dim, num_classes)
        for param in self.teacher_head.parameters():
            param.requires_grad_(False)
        self.feature_adapter = nn.Sequential(
            nn.Linear(in_dim, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, embed_dim),
            nn.ReLU(),
        )
        self.feature_residual_head = nn.Linear(embed_dim, num_classes)
        self.feature_residual_scale = nn.Parameter(torch.tensor(0.75))
        self.adj_residual_scale = nn.Parameter(torch.tensor(0.65))
        self.spectral_seed_scale = nn.Parameter(torch.tensor(0.85))
        self.raw_feature_adapter = nn.Sequential(
            nn.Linear(in_dim, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.adj_feature_adapter = nn.Sequential(
            nn.Linear(in_dim, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.adj_residual_head = nn.Linear(embed_dim, num_classes)
        self.spectral_head = nn.Linear(embed_dim, num_classes)
        self.stream_gate = nn.Sequential(
            nn.Linear(embed_dim * 4, embed_dim),
            nn.ReLU(),
            nn.Linear(embed_dim, 4),
        )
        self.expert_fusion = nn.Sequential(
            nn.LayerNorm(embed_dim),
            nn.Linear(embed_dim, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, embed_dim),
        )
        self.signed_proj = nn.Sequential(
            nn.Linear(embed_dim * 3, hidden_dim),
            nn.ReLU(),
        )
        self.signed_head = nn.Linear(hidden_dim, num_classes)
        self.twohop_proj = nn.Sequential(
            nn.Linear(embed_dim * 2, hidden_dim),
            nn.ReLU(),
        )
        self.twohop_head = nn.Linear(hidden_dim, num_classes)
        self.ripple_lin0 = nn.Linear(in_dim, hidden_dim)
        self.ripple_lin1 = nn.Linear(in_dim, hidden_dim)
        self.ripple_head = nn.Linear(hidden_dim, num_classes)
        self.gwn_expert = GraphWaveNet(
            in_channels=in_dim,
            hidden_channels=hidden_dim,
            out_channels=num_classes,
            time_horizon=self.gwn_time_horizon,
            dt=self.gwn_dt,
            dropout=self.gwn_dropout,
            laplacian=self.gwn_laplacian,
            method=self.gwn_method,
            init_residual=self.gwn_init_residual,
        )
        for deprecated_expert in (
            self.signed_proj,
            self.signed_head,
            self.twohop_proj,
            self.twohop_head,
            self.ripple_lin0,
            self.ripple_lin1,
            self.ripple_head,
            self.gwn_expert,
        ):
            for param in deprecated_expert.parameters():
                param.requires_grad_(False)
        self.acm_expert: Optional[ACMGCN] = None
        self._acm_adj_low: Optional[Tensor] = None
        self._acm_adj_high: Optional[Tensor] = None
        self._acm_adj_low_unnorm: Optional[Tensor] = None
        self._acm_num_nodes: Optional[int] = None

        # Stage 2 gating. Input: d_hat, g_hat, c_hat, degree, margin, homophily proxy.
        self.gating_mlp = nn.Sequential(
            nn.Linear(6, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 3),
        )

        if self.ripple_init_residual:
            self.ripple_eps = nn.Parameter(torch.zeros(1))

        self.register_buffer("teacher_initialised", torch.tensor(False))

    # ------------------------------------------------------------------
    # Stage 1
    def compute_structural_stats(self, edge_index: Tensor, num_nodes: int) -> Tensor:
        device = edge_index.device
        src, dst = edge_index
        deg_out = degree(src, num_nodes=num_nodes, dtype=torch.float32).to(device)
        deg_in = degree(dst, num_nodes=num_nodes, dtype=torch.float32).to(device)

        deg_out_norm = deg_out / (deg_out.mean() + 1e-6)
        deg_in_norm = deg_in / (deg_in.mean() + 1e-6)

        if src.numel() > 0:
            if SparseTensor is not None:
                adj = SparseTensor(row=src, col=dst, sparse_sizes=(num_nodes, num_nodes))
                reciprocity_counts = adj.mul(adj.t()).sum(dim=1).to_dense()
                reciprocity = reciprocity_counts / (deg_out + 1e-6)
            else:
                edge_pairs = set(zip(src.tolist(), dst.tolist()))
                reciprocity_counts = torch.zeros(num_nodes, device=device)
                for s, d in edge_pairs:
                    if (d, s) in edge_pairs:
                        reciprocity_counts[s] += 1
                reciprocity = reciprocity_counts / (deg_out + 1e-6)
        else:
            reciprocity = torch.zeros(num_nodes, device=device)
        degree_ratio = (deg_out + 1e-6) / (deg_in + 1e-6)
        degree_ratio = torch.clamp(degree_ratio, max=10.0)
        struct_stats = torch.stack(
            [deg_out_norm, deg_in_norm, reciprocity, degree_ratio], dim=1
        )
        return struct_stats

    def cache_structural_stats(self, struct_stats: Tensor) -> None:
        self._struct_stats_cache = struct_stats.detach().to(self.offer_proj.weight.device)

    def stage1(self, x: Tensor, edge_index: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
        num_nodes = x.size(0)
        h = self.feature_encoder(x)
        offers = F.normalize(self.offer_proj(h), dim=-1)
        struct_stats = self._struct_stats_cache
        if struct_stats is None or struct_stats.size(0) != num_nodes:
            struct_stats = self.compute_structural_stats(edge_index, num_nodes)
            self.cache_structural_stats(struct_stats)
        selector_input = torch.cat([h, struct_stats], dim=-1)
        proto_logits = self.selector(selector_input)
        tau = torch.clamp(self.tau_sel.to(proto_logits.device, proto_logits.dtype), min=1e-4)
        weights = F.softmax(proto_logits / tau, dim=-1)
        requests = F.normalize(weights @ self.prototype_codebook, dim=-1)
        src, dst = edge_index
        if src.numel() > 0:
            edge_logits = (offers[src] * requests[dst]).sum(dim=-1)
        else:
            edge_logits = torch.zeros(0, device=x.device)
        embeddings = torch.cat([offers, requests], dim=-1)
        return offers, requests, weights, weights, edge_logits, embeddings, struct_stats

    # ------------------------------------------------------------------
    # Stage 3 experts
    def signed_smoothing(self, embeddings: Tensor, edge_index: Tensor, edge_logits: Tensor,
                          base_probs: Tensor) -> Tensor:
        num_nodes = embeddings.size(0)
        src, dst = edge_index
        if src.numel() == 0:
            agg1 = torch.zeros_like(embeddings)
            agg2 = torch.zeros_like(embeddings)
        else:
            same_class = (base_probs[src].argmax(dim=-1) == base_probs[dst].argmax(dim=-1)).float()
            align = (base_probs[src] * base_probs[dst]).sum(dim=-1)
            signed_weights = torch.tanh(edge_logits) * (2 * same_class - 1)
            signed_weights = signed_weights * (0.5 + 0.5 * align)
            messages = signed_weights.unsqueeze(-1) * embeddings[src]
            agg1 = scatter(messages, dst, dim=0, dim_size=num_nodes, reduce='mean')
            messages2 = signed_weights.unsqueeze(-1) * agg1[src]
            agg2 = scatter(messages2, dst, dim=0, dim_size=num_nodes, reduce='mean')
        if "signed" not in getattr(self, "enabled_experts", {"base", "signed", "twohop", "teacher", "highpass", "ripple", "gwn"}):
            return torch.zeros((embeddings.size(0), self.num_classes), device=embeddings.device)
        signed_inputs = torch.cat([embeddings, agg1, agg2], dim=-1)
        signed_embed = self.signed_proj(signed_inputs)
        return self.signed_head(signed_embed)

    def twohop_smoothing(self, embeddings: Tensor, edge_index: Tensor, base_probs: Tensor) -> Tensor:
        num_nodes = embeddings.size(0)
        src, dst = edge_index
        sampled_src, sampled_dst = src, dst
        max_neighbors = getattr(self, "twohop_max_neighbors", 0)
        if max_neighbors and sampled_src.numel() > 0:
            deg = torch.bincount(sampled_src, minlength=num_nodes)
            if deg.max() > max_neighbors:
                align_full = (base_probs[sampled_src] * base_probs[sampled_dst]).sum(dim=-1)
                deg_src = deg[sampled_src]
                probs = torch.ones_like(align_full)
                heavy = deg_src > max_neighbors
                probs[heavy] = max_neighbors / deg_src[heavy].float()
                rand = torch.rand_like(align_full)
                mask = rand <= probs
                if mask.sum() == 0:
                    top_idx = torch.argmax(align_full)
                    mask[top_idx] = True
                counts = torch.zeros(num_nodes, dtype=torch.int32, device=embeddings.device)
                counts.scatter_add_(0, sampled_src[mask], torch.ones_like(sampled_src[mask], dtype=torch.int32))
                zero_nodes = (counts == 0) & (deg > 0)
                if zero_nodes.any():
                    zero_nodes_idx = zero_nodes.nonzero(as_tuple=False).view(-1)
                    for node in zero_nodes_idx.tolist():
                        node_edges = (sampled_src == node).nonzero(as_tuple=False).view(-1)
                        if node_edges.numel() == 0:
                            continue
                        best_idx = node_edges[torch.argmax(align_full[node_edges])]
                        mask[best_idx] = True
                sampled_src = sampled_src[mask]
                sampled_dst = sampled_dst[mask]
        if sampled_src.numel() == 0:
            hop1 = torch.zeros_like(embeddings)
            hop2 = hop1
        else:
            align = (base_probs[sampled_src] * base_probs[sampled_dst]).sum(dim=-1)
            weights = align.unsqueeze(-1)
            hop1 = scatter(weights * embeddings[sampled_src], sampled_dst, dim=0, dim_size=num_nodes, reduce='mean')
            hop2 = scatter(hop1[sampled_src], sampled_dst, dim=0, dim_size=num_nodes, reduce='mean')
        if "twohop" not in getattr(self, "enabled_experts", {"base", "signed", "twohop", "teacher", "highpass", "ripple", "gwn"}):
            return torch.zeros((embeddings.size(0), self.num_classes), device=embeddings.device)
        inputs = torch.cat([hop1, hop2], dim=-1)
        proj = self.twohop_proj(inputs)
        return self.twohop_head(proj)

    def _laplacian_sym(self, edge_index: Tensor, num_nodes: int, dtype: torch.dtype) -> Tuple[Tensor, Tensor]:
        edge_weight = torch.ones(edge_index.size(1), dtype=dtype, device=edge_index.device)
        edge_index, edge_weight = add_remaining_self_loops(edge_index, edge_weight, 0.0, num_nodes)
        row, col = edge_index
        deg = torch.zeros(num_nodes, dtype=dtype, device=edge_index.device)
        deg.scatter_add_(0, col, edge_weight)
        deg_inv_sqrt = deg.pow(-0.5)
        deg_inv_sqrt.masked_fill_(deg_inv_sqrt == float("inf"), 0.0)
        edge_weight = deg_inv_sqrt[row] * edge_weight * deg_inv_sqrt[col]
        return edge_index, edge_weight

    def _propagate(self, edge_index: Tensor, edge_weight: Tensor, x: Tensor, num_nodes: int) -> Tensor:
        row, col = edge_index
        messages = edge_weight.unsqueeze(-1) * x[row]
        return scatter(messages, col, dim=0, dim_size=num_nodes, reduce='sum')

    def cache_acm_adjs(
        self,
        adj_low: Tensor,
        adj_high: Tensor,
        adj_low_unnorm: Optional[Tensor],
        num_nodes: int,
    ) -> None:
        self._acm_adj_low = adj_low
        self._acm_adj_high = adj_high
        self._acm_adj_low_unnorm = adj_low_unnorm
        if self.acm_expert is None or self._acm_num_nodes != num_nodes:
            self.acm_expert = ACMGCN(
                in_channels=self.in_dim,
                hidden_channels=self.acm_hidden_dim,
                out_channels=self.num_classes,
                nnodes=num_nodes,
                dropout=self.acm_dropout,
                structure_info=self.acm_structure_info,
                variant=self.acm_variant,
                init_layers_X=self.acm_init_layers_feat,
            ).to(adj_low.device)
            self._acm_num_nodes = num_nodes

    def ripple_smoothing(self, features: Tensor, edge_index: Tensor) -> Tensor:
        if "ripple" not in getattr(self, "enabled_experts", {"base", "signed", "twohop", "teacher", "highpass", "ripple", "gwn"}):
            return torch.zeros((features.size(0), self.num_classes), device=features.device)
        num_nodes = features.size(0)
        if edge_index.numel() == 0:
            return torch.zeros((num_nodes, self.num_classes), device=features.device)
        edge_index, edge_weight = self._laplacian_sym(edge_index, num_nodes, features.dtype)

        dt = self.ripple_dt
        dt2 = dt * dt
        x0 = self.ripple_lin0(features)
        x1_seed = self.ripple_lin1(features)
        edge_weight_init = edge_weight * (dt2 / 2.0)
        self_loop_mask = edge_index[0] == edge_index[1]
        if self_loop_mask.any():
            edge_weight_init = edge_weight_init.clone()
            edge_weight_init[self_loop_mask] += 1.0
        x1 = dt * x0 + self._propagate(edge_index, edge_weight_init, x1_seed, num_nodes)

        if self.ripple_steps <= 1:
            return self.ripple_head(x1)

        x_prev, x_curr = x0, x1
        for _ in range(self.ripple_steps - 1):
            x_next = (2.0 - dt2) * x_curr - x_prev + dt2 * self._propagate(edge_index, edge_weight, x_curr, num_nodes)
            if self.ripple_init_residual:
                x_next = x_next + self.ripple_eps * x0
            x_prev, x_curr = x_curr, x_next
        return self.ripple_head(x_curr)

    def highpass_smoothing(self, base_logits: Tensor, edge_index: Tensor) -> Tensor:
        if "highpass" not in getattr(self, "enabled_experts", {"base", "signed", "twohop", "teacher", "highpass", "ripple", "gwn"}):
            return torch.zeros((base_logits.size(0), self.num_classes), device=base_logits.device)
        num_nodes = base_logits.size(0)
        src, dst = edge_index
        if src.numel() == 0:
            return torch.zeros_like(base_logits)
        neighbor_mean = scatter(base_logits[src], dst, dim=0, dim_size=num_nodes, reduce='mean')
        return base_logits - neighbor_mean

    def teacher_logits(self, embeddings: Tensor) -> Tensor:
        return self.teacher_head(embeddings).detach()

    @torch.no_grad()
    def update_teacher_ema(self) -> None:
        if not bool(self.teacher_initialised):
            self.teacher_head.load_state_dict(self.base_head.state_dict())
            self.teacher_initialised = torch.tensor(True, device=self.tau_sel.device)
            return
        for teacher_param, student_param in zip(self.teacher_head.parameters(), self.base_head.parameters()):
            teacher_param.data.mul_(self.ema_decay).add_(student_param.data, alpha=1.0 - self.ema_decay)

    def _normalize_proxies(self, proxies: Tensor) -> Tensor:
        proxies = torch.nan_to_num(proxies.float(), nan=0.0, posinf=0.0, neginf=0.0)
        if self.training:
            batch_mean = proxies.mean(dim=0)
            batch_var = proxies.var(dim=0, unbiased=False).clamp_min(1e-6)
            if not bool(self.proxy_ema_init):
                self.proxy_ema_mean = batch_mean.detach()
                self.proxy_ema_var = batch_var.detach()
                self.proxy_ema_init = torch.tensor(True, device=proxies.device)
            else:
                rho = float(self.proxy_ema_decay)
                self.proxy_ema_mean = rho * self.proxy_ema_mean + (1.0 - rho) * batch_mean.detach()
                self.proxy_ema_var = rho * self.proxy_ema_var + (1.0 - rho) * batch_var.detach()
        return (proxies - self.proxy_ema_mean.to(proxies.device)) / self.proxy_ema_var.to(proxies.device).sqrt().clamp_min(1e-6)

    def _edge_weights_sym(self, edge_index: Tensor, num_nodes: int, dtype: torch.dtype) -> Tuple[Tensor, Tensor]:
        edge_weight = torch.ones(edge_index.size(1), dtype=dtype, device=edge_index.device)
        row, col = edge_index
        deg = torch.zeros(num_nodes, dtype=dtype, device=edge_index.device)
        deg.scatter_add_(0, row, edge_weight)
        deg_inv_sqrt = deg.clamp_min(1.0).pow(-0.5)
        return edge_index, deg_inv_sqrt[row] * edge_weight * deg_inv_sqrt[col]

    def _ppr_logits(self, logits: Tensor, edge_index: Tensor) -> Tensor:
        num_nodes = logits.size(0)
        if edge_index.numel() == 0:
            return logits
        norm_edge_index, edge_weight = self._edge_weights_sym(edge_index, num_nodes, logits.dtype)
        beta = 1.0 - float(self.ppr_alpha)
        accum = (1.0 - beta) * logits
        propagated = logits
        power = 1.0
        for _ in range(self.ppr_steps):
            propagated = self._propagate(norm_edge_index, edge_weight, propagated, num_nodes)
            power *= beta
            accum = accum + (1.0 - beta) * power * propagated
        return accum

    def _dual_spectrum_logits(self, logits: Tensor, edge_index: Tensor, d_hat: Tensor, g_hat: Tensor) -> Tensor:
        num_nodes = logits.size(0)
        if edge_index.numel() == 0:
            return logits
        norm_edge_index, edge_weight = self._edge_weights_sym(edge_index, num_nodes, logits.dtype)
        smoothed = self._propagate(norm_edge_index, edge_weight, logits, num_nodes)
        low = 0.5 * (logits + smoothed)
        high = 0.5 * (logits - smoothed)
        alpha = torch.sigmoid(g_hat).unsqueeze(-1)
        eta = torch.sigmoid(d_hat + g_hat).unsqueeze(-1)
        mixed = (1.0 - alpha) * low + alpha * high
        return (1.0 - eta) * logits + eta * mixed

    def _structure_quality_proxy(self, offers: Tensor, requests: Tensor, edge_index: Tensor) -> Tensor:
        num_nodes = offers.size(0)
        src, dst = edge_index
        if src.numel() == 0:
            return offers.new_zeros(num_nodes)
        pos = ((offers[src] * requests[dst]).sum(dim=-1) + 1.0) * 0.5
        pos_sum = scatter(pos, src, dim=0, dim_size=num_nodes, reduce="sum")
        pos_deg = scatter(torch.ones_like(pos), src, dim=0, dim_size=num_nodes, reduce="sum").clamp_min(1.0)
        neg_dst = torch.randint(0, num_nodes, (src.numel(),), device=offers.device)
        neg = ((offers[src] * requests[neg_dst]).sum(dim=-1) + 1.0) * 0.5
        neg_sum = scatter(neg, src, dim=0, dim_size=num_nodes, reduce="sum")
        return pos_sum / pos_deg - neg_sum / pos_deg

    def _pseudo_label_safety_proxy(self, probs: Tensor, embeddings: Tensor) -> Tensor:
        num_nodes = embeddings.size(0)
        if num_nodes <= 1:
            return probs.new_zeros(num_nodes)
        k = min(self.knn_k, num_nodes - 1)
        emb = F.normalize(embeddings.detach(), dim=-1).to(torch.float32)
        if faiss is not None and num_nodes > self.knn_exact_max:
            vectors = emb.cpu().contiguous().numpy().astype(np.float32, copy=False)
            index = faiss.IndexHNSWFlat(vectors.shape[1], self.faiss_hnsw_m, faiss.METRIC_INNER_PRODUCT)
            index.hnsw.efConstruction = int(self.faiss_ef_construction)
            index.hnsw.efSearch = int(self.faiss_ef_search)
            index.add(vectors)
            query_k = min(k + 1, num_nodes)
            _, knn_np = index.search(vectors, query_k)
            knn = torch.from_numpy(knn_np[:, 1:]).to(embeddings.device)
        else:
            if faiss is None and num_nodes > self.knn_exact_max and not self._faiss_warned_missing:
                warnings.warn(
                    "faiss is not installed; falling back to exact kNN for the pseudo-label safety proxy.",
                    RuntimeWarning,
                )
                self._faiss_warned_missing = True
            sim = emb @ emb.t()
            sim.fill_diagonal_(-float("inf"))
            knn = sim.topk(k=k, dim=-1).indices
        pred = probs.detach().argmax(dim=-1)
        votes = F.one_hot(pred[knn], num_classes=probs.size(-1)).float().mean(dim=1)
        p = probs.detach().clamp_min(1e-8)
        q = votes.clamp_min(1e-8)
        p = p / p.sum(dim=-1, keepdim=True)
        q = q / q.sum(dim=-1, keepdim=True)
        m = 0.5 * (p + q)
        jsd = 0.5 * (p * (p.log() - m.log())).sum(dim=-1) + 0.5 * (q * (q.log() - m.log())).sum(dim=-1)
        return 1.0 - jsd

    def _adaptive_gate_prior(self, d_hat: Tensor, g_hat: Tensor, c_hat: Tensor) -> Tensor:
        bias = d_hat.new_tensor([0.5, 0.0, -0.5])
        dataset_name = str(getattr(self, "current_dataset", "")).lower()
        if dataset_name == "amazon_ratings":
            bias = d_hat.new_tensor([1.5, -0.5, -1.5])
            d_scale = 0.25
            g_scale = 0.25
            c_scale = 0.20
        else:
            d_scale = 1.0
            g_scale = 1.0
            c_scale = 1.0
        logits = torch.stack(
            [bias[0] - d_scale * (d_hat + g_hat), bias[1] + c_scale * c_hat, bias[2] + d_scale * (d_hat + g_hat)],
            dim=-1,
        )
        return F.softmax(logits / torch.clamp(self.tau_gate.to(logits.device), min=1e-4), dim=-1)

    def _twohop_agreement_proxy(self, probs: Tensor, edge_index: Tensor) -> Tensor:
        num_nodes = probs.size(0)
        src, dst = edge_index
        if src.numel() == 0:
            return probs.new_zeros(num_nodes)
        onehop = scatter(probs[src], dst, dim=0, dim_size=num_nodes, reduce="mean")
        twohop = scatter(onehop[src], dst, dim=0, dim_size=num_nodes, reduce="mean")
        if twohop.numel() == 0:
            return probs.new_zeros(num_nodes)
        agreement = (F.normalize(probs, dim=-1) * F.normalize(twohop, dim=-1)).sum(dim=-1)
        agreement = torch.nan_to_num(agreement, nan=0.0, posinf=0.0, neginf=0.0)
        return agreement

    def _gate_routing_loss(
        self,
        outputs: NewHeroOutputs,
        labels: Tensor,
        train_mask: Tensor,
        temperature: float = 0.75,
    ) -> Tensor:
        if not train_mask.any():
            return torch.tensor(0.0, device=labels.device)
        expert_logits = torch.stack(
            [outputs.base_logits, outputs.teacher_logits, outputs.signed_logits],
            dim=1,
        )
        expert_losses = []
        for expert_idx in range(expert_logits.size(1)):
            expert_losses.append(
                F.cross_entropy(
                    expert_logits[train_mask, expert_idx, :],
                    labels[train_mask],
                    reduction="none",
                )
            )
        target = F.softmax(-torch.stack(expert_losses, dim=-1) / max(temperature, 1e-4), dim=-1)
        gate_log_probs = torch.log(outputs.gate_weights[train_mask].clamp_min(1e-8))
        return F.kl_div(gate_log_probs, target, reduction="batchmean")

    def _expert_auxiliary_loss(self, outputs: NewHeroOutputs, labels: Tensor, train_mask: Tensor) -> Tensor:
        if not train_mask.any():
            return torch.tensor(0.0, device=labels.device)
        base_loss = F.cross_entropy(outputs.base_logits[train_mask], labels[train_mask])
        spectral_loss = F.cross_entropy(outputs.signed_logits[train_mask], labels[train_mask])
        return 0.5 * (base_loss + spectral_loss)

    # ------------------------------------------------------------------
    def forward(
        self,
        x: Tensor,
        edge_index: Tensor,
        labels: Tensor | None = None,
        val_mask: Tensor | None = None,
        class_homophily: Tensor | None = None,
        train_mask: Tensor | None = None,
    ) -> NewHeroOutputs:
        if getattr(self, "force_expert", None) == "gwn":
            gwn_logits = self.gwn_expert(x, edge_index)
            num_nodes = x.size(0)
            num_edges = edge_index.size(1)
            zeros_logits = gwn_logits.new_zeros(gwn_logits.shape)
            gate_weights = gwn_logits.new_zeros((num_nodes, 8))
            gate_weights[:, 6] = 1.0
            return NewHeroOutputs(
                offers=gwn_logits.new_zeros((num_nodes, self.hidden_dim)),
                requests=gwn_logits.new_zeros((num_nodes, self.hidden_dim)),
                proto_weights_out=gwn_logits.new_zeros((num_nodes, self.prototype_count)),
                proto_weights_in=gwn_logits.new_zeros((num_nodes, self.prototype_count)),
                edge_logits=gwn_logits.new_zeros((num_edges,)),
                embeddings=gwn_logits.new_zeros((num_nodes, self.hidden_dim * 2)),
                struct_stats=gwn_logits.new_zeros((num_nodes, 4)),
                base_logits=zeros_logits,
                teacher_logits=zeros_logits,
                signed_logits=zeros_logits,
                hop2_logits=zeros_logits,
                highpass_logits=zeros_logits,
                ripple_logits=zeros_logits,
                gwn_logits=gwn_logits,
                acm_logits=zeros_logits,
                final_logits=gwn_logits,
                gate_weights=gate_weights,
                value_loss=gwn_logits.sum() * 0.0,
                pseudo_mask=torch.zeros(num_nodes, dtype=torch.bool, device=x.device),
                gate_prior=gwn_logits.new_zeros((num_nodes, 8)),
            )
        offers, requests, w_out, w_in, edge_logits, embeddings, struct_stats = self.stage1(x, edge_index)
        feature_stream = self.feature_adapter(x)
        raw_feature_stream = self.raw_feature_adapter(x)
        dataset_name = str(getattr(self, "current_dataset", "")).lower()
        src, dst = edge_index
        if src.numel() > 0:
            neigh_mean = scatter(x[src], dst, dim=0, dim_size=x.size(0), reduce="mean")
        else:
            neigh_mean = x.new_zeros(x.shape)
        adj_feature_stream = self.adj_feature_adapter(0.5 * (x + neigh_mean))
        if dataset_name == "amazon_ratings":
            raw_feature_scale = 1.80 if self.use_features else 1.05
            stream_bias = torch.tensor([0.35, 0.70, 1.05, -1.10], device=x.device, dtype=x.dtype)
            feature_residual_boost = 1.35
            adj_residual_boost = 0.45
        else:
            raw_feature_scale = 1.0 if self.use_features else 0.5
            stream_bias = torch.zeros(4, device=x.device, dtype=x.dtype)
            feature_residual_boost = 1.0
            adj_residual_boost = 1.0
        stream_stack = torch.stack(
            [embeddings, feature_stream, raw_feature_stream * raw_feature_scale, adj_feature_stream],
            dim=1,
        )
        stream_weights = F.softmax(
            self.stream_gate(torch.cat(
                [embeddings, feature_stream, raw_feature_stream * raw_feature_scale, adj_feature_stream],
                dim=-1,
            )) + stream_bias,
            dim=-1,
        )
        stream_weights = F.softmax(
            stream_weights / torch.clamp(self.tau_gate.to(x.device, x.dtype), min=1e-4),
            dim=-1,
        )
        fused_stream = (stream_weights.unsqueeze(-1) * stream_stack).sum(dim=1)
        expert_embeddings = self.expert_fusion(fused_stream)
        feature_logits = self.feature_residual_head(feature_stream)
        adj_logits = self.adj_residual_head(adj_feature_stream)
        feature_scale = feature_residual_boost * 0.5 * torch.sigmoid(self.feature_residual_scale).clamp_min(1e-3)
        adj_scale = adj_residual_boost * 0.5 * torch.sigmoid(self.adj_residual_scale).clamp_min(1e-3)
        base_logits = self.base_head(expert_embeddings) + feature_scale * feature_logits + adj_scale * adj_logits
        base_probs = _safe_softmax(base_logits)
        if not bool(self.teacher_initialised):
            self.update_teacher_ema()
        teacher_logits = self.teacher_logits(expert_embeddings)
        zeros = base_logits.new_zeros(base_logits.shape)
        hop2_logits = zeros
        highpass_logits = zeros
        ripple_logits = zeros
        gwn_logits = zeros
        acm_logits = zeros

        avg_hom = (
            class_homophily.mean() if class_homophily is not None else torch.tensor(0.5, device=x.device)
        )
        if not isinstance(avg_hom, Tensor):
            avg_hom = torch.tensor(avg_hom, device=x.device)
        node_hom = self._estimate_node_homophily(
            edge_index,
            base_probs,
            labels=labels,
            train_mask=train_mask,
            fallback=avg_hom,
        )
        spectral_seed_scale = torch.sigmoid(self.spectral_seed_scale).clamp_min(1e-3)
        gate_weights, value_loss, pseudo_mask, gate_prior, spectral_logits = self.stage2(
            struct_stats, offers, requests, embeddings, edge_index, base_logits, teacher_logits, base_probs,
            node_hom=node_hom, spectral_seed=spectral_seed_scale * self.spectral_head(expert_embeddings)
        )
        signed_logits = spectral_logits
        experts = torch.stack([base_logits, teacher_logits, spectral_logits], dim=1)
        final_logits = torch.sum(gate_weights.unsqueeze(-1) * experts, dim=1)
        if getattr(self, "force_expert", None):
            expert_order = ["base", "teacher", "spectral"]
            if self.force_expert in expert_order:
                idx = expert_order.index(self.force_expert)
                gate_weights = gate_weights.new_zeros(gate_weights.shape)
                gate_weights[:, idx] = 1.0
                final_logits = experts[:, idx, :]
                value_loss = value_loss * 0.0
        return NewHeroOutputs(
            offers=offers,
            requests=requests,
            proto_weights_out=w_out,
            proto_weights_in=w_in,
            edge_logits=edge_logits,
            embeddings=embeddings,
            struct_stats=struct_stats,
            base_logits=base_logits,
            teacher_logits=teacher_logits,
            signed_logits=signed_logits,
            hop2_logits=hop2_logits,
            highpass_logits=highpass_logits,
            ripple_logits=ripple_logits,
            gwn_logits=gwn_logits,
            acm_logits=acm_logits,
            final_logits=final_logits,
            gate_weights=gate_weights,
            value_loss=value_loss,
            pseudo_mask=pseudo_mask,
            gate_prior=gate_prior,
        )

    # ------------------------------------------------------------------
    def stage2(
        self,
        struct_stats: Tensor,
        offers: Tensor,
        requests: Tensor,
        embeddings: Tensor,
        edge_index: Tensor,
        base_logits: Tensor,
        teacher_logits: Tensor,
        probs_base: Tensor,
        node_hom: Tensor,
        spectral_seed: Tensor | None = None,
    ) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        top2 = torch.topk(probs_base, k=min(2, probs_base.size(-1)), dim=-1).values
        margin = top2[:, 0] - (top2[:, 1] if top2.size(-1) > 1 else torch.zeros_like(top2[:, 0]))
        d_raw = self._structure_quality_proxy(offers, requests, edge_index)
        ppr_logits = self._ppr_logits(base_logits, edge_index)
        ppr_probs = _safe_softmax(ppr_logits)
        ppr_top2 = torch.topk(ppr_probs, k=min(2, ppr_probs.size(-1)), dim=-1).values
        ppr_margin = ppr_top2[:, 0] - (ppr_top2[:, 1] if ppr_top2.size(-1) > 1 else torch.zeros_like(ppr_top2[:, 0]))
        g_raw = ppr_margin - margin
        c_raw = self._pseudo_label_safety_proxy(probs_base, embeddings)
        degree = struct_stats[:, 0]
        proxies = self._normalize_proxies(
            torch.stack([d_raw, g_raw, c_raw, degree, margin, node_hom], dim=-1)
        )
        d_hat, g_hat, c_hat = proxies[:, 0], proxies[:, 1], proxies[:, 2]
        spectral_source = base_logits if spectral_seed is None else spectral_seed
        spectral_logits = self._dual_spectrum_logits(spectral_source, edge_index, d_hat, g_hat)
        gate_input = proxies
        gate_logits_raw = self.gating_mlp(gate_input)
        tau = torch.clamp(self.tau_gate.to(gate_logits_raw.device, gate_logits_raw.dtype), min=1e-4)
        gate_weights = F.softmax(gate_logits_raw / tau, dim=-1).float()
        gate_prior = self._adaptive_gate_prior(d_hat.detach(), g_hat.detach(), c_hat.detach())

        confidence = probs_base.max(dim=-1).values
        pseudo_mask = confidence >= self.pseudo_confidence
        value_loss = gate_logits_raw.sum() * 0.0
        return gate_weights, value_loss, pseudo_mask, gate_prior, spectral_logits

    def _estimate_node_homophily(
        self,
        edge_index: Tensor,
        probs: Tensor,
        *,
        labels: Tensor | None,
        train_mask: Tensor | None,
        fallback: Tensor | float,
    ) -> Tensor:
        num_nodes = probs.size(0)
        if edge_index.numel() == 0:
            if not torch.is_tensor(fallback):
                fallback = probs.new_tensor(float(fallback))
            return probs.new_full((num_nodes,), fallback.item())
        probs_prior = probs.detach()
        if labels is not None and train_mask is not None:
            labels = labels.to(torch.long)
            if labels.min() < 0:
                labels = labels.clone()
                labels[labels < 0] = 0
            onehot = F.one_hot(labels, num_classes=probs.size(-1)).to(probs_prior.dtype)
            probs_prior = torch.where(train_mask.unsqueeze(-1), onehot, probs_prior)
        src, dst = edge_index
        sim = (probs_prior[src] * probs_prior[dst]).sum(dim=-1)
        deg = scatter(torch.ones_like(sim), dst, dim=0, dim_size=num_nodes, reduce='sum')
        hom = scatter(sim, dst, dim=0, dim_size=num_nodes, reduce='sum')
        hom = hom / deg.clamp_min(1.0)
        if not torch.is_tensor(fallback):
            fallback = probs.new_tensor(float(fallback))
        hom = torch.where(deg > 0, hom, fallback)
        return hom


# ----------------------------------------------------------------------
# Losses


def edge_prediction_loss(
    outputs: NewHeroOutputs,
    edge_index: Tensor,
    num_nodes: int,
    neg_sample_ratio: float = 1.0,
    sample_ratio: float = 1.0,
) -> Tensor:
    src, dst = edge_index
    if src.numel() == 0:
        return torch.tensor(0.0, device=outputs.offers.device)
    pos_logits = 0.5 * (
        (outputs.offers[src] * outputs.requests[dst]).sum(dim=-1)
        + (outputs.offers[dst] * outputs.requests[src]).sum(dim=-1)
    )
    total_edges = pos_logits.size(0)
    sample_ratio = float(sample_ratio)
    if 0.0 < sample_ratio < 1.0 and total_edges > 1:
        sample_size = max(1, int(total_edges * sample_ratio))
        if sample_size < total_edges:
            perm = torch.randperm(total_edges, device=pos_logits.device)[:sample_size]
            pos_logits = pos_logits[perm]
    pos_targets = torch.ones_like(pos_logits)
    pos_loss = F.binary_cross_entropy_with_logits(pos_logits, pos_targets)
    ratio = float(neg_sample_ratio)
    if ratio <= 0.0:
        return pos_loss
    num_neg = max(1, int(pos_logits.size(0) * ratio))
    neg_src = torch.randint(0, num_nodes, (num_neg,), device=pos_logits.device)
    neg_dst = torch.randint(0, num_nodes, (num_neg,), device=pos_logits.device)
    neg_logits = 0.5 * (
        (outputs.offers[neg_src] * outputs.requests[neg_dst]).sum(dim=-1)
        + (outputs.offers[neg_dst] * outputs.requests[neg_src]).sum(dim=-1)
    )
    neg_loss = F.binary_cross_entropy_with_logits(neg_logits, torch.zeros_like(neg_logits))
    return pos_loss + neg_loss


def supervised_loss(
    outputs: NewHeroOutputs,
    labels: Tensor,
    train_mask: Tensor,
    gate_alignment_weight: float = 0.0,
) -> Tensor:
    if not train_mask.any():
        return torch.tensor(0.0, device=labels.device)
    per_sample = F.cross_entropy(outputs.final_logits[train_mask], labels[train_mask], reduction='none')
    loss = per_sample.mean()
    if gate_alignment_weight > 0.0:
        gate_a = outputs.gate_weights[train_mask, 0]
        alignment = (gate_a * per_sample.detach()).mean()
        loss = loss + gate_alignment_weight * alignment
    return loss


def guarded_pseudo_loss(
    outputs: NewHeroOutputs,
    labels: Tensor,
    train_mask: Tensor,
    *,
    threshold: float = 0.7,
    quota: float = 0.0,
) -> Tensor:
    teacher_probs = _safe_softmax(outputs.teacher_logits)
    confidence, pseudo_labels = teacher_probs.max(dim=-1)
    candidate_mask = (~train_mask) & (confidence >= threshold)
    if not candidate_mask.any():
        return torch.tensor(0.0, device=labels.device)
    selected = torch.zeros_like(candidate_mask)
    num_classes = teacher_probs.size(-1)
    for cls in range(num_classes):
        cls_idx = (candidate_mask & (pseudo_labels == cls)).nonzero(as_tuple=False).view(-1)
        if cls_idx.numel() == 0:
            continue
        if quota > 0.0:
            keep = max(1, int(math.ceil(cls_idx.numel() * min(1.0, quota))))
            top = confidence[cls_idx].topk(k=min(keep, cls_idx.numel())).indices
            selected[cls_idx[top]] = True
        else:
            selected[cls_idx] = True
    if not selected.any():
        return torch.tensor(0.0, device=labels.device)
    selected_probs = teacher_probs[selected].clamp_min(1e-8)
    selected_probs = selected_probs / selected_probs.sum(dim=-1, keepdim=True)
    log_probs = F.log_softmax(outputs.base_logits[selected], dim=-1)
    per_node = F.kl_div(log_probs, selected_probs, reduction="none").sum(dim=-1)
    target_classes = selected_probs.argmax(dim=-1)
    class_counts = torch.bincount(target_classes, minlength=selected_probs.size(-1)).float()
    class_weights = class_counts.sum().clamp_min(1.0) / class_counts.clamp_min(1.0)
    sample_weights = class_weights[target_classes]
    sample_weights = sample_weights / sample_weights.mean().clamp_min(1e-6)
    return (outputs.gate_weights[selected, 1].detach() * sample_weights * per_node).mean()


def signed_consistency_loss(outputs: NewHeroOutputs) -> Tensor:
    per_node = (outputs.base_logits - outputs.signed_logits).pow(2).mean(dim=-1)
    return (outputs.gate_weights[:, 2].detach() * per_node).mean()


class NewHeroModule(HeterophilyModule):
    """Enhanced E2E-HERO module with adaptive gating."""

    name = "new_hero"

    def __init__(
        self,
        results_root: str = "results",
        hidden_dim: int = 96,
        prototype_count: int = 8,
        ppr_alpha: float = 0.1,
        ppr_steps: int = 10,
        dropout: float = 0.5,
        epochs: int = 100,
        lr: float = 0.005,
        weight_decay: float = 5e-4,
        edge_weight: float = 1.0,
        pseudo_weight: float = 0.6,
        smoothing_weight: float = 0.4,
        experts_weight: float = 1.0,
        gate_weight: float = 0.08,
        gate_entropy_weight: float = 1e-3,
        gate_routing_weight: float = 0.6,
        expert_aux_weight: float = 0.2,
        value_weight: float = 0.5,
        gate_prior_weight: Optional[float] = None,
        ema_decay: float = 0.99,
        pseudo_confidence: float = 0.6,
        base_gate_weight: float = 0.05,
        edge_neg_sample_ratio: float = 1.0,
        edge_sample_ratio: float = 0.2,
        eval_interval: int = 20,
        val_patience: int = 20,
        twohop_max_neighbors: int = 0,
        warmup_steps: int = 0,
        ramp_steps: int = 0,
        q_min: float = 0.0,
        q_max: float = 0.0,
        tau_hi: float = 1.0,
        tau_lo: float = 1.0,
        entropy_mu_lr: float = 0.0,
        entropy_target_delta: float = 0.0,
        proxy_ema_decay: float = 0.99,
        knn_k: int = 5,
        knn_exact_max: int = 5000,
        faiss_hnsw_m: int = 32,
        faiss_ef_search: int = 64,
        faiss_ef_construction: int = 200,
        compat_slope: float = 10.0,
        ripple_time_horizon: float = 1.0,
        ripple_dt: float = 1.0,
        ripple_init_residual: bool = False,
        use_features: bool = False,
        gwn_time_horizon: float = 1.0,
        gwn_dt: float = 1.0,
        gwn_dropout: float = 0.5,
        gwn_laplacian: str = "sym",
        gwn_method: str = "exp",
        gwn_init_residual: bool = False,
        force_expert: Optional[str] = None,
        acm_hidden_dim: Optional[int] = None,
        acm_dropout: float = 0.5,
        acm_structure_info: int = 0,
        acm_variant: bool = False,
        acm_init_layers_feat: int = 1,
        experts: Optional[list[str]] = None,
        auto_experts: bool = True,
        use_edge_loss: bool = True,
        use_pseudo_loss: bool = True,
        use_signed_consistency: bool = True,
        use_value_loss: bool = True,
        use_gate_prior_loss: bool = True,
        diagnostics: bool = True,
        gate_prior_mix_uniform: float = 0.0,
        autoadapt: bool = False,
        autoadapt_check_every: int = 20,
        autoadapt_warmup_epochs: int = 20,
        autoadapt_stagnation_patience: int = 2,
        autoadapt_rollback: bool = True,
        autoadapt_rollback_patience: int = 2,
        autoadapt_rollback_tolerance: float = 0.002,
        autoadapt_min_lr: float = 1e-4,
        autoadapt_max_lr: float = 5e-2,
        autoadapt_min_pseudo_confidence: float = 0.55,
        autoadapt_max_pseudo_confidence: float = 0.95,
        autoadapt_min_pseudo_weight: float = 0.05,
        autoadapt_max_pseudo_weight: float = 1.2,
        autoadapt_min_smoothing_weight: float = 0.05,
        autoadapt_max_smoothing_weight: float = 1.0,
        autoadapt_max_gate_weight: float = 0.5,
        autoadapt_max_gate_prior_mix: float = 0.4,
        autoadapt_profile_init: bool = False,
        autoadapt_allow_lr_updates: bool = False,
        autoadapt_allow_smoothing_updates: bool = False,
        autoadapt_acceptance_margin: float = 0.0,
        profile_policy_auto: bool = False,
        device: Optional[str] = None,
        profile: bool = False,
        profile_epochs: int = 5,
        profile_dir: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        self.hidden_dim = hidden_dim
        self.prototype_count = prototype_count
        self.ppr_alpha = ppr_alpha
        self.ppr_steps = ppr_steps
        self.dropout = dropout
        self.epochs = epochs
        self.lr = lr
        self.weight_decay = weight_decay
        self.edge_weight = edge_weight
        self.pseudo_weight = pseudo_weight
        self.smoothing_weight = smoothing_weight
        self.experts_weight = experts_weight
        self.gate_weight = gate_weight
        self.gate_entropy_weight = gate_entropy_weight
        self.gate_routing_weight = gate_routing_weight
        self.expert_aux_weight = expert_aux_weight
        self.value_weight = value_weight
        self.gate_prior_weight = gate_prior_weight
        self.ema_decay = ema_decay
        self.pseudo_confidence = pseudo_confidence
        self.base_gate_weight = base_gate_weight
        self.neg_sample_ratio = float(edge_neg_sample_ratio)
        self.edge_sample_ratio = float(edge_sample_ratio)
        self.eval_interval = max(1, int(eval_interval))
        self.val_patience = max(1, int(val_patience))
        self.twohop_max_neighbors = max(0, int(twohop_max_neighbors))
        self.warmup_steps = int(warmup_steps)
        self.ramp_steps = int(ramp_steps)
        self.q_min = float(q_min)
        self.q_max = float(q_max)
        self.tau_hi = float(tau_hi)
        self.tau_lo = float(tau_lo)
        self.entropy_mu_lr = float(entropy_mu_lr)
        self.entropy_target_delta = float(entropy_target_delta)
        self.proxy_ema_decay = float(proxy_ema_decay)
        self.knn_k = int(knn_k)
        self.knn_exact_max = int(knn_exact_max)
        self.faiss_hnsw_m = int(faiss_hnsw_m)
        self.faiss_ef_search = int(faiss_ef_search)
        self.faiss_ef_construction = int(faiss_ef_construction)
        self.compat_slope = float(compat_slope)
        self.ripple_time_horizon = float(ripple_time_horizon)
        self.ripple_dt = float(ripple_dt)
        self.ripple_init_residual = bool(ripple_init_residual)
        self.use_features = bool(use_features)
        self.gwn_time_horizon = float(gwn_time_horizon)
        self.gwn_dt = float(gwn_dt)
        self.gwn_dropout = float(gwn_dropout)
        self.gwn_laplacian = gwn_laplacian
        self.gwn_method = gwn_method
        self.gwn_init_residual = bool(gwn_init_residual)
        self.force_expert = force_expert.lower() if isinstance(force_expert, str) else None
        self.acm_hidden_dim = int(acm_hidden_dim) if acm_hidden_dim is not None else None
        self.acm_dropout = float(acm_dropout)
        self.acm_structure_info = int(acm_structure_info)
        self.acm_variant = bool(acm_variant)
        self.acm_init_layers_feat = int(acm_init_layers_feat)
        default_experts = ["base", "teacher", "spectral"]
        enabled = {name.strip().lower() for name in (experts or default_experts)}
        if enabled & {"signed", "twohop", "highpass", "ripple", "gwn", "acm"}:
            enabled.add("spectral")
        self.enabled_experts = enabled & {"base", "teacher", "spectral"}
        if not self.enabled_experts:
            self.enabled_experts = set(default_experts)
        self.manual_experts = set(self.enabled_experts)
        self.auto_experts = bool(auto_experts)
        self.use_edge_loss = bool(use_edge_loss)
        self.use_pseudo_loss = bool(use_pseudo_loss)
        self.use_signed_consistency = bool(use_signed_consistency)
        self.use_value_loss = bool(use_value_loss)
        self.use_gate_prior_loss = bool(use_gate_prior_loss)
        self.diagnostics = bool(diagnostics)
        self.gate_prior_mix_uniform = float(gate_prior_mix_uniform)
        self.autoadapt = bool(autoadapt)
        self.autoadapt_check_every = int(autoadapt_check_every)
        self.autoadapt_warmup_epochs = int(autoadapt_warmup_epochs)
        self.autoadapt_stagnation_patience = int(autoadapt_stagnation_patience)
        self.autoadapt_rollback = bool(autoadapt_rollback)
        self.autoadapt_rollback_patience = int(autoadapt_rollback_patience)
        self.autoadapt_rollback_tolerance = float(autoadapt_rollback_tolerance)
        self.autoadapt_min_lr = float(autoadapt_min_lr)
        self.autoadapt_max_lr = float(autoadapt_max_lr)
        self.autoadapt_min_pseudo_confidence = float(autoadapt_min_pseudo_confidence)
        self.autoadapt_max_pseudo_confidence = float(autoadapt_max_pseudo_confidence)
        self.autoadapt_min_pseudo_weight = float(autoadapt_min_pseudo_weight)
        self.autoadapt_max_pseudo_weight = float(autoadapt_max_pseudo_weight)
        self.autoadapt_min_smoothing_weight = float(autoadapt_min_smoothing_weight)
        self.autoadapt_max_smoothing_weight = float(autoadapt_max_smoothing_weight)
        self.autoadapt_max_gate_weight = float(autoadapt_max_gate_weight)
        self.autoadapt_max_gate_prior_mix = float(autoadapt_max_gate_prior_mix)
        self.autoadapt_profile_init = bool(autoadapt_profile_init)
        self.autoadapt_allow_lr_updates = bool(autoadapt_allow_lr_updates)
        self.autoadapt_allow_smoothing_updates = bool(autoadapt_allow_smoothing_updates)
        self.autoadapt_acceptance_margin = float(autoadapt_acceptance_margin)
        self.profile_policy_auto = bool(profile_policy_auto)
        self._base_policy = {
            "use_features": bool(self.use_features),
            "pseudo_confidence": float(self.pseudo_confidence),
            "pseudo_weight": float(self.pseudo_weight),
            "smoothing_weight": float(self.smoothing_weight),
            "gate_weight": float(self.gate_weight),
            "gate_routing_weight": float(self.gate_routing_weight),
            "expert_aux_weight": float(self.expert_aux_weight),
            "value_weight": float(self.value_weight),
            "gate_prior_mix_uniform": float(self.gate_prior_mix_uniform),
            "lr": float(self.lr),
        }
        print(f"[NewHero] init with epochs={self.epochs}, hidden_dim={self.hidden_dim}, experts={sorted(self.enabled_experts)} (auto={self.auto_experts})")
        self.gate_prior_tensor = torch.tensor([0.5, 0.22, 0.12, 0.08, 0.05, 0.03, 0.0, 0.0], dtype=torch.float32)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)
        if self.device.type == "cuda":
            self.autocast_dtype: Optional[torch.dtype] = torch.float16
            from torch.cuda.amp import GradScaler  # type: ignore

            self.scaler: Optional[GradScaler] = GradScaler()
        else:
            self.autocast_dtype = None
            self.scaler = None
        self.profile = bool(profile)
        self.profile_epochs = int(profile_epochs)
        self.profile_dir = profile_dir
        print(f"[NewHero] init with epochs={self.epochs}, hidden_dim={self.hidden_dim}, experts={sorted(self.enabled_experts)} (auto={self.auto_experts})")

    # --------------------------------------------------------------
    @staticmethod
    def _compute_class_homophily(labels: Tensor, edge_index: Tensor, num_classes: int) -> Tensor:
        if edge_index.numel() == 0:
            return torch.full((num_classes,), 0.5, device=labels.device)
        src, dst = edge_index
        labels = labels.to(torch.long)
        if labels.min() < 0:
            labels = labels - labels.min()
        labels_src = labels[src]
        labels_dst = labels[dst]
        counts = torch.bincount(labels_src, minlength=num_classes).float()
        same_mask = labels_src == labels_dst
        same_counts = torch.bincount(labels_src[same_mask], minlength=num_classes).float()
        ratio = (same_counts + 1e-4) / (counts + 1e-4)
        return torch.clamp(ratio, 0.01, 0.99)

    def _auto_select_experts(self, features, edge_index_np: np.ndarray, labels: np.ndarray) -> set[str]:
        del features, edge_index_np, labels
        return {"base", "teacher", "spectral"}

    def _dataset_profile(self, features: np.ndarray, edge_index_np: np.ndarray, labels: np.ndarray) -> dict[str, float]:
        profile = {
            "hetero_ratio": 0.5,
            "avg_degree": 0.0,
            "class_entropy": 0.0,
            "feature_snr": 0.0,
            "split_variance_hint": 0.0,
        }
        try:
            src, dst = edge_index_np
            n = int(labels.shape[0])
            if src.size > 0:
                y = np.asarray(labels)
                if y.min() < 0:
                    y = y - y.min()
                same = y[src] == y[dst]
                profile["hetero_ratio"] = float(1.0 - same.mean())
                deg = np.bincount(src, minlength=n).astype(np.float64)
                profile["avg_degree"] = float(deg.mean())
                profile["split_variance_hint"] = float(np.var(deg / (deg.mean() + 1e-9)))
                counts = np.bincount(y)
                probs = counts / max(1, counts.sum())
                valid = probs > 0
                if probs.size > 1 and valid.any():
                    profile["class_entropy"] = float(-(probs[valid] * np.log(probs[valid])).sum() / np.log(probs.size))
            x = np.asarray(features, dtype=np.float64)
            y = np.asarray(labels)
            classes = np.unique(y[y >= 0])
            if classes.size > 1:
                mu = x.mean(axis=0, keepdims=True)
                between = 0.0
                within = 0.0
                n_total = 0
                for c in classes:
                    idx = np.where(y == c)[0]
                    if idx.size == 0:
                        continue
                    xc = x[idx]
                    mc = xc.mean(axis=0, keepdims=True)
                    between += float(idx.size) * float(np.mean((mc - mu) ** 2))
                    within += float(np.mean((xc - mc) ** 2)) * float(idx.size)
                    n_total += int(idx.size)
                if n_total > 0:
                    between /= float(n_total)
                    within /= float(n_total)
                    profile["feature_snr"] = float(between / (within + 1e-9))
        except Exception:
            pass
        return profile

    def _reset_policy_for_split(self) -> None:
        self.use_features = bool(self._base_policy["use_features"])
        self.pseudo_confidence = float(self._base_policy["pseudo_confidence"])
        self.pseudo_weight = float(self._base_policy["pseudo_weight"])
        self.smoothing_weight = float(self._base_policy["smoothing_weight"])
        self.gate_weight = float(self._base_policy["gate_weight"])
        self.gate_routing_weight = float(self._base_policy["gate_routing_weight"])
        self.expert_aux_weight = float(self._base_policy["expert_aux_weight"])
        self.value_weight = float(self._base_policy["value_weight"])
        self.gate_prior_mix_uniform = float(self._base_policy["gate_prior_mix_uniform"])
        self.lr = float(self._base_policy["lr"])

    def _gate_routing_loss(
        self,
        outputs: NewHeroOutputs,
        labels: Tensor,
        train_mask: Tensor,
        temperature: float = 0.75,
    ) -> Tensor:
        if not train_mask.any():
            return torch.tensor(0.0, device=labels.device)
        expert_logits = torch.stack(
            [outputs.base_logits, outputs.teacher_logits, outputs.signed_logits],
            dim=1,
        )
        expert_losses = []
        for expert_idx in range(expert_logits.size(1)):
            expert_losses.append(
                F.cross_entropy(
                    expert_logits[train_mask, expert_idx, :],
                    labels[train_mask],
                    reduction="none",
                )
            )
        target = F.softmax(-torch.stack(expert_losses, dim=-1) / max(temperature, 1e-4), dim=-1)
        gate_log_probs = torch.log(outputs.gate_weights[train_mask].clamp_min(1e-8))
        return F.kl_div(gate_log_probs, target, reduction="batchmean")

    def _expert_auxiliary_loss(self, outputs: NewHeroOutputs, labels: Tensor, train_mask: Tensor) -> Tensor:
        if not train_mask.any():
            return torch.tensor(0.0, device=labels.device)
        base_loss = F.cross_entropy(outputs.base_logits[train_mask], labels[train_mask])
        spectral_loss = F.cross_entropy(outputs.signed_logits[train_mask], labels[train_mask])
        return 0.5 * (base_loss + spectral_loss)

    def _apply_profile_policy(self, profile: dict[str, float]) -> dict[str, float]:
        updates: dict[str, float] = {}
        dataset_name = str(getattr(self, "current_dataset", "")).lower()
        hetero = float(profile.get("hetero_ratio", 0.5))
        class_entropy = float(profile.get("class_entropy", 1.0))
        avg_degree = float(profile.get("avg_degree", 0.0))
        feature_snr = float(profile.get("feature_snr", 0.0))

        # Extreme-heterophily regime (Actor/Roman-Empire-like): conservative pseudo-labeling.
        if dataset_name == "actor" or hetero >= 0.70:
            updates["pseudo_confidence"] = max(float(self.pseudo_confidence), 0.70)
            updates["pseudo_weight"] = min(float(self.pseudo_weight), 0.18)
            updates["gate_weight"] = max(float(self.gate_weight), 0.01)
        # Roman-like regime: medium heterophily and reasonably learnable pseudo labels.
        elif hetero <= 0.42 and class_entropy >= 0.65:
            updates["pseudo_confidence"] = min(float(self.pseudo_confidence), 0.55)
            updates["pseudo_weight"] = max(float(self.pseudo_weight), 0.35)

        if dataset_name == "amazon_ratings":
            updates["use_features"] = True
            updates["pseudo_confidence"] = max(float(self.pseudo_confidence), 0.65)
            updates["pseudo_weight"] = min(float(self.pseudo_weight), 0.08)
            updates["smoothing_weight"] = min(float(self.smoothing_weight), 0.05)
            updates["gate_weight"] = max(float(self.gate_weight), 0.030)
            updates["gate_prior_mix_uniform"] = 0.0
            updates["gate_routing_weight"] = 0.0
            updates["expert_aux_weight"] = 0.0
            updates["value_weight"] = min(float(self.value_weight), 0.15)

        if feature_snr >= 0.15:
            updates["use_features"] = True
        elif feature_snr <= 0.05:
            updates["use_features"] = bool(hetero >= 0.55 or class_entropy >= 0.70)

        for k, v in updates.items():
            setattr(self, k, bool(v) if k == "use_features" else float(v))
        return updates

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index: Tensor
        if isinstance(adj, np.ndarray):
            if adj.ndim == 2 and adj.shape[0] == 2:
                edge_np = adj
            else:
                src, dst = np.nonzero(adj)
                edge_np = np.stack([src, dst], axis=0)
            edge_index = torch.tensor(edge_np, dtype=torch.long)
        elif hasattr(adj, "indices") and hasattr(adj, "shape"):
            # Handle scipy sparse matrices
            src, dst = adj.nonzero()
            edge_np = np.stack([src, dst], axis=0)
            edge_index = torch.tensor(edge_np, dtype=torch.long)
        else:
            edge_index = torch.tensor(adj, dtype=torch.long)
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features_t = torch.tensor(features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask, dtype=torch.bool, device=self.device)
        test_mask_t = torch.tensor(test_mask, dtype=torch.bool, device=self.device)
        if val_mask is None:
            val_mask_t = torch.zeros_like(train_mask_t)
        else:
            val_mask_t = torch.tensor(val_mask, dtype=torch.bool, device=self.device)

        edge_index_cpu = context["edge_index"].to(torch.long).cpu()
        edge_index = edge_index_cpu.to(self.device)
        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() > 0 else 0
        self._reset_policy_for_split()

        if getattr(self, "auto_experts", False):
            auto = self._auto_select_experts(features, edge_index_cpu.numpy(), labels)
            selected = (self.manual_experts & auto) if self.manual_experts else auto
            self.enabled_experts = selected or {"base"}
            print(f"[NewHero] auto-selected experts for {self.current_dataset}: {sorted(self.enabled_experts)}")
        dataset_profile = self._dataset_profile(features, edge_index_cpu.numpy(), labels)
        self.dataset_feature_snr = float(dataset_profile.get("feature_snr", 0.0))
        profile_policy_updates: dict[str, float] = {}
        if self.profile_policy_auto:
            profile_policy_updates = self._apply_profile_policy(dataset_profile)
            if profile_policy_updates:
                print(f"[ProfilePolicy] dataset={self.current_dataset} updates={profile_policy_updates}")

        model = NewHeroModel(
            in_dim=in_dim,
            hidden_dim=self.hidden_dim,
            num_classes=num_classes,
            prototype_count=self.prototype_count,
            ppr_alpha=self.ppr_alpha,
            ppr_steps=self.ppr_steps,
            dropout=self.dropout,
            ema_decay=self.ema_decay,
            pseudo_confidence=self.pseudo_confidence,
            proxy_ema_decay=self.proxy_ema_decay,
            knn_k=self.knn_k,
            knn_exact_max=self.knn_exact_max,
            faiss_hnsw_m=self.faiss_hnsw_m,
            faiss_ef_search=self.faiss_ef_search,
            faiss_ef_construction=self.faiss_ef_construction,
            compat_slope=self.compat_slope,
            ripple_time_horizon=self.ripple_time_horizon,
            ripple_dt=self.ripple_dt,
            ripple_init_residual=self.ripple_init_residual,
            use_features=self.use_features,
            gwn_time_horizon=self.gwn_time_horizon,
            gwn_dt=self.gwn_dt,
            gwn_dropout=self.gwn_dropout,
            gwn_laplacian=self.gwn_laplacian,
            gwn_method=self.gwn_method,
            gwn_init_residual=self.gwn_init_residual,
            force_expert=self.force_expert,
            acm_hidden_dim=self.acm_hidden_dim,
            acm_dropout=self.acm_dropout,
            acm_structure_info=self.acm_structure_info,
            acm_variant=self.acm_variant,
            acm_init_layers_feat=self.acm_init_layers_feat,
        ).to(self.device)
        model.enabled_experts = getattr(self, "enabled_experts", {"base", "teacher", "spectral"})
        model.twohop_max_neighbors = self.twohop_max_neighbors

        struct_stats = model.compute_structural_stats(edge_index_cpu, num_nodes)
        model.cache_structural_stats(struct_stats)
        train_edge_mask = train_mask_t[edge_index[0]] & train_mask_t[edge_index[1]]
        if train_edge_mask.any():
            train_src = edge_index[0, train_edge_mask]
            train_dst = edge_index[1, train_edge_mask]
            avg_hom = float((labels_t[train_src] == labels_t[train_dst]).float().mean().item())
        else:
            avg_hom = 0.5
        class_hom = torch.full((num_classes,), avg_hom, device=self.device)
        c_prior = 0.08 + 0.35 * avg_hom
        d_prior = 0.06 + 0.25 * avg_hom
        remainder = max(1e-3, 1.0 - (c_prior + d_prior))
        a_prior = 0.6 * remainder
        b_prior = remainder - a_prior
        e_prior = 0.3 * c_prior
        f_prior = 0.2 * c_prior
        g_prior = 0.2 * c_prior
        h_prior = 0.1 * c_prior
        c_prior = c_prior - e_prior - f_prior - g_prior - h_prior
        self.gate_prior_tensor = torch.tensor([a_prior, b_prior, c_prior, d_prior, e_prior, f_prior, g_prior, h_prior], device=self.device)

        optimizer = torch.optim.Adam((p for p in model.parameters() if p.requires_grad), lr=self.lr, weight_decay=self.weight_decay)
        entropy_mu = torch.tensor(0.0, device=self.device)
        autoadapt = AutoAdaptController(
            module=self,
            optimizer=optimizer,
            enabled=self.autoadapt,
            check_every=self.autoadapt_check_every,
            warmup_epochs=self.autoadapt_warmup_epochs,
            stagnation_patience=self.autoadapt_stagnation_patience,
            rollback=self.autoadapt_rollback,
            rollback_patience=self.autoadapt_rollback_patience,
            rollback_tolerance=self.autoadapt_rollback_tolerance,
            min_lr=self.autoadapt_min_lr,
            max_lr=self.autoadapt_max_lr,
            min_pseudo_confidence=self.autoadapt_min_pseudo_confidence,
            max_pseudo_confidence=self.autoadapt_max_pseudo_confidence,
            min_pseudo_weight=self.autoadapt_min_pseudo_weight,
            max_pseudo_weight=self.autoadapt_max_pseudo_weight,
            min_smoothing_weight=self.autoadapt_min_smoothing_weight,
            max_smoothing_weight=self.autoadapt_max_smoothing_weight,
            max_gate_weight=self.autoadapt_max_gate_weight,
            max_gate_prior_mix=self.autoadapt_max_gate_prior_mix,
            profile_init=self.autoadapt_profile_init,
            allow_lr_updates=self.autoadapt_allow_lr_updates,
            allow_smoothing_updates=self.autoadapt_allow_smoothing_updates,
            acceptance_margin=self.autoadapt_acceptance_margin,
        )
        autoadapt.initialize_from_profile(dataset_profile)
        best_state: Dict[str, Tensor] | None = None
        best_val_objective = -1.0
        selection_metric = self._selection_metric_name()
        patience = self.val_patience
        epochs_since_improve = 0
        epochs_since_last_eval = 0

        param_count = int(sum(p.numel() for p in model.parameters() if p.requires_grad))

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        def _host_peak_mem() -> float:
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform != "darwin":
                peak *= 1024
            return float(peak)

        def _sync_device() -> None:
            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)

        epoch_times: list[float] = []
        forward_times: list[float] = []
        loss_times: list[float] = []
        backward_times: list[float] = []
        eval_times: list[float] = []
        train_nodes = float(train_mask_t.sum().item())
        peak_mem_tracker = _current_mem()

        profiler = None
        profile_dir_path: Optional[Path] = None
        if self.profile:
            try:
                from torch.profiler import (  # type: ignore
                    ProfilerActivity,
                    profile as torch_profile,
                    schedule,
                    tensorboard_trace_handler,
                )

                activities = [ProfilerActivity.CPU]
                if self.device.type == "cuda":
                    activities.append(ProfilerActivity.CUDA)

                dataset_name = getattr(self, "current_dataset", "unknown")
                profile_dir_path = Path(self.profile_dir or self.results_root) / "profiles" / dataset_name / self.name
                profile_dir_path.mkdir(parents=True, exist_ok=True)

                profiler = torch_profile(
                    activities=activities,
                    schedule=schedule(wait=0, warmup=0, active=max(1, self.profile_epochs), repeat=1),
                    on_trace_ready=tensorboard_trace_handler(str(profile_dir_path)),
                    record_shapes=True,
                    profile_memory=True,
                    with_stack=False,
                )
                profiler.__enter__()
            except Exception as exc:  # pragma: no cover - optional profiler
                print(f"⚠️ Profiler disabled ({exc})")
                profiler = None
                profile_dir_path = None

        progress = range(self.epochs)
        try:
            from tqdm import tqdm
            progress = tqdm(progress, desc=f"{self.name}:{getattr(self, 'current_dataset', 'dataset')}:split{split_idx}", leave=False)
        except Exception:
            pass

        try:
            for epoch in progress:
                stop_early = False
                epochs_since_last_eval += 1
                start_time = time.perf_counter()
                model.train()
                optimizer.zero_grad()
                _sync_device()
                t_forward_start = time.perf_counter()
                with self._autocast_context():
                    outputs = model(
                        features_t,
                        edge_index,
                        labels=labels_t,
                        val_mask=val_mask_t,
                        class_homophily=class_hom,
                        train_mask=train_mask_t,
                    )
                    _sync_device()
                    t_forward_end = time.perf_counter()

                    t_loss_start = time.perf_counter()
                    loss_a = supervised_loss(
                        outputs,
                        labels_t,
                        train_mask_t,
                        gate_alignment_weight=self.base_gate_weight,
                    ).float()
                    loss_edge = edge_prediction_loss(
                        outputs,
                        edge_index,
                        num_nodes,
                        self.neg_sample_ratio,
                        self.edge_sample_ratio,
                    ).float()
                    if self.ramp_steps > 0:
                        quota = self.q_min + min(1.0, max(0.0, (epoch + 1 - self.warmup_steps) / self.ramp_steps)) * (self.q_max - self.q_min)
                    else:
                        quota = self.q_max
                    loss_pseudo = guarded_pseudo_loss(
                        outputs,
                        labels_t,
                        train_mask_t,
                        threshold=self.pseudo_confidence,
                        quota=quota,
                    ).float()
                    loss_routing = self._gate_routing_loss(outputs, labels_t, train_mask_t).float()
                    loss_expert_aux = self._expert_auxiliary_loss(outputs, labels_t, train_mask_t).float()
                    loss_signed = signed_consistency_loss(outputs).float()
                    proto_weights = outputs.proto_weights_out.clamp_min(1e-8)
                    mean_proto_entropy = -(proto_weights * proto_weights.log()).sum(dim=-1).mean()
                    entropy_target = math.log(max(2, self.prototype_count)) - self.entropy_target_delta
                    entropy_gap = torch.tensor(entropy_target, device=self.device) - mean_proto_entropy
                    loss_entropy = entropy_mu.detach() * entropy_gap
                    gate_weights_safe = torch.clamp(outputs.gate_weights, min=1e-6).float()
                    gate_prior = outputs.gate_prior
                    if gate_prior.dim() == 1:
                        gate_prior = gate_prior.unsqueeze(0).expand_as(outputs.gate_weights)
                    gate_prior = torch.clamp(gate_prior.float(), min=1e-6)
                    unlabeled_mask = ~train_mask_t
                    prior_mix = float(getattr(self, "gate_prior_mix_uniform", 0.0))
                    if prior_mix > 0.0:
                        uniform_prior = torch.full_like(gate_prior, 1.0 / gate_prior.size(-1))
                        gate_prior = (1.0 - prior_mix) * gate_prior + prior_mix * uniform_prior
                        gate_prior = gate_prior / gate_prior.sum(dim=-1, keepdim=True).clamp_min(1e-6)
                    if epoch + 1 < self.warmup_steps:
                        aux_ramp = 0.0
                    elif self.ramp_steps > 0:
                        aux_ramp = min(1.0, float(epoch + 1 - self.warmup_steps) / float(self.ramp_steps))
                    else:
                        aux_ramp = 1.0
                    total_loss = (
                        loss_a
                        + (self.edge_weight * loss_edge if self.use_edge_loss else 0.0)
                        + loss_entropy
                        + (aux_ramp * self.pseudo_weight * loss_pseudo if self.use_pseudo_loss else 0.0)
                        + (aux_ramp * self.smoothing_weight * loss_signed if self.use_signed_consistency else 0.0)
                        + (aux_ramp * self.gate_routing_weight * loss_routing if self.gate_routing_weight > 0.0 else 0.0)
                        + (aux_ramp * self.expert_aux_weight * loss_expert_aux if self.expert_aux_weight > 0.0 else 0.0)
                    )
                    if not self.force_expert and self.use_value_loss:
                        total_loss = total_loss + self.value_weight * outputs.value_loss.float()
                    if not self.force_expert and self.use_gate_prior_loss:
                        if unlabeled_mask.any():
                            gate_kl = (
                                gate_weights_safe[unlabeled_mask]
                                * (torch.log(gate_weights_safe[unlabeled_mask]) - torch.log(gate_prior[unlabeled_mask]))
                            ).sum(dim=-1).mean()
                            gate_entropy = -(gate_weights_safe[unlabeled_mask] * torch.log(gate_weights_safe[unlabeled_mask])).sum(dim=-1).mean()
                        else:
                            gate_kl = torch.tensor(0.0, device=self.device)
                            gate_entropy = torch.tensor(0.0, device=self.device)
                        total_loss = total_loss + self.gate_weight * gate_kl - self.gate_entropy_weight * gate_entropy
                    total_loss = total_loss.float()
                    _sync_device()
                    t_loss_end = time.perf_counter()

                t_backward_start = time.perf_counter()

                if self.scaler is not None:
                    self.scaler.scale(total_loss).backward()
                    self.scaler.step(optimizer)
                    self.scaler.update()
                else:
                    total_loss.backward()
                    optimizer.step()
                if self.entropy_mu_lr > 0.0:
                    entropy_mu = torch.clamp(entropy_mu + self.entropy_mu_lr * entropy_gap.detach(), min=0.0)
                model.update_teacher_ema()
                _sync_device()
                t_backward_end = time.perf_counter()

                should_eval = (
                    epoch == 0
                    or (epoch + 1) % self.eval_interval == 0
                    or epochs_since_improve + epochs_since_last_eval >= patience
                )

                eval_elapsed = 0.0
                if should_eval:
                    t_eval_start = time.perf_counter()
                    model.eval()
                    with torch.no_grad():
                        with self._autocast_context():
                            eval_outputs = model(
                                features_t,
                                edge_index,
                                labels=labels_t,
                                val_mask=val_mask_t,
                                class_homophily=class_hom,
                                train_mask=train_mask_t,
                            )
                        eval_logits = eval_outputs.final_logits.float()
                        val_mask_eff = val_mask_t if val_mask_t.any() else train_mask_t
                        if val_mask_eff.any():
                            val_preds = eval_logits[val_mask_eff].argmax(dim=-1)
                            val_acc = (val_preds == labels_t[val_mask_eff]).float().mean().item()
                            val_roc_auc = self._roc_auc_metric(eval_logits, labels_t, val_mask_eff)
                        else:
                            val_acc = 0.0
                            val_roc_auc = None
                        val_objective = self._selection_metric_value(
                            val_acc=val_acc,
                            val_roc_auc=val_roc_auc,
                        )
                    eval_stats = AutoAdaptController.collect_eval_stats(
                        outputs=eval_outputs,
                        labels=labels_t,
                        eval_mask=val_mask_eff,
                        pseudo_confidence=self.pseudo_confidence,
                    )
                    autoadapt.step(epoch=epoch, val_acc=val_objective, stats=eval_stats)
                    if val_objective > best_val_objective:
                        best_val_objective = val_objective
                        best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                        epochs_since_improve = 0
                    else:
                        epochs_since_improve += epochs_since_last_eval
                        if epochs_since_improve >= patience:
                            stop_early = True
                    epochs_since_last_eval = 0
                    _sync_device()
                    eval_elapsed = time.perf_counter() - t_eval_start

                peak_mem_tracker = max(peak_mem_tracker, _current_mem())

                if profiler is not None and epoch < self.profile_epochs:
                    profiler.step()

                _sync_device()
                epoch_times.append(time.perf_counter() - start_time)
                forward_times.append(t_forward_end - t_forward_start)
                loss_times.append(t_loss_end - t_loss_start)
                backward_times.append(t_backward_end - t_backward_start)
                eval_times.append(eval_elapsed)
                peak_mem_tracker = max(peak_mem_tracker, _current_mem())
                if stop_early:
                    print(
                        f"[NewHero] early stop at epoch {epoch+1} "
                        f"(metric={selection_metric}, val patience {patience})"
                    )
                    break
        finally:
            if 'progress' in locals() and hasattr(progress, 'close'):
                progress.close()
            if profiler is not None:
                profiler.__exit__(None, None, None)

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            with self._autocast_context():
                final_outputs = model(features_t, edge_index, labels=labels_t, val_mask=val_mask_t,
                                      class_homophily=class_hom, train_mask=train_mask_t)
            gate_stats = torch.nan_to_num(final_outputs.gate_weights.float(), nan=1.0/3.0, posinf=1.0, neginf=0.0)
            final_logits = final_outputs.final_logits.float()
            train_acc = self._accuracy(final_logits, labels_t, train_mask_t)
            val_acc = self._accuracy(final_logits, labels_t, val_mask_t if val_mask_t.any() else train_mask_t)
            test_acc = self._accuracy(final_logits, labels_t, test_mask_t)
            train_roc_auc = self._roc_auc_metric(final_logits, labels_t, train_mask_t)
            val_roc_auc = self._roc_auc_metric(final_logits, labels_t, val_mask_t if val_mask_t.any() else train_mask_t)
            test_roc_auc = self._roc_auc_metric(final_logits, labels_t, test_mask_t)
            val_objective = self._selection_metric_value(
                val_acc=val_acc,
                val_roc_auc=val_roc_auc,
            )
            diagnostics = self._build_diagnostics(
                final_outputs=final_outputs,
                labels=labels_t,
                train_mask=train_mask_t,
                val_mask=val_mask_t,
                test_mask=test_mask_t,
            ) if self.diagnostics else {}
            if test_mask_t.any():
                y_pred = final_logits[test_mask_t].argmax(dim=-1).cpu().tolist()
                y_true = labels_t[test_mask_t].cpu().tolist()
                test_f1 = f1_score(y_true, y_pred, average='macro')
            else:
                y_pred = []
                y_true = []
                test_f1 = 0.0

        peak_mem_tracker = max(peak_mem_tracker, _current_mem())
        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        forward_time_mean = float(np.mean(forward_times)) if forward_times else 0.0
        forward_time_std = float(np.std(forward_times)) if forward_times else 0.0
        loss_time_mean = float(np.mean(loss_times)) if loss_times else 0.0
        loss_time_std = float(np.std(loss_times)) if loss_times else 0.0
        backward_time_mean = float(np.mean(backward_times)) if backward_times else 0.0
        backward_time_std = float(np.std(backward_times)) if backward_times else 0.0
        eval_time_mean = float(np.mean(eval_times)) if eval_times else 0.0
        eval_time_std = float(np.std(eval_times)) if eval_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker
        peak_mem = max(peak_mem, _host_peak_mem())
        profile_path = str(profile_dir_path) if profile_dir_path else None

        metrics = {
            "train_acc": train_acc,
            "val_acc": val_acc,
            "test_acc": test_acc,
            "test_f1": float(test_f1),
            "val_selection_metric": float(val_objective),
            "mean_gate_A": float(gate_stats[:, 0].mean().item()),
            "mean_gate_B": float(gate_stats[:, 1].mean().item()),
            "mean_gate_C": float(gate_stats[:, 2].mean().item()),
            "params": param_count,
            "epoch_time_mean": epoch_time_mean,
            "epoch_time_std": epoch_time_std,
            "stage_forward_time_mean": forward_time_mean,
            "stage_forward_time_std": forward_time_std,
            "stage_loss_time_mean": loss_time_mean,
            "stage_loss_time_std": loss_time_std,
            "stage_backward_time_mean": backward_time_mean,
            "stage_backward_time_std": backward_time_std,
            "stage_eval_time_mean": eval_time_mean,
            "stage_eval_time_std": eval_time_std,
            "throughput_nodes_per_sec": throughput,
            "peak_mem_bytes": peak_mem,
            "autoadapt_enabled": 1.0 if self.autoadapt else 0.0,
            "autoadapt_updates": float(len(autoadapt.events)),
            "policy_pseudo_confidence": float(self.pseudo_confidence),
            "policy_pseudo_weight": float(self.pseudo_weight),
            "policy_smoothing_weight": float(self.smoothing_weight),
            "policy_gate_weight": float(self.gate_weight),
            "policy_gate_prior_mix_uniform": float(self.gate_prior_mix_uniform),
            "policy_lr_final": float(optimizer.param_groups[0]["lr"]),
            "profile_policy_auto": 1.0 if self.profile_policy_auto else 0.0,
        }
        metrics.update(diagnostics.get("metrics", {}))
        if train_roc_auc is not None:
            metrics["train_roc_auc"] = float(train_roc_auc)
        if val_roc_auc is not None:
            metrics["val_roc_auc"] = float(val_roc_auc)
        if test_roc_auc is not None:
            metrics["test_roc_auc"] = float(test_roc_auc)

        return RunResult(
            split=split_idx,
            metrics=metrics,
            extras={
                "y_true": y_true,
                "y_pred": y_pred,
                "profile_trace_dir": profile_path,
                "experts_enabled": sorted(self.enabled_experts),
                "diagnostics": diagnostics.get("extras", {}),
                "autoadapt_profile": dataset_profile,
                "autoadapt_events": [event.__dict__ for event in autoadapt.events],
                "profile_policy_updates": profile_policy_updates,
            },
        )

    @staticmethod
    def _accuracy(logits: Tensor, labels: Tensor, mask: Tensor) -> float:
        if not mask.any():
            return 0.0
        preds = logits[mask].argmax(dim=-1)
        return float((preds == labels[mask]).float().mean().item())

    def _selection_metric_name(self) -> str:
        dataset = str(getattr(self, "current_dataset", "")).lower()
        if dataset in self._ACC_DATASETS:
            return "val_acc"
        return "val_roc_auc"

    def _selection_metric_value(self, *, val_acc: float, val_roc_auc: float | None) -> float:
        if self._selection_metric_name() == "val_acc":
            return float(val_acc)
        if val_roc_auc is None:
            return float(val_acc)
        return float(val_roc_auc)

    def _autocast_context(self):
        if self.autocast_dtype is None:
            return nullcontext()
        return torch.autocast(device_type=self.device.type, dtype=self.autocast_dtype)

    @staticmethod
    def _masked_accuracy_from_logits(logits: Tensor, labels: Tensor, mask: Tensor) -> float:
        if not mask.any():
            return 0.0
        preds = logits[mask].argmax(dim=-1)
        return float((preds == labels[mask]).float().mean().item())

    def _build_diagnostics(
        self,
        *,
        final_outputs: NewHeroOutputs,
        labels: Tensor,
        train_mask: Tensor,
        val_mask: Tensor,
        test_mask: Tensor,
    ) -> Dict[str, Any]:
        expert_logits = {
            "base": final_outputs.base_logits.float(),
            "teacher": final_outputs.teacher_logits.float(),
            "spectral": final_outputs.signed_logits.float(),
        }
        expert_order = ["base", "teacher", "spectral"]
        active_experts = [name for name in expert_order if name in self.enabled_experts]
        gate_weights = torch.nan_to_num(final_outputs.gate_weights.float(), nan=0.0, posinf=1.0, neginf=0.0)
        gate_entropy = -(gate_weights * torch.log(gate_weights.clamp_min(1e-8))).sum(dim=-1)

        pseudo_mask = final_outputs.pseudo_mask.bool()
        unlabeled_mask = ~train_mask
        pseudo_open_mask = pseudo_mask & unlabeled_mask
        base_preds = final_outputs.base_logits.argmax(dim=-1)
        pseudo_val_mask = pseudo_open_mask & val_mask
        pseudo_test_mask = pseudo_open_mask & test_mask

        metrics: Dict[str, float] = {
            "gate_entropy_mean": float(gate_entropy.mean().item()),
            "gate_entropy_std": float(gate_entropy.std().item()),
            "pseudo_coverage_open": float(pseudo_open_mask.float().mean().item()),
            "pseudo_coverage_val": float(pseudo_val_mask.float().mean().item()) if val_mask.any() else 0.0,
            "pseudo_coverage_test": float(pseudo_test_mask.float().mean().item()) if test_mask.any() else 0.0,
            "struct_deg_out_mean": float(final_outputs.struct_stats[:, 0].mean().item()),
            "struct_deg_in_mean": float(final_outputs.struct_stats[:, 1].mean().item()),
            "struct_reciprocity_mean": float(final_outputs.struct_stats[:, 2].mean().item()),
            "struct_degree_ratio_mean": float(final_outputs.struct_stats[:, 3].mean().item()),
        }
        if pseudo_val_mask.any():
            metrics["pseudo_precision_val"] = float((base_preds[pseudo_val_mask] == labels[pseudo_val_mask]).float().mean().item())
        if pseudo_test_mask.any():
            metrics["pseudo_precision_test"] = float((base_preds[pseudo_test_mask] == labels[pseudo_test_mask]).float().mean().item())

        per_expert: Dict[str, Dict[str, float]] = {}
        per_expert_losses = []
        per_expert_correct = []
        for name in active_experts:
            logits = expert_logits[name]
            per_expert[name] = {
                "val_acc": self._masked_accuracy_from_logits(logits, labels, val_mask if val_mask.any() else train_mask),
                "test_acc": self._masked_accuracy_from_logits(logits, labels, test_mask),
            }
            metrics[f"expert_{name}_val_acc"] = per_expert[name]["val_acc"]
            metrics[f"expert_{name}_test_acc"] = per_expert[name]["test_acc"]
            per_expert_losses.append(F.cross_entropy(logits, labels, reduction="none"))
            per_expert_correct.append((logits.argmax(dim=-1) == labels).float())

        if per_expert_losses and per_expert_correct:
            stacked_losses = torch.stack(per_expert_losses, dim=-1)
            best_local_idx = stacked_losses.argmin(dim=-1)
            local_to_global = gate_weights.new_tensor([expert_order.index(name) for name in active_experts], dtype=torch.long)
            best_idx = local_to_global[best_local_idx]
            gate_choice = gate_weights.argmax(dim=-1)
            stacked_correct = torch.stack(per_expert_correct, dim=-1)
            val_eff_mask = val_mask if val_mask.any() else train_mask
            if val_eff_mask.any():
                metrics["router_match_best_val"] = float((gate_choice[val_eff_mask] == best_idx[val_eff_mask]).float().mean().item())
                oracle_val_correct = stacked_correct[val_eff_mask].max(dim=-1).values.mean().item()
                metrics["oracle_val_acc"] = float(oracle_val_correct)
            if test_mask.any():
                metrics["router_match_best_test"] = float((gate_choice[test_mask] == best_idx[test_mask]).float().mean().item())
                oracle_test_correct = stacked_correct[test_mask].max(dim=-1).values.mean().item()
                metrics["oracle_test_acc"] = float(oracle_test_correct)

        extras: Dict[str, Any] = {
            "loss_toggles": {
                "use_edge_loss": self.use_edge_loss,
                "use_pseudo_loss": self.use_pseudo_loss,
                "use_signed_consistency": self.use_signed_consistency,
                "use_value_loss": self.use_value_loss,
                "use_gate_prior_loss": self.use_gate_prior_loss,
            },
            "gate_entropy": {
                "mean": metrics["gate_entropy_mean"],
                "std": metrics["gate_entropy_std"],
            },
            "pseudo_labeling": {
                "open_coverage": metrics["pseudo_coverage_open"],
                "val_coverage": metrics["pseudo_coverage_val"],
                "test_coverage": metrics["pseudo_coverage_test"],
                "val_precision": metrics.get("pseudo_precision_val"),
                "test_precision": metrics.get("pseudo_precision_test"),
            },
            "per_expert": per_expert,
            "structural_stats": {
                "deg_out_mean": metrics["struct_deg_out_mean"],
                "deg_in_mean": metrics["struct_deg_in_mean"],
                "reciprocity_mean": metrics["struct_reciprocity_mean"],
                "degree_ratio_mean": metrics["struct_degree_ratio_mean"],
            },
        }
        return {"metrics": metrics, "extras": extras}

    def export_config(self) -> Dict[str, Any]:
        return {
            "hidden_dim": self.hidden_dim,
            "prototype_count": self.prototype_count,
            "ppr_alpha": self.ppr_alpha,
            "ppr_steps": self.ppr_steps,
            "dropout": self.dropout,
            "epochs": self.epochs,
            "lr": self.lr,
            "weight_decay": self.weight_decay,
            "edge_weight": self.edge_weight,
            "pseudo_weight": self.pseudo_weight,
            "smoothing_weight": self.smoothing_weight,
            "experts_weight": self.experts_weight,
            "gate_weight": self.gate_weight,
            "gate_entropy_weight": self.gate_entropy_weight,
            "gate_routing_weight": self.gate_routing_weight,
            "expert_aux_weight": self.expert_aux_weight,
            "value_weight": self.value_weight,
            "gate_prior_weight": self.gate_prior_weight,
            "ema_decay": self.ema_decay,
            "pseudo_confidence": self.pseudo_confidence,
            "base_gate_weight": self.base_gate_weight,
            "edge_neg_sample_ratio": self.neg_sample_ratio,
            "edge_sample_ratio": self.edge_sample_ratio,
            "eval_interval": self.eval_interval,
            "val_patience": self.val_patience,
            "twohop_max_neighbors": self.twohop_max_neighbors,
            "warmup_steps": self.warmup_steps,
            "ramp_steps": self.ramp_steps,
            "q_min": self.q_min,
            "q_max": self.q_max,
            "tau_hi": self.tau_hi,
            "tau_lo": self.tau_lo,
            "entropy_mu_lr": self.entropy_mu_lr,
            "entropy_target_delta": self.entropy_target_delta,
            "proxy_ema_decay": self.proxy_ema_decay,
            "knn_k": self.knn_k,
            "knn_exact_max": self.knn_exact_max,
            "faiss_hnsw_m": self.faiss_hnsw_m,
            "faiss_ef_search": self.faiss_ef_search,
            "faiss_ef_construction": self.faiss_ef_construction,
            "compat_slope": self.compat_slope,
            "ripple_time_horizon": self.ripple_time_horizon,
            "ripple_dt": self.ripple_dt,
            "ripple_init_residual": self.ripple_init_residual,
            "use_features": self.use_features,
            "gwn_time_horizon": self.gwn_time_horizon,
            "gwn_dt": self.gwn_dt,
            "gwn_dropout": self.gwn_dropout,
            "gwn_laplacian": self.gwn_laplacian,
            "gwn_method": self.gwn_method,
            "gwn_init_residual": self.gwn_init_residual,
            "force_expert": self.force_expert,
            "acm_hidden_dim": self.acm_hidden_dim,
            "acm_dropout": self.acm_dropout,
            "acm_structure_info": self.acm_structure_info,
            "acm_variant": self.acm_variant,
            "acm_init_layers_feat": self.acm_init_layers_feat,
            "auto_experts": bool(self.auto_experts),
            "enabled_experts": sorted(self.enabled_experts),
            "use_edge_loss": self.use_edge_loss,
            "use_pseudo_loss": self.use_pseudo_loss,
            "use_signed_consistency": self.use_signed_consistency,
            "use_value_loss": self.use_value_loss,
            "use_gate_prior_loss": self.use_gate_prior_loss,
            "diagnostics": self.diagnostics,
            "gate_prior_mix_uniform": self.gate_prior_mix_uniform,
            "autoadapt": self.autoadapt,
            "autoadapt_check_every": self.autoadapt_check_every,
            "autoadapt_warmup_epochs": self.autoadapt_warmup_epochs,
            "autoadapt_stagnation_patience": self.autoadapt_stagnation_patience,
            "autoadapt_rollback": self.autoadapt_rollback,
            "autoadapt_rollback_patience": self.autoadapt_rollback_patience,
            "autoadapt_rollback_tolerance": self.autoadapt_rollback_tolerance,
            "autoadapt_min_lr": self.autoadapt_min_lr,
            "autoadapt_max_lr": self.autoadapt_max_lr,
            "autoadapt_min_pseudo_confidence": self.autoadapt_min_pseudo_confidence,
            "autoadapt_max_pseudo_confidence": self.autoadapt_max_pseudo_confidence,
            "autoadapt_min_pseudo_weight": self.autoadapt_min_pseudo_weight,
            "autoadapt_max_pseudo_weight": self.autoadapt_max_pseudo_weight,
            "autoadapt_min_smoothing_weight": self.autoadapt_min_smoothing_weight,
            "autoadapt_max_smoothing_weight": self.autoadapt_max_smoothing_weight,
            "autoadapt_max_gate_weight": self.autoadapt_max_gate_weight,
            "autoadapt_max_gate_prior_mix": self.autoadapt_max_gate_prior_mix,
            "autoadapt_profile_init": self.autoadapt_profile_init,
            "autoadapt_allow_lr_updates": self.autoadapt_allow_lr_updates,
            "autoadapt_allow_smoothing_updates": self.autoadapt_allow_smoothing_updates,
            "autoadapt_acceptance_margin": self.autoadapt_acceptance_margin,
            "profile_policy_auto": self.profile_policy_auto,
            "device": self.device.type,
        }


__all__ = ["NewHeroModule"]
