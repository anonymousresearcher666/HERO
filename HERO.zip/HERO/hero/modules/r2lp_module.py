"""R2LP baseline module (iterative label propagation with graph reconstruction)."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score
from sklearn.neighbors import NearestNeighbors
from torch import Tensor
from torch_geometric.utils import scatter

from .base import HeterophilyModule, RunResult


def _edge_index(adj: np.ndarray | Tensor) -> Tensor:
    if isinstance(adj, Tensor):
        if adj.dim() == 2 and adj.size(0) == 2:
            return adj.long()
        idx = torch.nonzero(adj, as_tuple=False).t()
        return idx.long()
    if adj.ndim == 2 and adj.shape[0] == 2:
        return torch.from_numpy(adj).long()
    row, col = np.nonzero(adj)
    return torch.from_numpy(np.stack([row, col], axis=0)).long()


def _propagate(F: Tensor, edge_index: Tensor, num_nodes: int) -> Tensor:
    if edge_index.numel() == 0:
        return F
    src, dst = edge_index
    deg = scatter(torch.ones_like(src, dtype=F.dtype), src, dim=0, dim_size=num_nodes, reduce="sum")
    norm = 1.0 / deg.clamp_min(1.0)
    messages = F[src] * norm[src].unsqueeze(-1)
    out = scatter(messages, dst, dim=0, dim_size=num_nodes, reduce="sum")
    return out


@dataclass
class R2LPConfig:
    steps: int = 20
    alpha: float = 0.9
    rounds: int = 3
    conf_thr: float = 0.8
    knn_k: int = 10


class R2LPModule(HeterophilyModule):
    name = "r2lp"

    def __init__(
        self,
        results_root: str | None = None,
        steps: int = 20,
        alpha: float = 0.9,
        rounds: int = 3,
        conf_thr: float = 0.8,
        knn_k: int = 10,
    ) -> None:
        super().__init__(results_root)
        self.cfg = R2LPConfig(
            steps=steps,
            alpha=alpha,
            rounds=rounds,
            conf_thr=conf_thr,
            knn_k=knn_k,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = _edge_index(adj)
        return {"edge_index": edge_index}

    def _build_knn(self, X: np.ndarray, k: int) -> np.ndarray:
        if k <= 0:
            return np.zeros((2, 0), dtype=np.int64)
        nn = NearestNeighbors(n_neighbors=min(k + 1, X.shape[0]), metric="cosine")
        nn.fit(X)
        _, idx = nn.kneighbors(X)
        # drop self at col 0
        neighbors = idx[:, 1:]
        src = np.repeat(np.arange(X.shape[0]), neighbors.shape[1])
        dst = neighbors.reshape(-1)
        return np.stack([src, dst], axis=0).astype(np.int64)

    def _reconstruct_edges(self, knn_edges: np.ndarray, pseudo: np.ndarray) -> np.ndarray:
        if knn_edges.size == 0:
            return knn_edges
        src = knn_edges[0]
        dst = knn_edges[1]
        same = (pseudo[src] == pseudo[dst]) & (pseudo[src] >= 0)
        return knn_edges[:, same]

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        n = labels.shape[0]
        C = int(labels.max()) + 1
        edge_index = context["edge_index"].long()

        X = features.astype(np.float32)
        X_norm = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-8)
        knn_edges = self._build_knn(X_norm, self.cfg.knn_k)

        edge_index_np = edge_index.cpu().numpy()

        pseudo = -np.ones(n, dtype=np.int64)
        pseudo[train_mask] = labels[train_mask]

        for _ in range(self.cfg.rounds):
            # Build label matrix
            Y = np.zeros((n, C), dtype=np.float32)
            Y[pseudo >= 0, pseudo[pseudo >= 0]] = 1.0
            F = torch.tensor(Y, dtype=torch.float32)
            # LP on current graph
            for _ in range(self.cfg.steps):
                F = self.cfg.alpha * _propagate(F, edge_index, n) + (1.0 - self.cfg.alpha) * torch.tensor(Y)
            probs = F.softmax(dim=-1).detach().cpu().numpy()
            conf = probs.max(axis=1)
            pred = probs.argmax(axis=1)
            pseudo = np.where(conf >= self.cfg.conf_thr, pred, pseudo)
            pseudo[train_mask] = labels[train_mask]
            # Reconstruct edges based on pseudo labels
            new_edges = self._reconstruct_edges(knn_edges, pseudo)
            if new_edges.size > 0:
                combined = np.concatenate([edge_index_np, new_edges], axis=1)
                combined = np.unique(combined, axis=1)
                edge_index = torch.from_numpy(combined).long()
                edge_index_np = combined

        # Final LP on reconstructed graph
        Y = np.zeros((n, C), dtype=np.float32)
        Y[train_mask, labels[train_mask]] = 1.0
        F = torch.tensor(Y, dtype=torch.float32)
        for _ in range(self.cfg.steps):
            F = self.cfg.alpha * _propagate(F, edge_index, n) + (1.0 - self.cfg.alpha) * torch.tensor(Y)
        logits = F
        preds = logits.argmax(dim=-1).cpu().numpy()

        test_idx = np.where(test_mask)[0]
        y_true = labels[test_idx]
        y_pred = preds[test_idx]
        acc = float((y_true == y_pred).mean()) if test_idx.size else 0.0
        test_f1 = f1_score(y_true, y_pred, average="macro") if test_idx.size else 0.0

        metrics = {
            "test_acc": acc,
            "test_f1": float(test_f1),
        }

        # Use ROC-AUC where appropriate
        logits_t = torch.tensor(logits, dtype=torch.float32)
        labels_t = torch.tensor(labels, dtype=torch.long)
        test_mask_t = torch.tensor(test_mask.astype(bool))
        roc_auc = self._roc_auc_metric(logits_t, labels_t, test_mask_t)
        if roc_auc is not None:
            metrics["test_roc_auc"] = roc_auc

        return RunResult(
            split=split_idx,
            metrics=metrics,
            extras={"y_true": y_true.tolist(), "y_pred": y_pred.tolist()},
        )
