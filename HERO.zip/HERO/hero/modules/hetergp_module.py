"""Multi-view prompting baseline module (HeterGP-style approximation)."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score
from torch import Tensor
from torch_geometric.utils import scatter

from .base import HeterophilyModule, RunResult


def _edge_index(adj: np.ndarray | Tensor) -> Tensor:
    if isinstance(adj, Tensor):
        if adj.dim() == 2 and adj.size(0) == 2:
            return adj.long()
        idx = torch.nonzero(adj, as_tuple=False).t()
        return idx.long()
    if adj.ndim == 2 and adj.shape[0] == 2:
        return torch.from_numpy(adj).long()
    row, col = np.nonzero(adj)
    return torch.from_numpy(np.stack([row, col], axis=0)).long()


def _propagate(x: Tensor, edge_index: Tensor, num_nodes: int) -> Tensor:
    if edge_index.numel() == 0:
        return x
    src, dst = edge_index
    deg = scatter(torch.ones_like(src, dtype=x.dtype), src, dim=0, dim_size=num_nodes, reduce="sum")
    norm = 1.0 / deg.clamp_min(1.0)
    messages = x[src] * norm[src].unsqueeze(-1)
    out = scatter(messages, dst, dim=0, dim_size=num_nodes, reduce="sum")
    return out


def _build_prompt_edges(
    node_feats: Tensor,
    prompt_feats: Tensor,
    *,
    tintra: float,
    tinter: float,
) -> Tensor:
    n = node_feats.size(0)
    k = prompt_feats.size(0)
    if k == 0:
        return node_feats.new_zeros((2, 0), dtype=torch.long)
    # Normalize for cosine similarity
    node_norm = F.normalize(node_feats, dim=-1)
    prompt_norm = F.normalize(prompt_feats, dim=-1)
    # Intra-prompt edges
    sim_pp = prompt_norm @ prompt_norm.t()
    mask_pp = sim_pp > tintra if tintra >= 0 else sim_pp < abs(tintra)
    idx_pp = mask_pp.nonzero(as_tuple=False)
    if idx_pp.numel():
        src_pp = idx_pp[:, 0]
        dst_pp = idx_pp[:, 1]
        prompt_offset = n
        edge_pp = torch.stack([src_pp + prompt_offset, dst_pp + prompt_offset], dim=0)
    else:
        edge_pp = node_feats.new_zeros((2, 0), dtype=torch.long)
    # Inter edges between prompts and nodes
    sim_pn = prompt_norm @ node_norm.t()
    mask_pn = sim_pn > tinter if tinter >= 0 else sim_pn < abs(tinter)
    idx_pn = mask_pn.nonzero(as_tuple=False)
    if idx_pn.numel():
        src = idx_pn[:, 0] + n
        dst = idx_pn[:, 1]
        edge_pn = torch.stack([src, dst], dim=0)
        edge_np = torch.stack([dst, src], dim=0)
        edge_pn = torch.cat([edge_pn, edge_np], dim=1)
    else:
        edge_pn = node_feats.new_zeros((2, 0), dtype=torch.long)
    return torch.cat([edge_pp, edge_pn], dim=1)


class HeterGPModel(nn.Module):
    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        num_classes: int,
        dropout: float,
        num_prompts: int,
        tintra_homo: float,
        tintra_heter: float,
        tinter_homo: float,
        tinter_heter: float,
    ) -> None:
        super().__init__()
        self.prompt_homo = nn.Parameter(torch.zeros(num_prompts, in_dim))
        self.prompt_heter = nn.Parameter(torch.zeros(num_prompts, in_dim))
        self.lin_h1 = nn.Linear(in_dim, hidden_dim)
        self.lin_h2 = nn.Linear(hidden_dim, num_classes)
        self.lin_t1 = nn.Linear(in_dim, hidden_dim)
        self.lin_t2 = nn.Linear(hidden_dim, num_classes)
        self.fuse = nn.Linear(num_classes * 2, num_classes)
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.dropout = float(dropout)
        self.tintra_homo = float(tintra_homo)
        self.tintra_heter = float(tintra_heter)
        self.tinter_homo = float(tinter_homo)
        self.tinter_heter = float(tinter_heter)

    def _gcn(self, x: Tensor, edge_index: Tensor, lin1: nn.Linear, lin2: nn.Linear) -> Tensor:
        num_nodes = x.size(0)
        h = F.dropout(x, p=self.dropout, training=self.training)
        h = F.relu(lin1(h))
        h = _propagate(h, edge_index, num_nodes)
        h = F.dropout(h, p=self.dropout, training=self.training)
        out = lin2(h)
        return out

    def forward(self, x: Tensor, edge_homo: Tensor, edge_heter: Tensor) -> Tensor:
        n = x.size(0)
        # Homo view with prompt graph
        xh = torch.cat([x, self.prompt_homo], dim=0)
        prompt_edges_h = _build_prompt_edges(
            x, self.prompt_homo, tintra=self.tintra_homo, tinter=self.tinter_homo
        ).to(edge_homo.device)
        edge_h = torch.cat([edge_homo, prompt_edges_h], dim=1) if prompt_edges_h.numel() else edge_homo
        logits_h = self._gcn(xh, edge_h, self.lin_h1, self.lin_h2)[:n]
        # Heter view with prompt graph
        xt = torch.cat([x, self.prompt_heter], dim=0)
        prompt_edges_t = _build_prompt_edges(
            x, self.prompt_heter, tintra=-abs(self.tintra_heter), tinter=-abs(self.tinter_heter)
        ).to(edge_heter.device)
        edge_t = torch.cat([edge_heter, prompt_edges_t], dim=1) if prompt_edges_t.numel() else edge_heter
        logits_t = self._gcn(xt, edge_t, self.lin_t1, self.lin_t2)[:n]
        alpha = torch.sigmoid(self.alpha)
        fused = torch.cat([logits_h, logits_t], dim=-1)
        return alpha * self.fuse(fused) + (1.0 - alpha) * logits_h


@dataclass
class HeterGPConfig:
    hidden_dim: int = 64
    dropout: float = 0.5
    epochs: int = 300
    patience: int = 50
    lr: float = 0.01
    weight_decay: float = 5e-4
    num_prompts: int = 8
    walk_length: int = 8
    walk_count: int = 5
    p_dfs: float = 2.0
    q_dfs: float = 0.5
    tintra_homo: float = 0.2
    tintra_heter: float = 0.2
    tinter_homo: float = 0.2
    tinter_heter: float = 0.2


class HeterGPModule(HeterophilyModule):
    name = "hetergp"

    def __init__(
        self,
        results_root: str | None = None,
        hidden_dim: int = 64,
        dropout: float = 0.5,
        epochs: int = 300,
        patience: int = 50,
        lr: float = 0.01,
        weight_decay: float = 5e-4,
        num_prompts: int = 8,
        walk_length: int = 8,
        walk_count: int = 5,
        p_dfs: float = 2.0,
        q_dfs: float = 0.5,
        tintra_homo: float = 0.2,
        tintra_heter: float = 0.2,
        tinter_homo: float = 0.2,
        tinter_heter: float = 0.2,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)
        self.cfg = HeterGPConfig(
            hidden_dim=hidden_dim,
            dropout=dropout,
            epochs=epochs,
            patience=patience,
            lr=lr,
            weight_decay=weight_decay,
            num_prompts=num_prompts,
            walk_length=walk_length,
            walk_count=walk_count,
            p_dfs=p_dfs,
            q_dfs=q_dfs,
            tintra_homo=tintra_homo,
            tintra_heter=tintra_heter,
            tinter_homo=tinter_homo,
            tinter_heter=tinter_heter,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = _edge_index(adj)
        edge_index_dfs = self._build_dfs_edges(edge_index, features.shape[0])
        return {"edge_homo": edge_index, "edge_heter": edge_index_dfs}

    def _build_dfs_edges(self, edge_index: Tensor, num_nodes: int) -> Tensor:
        if edge_index.numel() == 0:
            return edge_index
        src, dst = edge_index.cpu().numpy()
        adj = [[] for _ in range(num_nodes)]
        for u, v in zip(src, dst):
            adj[u].append(v)
        rng = np.random.default_rng(0)
        edges = []
        for v in range(num_nodes):
            for _ in range(self.cfg.walk_count):
                walk = [v]
                prev = -1
                for _ in range(self.cfg.walk_length - 1):
                    cur = walk[-1]
                    neigh = adj[cur]
                    if not neigh:
                        break
                    if prev < 0:
                        nxt = neigh[int(rng.integers(0, len(neigh)))]
                    else:
                        probs = []
                        for nb in neigh:
                            if nb == prev:
                                probs.append(1.0 / max(1e-6, self.cfg.p_dfs))
                            elif prev in adj[nb]:
                                probs.append(1.0)
                            else:
                                probs.append(1.0 / max(1e-6, self.cfg.q_dfs))
                        probs = np.asarray(probs, dtype=np.float64)
                        probs = probs / probs.sum()
                        nxt = rng.choice(neigh, p=probs)
                    edges.append((cur, nxt))
                    prev = cur
                    walk.append(nxt)
        if not edges:
            return edge_index
        edges = np.unique(np.array(edges, dtype=np.int64), axis=0)
        return torch.from_numpy(edges.T).long()

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        x = torch.tensor(features, dtype=torch.float32, device=self.device)
        y = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask.astype(bool), device=self.device)
        val_mask_t = torch.tensor(val_mask.astype(bool), device=self.device) if val_mask is not None else train_mask_t
        if not val_mask_t.any():
            val_mask_t = train_mask_t
        test_mask_t = torch.tensor(test_mask.astype(bool), device=self.device)

        num_nodes, in_dim = x.shape
        num_classes = int(y.max().item()) + 1 if y.numel() else 0

        edge_homo = context["edge_homo"].to(self.device)
        edge_heter = context["edge_heter"].to(self.device)
        model = HeterGPModel(
            in_dim,
            self.cfg.hidden_dim,
            num_classes,
            self.cfg.dropout,
            self.cfg.num_prompts,
            self.cfg.tintra_homo,
            self.cfg.tintra_heter,
            self.cfg.tinter_homo,
            self.cfg.tinter_heter,
        ).to(self.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay)

        param_count = int(sum(p.numel() for p in model.parameters()))
        train_nodes = float(train_mask_t.sum().item())
        epoch_times: list[float] = []
        best_state = None
        best_val = -1.0
        patience_ctr = 0

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)
        peak_mem_tracker = _current_mem()

        for epoch in range(self.cfg.epochs):
            start = time.perf_counter()
            model.train()
            optimizer.zero_grad()
            logits = model(x, edge_homo, edge_heter)
            loss = F.cross_entropy(logits[train_mask_t], y[train_mask_t])
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                logits = model(x, edge_homo, edge_heter)
                val_logits = logits[val_mask_t]
                val_acc = (val_logits.argmax(dim=-1) == y[val_mask_t]).float().mean().item()

            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1
                if patience_ctr >= self.cfg.patience:
                    if self.device.type == "cuda":
                        torch.cuda.synchronize(self.device)
                    epoch_times.append(time.perf_counter() - start)
                    peak_mem_tracker = max(peak_mem_tracker, _current_mem())
                    break

            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
            epoch_times.append(time.perf_counter() - start)
            peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            logits = model(x, edge_homo, edge_heter)
            train_acc = (logits[train_mask_t].argmax(dim=-1) == y[train_mask_t]).float().mean().item()
            val_acc = (logits[val_mask_t].argmax(dim=-1) == y[val_mask_t]).float().mean().item()
            test_logits = logits[test_mask_t]
            test_pred = test_logits.argmax(dim=-1)
            test_acc = (test_pred == y[test_mask_t]).float().mean().item()
            if test_mask_t.any():
                test_f1 = f1_score(y[test_mask_t].cpu().numpy(), test_pred.cpu().numpy(), average="macro")
            else:
                test_f1 = 0.0
            roc_auc = self._roc_auc_metric(logits, y, test_mask_t)
        peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker

        metrics = {
            "train_acc": float(train_acc),
            "val_acc": float(val_acc),
            "test_acc": float(test_acc),
            "test_f1": float(test_f1),
            "params": float(param_count),
            "epoch_time_mean": float(epoch_time_mean),
            "epoch_time_std": float(epoch_time_std),
            "throughput_nodes_per_sec": float(throughput),
            "peak_mem_bytes": float(peak_mem),
        }
        if roc_auc is not None:
            metrics["test_roc_auc"] = roc_auc

        test_idx = np.where(test_mask)[0]
        y_true = [int(labels[i]) for i in test_idx]
        y_pred = test_pred.cpu().tolist()
        return RunResult(split=split_idx, metrics=metrics, extras={"y_true": y_true, "y_pred": y_pred})
