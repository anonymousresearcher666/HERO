"""UniFilter baseline module integrated with the HERO pipeline."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score
from torch import Tensor
import resource
import sys

from legacy.unifilter.models import GFK
from legacy.unifilter.utils import edgeindex_construct, load_dataset

from .base import HeterophilyModule, RunResult


@dataclass
class UniFilterConfig:
    hidden_dim: int = 64
    num_layers: int = 2
    mlp_dropout: float = 0.5
    comb_dropout: float = 0.5
    mlp_lr: float = 0.01
    comb_lr: float = 0.01
    mlp_weight_decay: float = 5e-4
    comb_weight_decay: float = 5e-4
    epochs: int = 1000
    patience: int = 100
    K: int = 10
    tau: float = 0.5
    sole: bool = True
    plain: bool = False
    bias: str = "none"


class UniFilterModule(HeterophilyModule):
    name = "unifilter"

    def __init__(
        self,
        results_root: str | None = None,
        hidden_dim: int = 64,
        num_layers: int = 2,
        mlp_dropout: float = 0.5,
        comb_dropout: float = 0.5,
        mlp_lr: float = 0.01,
        comb_lr: float = 0.01,
        mlp_weight_decay: float = 5e-4,
        comb_weight_decay: float = 5e-4,
        epochs: int = 1000,
        patience: int = 100,
        K: int = 10,
        tau: float = 0.5,
        sole: bool = True,
        plain: bool = False,
        bias: str = "none",
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)
        self.cfg = UniFilterConfig(
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            mlp_dropout=mlp_dropout,
            comb_dropout=comb_dropout,
            mlp_lr=mlp_lr,
            comb_lr=comb_lr,
            mlp_weight_decay=mlp_weight_decay,
            comb_weight_decay=comb_weight_decay,
            epochs=epochs,
            patience=patience,
            K=K,
            tau=tau,
            sole=sole,
            plain=plain,
            bias=bias,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = torch.from_numpy(adj).long() if isinstance(adj, np.ndarray) and adj.ndim == 2 and adj.shape[0] == 2 else None
        if edge_index is None:
            if isinstance(adj, np.ndarray):
                row, col = np.nonzero(adj)
                edge_index = torch.from_numpy(np.stack([row, col], axis=0)).long()
            else:
                tensor_adj = torch.as_tensor(adj)
                if tensor_adj.dim() == 2 and tensor_adj.size(0) == 2:
                    edge_index = tensor_adj.long()
                else:
                    edge_index = torch.nonzero(tensor_adj, as_tuple=False).t().long()
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        train_mask_t = torch.tensor(train_mask.astype(bool))
        if val_mask is None:
            val_mask_t = train_mask_t
        else:
            val_mask_t = torch.tensor(val_mask.astype(bool))
            if not val_mask_t.any():
                val_mask_t = train_mask_t
        test_mask_t = torch.tensor(test_mask.astype(bool))

        features_t = torch.tensor(features, dtype=torch.float32)
        labels_t = torch.tensor(labels, dtype=torch.long)

        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() else 0

        edge_index = context["edge_index"].numpy()
        lp, _, _ = edgeindex_construct(edge_index, num_nodes)

        feat_aug, base_dim = load_dataset(
            lp.cpu(), features_t, K=self.cfg.K, tau=self.cfg.tau, homo_ratio=0.6, plain=self.cfg.plain
        )
        if not self.cfg.plain:
            feat_aug = feat_aug.view(num_nodes, self.cfg.K + 1, base_dim)
        else:
            feat_aug = feat_aug.view(num_nodes, self.cfg.K + 1, base_dim)

        feat_aug = feat_aug.to(self.device)
        labels_t = labels_t.to(self.device)
        train_mask_t = train_mask_t.to(self.device)
        val_mask_t = val_mask_t.to(self.device)
        test_mask_t = test_mask_t.to(self.device)

        model = GFK(
            level=self.cfg.K,
            in_dim=base_dim,
            num_layers=self.cfg.num_layers,
            hidden_dim=self.cfg.hidden_dim,
            out_dim=num_classes,
            dropout_comb=self.cfg.comb_dropout,
            dropout_mlp=self.cfg.mlp_dropout,
            bias=self.cfg.bias,
            sole=self.cfg.sole,
        ).to(self.device)

        optimizer = torch.optim.Adam(
            [
                {
                    "params": model.mlp.parameters(),
                    "lr": self.cfg.mlp_lr,
                    "weight_decay": self.cfg.mlp_weight_decay,
                },
                {
                    "params": model.comb.parameters(),
                    "lr": self.cfg.comb_lr,
                    "weight_decay": self.cfg.comb_weight_decay,
                },
            ]
        )

        criterion = nn.CrossEntropyLoss().to(self.device)

        param_count = int(sum(p.numel() for p in model.parameters()))
        train_nodes = float(train_mask_t.sum().item())
        epoch_times: list[float] = []

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        def _host_peak_mem() -> float:
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform != "darwin":
                peak *= 1024
            return float(peak)

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)

        best_state = None
        best_val = -1.0
        patience_ctr = 0
        peak_mem_tracker = _current_mem()

        for epoch in range(self.cfg.epochs):
            start = time.perf_counter()
            model.train()
            optimizer.zero_grad()
            logits = model(feat_aug)
            loss = criterion(logits[train_mask_t], labels_t[train_mask_t])
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                logits = model(feat_aug)
                val_logits = logits[val_mask_t]
                val_acc = (val_logits.argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()

            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1
                if patience_ctr >= self.cfg.patience:
                    if self.device.type == "cuda":
                        torch.cuda.synchronize(self.device)
                    epoch_times.append(time.perf_counter() - start)
                    break

                if self.device.type == "cuda":
                    torch.cuda.synchronize(self.device)
                epoch_times.append(time.perf_counter() - start)
                peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            logits = model(feat_aug)
            train_acc = (logits[train_mask_t].argmax(dim=-1) == labels_t[train_mask_t]).float().mean().item()
            val_acc = (logits[val_mask_t].argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()
            test_logits = logits[test_mask_t]
            test_pred = test_logits.argmax(dim=-1)
            test_acc = (test_pred == labels_t[test_mask_t]).float().mean().item()
            if test_mask_t.any():
                test_f1 = f1_score(labels_t[test_mask_t].cpu().numpy(), test_pred.cpu().numpy(), average="macro")
            else:
                test_f1 = 0.0
            roc_auc = self._roc_auc_metric(logits, labels_t, test_mask_t)

        peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker
        peak_mem = max(peak_mem, _host_peak_mem())

        metrics = {
            "train_acc": float(train_acc),
            "val_acc": float(val_acc),
            "test_acc": float(test_acc),
            "test_f1": float(test_f1),
            "params": param_count,
            "epoch_time_mean": epoch_time_mean,
            "epoch_time_std": epoch_time_std,
            "throughput_nodes_per_sec": throughput,
            "peak_mem_bytes": peak_mem,
        }
        if roc_auc is not None:
            metrics["test_roc_auc"] = roc_auc

        return RunResult(
            split=split_idx,
            metrics=metrics,
            extras={
                "y_true": labels_t[test_mask_t].cpu().tolist(),
                "y_pred": test_pred.cpu().tolist(),
            },
        )
