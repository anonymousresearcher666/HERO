"""Profile-based pseudo-labeling module.

Trains an unsupervised request-profile model, selects high-confidence pseudo-labels
on non-train/non-test nodes, retrains in semi-supervised mode, and evaluates.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import log_loss, precision_score

from hero.core import ExperimentConfig, ProfileModel, ProfileTrainer, ProfileClassifier, DEVICE
from .base import HeterophilyModule, RunResult


def _row_norm(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


def knn_probs(emb_test: np.ndarray, emb_train: np.ndarray, y_train: np.ndarray, k: int):
    n_test = emb_test.shape[0]
    preds = np.zeros(n_test, dtype=np.int64)
    conf = np.zeros(n_test, dtype=np.float32)
    S = emb_test @ emb_train.T
    kk = min(k, S.shape[1])
    idx = np.argpartition(-S, kth=kk - 1, axis=1)[:, :kk]
    for i in range(idx.shape[0]):
        neigh = idx[i]
        w = S[i, neigh]
        w = np.maximum(w, 0)
        if w.sum() == 0:
            w = np.ones_like(w)
        w /= (w.sum() + 1e-8)
        labs = y_train[neigh]
        classes, inv = np.unique(labs, return_inverse=True)
        probs = np.zeros(len(classes), dtype=np.float32)
        for j, cidx in enumerate(inv):
            probs[cidx] += w[j]
        preds[i] = int(classes[probs.argmax()])
        conf[i] = float(probs.max())
    return preds, conf


class ProfilePseudoLabelModule(HeterophilyModule):
    name = 'profile_pseudolabel'

    def __init__(self, results_root: str = 'results', profile_dim: int = 128,
                 conf_thr: float = 0.6, per_class_cap: float = 0.10, global_cap: float = 0.2,
                 agreement: bool = False, agree_conf_thr: float = 0.6, pl_rounds: int = 1,
                 semi_label_weight: float = 0.15, semi_contrastive_weight: float = 0.5,
                 unsup_epochs: int | None = None, semi_epochs: int | None = None):
        super().__init__(results_root)
        self.profile_dim = profile_dim
        self.conf_thr = conf_thr
        self.per_class_cap = per_class_cap
        self.global_cap = global_cap
        # Enhancements
        self.agreement = agreement
        self.agree_conf_thr = agree_conf_thr
        self.pl_rounds = max(1, int(pl_rounds))
        self.semi_label_weight = float(semi_label_weight)
        self.semi_contrastive_weight = float(semi_contrastive_weight)
        self.unsup_epochs = unsup_epochs
        self.semi_epochs = semi_epochs

    def _config_unsup(self) -> ExperimentConfig:
        return ExperimentConfig(
            datasets=['custom'], profile_dim=self.profile_dim, learning_rate=0.005,
            epochs=int(self.unsup_epochs) if self.unsup_epochs is not None else 40,
            early_stopping_patience=10, structure_weight=0.0, label_weight=0.0, contrastive_weight=1.0,
            unsupervised=True, temperature=0.1, strategy='contrastive_proto', proto_weight=0.1,
            feature_dropout=0.3, edge_dropout=0.3, k_neighbors=25, embedding_type='projected',
            use_weighted_voting=True, test_runs=1, save_results=False)

    def _config_semi(self, k: int) -> ExperimentConfig:
        return ExperimentConfig(
            datasets=['custom'], profile_dim=self.profile_dim, learning_rate=0.003,
            epochs=int(self.semi_epochs) if self.semi_epochs is not None else 30,
            early_stopping_patience=8, structure_weight=0.0,
            label_weight=self.semi_label_weight, contrastive_weight=self.semi_contrastive_weight,
            unsupervised=False, temperature=0.1, strategy='contrastive_proto', proto_weight=0.1,
            feature_dropout=0.3, edge_dropout=0.3, k_neighbors=k, embedding_type='projected',
            use_weighted_voting=True, test_runs=1, save_results=False)

    def run_split(self, features, adj, labels, masks, split_idx, context):
        tm = masks['train_mask'][:, split_idx] if masks['train_mask'].ndim == 2 else masks['train_mask']
        sm = masks['test_mask'][:, split_idx] if masks['test_mask'].ndim == 2 else masks['test_mask']
        n_nodes, n_features = features.shape
        # Unsupervised training
        cfg_u = self._config_unsup()
        model = ProfileModel(n_nodes, n_features, cfg_u.profile_dim, DEVICE)
        ProfileTrainer(model, cfg_u).train(features, adj, labels, tm)
        # Embedding
        with torch.no_grad():
            ft = torch.tensor(features, dtype=torch.float32, device=model.device)
            proj = model.proj_head(model.feature_projection(ft))
            proj = F.normalize(proj, dim=1, eps=1e-8).cpu().numpy()
        train_idx = np.where(tm)[0]
        y_train = labels[train_idx]
        E_train = _row_norm(proj[train_idx])
        # Calibration for LR head on embedding
        def fit_calibrated_lr(E, y, seed=42):
            skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
            # Single split (first fold) for speed: train 4/5, val 1/5
            for tr, va in skf.split(E, y):
                break
            lr = LogisticRegression(max_iter=1000, multi_class='auto', n_jobs=1)
            lr.fit(E[tr], y[tr])
            # Temperature scaling by grid search on decision_function
            logits_val = lr.decision_function(E[va])
            if logits_val.ndim == 1:
                logits_val = np.stack([-logits_val, logits_val], axis=1)
            def softmax(z):
                z = z - z.max(axis=1, keepdims=True)
                ez = np.exp(z)
                return ez / (ez.sum(axis=1, keepdims=True) + 1e-8)
            Ts = [0.5, 0.75, 1.0, 1.25, 1.5]
            best_T, best_nll = 1.0, 1e9
            for T in Ts:
                p = softmax(logits_val / T)
                nll = log_loss(y[va], p, labels=np.unique(y))
                if nll < best_nll:
                    best_nll, best_T = nll, T
            # Per-class thresholds to target precision 0.95 on val
            probs_val = softmax(logits_val / best_T)
            preds_val = np.argmax(probs_val, axis=1)
            conf_val = np.max(probs_val, axis=1)
            classes = np.unique(y)
            tau_c = {int(c): 0.9 for c in classes}
            for c in classes:
                idx_c = preds_val == c
                if not np.any(idx_c):
                    continue
                # grid thresholds high to low
                for thr in [0.95, 0.9, 0.85, 0.8]:
                    sel = idx_c & (conf_val >= thr)
                    if np.any(sel):
                        prec = precision_score(y[va][sel], preds_val[sel], average='binary' if len(classes)==2 else 'micro')
                        if prec >= 0.95 or thr == 0.8:
                            tau_c[int(c)] = thr; break
            return lr, best_T, tau_c

        lr_head, temp_T, tau_per_class = fit_calibrated_lr(E_train, y_train)
        # Pseudo-label candidates: not train/test (include val)
        cand_mask = (~tm) & (~sm)
        cand_idx = np.where(cand_mask)[0]
        E_cand = _row_norm(proj[cand_idx])
        pred_knn, conf_knn = knn_probs(E_cand, E_train, y_train, k=cfg_u.k_neighbors)
        # LR calibrated predictions on candidates
        logits_cand = lr_head.decision_function(E_cand)
        if logits_cand.ndim == 1:
            logits_cand = np.stack([-logits_cand, logits_cand], axis=1)
        # Softmax with temperature
        lc = logits_cand / max(temp_T, 1e-6)
        lc = lc - lc.max(axis=1, keepdims=True)
        prob_lr = np.exp(lc) / (np.exp(lc).sum(axis=1, keepdims=True) + 1e-8)
        pred_lr = lr_head.classes_[np.argmax(prob_lr, axis=1)]
        conf_lr = np.max(prob_lr, axis=1).astype(np.float32)

        # Optional agreement with logistic head on embedding
        if self.agreement and cand_idx.size > 0:
            # Per-class threshold on LR confidences
            thr_lr = np.array([tau_per_class.get(int(c), self.agree_conf_thr) for c in pred_lr])
            agree_mask = (pred_knn == pred_lr) & (conf_knn >= self.conf_thr) & (conf_lr >= thr_lr)
            sel_score = np.minimum(conf_knn, conf_lr)
        else:
            agree_mask = conf_knn >= self.conf_thr
            sel_score = conf_knn

        # Curriculum-style multi-round capped selection
        selected_local = np.zeros_like(agree_mask, dtype=bool)
        rounds = self.pl_rounds
        for r in range(rounds):
            # Available pool in this round
            pool_mask = agree_mask & (~selected_local)
            if not np.any(pool_mask):
                break
            # Effective caps ramp up with rounds
            scale = float(r + 1) / float(rounds)
            eff_per_class_cap = max(1e-6, self.per_class_cap * scale)
            eff_global_cap = max(1e-6, self.global_cap * scale)
            # Per-class capped selection by highest selection score
            for c in np.unique(pred_knn[pool_mask]):
                idx_all = np.where((pred_knn == c) & pool_mask)[0]
                if idx_all.size == 0:
                    continue
                # Select top-k by sel_score
                k_cap = max(1, int(eff_per_class_cap * idx_all.size))
                order = np.argsort(-sel_score[idx_all])[:k_cap]
                selected_local[idx_all[order]] = True
            # Enforce global cap relative to train size
            sel_idx = np.where(selected_local)[0]
            max_global = int(eff_global_cap * train_idx.size)
            if sel_idx.size > max_global > 0:
                order = np.argsort(-sel_score[sel_idx])[:max_global]
                keep = np.zeros_like(selected_local)
                keep[sel_idx[order]] = True
                selected_local = keep

        accept_idx = cand_idx[selected_local]
        # Fallback mechanisms if too few PLs or class coverage poor
        min_cov = max(5, int(0.03 * (~tm & ~sm).sum()))
        if accept_idx.size < min_cov:
            # Relax k and include simple LP vote (2-of-3 consensus)
            pred_knn2, conf_knn2 = knn_probs(E_cand, E_train, y_train, k=min(cfg_u.k_neighbors + 5, 50))
            # Simple LP vote using neighbor majority (train labels only)
            pred_lp = []
            for u in cand_idx:
                neigh = np.where(adj[u] > 0)[0]
                neigh_train = neigh[tm[neigh]]
                if neigh_train.size == 0:
                    pred_lp.append(-1)
                else:
                    labs = labels[neigh_train]
                    pr = np.bincount(labs, minlength=int(labels.max())+1).argmax()
                    pred_lp.append(int(pr))
            pred_lp = np.array(pred_lp)
            agree2 = (pred_knn2 == pred_lr) | (pred_knn2 == pred_lp) | (pred_lr == pred_lp)
            strong = agree2 & (conf_knn2 >= self.conf_thr)
            # Update selection
            sel_score2 = np.maximum(sel_score, conf_knn2)
            selected_local = strong
            accept_idx = cand_idx[selected_local]
        # Retrain semi-supervised
        tm_pl = tm.copy()
        labels_pl = labels.copy()
        if accept_idx.size > 0:
            tm_pl[accept_idx] = True
            # Assign kNN predictions for accepted candidates
            labels_pl[accept_idx] = pred_knn[selected_local]
        cfg_s = self._config_semi(cfg_u.k_neighbors)
        model_s = ProfileModel(n_nodes, n_features, cfg_s.profile_dim, DEVICE)
        ProfileTrainer(model_s, cfg_s).train(features, adj, labels_pl, tm_pl)
        # Evaluate using kNN soft probabilities for AUC as well
        with torch.no_grad():
            ft2 = torch.tensor(features, dtype=torch.float32, device=model_s.device)
            proj2 = model_s.proj_head(model_s.feature_projection(ft2))
            proj2 = F.normalize(proj2, dim=1, eps=1e-8).cpu().numpy()
        train_idx2 = np.where(tm_pl)[0]
        test_idx = np.where(sm)[0]
        E_train2 = _row_norm(proj2[train_idx2])
        E_test = _row_norm(proj2[test_idx])
        C = int(labels.max() + 1)
        # cosine similarity
        S = E_test @ E_train2.T
        k = int(cfg_s.k_neighbors)
        kk = min(k, S.shape[1])
        idx = np.argpartition(-S, kth=kk - 1, axis=1)[:, :kk]
        P = np.zeros((E_test.shape[0], C), dtype=np.float32)
        for i in range(E_test.shape[0]):
            neigh = idx[i]
            w = np.maximum(S[i, neigh], 0.0)
            if w.sum() == 0:
                w = np.ones_like(w)
            w = w / (w.sum() + 1e-8)
            labs = labels_pl[train_idx2[neigh]]
            for j, lab in enumerate(labs):
                P[i, int(lab)] += w[j]
        y_pred = P.argmax(axis=1)
        from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
        acc = float(accuracy_score(labels[test_idx], y_pred))
        f1 = float(f1_score(labels[test_idx], y_pred, average='weighted'))
        try:
            auc = float(roc_auc_score(labels[test_idx], P[:, 1] if C == 2 else P, multi_class='ovr', average='macro'))
        except Exception:
            auc = None
        y_true = [int(labels[i]) for i in test_idx]
        y_pred_list = [int(v) for v in y_pred.tolist()]
        metrics = {'pl_acc': acc, 'pl_f1': f1, 'pl_added': int(accept_idx.size)}
        if auc is not None:
            metrics['pl_auc'] = auc
        return RunResult(split=split_idx, metrics=metrics, extras={'y_true': y_true, 'y_pred': y_pred_list})
