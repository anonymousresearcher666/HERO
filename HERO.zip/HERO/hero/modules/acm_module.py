"""ACM-GNN baseline module compatible with the HERO pipeline."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score
from torch import Tensor
import resource
import sys

from legacy.acm import ACMGCN

from .base import HeterophilyModule, RunResult


def _edge_index_from_adj(adj: np.ndarray) -> np.ndarray:
    if adj.ndim == 2 and adj.shape[0] == 2:
        return adj
    if adj.ndim != 2:
        raise ValueError("Adjacency must be 2-D")
    row, col = np.nonzero(adj)
    return np.stack([row, col], axis=0)


def _to_edge_index(adj: np.ndarray | Tensor) -> Tensor:
    if isinstance(adj, Tensor):
        if adj.dim() == 2 and adj.size(0) == 2:
            return adj.to(torch.long)
        if adj.dim() == 2:
            idx = torch.nonzero(adj, as_tuple=False).t()
            return idx.to(torch.long)
        raise ValueError("Unsupported adjacency tensor shape")
    return torch.from_numpy(_edge_index_from_adj(adj)).long()


def _build_adjacencies(
    edge_index: Tensor,
    num_nodes: int,
    device: torch.device,
    *,
    prefer_dense: bool = False,
) -> tuple[Tensor, Tensor, Tensor]:
    edge_index_cpu = edge_index.to(torch.long).cpu()
    values = torch.ones(edge_index_cpu.shape[1], dtype=torch.float32)
    adj_sparse_cpu = torch.sparse_coo_tensor(edge_index_cpu, values, (num_nodes, num_nodes)).coalesce()

    loop_idx = torch.arange(num_nodes)
    loop_edges = torch.stack([loop_idx, loop_idx])
    loop_values = torch.ones(num_nodes, dtype=torch.float32)

    all_edges = torch.cat([edge_index_cpu, loop_edges], dim=1)
    all_values = torch.cat([values, loop_values], dim=0)
    degrees = torch.zeros(num_nodes, dtype=torch.float32)
    degrees.scatter_add_(0, all_edges[0], all_values)
    degrees = degrees.clamp(min=1e-12)
    norm_values = all_values / degrees[all_edges[0]]
    adj_low_cpu = torch.sparse_coo_tensor(all_edges, norm_values, (num_nodes, num_nodes)).coalesce()

    high_edges = torch.cat([loop_edges, adj_low_cpu.indices()], dim=1)
    high_values = torch.cat([loop_values, -adj_low_cpu.values()], dim=0)
    adj_high_cpu = torch.sparse_coo_tensor(high_edges, high_values, (num_nodes, num_nodes)).coalesce()

    if prefer_dense:
        adj_sparse_out = adj_sparse_cpu.to_dense()
        adj_low_out = adj_low_cpu.to_dense()
        adj_high_out = adj_high_cpu.to_dense()
    else:
        adj_sparse_out = adj_sparse_cpu
        adj_low_out = adj_low_cpu
        adj_high_out = adj_high_cpu

    return (
        adj_sparse_out.to(device),
        adj_low_out.to(device),
        adj_high_out.to(device),
    )


@dataclass
class ACMConfig:
    hidden_dim: int = 256
    dropout: float = 0.5
    lr: float = 0.005
    weight_decay: float = 0.0
    epochs: int = 400
    patience: int = 50
    structure_info: int = 0
    variant: bool = False
    init_layers_feat: int = 1


class ACMModule(HeterophilyModule):
    name = "acm"

    def __init__(
        self,
        results_root: str | None = None,
        hidden_dim: int = 256,
        dropout: float = 0.5,
        lr: float = 0.005,
        weight_decay: float = 0.0,
        epochs: int = 400,
        patience: int = 50,
        structure_info: int = 0,
        variant: bool = False,
        init_layers_feat: int = 1,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        if device == "mps":
            print("[ACM] MPS backend lacks sparse support; falling back to CPU for stability.")
            device = "cpu"
        self.device = torch.device(device)
        self.cfg = ACMConfig(
            hidden_dim=hidden_dim,
            dropout=dropout,
            lr=lr,
            weight_decay=weight_decay,
            epochs=epochs,
            patience=patience,
            structure_info=structure_info,
            variant=variant,
            init_layers_feat=init_layers_feat,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = _to_edge_index(adj)
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features_t = torch.tensor(features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask.astype(bool), device=self.device)
        test_mask_t = torch.tensor(test_mask.astype(bool), device=self.device)
        if val_mask is None:
            val_mask_t = train_mask_t
        else:
            val_mask_t = torch.tensor(val_mask.astype(bool), device=self.device)
            if not val_mask_t.any():
                val_mask_t = train_mask_t

        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() else 0

        edge_index = context["edge_index"]
        prefer_dense = self.device.type == "mps"
        adj_sparse, adj_low, adj_high = _build_adjacencies(
            edge_index, num_nodes, self.device, prefer_dense=prefer_dense
        )
        if self.cfg.structure_info:
            if prefer_dense:
                adj_low_unnorm = adj_sparse
            else:
                adj_low_unnorm = adj_sparse.to_dense()
        else:
            adj_low_unnorm = None

        model = ACMGCN(
            in_channels=in_dim,
            hidden_channels=self.cfg.hidden_dim,
            out_channels=num_classes,
            nnodes=num_nodes,
            dropout=self.cfg.dropout,
            structure_info=self.cfg.structure_info,
            variant=self.cfg.variant,
            init_layers_X=self.cfg.init_layers_feat,
        ).to(self.device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay
        )

        param_count = int(sum(p.numel() for p in model.parameters()))
        train_nodes = float(train_mask_t.sum().item())
        epoch_times: list[float] = []

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        def _host_peak_mem() -> float:
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform != "darwin":
                peak *= 1024
            return float(peak)

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)

        best_state = None
        best_val = -1.0
        patience_ctr = 0
        peak_mem_tracker = _current_mem()

        for epoch in range(self.cfg.epochs):
            start = time.perf_counter()
            model.train()
            optimizer.zero_grad()
            logits = model(features_t, adj_low, adj_high, adj_low_unnorm)
            loss = F.cross_entropy(logits[train_mask_t], labels_t[train_mask_t])
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                logits = model(features_t, adj_low, adj_high, adj_low_unnorm)
                val_logits = logits[val_mask_t]
                val_acc = (val_logits.argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()

            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1
                if patience_ctr >= self.cfg.patience:
                    if self.device.type == "cuda":
                        torch.cuda.synchronize(self.device)
                    epoch_times.append(time.perf_counter() - start)
                    break

            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
            epoch_times.append(time.perf_counter() - start)
            peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            logits = model(features_t, adj_low, adj_high, adj_low_unnorm)
            train_acc = (logits[train_mask_t].argmax(dim=-1) == labels_t[train_mask_t]).float().mean().item()
            val_acc = (logits[val_mask_t].argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()
            test_logits = logits[test_mask_t]
            test_pred = test_logits.argmax(dim=-1)
            test_acc = (test_pred == labels_t[test_mask_t]).float().mean().item()
            if test_mask_t.any():
                test_f1 = f1_score(
                    labels_t[test_mask_t].cpu().numpy(),
                    test_pred.cpu().numpy(),
                    average="macro",
                )
            else:
                test_f1 = 0.0
            roc_auc = self._roc_auc_metric(logits, labels_t, test_mask_t)

        peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker
        peak_mem = max(peak_mem, _host_peak_mem())

        metrics = {
            "train_acc": float(train_acc),
            "val_acc": float(val_acc),
            "test_acc": float(test_acc),
            "test_f1": float(test_f1),
            "params": param_count,
            "epoch_time_mean": epoch_time_mean,
            "epoch_time_std": epoch_time_std,
            "throughput_nodes_per_sec": throughput,
            "peak_mem_bytes": peak_mem,
        }
        if roc_auc is not None:
            metrics["test_roc_auc"] = roc_auc

        return RunResult(
            split=split_idx,
            metrics=metrics,
            extras={
                "y_true": labels_t[test_mask_t].cpu().tolist(),
                "y_pred": test_pred.cpu().tolist(),
            },
        )
