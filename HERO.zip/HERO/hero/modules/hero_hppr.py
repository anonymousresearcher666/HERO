"""HERO HPPR module.

Re-implementation providing a clear, differentiable pipeline for
heterophily-aware subgraph aggregation, prototype guidance, and expert
mixture gating.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score
from tqdm import trange, tqdm
from torch import Tensor
from torch_geometric.utils import scatter

from .base import HeterophilyModule, RunResult


@dataclass
class HPPRForwardOutput:
    offers: Tensor
    requests: Tensor
    proto_weights: Tensor
    base_logits: Tensor
    final_logits: Tensor
    compatibilities: Tensor
    lambda_vec: Tensor
    edge_weight: Tensor
    restart: Tensor
    subgraphs: Dict[str, List[List[int]]]
    proxies: Dict[str, Tensor]
    gate_weights: Tensor
    aggregated_logits: Dict[str, Tensor]

    def as_dict(self) -> Dict[str, object]:
        return {
            'offers': self.offers,
            'requests': self.requests,
            'proto_weights': self.proto_weights,
            'base_logits': self.base_logits,
            'logits': self.final_logits,
            'compat': self.compatibilities,
            'lambda': self.lambda_vec,
            'weights': self.edge_weight,
            'restart': self.restart,
            'subgraphs': self.subgraphs,
            'proxies': self.proxies,
            'gate_weights': self.gate_weights,
            'aggregated_logits': self.aggregated_logits,
        }


def _min_max_normalize(values: Tensor, eps: float = 1e-6) -> Tensor:
    min_val = values.min()
    max_val = values.max()
    denom = torch.clamp(max_val - min_val, min=eps)
    return (values - min_val) / denom


def _margin_from_logits(logits: Tensor) -> Tensor:
    probs = F.softmax(logits, dim=-1)
    top2 = torch.topk(probs, k=min(2, probs.size(-1)), dim=-1).values
    if top2.size(-1) == 1:
        return top2[:, 0]
    return top2[:, 0] - top2[:, 1]


class Stage1Profiles(nn.Module):
    """Encodes node representations and learns prototype mixtures."""

    def __init__(self, in_dim: int, hidden_dim: int, prototype_count: int) -> None:
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.offer_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.prototype_selector = nn.Linear(hidden_dim, prototype_count)
        self.prototypes = nn.Parameter(torch.randn(prototype_count, hidden_dim) * 0.1)

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        h = self.encoder(x)
        offers = F.normalize(self.offer_proj(h), dim=-1)
        logits = self.prototype_selector(h)
        weights = F.softmax(logits, dim=-1)
        requests = F.normalize(weights @ self.prototypes, dim=-1)
        return offers, requests, weights


class HPPRModel(nn.Module):
    """End-to-end differentiable HPPR model."""

    expert_names = ('base', 'topk', 'threshold', 'structure', 'diversity')

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        num_classes: int,
        prototype_count: int = 16,
        temperature: float = 0.07,
        hetero_gamma: float = 2.0,
        restart_lambda: float = 0.5,
        max_iters: int = 8,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.stage1 = Stage1Profiles(in_dim, hidden_dim, prototype_count)
        self.classifier = nn.Linear(hidden_dim * 2, num_classes)
        self.temperature = temperature
        self.hetero_gamma = hetero_gamma
        self.restart_lambda = restart_lambda
        self.max_iters = max_iters
        self.dropout = nn.Dropout(dropout)

        feat_dim = 2 + (len(self.expert_names) - 1)  # lambda, restart, four proxy scores
        self.gating_mlp = nn.Sequential(
            nn.Linear(feat_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, len(self.expert_names)),
        )

    def forward(self, x: Tensor, edge_index: Tensor) -> Dict[str, object]:
        x = self.dropout(x)
        offers, requests, proto_weights = self.stage1(x)
        base_logits = self.classifier(torch.cat([offers, requests], dim=-1))

        compat, lambda_vec = self._edge_statistics(offers, requests, edge_index)
        edge_weight = self._transition_weights(compat, lambda_vec, edge_index, x.size(0))
        restart = self._adaptive_restart(proto_weights, compat, edge_index, x.size(0))
        agg_logits, proxies, subgraphs = self._subgraph_aggregations(
            base_logits, edge_index, edge_weight, lambda_vec, proto_weights
        )
        gate_weights, final_logits = self._mix_experts(base_logits, agg_logits, lambda_vec, restart, proxies)

        output = HPPRForwardOutput(
            offers=offers,
            requests=requests,
            proto_weights=proto_weights,
            base_logits=base_logits,
            final_logits=final_logits,
            compatibilities=compat,
            lambda_vec=lambda_vec,
            edge_weight=edge_weight,
            restart=restart,
            subgraphs=subgraphs,
            proxies=proxies,
            gate_weights=gate_weights,
            aggregated_logits=agg_logits,
        )
        return output.as_dict()

    def _edge_statistics(
        self,
        offers: Tensor,
        requests: Tensor,
        edge_index: Tensor,
    ) -> Tuple[Tensor, Tensor]:
        if edge_index.numel() == 0:
            num_nodes = offers.size(0)
            compat = edge_index.new_zeros((0,), dtype=offers.dtype)
            lambda_vec = torch.full((num_nodes,), 0.5, device=offers.device)
            return compat, lambda_vec

        src, dst = edge_index
        q_norm = F.normalize(offers[src], dim=-1)
        r_norm = F.normalize(requests[dst], dim=-1)
        dots = (q_norm * r_norm).sum(dim=-1)
        compat = torch.sigmoid(dots / self.temperature)

        num_nodes = offers.size(0)
        pos_mean = scatter(compat, src, dim=0, dim_size=num_nodes, reduce='mean')
        neg_mean = scatter(compat, dst, dim=0, dim_size=num_nodes, reduce='mean')
        hetero_gap = pos_mean - neg_mean
        lambda_vec = torch.sigmoid(-self.hetero_gamma * hetero_gap)
        return compat, lambda_vec

    def _transition_weights(
        self,
        compat: Tensor,
        lambda_vec: Tensor,
        edge_index: Tensor,
        num_nodes: int,
    ) -> Tensor:
        if compat.numel() == 0:
            return torch.zeros_like(compat)
        src, _ = edge_index
        lam = lambda_vec[src]
        weights = lam * (1.0 - compat) + (1.0 - lam) * compat
        denom = scatter(weights, src, dim=0, dim_size=num_nodes, reduce='sum').clamp_min(1e-6)
        normalized = weights / denom[src]
        return normalized

    def _adaptive_restart(
        self,
        proto_weights: Tensor,
        compat: Tensor,
        edge_index: Tensor,
        num_nodes: int,
    ) -> Tensor:
        entropy = -(proto_weights * torch.log(proto_weights.clamp_min(1e-8))).sum(dim=-1)
        if compat.numel() == 0:
            return torch.clamp(_min_max_normalize(entropy), 0.05, 0.95)
        src, _ = edge_index
        avg_compat = scatter(compat, src, dim=0, dim_size=num_nodes, reduce='mean')
        norm_entropy = _min_max_normalize(entropy)
        norm_compat = _min_max_normalize(avg_compat)
        restart = self.restart_lambda * norm_entropy + (1.0 - self.restart_lambda) * norm_compat
        return torch.clamp(restart, 0.05, 0.95)

    def _subgraph_aggregations(
        self,
        base_logits: Tensor,
        edge_index: Tensor,
        edge_weight: Tensor,
        lambda_vec: Tensor,
        proto_weights: Tensor,
    ) -> Tuple[Dict[str, Tensor], Dict[str, Tensor], Dict[str, List[List[int]]]]:
        num_nodes = base_logits.size(0)
        device = base_logits.device
        margin = _margin_from_logits(base_logits)

        agg_logits = {name: torch.zeros_like(base_logits) for name in self.expert_names if name != 'base'}
        proxies = {name: torch.zeros(num_nodes, device=device) for name in agg_logits.keys()}
        subgraphs: Dict[str, List[List[int]]] = {name: [] for name in agg_logits.keys()}

        src, dst = edge_index
        num_edges = compat_size = edge_weight.size(0)
        if compat_size == 0:
            for name in agg_logits.keys():
                agg_logits[name] = base_logits.clone()
                proxies[name] = margin.clone()
                subgraphs[name] = [[int(i)] for i in range(num_nodes)]
            return agg_logits, proxies, subgraphs

        edge_ids = torch.arange(num_edges, device=device)

        for node in range(num_nodes):
            mask = src == node
            neighbor_indices = edge_ids[mask]
            if neighbor_indices.numel() == 0:
                for name in agg_logits.keys():
                    agg_logits[name][node] = base_logits[node]
                    proxies[name][node] = margin[node]
                    subgraphs[name].append([int(node)])
                continue

            neighbor_nodes = dst[neighbor_indices]
            neighbor_weights = edge_weight[neighbor_indices]
            k = max(1, math.ceil(neighbor_nodes.numel() * 0.5))

            top_values, top_idx = torch.topk(neighbor_weights, k)
            top_nodes = neighbor_nodes[top_idx]

            mean_w = neighbor_weights.mean()
            std_w = neighbor_weights.std(unbiased=False)
            threshold = mean_w + lambda_vec[node] * std_w
            thr_mask = neighbor_weights > threshold
            if thr_mask.any():
                thr_nodes = neighbor_nodes[thr_mask]
                thr_weights = neighbor_weights[thr_mask]
            else:
                thr_nodes = top_nodes
                thr_weights = top_values

            uniform_prior = torch.full_like(neighbor_weights, 1.0 / neighbor_weights.numel())
            struct_score = (1.0 - lambda_vec[node]) * neighbor_weights + lambda_vec[node] * uniform_prior
            struct_k = min(k, struct_score.numel())
            struct_values, struct_idx = torch.topk(struct_score, struct_k)
            struct_nodes = neighbor_nodes[struct_idx]
            struct_weights = neighbor_weights[struct_idx]

            proto_node = proto_weights[node].unsqueeze(0)
            proto_neigh = proto_weights[neighbor_nodes]
            js_div = self._js_divergence(proto_neigh, proto_node)
            diversity_score = neighbor_weights + lambda_vec[node] * js_div
            div_k = min(k, diversity_score.numel())
            div_values, div_idx = torch.topk(diversity_score, div_k)
            div_nodes = neighbor_nodes[div_idx]
            div_weights = neighbor_weights[div_idx]

            groups = {
                'topk': (top_nodes, top_values),
                'threshold': (thr_nodes, thr_weights),
                'structure': (struct_nodes, struct_weights),
                'diversity': (div_nodes, div_weights),
            }

            for name, (nodes, weights) in groups.items():
                group_nodes = torch.cat([torch.tensor([node], device=device), nodes])
                group_weights = torch.cat([torch.ones(1, device=device), weights])
                pooled = self._weighted_average(base_logits[group_nodes], group_weights)
                agg_logits[name][node] = pooled
                proxies[name][node] = margin[group_nodes].mean()
                subgraphs[name].append(group_nodes.detach().cpu().tolist())

        return agg_logits, proxies, subgraphs

    @staticmethod
    def _weighted_average(logits: Tensor, weights: Tensor, eps: float = 1e-6) -> Tensor:
        norm = weights.sum().clamp_min(eps)
        scaled = weights.unsqueeze(-1) * logits
        return scaled.sum(dim=0) / norm

    @staticmethod
    def _js_divergence(proto_a: Tensor, proto_b: Tensor, eps: float = 1e-6) -> Tensor:
        m = 0.5 * (proto_a + proto_b)
        kl_a = (proto_a * (torch.log(proto_a.clamp_min(eps)) - torch.log(m.clamp_min(eps)))).sum(dim=-1)
        kl_b = (proto_b * (torch.log(proto_b.clamp_min(eps)) - torch.log(m.clamp_min(eps)))).sum(dim=-1)
        return 0.5 * (kl_a + kl_b)

    def _mix_experts(
        self,
        base_logits: Tensor,
        agg_logits: Dict[str, Tensor],
        lambda_vec: Tensor,
        restart: Tensor,
        proxies: Dict[str, Tensor],
    ) -> Tuple[Tensor, Tensor]:
        features = torch.stack([
            lambda_vec,
            restart,
            proxies['topk'],
            proxies['threshold'],
            proxies['structure'],
            proxies['diversity'],
        ], dim=1)
        gate_logits = self.gating_mlp(features)
        gate_weights = F.softmax(gate_logits, dim=-1)

        expert_stack = torch.stack(
            [base_logits, agg_logits['topk'], agg_logits['threshold'], agg_logits['structure'], agg_logits['diversity']],
            dim=1,
        )
        final = torch.sum(gate_weights.unsqueeze(-1) * expert_stack, dim=1)
        return gate_weights, final


class HeroHPPRModule(HeterophilyModule):
    name = 'hero_hppr'

    def __init__(
        self,
        results_root: str = 'results',
        hidden_dim: int = 96,
        prototype_count: int = 16,
        temperature: float = 0.07,
        hetero_gamma: float = 2.0,
        restart_lambda: float = 0.5,
        hppr_iters: int = 8,
        dropout: float = 0.1,
        epochs: int = 200,
        lr: float = 0.005,
        weight_decay: float = 5e-4,
        edge_weight: float = 1.0,
        pseudo_weight: float = 0.6,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        self.hidden_dim = hidden_dim
        self.prototype_count = prototype_count
        self.temperature = temperature
        self.hetero_gamma = hetero_gamma
        self.restart_lambda = restart_lambda
        self.hppr_iters = hppr_iters
        self.dropout = dropout
        self.epochs = epochs
        self.lr = lr
        self.weight_decay = weight_decay
        self.edge_weight = edge_weight
        self.pseudo_weight = pseudo_weight
        if device is None:
            if torch.cuda.is_available():
                device = 'cuda'
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = 'mps'
            else:
                device = 'cpu'
        self.device = torch.device(device)

    def prepare_split(self, features, adj, labels, masks, split_idx):
        if isinstance(adj, np.ndarray):
            if adj.ndim == 2 and adj.shape[0] == 2:
                edge_np = adj
            else:
                src, dst = np.nonzero(adj)
                edge_np = np.stack([src, dst], axis=0)
            edge_index = torch.tensor(edge_np, dtype=torch.long)
        else:
            edge_index = torch.tensor(adj, dtype=torch.long)
        return {'edge_index': edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context):
        train_mask = masks['train_mask']
        val_mask = masks.get('val_mask')
        test_mask = masks['test_mask']
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features_t = torch.tensor(features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask, dtype=torch.bool, device=self.device)
        test_mask_t = torch.tensor(test_mask, dtype=torch.bool, device=self.device)
        if val_mask is None:
            val_mask_t = torch.zeros_like(train_mask_t)
        else:
            val_mask_t = torch.tensor(val_mask, dtype=torch.bool, device=self.device)

        edge_index = context['edge_index'].to(self.device)
        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() > 0 else 0

        model = HPPRModel(
            in_dim=in_dim,
            hidden_dim=self.hidden_dim,
            num_classes=num_classes,
            prototype_count=self.prototype_count,
            temperature=self.temperature,
            hetero_gamma=self.hetero_gamma,
            restart_lambda=self.restart_lambda,
            max_iters=self.hppr_iters,
            dropout=self.dropout,
        ).to(self.device)

        optimizer = torch.optim.Adam(model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        best_state: Dict[str, Tensor] | None = None
        best_val = -1.0
        patience = 20
        epochs_no_improve = 0

        dataset_name = getattr(self, 'current_dataset', 'unknown')
        progress = trange(self.epochs, desc=f"[{dataset_name}][split {split_idx}]", leave=False)

        for epoch in progress:
            model.train()
            optimizer.zero_grad()
            outputs = model(features_t, edge_index)
            loss = self._total_loss(outputs, labels_t, train_mask_t)
            loss.backward()
            optimizer.step()

            if epoch == 0 or (epoch + 1) % 5 == 0:
                logits_det = outputs['logits'].detach()
                train_acc_step = self._accuracy(logits_det, labels_t, train_mask_t)
                val_mask_eff = val_mask_t if val_mask_t.any() else train_mask_t
                val_acc_step = self._accuracy(logits_det, labels_t, val_mask_eff)
                progress.set_postfix(
                    loss=f"{loss.item():.4f}",
                    train_acc=f"{train_acc_step:.4f}",
                    val_acc=f"{val_acc_step:.4f}",
                )

            if (epoch + 1) % 5 == 0:
                model.eval()
                with torch.no_grad():
                    eval_out = model(features_t, edge_index)
                    logits = eval_out['logits']
                    val_mask_eff = val_mask_t if val_mask_t.any() else train_mask_t
                    if val_mask_eff.any():
                        preds = logits[val_mask_eff].argmax(dim=-1)
                        val_acc = (preds == labels_t[val_mask_eff]).float().mean().item()
                    else:
                        val_acc = 0.0
                if val_acc > best_val:
                    best_val = val_acc
                    best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                    epochs_no_improve = 0
                else:
                    epochs_no_improve += 1
                    if epochs_no_improve >= patience:
                        break

        progress.close()

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            final_outputs = model(features_t, edge_index)
            final_logits = final_outputs['logits']
            train_acc = self._accuracy(final_logits, labels_t, train_mask_t)
            val_acc = self._accuracy(final_logits, labels_t, val_mask_t if val_mask_t.any() else train_mask_t)
            test_acc = self._accuracy(final_logits, labels_t, test_mask_t)
            if test_mask_t.any():
                preds = final_logits[test_mask_t].argmax(dim=-1).cpu().tolist()
                y_true = labels_t[test_mask_t].cpu().tolist()
                test_f1 = f1_score(y_true, preds, average='macro')
            else:
                preds = []
                y_true = []
                test_f1 = 0.0

        tqdm.write(
            f"[{dataset_name}][split {split_idx}] final train_acc={train_acc:.4f} val_acc={val_acc:.4f} test_acc={test_acc:.4f}"
        )

        gate_weights = final_outputs.get('gate_weights')
        proxies = final_outputs.get('proxies', {})

        def _proxy_mean(key: str) -> Optional[float]:
            tensor = proxies.get(key)
            if tensor is None:
                return None
            return float(tensor.mean().item())

        return RunResult(
            split=split_idx,
            metrics={
                'train_acc': train_acc,
                'val_acc': val_acc,
                'test_acc': test_acc,
                'test_f1': float(test_f1),
                'mean_gate_base': float(gate_weights[:, 0].mean().item()) if gate_weights is not None else None,
                'mean_gate_topk': float(gate_weights[:, 1].mean().item()) if gate_weights is not None else None,
                'mean_gate_threshold': float(gate_weights[:, 2].mean().item()) if gate_weights is not None else None,
                'mean_gate_structure': float(gate_weights[:, 3].mean().item()) if gate_weights is not None else None,
                'mean_gate_diversity': float(gate_weights[:, 4].mean().item()) if gate_weights is not None else None,
            },
            extras={
                'y_true': y_true,
                'y_pred': preds,
                'proxy_topk_mean': _proxy_mean('topk'),
                'proxy_threshold_mean': _proxy_mean('threshold'),
                'proxy_structure_mean': _proxy_mean('structure'),
                'proxy_diversity_mean': _proxy_mean('diversity'),
            },
        )

    def _total_loss(self, outputs: Dict[str, object], labels: Tensor, train_mask: Tensor) -> Tensor:
        logits = outputs['logits']
        compat = outputs['compat']
        if train_mask.any():
            ce_loss = F.cross_entropy(logits[train_mask], labels[train_mask])
        else:
            ce_loss = torch.tensor(0.0, device=logits.device)
        if compat.numel() == 0:
            reg = torch.tensor(0.0, device=logits.device)
        else:
            reg = F.binary_cross_entropy(compat, torch.ones_like(compat))
        return ce_loss + self.edge_weight * reg

    @staticmethod
    def _accuracy(logits: Tensor, labels: Tensor, mask: Tensor) -> float:
        if not mask.any():
            return 0.0
        preds = logits[mask].argmax(dim=-1)
        return float((preds == labels[mask]).float().mean().item())


__all__ = ["HeroHPPRModule"]
