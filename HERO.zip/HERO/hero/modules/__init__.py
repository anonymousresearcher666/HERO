"""Heterophily modules (pluggable experiment implementations)."""

from .profile_contrastive import ProfileContrastiveModule  # noqa: F401
from .profile_pseudolabel import ProfilePseudoLabelModule  # noqa: F401
from .base import HeterophilyModule, RunResult  # noqa: F401
from .spectral_label_propagation import SpectralLabelPropagationModule  # noqa: F401
from .label_guided_rewiring import LabelGuidedRewiringModule  # noqa: F401
from .e2e_hero import E2EHeroModule  # noqa: F401
from .hero_hppr import HeroHPPRModule  # noqa: F401
from .new_hero import NewHeroModule  # noqa: F401
from .linkx_module import LinkxModule  # noqa: F401
from .acm_module import ACMModule  # noqa: F401
from .unifilter_module import UniFilterModule  # noqa: F401
from .gwn_module import GWNModule  # noqa: F401
from .lggnn_module import LGGNNModule  # noqa: F401
from .r2lp_module import R2LPModule  # noqa: F401
from .eggcn_module import EGGCNModule  # noqa: F401
from .hetergp_module import HeterGPModule  # noqa: F401
