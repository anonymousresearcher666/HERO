"""LINKX baseline module compatible with the HERO experiment pipeline."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor
import resource
import sys

from sklearn.metrics import f1_score

from legacy.linkx import LINKX

from .base import HeterophilyModule, RunResult


def _edge_index_from_adj(adj: np.ndarray) -> np.ndarray:
    if adj.ndim != 2:
        raise ValueError("Adjacency matrix must be 2-D")
    row, col = np.nonzero(adj)
    return np.stack([row, col], axis=0)


def _to_edge_index(adj: np.ndarray | Tensor) -> Tensor:
    if isinstance(adj, Tensor):
        if adj.dim() == 2 and adj.size(0) == 2:
            return adj.to(torch.long)
        if adj.dim() == 2:
            idx = torch.nonzero(adj, as_tuple=False).t()
            return idx.to(torch.long)
        raise ValueError("Unsupported adjacency tensor shape")
    if adj.ndim == 2 and adj.shape[0] == 2:
        return torch.from_numpy(adj).long()
    return torch.from_numpy(_edge_index_from_adj(adj)).long()


@dataclass
class LinkxConfig:
    hidden_dim: int = 256
    final_layers: int = 2
    dropout: float = 0.5
    lr: float = 0.001
    weight_decay: float = 0.0
    epochs: int = 400
    patience: int = 50
    init_layers_adj: int = 1
    init_layers_feat: int = 1
    inner_activation: bool = False
    inner_dropout: bool = False


class LinkxModule(HeterophilyModule):
    name = "linkx"

    def __init__(
        self,
        results_root: str | None = None,
        hidden_dim: int = 256,
        final_layers: int = 2,
        dropout: float = 0.5,
        lr: float = 0.001,
        weight_decay: float = 0.0,
        epochs: int = 400,
        patience: int = 50,
        init_layers_adj: int = 1,
        init_layers_feat: int = 1,
        inner_activation: bool = False,
        inner_dropout: bool = False,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        if device == "mps":
            print("[LINKX] MPS backend lacks sparse tensor ops; falling back to CPU.")
            device = "cpu"
        self.device = torch.device(device)
        self.cfg = LinkxConfig(
            hidden_dim=hidden_dim,
            final_layers=final_layers,
            dropout=dropout,
            lr=lr,
            weight_decay=weight_decay,
            epochs=epochs,
            patience=patience,
            init_layers_adj=init_layers_adj,
            init_layers_feat=init_layers_feat,
            inner_activation=inner_activation,
            inner_dropout=inner_dropout,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = _to_edge_index(adj)
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features_t = torch.tensor(features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask.astype(bool), device=self.device)
        if val_mask is None:
            val_mask_t = train_mask_t
        else:
            val_mask_t = torch.tensor(val_mask.astype(bool), device=self.device)
        test_mask_t = torch.tensor(test_mask.astype(bool), device=self.device)

        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() else 0

        edge_index = context["edge_index"].to(self.device)
        values = torch.ones(edge_index.shape[1], device=self.device)
        adj_sparse = torch.sparse_coo_tensor(edge_index, values, (num_nodes, num_nodes)).coalesce()

        model = LINKX(
            num_nodes=num_nodes,
            in_channels=in_dim,
            hidden_channels=self.cfg.hidden_dim,
            out_channels=num_classes,
            final_layers=self.cfg.final_layers,
            dropout=self.cfg.dropout,
            init_layers_A=self.cfg.init_layers_adj,
            init_layers_X=self.cfg.init_layers_feat,
            inner_activation=self.cfg.inner_activation,
            inner_dropout=self.cfg.inner_dropout,
        ).to(self.device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay
        )

        param_count = int(sum(p.numel() for p in model.parameters()))
        train_nodes = float(train_mask_t.sum().item())
        epoch_times: list[float] = []
        best_val = -1.0
        best_state = None
        patience_ctr = 0

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        def _host_peak_mem() -> float:
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if sys.platform != "darwin":
                peak *= 1024
            return float(peak)

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)

        peak_mem_tracker = _current_mem()

        for epoch in range(self.cfg.epochs):
            start = time.perf_counter()
            model.train()
            optimizer.zero_grad()
            logits = model(adj_sparse, features_t)
            loss = F.cross_entropy(logits[train_mask_t], labels_t[train_mask_t])
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                logits = model(adj_sparse, features_t)
                val_logits = logits[val_mask_t]
                val_pred = val_logits.argmax(dim=-1)
                val_acc = (val_pred == labels_t[val_mask_t]).float().mean().item()

            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1

            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
            epoch_times.append(time.perf_counter() - start)
            peak_mem_tracker = max(peak_mem_tracker, _current_mem())
            if patience_ctr >= self.cfg.patience:
                break

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            logits = model(adj_sparse, features_t)
            train_acc = (logits[train_mask_t].argmax(dim=-1) == labels_t[train_mask_t]).float().mean().item()
            val_acc = (logits[val_mask_t].argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()
            test_logits = logits[test_mask_t]
            test_pred = test_logits.argmax(dim=-1)
            test_acc = (test_pred == labels_t[test_mask_t]).float().mean().item()
            if test_mask_t.any():
                test_f1 = f1_score(labels_t[test_mask_t].cpu().numpy(), test_pred.cpu().numpy(), average='macro')
            else:
                test_f1 = 0.0
            roc_auc = self._roc_auc_metric(logits, labels_t, test_mask_t)
        peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker
        peak_mem = max(peak_mem, _host_peak_mem())

        return RunResult(
            split=split_idx,
            metrics={
                "train_acc": float(train_acc),
                "val_acc": float(val_acc),
                "test_acc": float(test_acc),
                "test_f1": float(test_f1),
                **({"test_roc_auc": roc_auc} if roc_auc is not None else {}),
                "params": param_count,
                "epoch_time_mean": epoch_time_mean,
                "epoch_time_std": epoch_time_std,
                "throughput_nodes_per_sec": throughput,
                "peak_mem_bytes": peak_mem,
            },
            extras={
                "y_true": labels_t[test_mask_t].cpu().tolist(),
                "y_pred": test_pred.cpu().tolist(),
            },
        )
