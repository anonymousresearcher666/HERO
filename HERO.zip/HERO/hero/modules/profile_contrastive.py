"""Profile-based contrastive module derived from HeterophilyModule.

This is a structured version of the Roman Empire demo logic.
"""

from __future__ import annotations

from typing import Tuple

import numpy as np

from hero.core import ExperimentConfig, ProfileModel, ProfileTrainer, ProfileClassifier, BaselineClassifiers, DEVICE
from .base import HeterophilyModule, RunResult


def _row_norm(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


def knn_probs(emb_test: np.ndarray, emb_train: np.ndarray, y_train: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    n_test = emb_test.shape[0]
    preds = np.zeros(n_test, dtype=np.int64)
    conf = np.zeros(n_test, dtype=np.float32)
    S = emb_test @ emb_train.T
    kk = min(k, S.shape[1])
    idx = np.argpartition(-S, kth=kk - 1, axis=1)[:, :kk]
    for i in range(idx.shape[0]):
        neigh = idx[i]
        w = S[i, neigh]
        w = np.maximum(w, 0)
        if w.sum() == 0:
            w = np.ones_like(w)
        w /= (w.sum() + 1e-8)
        labs = y_train[neigh]
        classes, inv = np.unique(labs, return_inverse=True)
        probs = np.zeros(len(classes), dtype=np.float32)
        for j, cidx in enumerate(inv):
            probs[cidx] += w[j]
        preds[i] = int(classes[probs.argmax()])
        conf[i] = float(probs.max())
    return preds, conf


class ProfileContrastiveModule(HeterophilyModule):
    name = 'profile_contrastive'

    def __init__(self, results_root: str = 'results', profile_dim: int = 128) -> None:
        super().__init__(results_root)
        self.profile_dim = profile_dim

    def prepare_split(self, features, adj, labels, masks, split_idx):
        return {}

    def _unsup_config(self) -> ExperimentConfig:
        return ExperimentConfig(
            datasets=['custom'],
            profile_dim=self.profile_dim,
            learning_rate=0.005,
            epochs=50,
            early_stopping_patience=10,
            structure_weight=0.0,
            label_weight=0.0,
            contrastive_weight=1.0,
            unsupervised=True,
            temperature=0.1,
            strategy='contrastive_proto',
            proto_weight=0.1,
            feature_dropout=0.3,
            edge_dropout=0.3,
            k_neighbors=25,
            embedding_type='projected',
            use_weighted_voting=True,
            test_runs=1,
            save_results=False,
        )

    def run_split(self, features, adj, labels, masks, split_idx, context):
        tm = masks['train_mask'][:, split_idx] if masks['train_mask'].ndim == 2 else masks['train_mask']
        sm = masks['test_mask'][:, split_idx] if masks['test_mask'].ndim == 2 else masks['test_mask']
        n_nodes, n_features = features.shape
        # Train unsupervised
        cfg = self._unsup_config()
        model = ProfileModel(n_nodes, n_features, cfg.profile_dim, DEVICE)
        trainer = ProfileTrainer(model, cfg)
        trainer.train(features, adj, labels, tm)
        # Predict with kNN on projected embedding
        clf = ProfileClassifier(model, cfg, features)
        preds = clf.predict(labels, tm, sm)
        acc, f1 = self.evaluate_predictions(preds, labels, sm)
        # Build extras for potential confusion matrix
        test_idx = np.where(sm)[0]
        y_true = [int(labels[i]) for i in test_idx]
        y_pred = [int(preds[i]) for i in test_idx]
        # Baselines
        base = BaselineClassifiers(cfg)
        graph_preds = base.classify_graph_neighbors(adj, labels, tm, sm)
        feat_preds = base.classify_feature_similarity(features, labels, tm, sm)
        log_preds = base.classify_sklearn(features, labels, tm, sm, 'logistic')
        acc_graph, _ = self.evaluate_predictions(graph_preds, labels, sm)
        acc_feat, _ = self.evaluate_predictions(feat_preds, labels, sm)
        acc_log, _ = self.evaluate_predictions(log_preds, labels, sm)
        return RunResult(
            split=split_idx,
            metrics={
                'request_unsup_acc': acc,
                'request_unsup_f1': f1,
                'baseline_graph_acc': acc_graph,
                'baseline_feat_acc': acc_feat,
                'baseline_log_acc': acc_log,
            },
            extras={'y_true': y_true, 'y_pred': y_pred},
        )
