"""Base class for heterophily-robust node classification modules.

Provides common utilities to run per-dataset, per-split experiments,
evaluate baselines, and persist results. Concrete techniques derive
from this class and override the hooks.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any, Tuple, Optional, List

import time

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


def _json_sanitise(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(k): _json_sanitise(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_sanitise(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    return str(value)

from hero.core import (
    DatasetLoader,
)
from hero.paths import get_results_dir


@dataclass
class RunResult:
    split: int
    metrics: Dict[str, float]
    extras: Dict[str, Any]


class HeterophilyModule:
    """Abstract experiment module interface."""

    name: str = "base"
    _ACC_DATASETS = {"roman_empire", "amazon_ratings", "actor"}

    def __init__(self, results_root: str | None = None) -> None:
        self.results_root = results_root or get_results_dir()

    # ----- Hooks for subclasses -----
    def prepare_split(self, features: np.ndarray, adj: np.ndarray, labels: np.ndarray,
                      masks: Dict[str, np.ndarray], split_idx: int) -> Dict[str, Any]:
        return {}

    def run_split(self, features: np.ndarray, adj: np.ndarray, labels: np.ndarray,
                  masks: Dict[str, np.ndarray], split_idx: int, context: Dict[str, Any]) -> RunResult:
        raise NotImplementedError

    # ----- Configuration helpers -----
    def export_config(self) -> Dict[str, Any]:
        """Return a JSON-serialisable snapshot of the module configuration."""
        return {}

    # ----- Utilities shared across modules -----
    @staticmethod
    def evaluate_predictions(preds: Dict[int, int], labels: np.ndarray, test_mask: np.ndarray) -> Tuple[float, float]:
        test_idx = np.where(test_mask)[0]
        y_true = [int(labels[i]) for i in test_idx]
        y_pred = [int(preds[i]) for i in test_idx]
        acc = accuracy_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred, average='weighted')
        return float(acc), float(f1)

    def _roc_auc_metric(self, logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor) -> Optional[float]:
        dataset = getattr(self, 'current_dataset', None)
        if dataset is None or dataset.lower() in self._ACC_DATASETS:
            return None
        if not mask.any():
            return None
        probs = torch.softmax(logits[mask], dim=-1).detach().cpu().numpy()
        y_true = labels[mask].detach().cpu().numpy()
        try:
            if probs.shape[1] == 2:
                score = roc_auc_score(y_true, probs[:, 1])
            else:
                score = roc_auc_score(y_true, probs, multi_class='ovr')
            return float(score)
        except ValueError:
            return None

    def run_dataset(self, dataset: str, tag: Optional[str] = None, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        t0 = time.perf_counter()
        feats, adj, labels, masks = DatasetLoader.load_dataset(dataset)
        load_time = time.perf_counter() - t0
        print(f"[HeterophilyModule] Loaded {dataset} in {load_time:.2f}s")
        if feats is None:
            raise RuntimeError(f"Failed to load dataset: {dataset}")

        setattr(self, 'current_dataset', dataset)

        n_splits = masks['train_mask'].shape[1] if masks['train_mask'].ndim == 2 else 1
        results: List[RunResult] = []
        per_split_times: List[Dict[str, float]] = []
        iterator = range(n_splits)
        try:
            from tqdm import tqdm
            iterator = tqdm(iterator, desc=f"{self.name}:{dataset}", leave=False)
        except Exception:
            pass

        for s in iterator:
            split_start = time.perf_counter()
            ctx = self.prepare_split(feats, adj, labels, masks, s)
            res = self.run_split(feats, adj, labels, masks, s, ctx)
            results.append(res)
            split_end = time.perf_counter()
            per_split_times.append({'split': s, 'train_eval_time': split_end - split_start})

        # Aggregate
        mean: Dict[str, float] = {}
        if results:
            metric_keys = set()
            for r in results:
                metric_keys.update(r.metrics.keys())
            for k in sorted(metric_keys):
                values = [r.metrics[k] for r in results if k in r.metrics]
                if values:
                    mean[k] = float(np.mean(values))

        # Persist
        tag = tag or datetime.now().strftime('%Y%m%d_%H%M%S')
        base_dir = os.path.join(self.results_root, dataset, self.name)
        os.makedirs(base_dir, exist_ok=True)
        existing = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d)) and d.startswith(tag)]
        if existing:
            tag = f"{tag}_{len(existing)}"
        out_dir = os.path.join(base_dir, tag)
        os.makedirs(out_dir, exist_ok=True)

        # Save config at START (include repro command and params)
        cfg = {
            'dataset': dataset,
            'module': self.name,
            'tag': tag,
        }
        if config:
            cfg.update(config)
        resolved = self.export_config()
        if resolved:
            cfg['resolved_params'] = _json_sanitise(resolved)
        try:
            import sys as _sys
            cfg['repro_command'] = f"python {' '.join(_sys.argv)}"
        except Exception:
            pass
        with open(os.path.join(out_dir, 'config.json'), 'w') as f:
            json.dump(cfg, f, indent=2)

        summary_payload = {
            'dataset': dataset,
            'module': self.name,
            'tag': tag,
            'mean': mean,
            'splits': [dict(split=r.split, metrics=r.metrics, extras=r.extras) for r in results],
            'timing': per_split_times,
        }
        with open(os.path.join(out_dir, 'summary.json'), 'w') as f:
            json.dump(summary_payload, f, indent=2)

        # Generate plots and indexes
        try:
            from hero.plotting.plots import (
                plot_experiment_bars,
                plot_per_split_lines,
                plot_confusion_matrix,
                write_index,
                write_root_index,
            )
            plots_cfg = (config or {}).get('plots', {})
            if plots_cfg.get('enable', True):
                plots_dir = os.path.join(out_dir, 'plots')
                os.makedirs(plots_dir, exist_ok=True)
                save_tex = bool(plots_cfg.get('save_tex', False))
                # Summary bars
                plot_experiment_bars(results, mean, out_dir=plots_dir, save_tex=save_tex)
                entries = [('Summary (Acc)', 'summary_bars.png')]
                # Per-split lines for first few metrics
                if results and isinstance(results[0].metrics, dict):
                    metric_keys = list(results[0].metrics.keys())
                    if metric_keys:
                        plot_keys = metric_keys[:3]
                        plot_per_split_lines(results, plot_keys, plot_keys, out_dir=plots_dir, save_tex=save_tex)
                        entries.append(('Per-split Acc', 'per_split_lines.png'))
                # Confusion matrices: split 1 and aggregate
                if results and isinstance(results[0].extras, dict):
                    y_true0 = results[0].extras.get('y_true')
                    y_pred0 = results[0].extras.get('y_pred')
                    if y_true0 and y_pred0:
                        plot_confusion_matrix(y_true0, y_pred0, out_dir=plots_dir, name='confusion', save_tex=save_tex)
                        entries.append(('Confusion (split 1)', 'confusion.png'))
                # Aggregate confusion over splits
                y_true_all, y_pred_all = [], []
                for r in results:
                    if isinstance(r.extras, dict):
                        yt = r.extras.get('y_true'); yp = r.extras.get('y_pred')
                        if yt and yp:
                            y_true_all.extend(yt); y_pred_all.extend(yp)
                if y_true_all and y_pred_all:
                    plot_confusion_matrix(y_true_all, y_pred_all, out_dir=plots_dir, name='confusion_agg', save_tex=save_tex)
                    entries.append(('Confusion (aggregate)', 'confusion_agg.png'))
                write_index(plots_dir, f"{dataset} – {self.name} ({tag})", entries)
                # Root index linking artifacts
                root_links = [
                    ('summary.json', 'summary.json'),
                    ('config.json', 'config.json'),
                    ('plots/', 'plots/index.html'),
                ]
                write_root_index(out_dir, f"{dataset} – {self.name} ({tag})", root_links)
                # Full report embedding plots and metrics
                from hero.plotting.plots import write_full_report
                write_full_report(out_dir, f"{dataset} – {self.name} ({tag})", mean, results)
        except Exception:
            pass

        return {'dir': out_dir, 'mean': mean, 'splits': results}
