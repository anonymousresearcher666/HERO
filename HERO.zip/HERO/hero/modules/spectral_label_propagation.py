"""Spectral label propagation module.

Simple baseline that propagates one-hot labels over the symmetrically
normalized adjacency for a few steps.
"""

from __future__ import annotations

import numpy as np

from .base import HeterophilyModule, RunResult


class SpectralLabelPropagationModule(HeterophilyModule):
    name = 'spectral_label_propagation'

    def __init__(self, results_root: str = 'results', steps: int = 10, alpha: float = 0.9):
        super().__init__(results_root)
        self.steps = steps
        self.alpha = alpha

    @staticmethod
    def _sym_norm(adj: np.ndarray) -> np.ndarray:
        A = adj.astype(np.float32)
        np.fill_diagonal(A, 0.0)
        deg = A.sum(axis=1) + 1e-8
        D_inv_sqrt = 1.0 / np.sqrt(deg)
        return (D_inv_sqrt[:, None] * A) * D_inv_sqrt[None, :]

    def run_split(self, features, adj, labels, masks, split_idx, context):
        tm = masks['train_mask'][:, split_idx] if masks['train_mask'].ndim == 2 else masks['train_mask']
        sm = masks['test_mask'][:, split_idx] if masks['test_mask'].ndim == 2 else masks['test_mask']
        n = labels.shape[0]
        C = int(labels.max()) + 1
        S = self._sym_norm(adj)
        Y = np.zeros((n, C), dtype=np.float32)
        Y[tm, labels[tm]] = 1.0
        F = Y.copy()
        for _ in range(self.steps):
            F = self.alpha * (S @ F) + (1 - self.alpha) * Y
        preds = {i: int(np.argmax(F[i])) for i in np.where(sm)[0]}
        acc, f1 = self.evaluate_predictions(preds, labels, sm)
        return RunResult(split=split_idx, metrics={'lp_acc': acc, 'lp_f1': f1}, extras={})

