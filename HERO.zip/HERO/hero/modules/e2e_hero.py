"""End-to-end HERO module implemented in PyTorch Geometric.

This module trains a single graph model that learns asymmetric offer/request
representations, estimates per-node propagation utility, and combines three
prediction strategies (feature-only, guarded pseudo-labeling, post-hoc
smoothing) through a differentiable mixture.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch_geometric.utils import softmax as pyg_softmax, scatter

from sklearn.metrics import f1_score

from .base import HeterophilyModule, RunResult


@dataclass
class E2EHeroOutputs:
    base_logits: Tensor
    smooth_logits: Tensor
    post_logits: Tensor
    final_logits: Tensor
    offer: Tensor
    request: Tensor
    edge_scores: Tensor
    edge_weights: Tensor
    mix_coeffs: Tensor
    propensity: Tensor
    propensity_logits: Tensor
    teacher_probs: Tensor


class E2EHeroModel(nn.Module):
    """Single model that carries the three HERO strategies end-to-end."""

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        num_classes: int,
        prototype_count: int = 16,
        dropout: float = 0.2,
        propensity_bias: float = 0.0,
        propensity_floor: float = 0.0,
    ) -> None:
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_classes = num_classes
        self.prototype_count = prototype_count
        self.dropout = dropout
        self.propensity_bias = propensity_bias
        self.propensity_floor = propensity_floor

        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(p=dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.offer_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.request_assign = nn.Linear(hidden_dim, prototype_count)
        self.prototypes = nn.Parameter(torch.randn(prototype_count, hidden_dim) * 0.1)

        self.classifier = nn.Linear(hidden_dim, num_classes)
        self.mix_head = nn.Sequential(
            nn.Linear(hidden_dim + 3, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 3),
        )
        self.propensity_head = nn.Sequential(
            nn.Linear(hidden_dim + 3, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, x: Tensor, edge_index: Tensor) -> E2EHeroOutputs:
        x = F.dropout(x, p=self.dropout, training=self.training)
        h = self.encoder(x)

        offer = F.normalize(self.offer_proj(h), dim=-1)
        assign_logits = self.request_assign(h)
        assign = F.softmax(assign_logits, dim=-1)
        request = assign @ self.prototypes
        request = F.normalize(request, dim=-1)

        src, dst = edge_index
        edge_scores = (offer[src] * request[dst]).sum(dim=-1)
        edge_weights = pyg_softmax(edge_scores, src)

        # Aggregate neighbor representations for smoothing.
        smooth_feat = scatter(edge_weights.unsqueeze(-1) * h[dst], src, dim=0, dim_size=h.size(0), reduce='sum')
        base_logits = self.classifier(h)
        smooth_logits = self.classifier(smooth_feat)

        confidence = F.softmax(base_logits, dim=-1).amax(dim=-1)
        incoming_strength = scatter(edge_scores, dst, dim=0, dim_size=h.size(0), reduce='mean')
        outgoing_strength = scatter(edge_scores, src, dim=0, dim_size=h.size(0), reduce='mean')
        gate_input = torch.cat([
            h,
            confidence.unsqueeze(-1),
            incoming_strength.unsqueeze(-1),
            outgoing_strength.unsqueeze(-1),
        ], dim=-1)

        propensity_logits = self.propensity_head(gate_input).squeeze(-1) + self.propensity_bias
        propensity = torch.sigmoid(propensity_logits)
        if self.propensity_floor > 0:
            propensity = torch.clamp(propensity, min=self.propensity_floor)
        post_logits = base_logits + propensity.unsqueeze(-1) * (smooth_logits - base_logits)

        mix_logits = self.mix_head(gate_input)
        mix_coeffs = F.softmax(mix_logits, dim=-1)
        stacked = torch.stack([base_logits, smooth_logits, post_logits], dim=1)
        final_logits = (mix_coeffs.unsqueeze(-1) * stacked).sum(dim=1)

        teacher_probs = F.softmax(smooth_logits.detach(), dim=-1)

        return E2EHeroOutputs(
            base_logits=base_logits,
            smooth_logits=smooth_logits,
            post_logits=post_logits,
            final_logits=final_logits,
            offer=offer,
            request=request,
            edge_scores=edge_scores,
            edge_weights=edge_weights,
            mix_coeffs=mix_coeffs,
            propensity=propensity,
            propensity_logits=propensity_logits,
            teacher_probs=teacher_probs,
        )


def structure_loss(outputs: E2EHeroOutputs, num_nodes: int) -> Tensor:
    pos_scores = outputs.edge_scores
    if pos_scores.numel() == 0:
        return torch.tensor(0.0, device=outputs.edge_scores.device)
    pos_loss = F.binary_cross_entropy_with_logits(pos_scores, torch.ones_like(pos_scores))
    num_neg = min(int(pos_scores.numel()), max(1, num_nodes * 5))
    if num_neg == 0:
        return pos_loss
    neg_src = torch.randint(0, num_nodes, (num_neg,), device=pos_scores.device)
    neg_dst = torch.randint(0, num_nodes, (num_neg,), device=pos_scores.device)
    neg_scores = (outputs.offer[neg_src] * outputs.request[neg_dst]).sum(dim=-1)
    neg_loss = F.binary_cross_entropy_with_logits(neg_scores, torch.zeros_like(neg_scores))
    return pos_loss + neg_loss


def guarded_pseudo_loss(outputs: E2EHeroOutputs, train_mask: Tensor) -> Tensor:
    if outputs.base_logits.size(0) == 0:
        return outputs.base_logits.sum() * 0.0
    unlabeled_mask = ~train_mask
    if unlabeled_mask.sum() == 0:
        return outputs.base_logits.sum() * 0.0
    log_probs = F.log_softmax(outputs.base_logits, dim=-1)
    teacher = outputs.teacher_probs
    per_node_kl = F.kl_div(log_probs, teacher, reduction='none').sum(dim=-1)
    weighted = per_node_kl * outputs.propensity
    return weighted[unlabeled_mask].mean()


def posthoc_smoothing_loss(outputs: E2EHeroOutputs) -> Tensor:
    log_post = F.log_softmax(outputs.post_logits, dim=-1)
    teacher = outputs.teacher_probs
    kl = F.kl_div(log_post, teacher, reduction='none').sum(dim=-1)
    return (kl * outputs.propensity).mean()


def mixture_entropy_loss(outputs: E2EHeroOutputs) -> Tensor:
    mix = outputs.mix_coeffs
    entropy = -(mix * (mix + 1e-8).log()).sum(dim=-1)
    return entropy.mean()


def mix_uniformity_loss(outputs: E2EHeroOutputs) -> Tensor:
    mix = outputs.mix_coeffs
    if mix.numel() == 0:
        return mix.sum() * 0.0
    uniform = torch.full_like(mix, 1.0 / mix.size(-1))
    return F.mse_loss(mix, uniform)


def accuracy_from_logits(logits: Tensor, labels: Tensor, mask: Tensor) -> float:
    if mask.sum() == 0:
        return 0.0
    preds = logits[mask].argmax(dim=-1)
    truth = labels[mask]
    return float((preds == truth).float().mean().item())


class E2EHeroModule(HeterophilyModule):
    name = "e2e_hero"

    def __init__(
        self,
        results_root: str = "results",
        hidden_dim: int = 128,
        prototype_count: int = 16,
        dropout: float = 0.2,
        epochs: int = 120,
        lr: float = 0.005,
        weight_decay: float = 5e-4,
        structure_weight: float = 0.5,
        pseudo_weight: float = 0.3,
        smoothing_weight: float = 0.1,
        entropy_weight: float = 0.01,
        propensity_weight: float = 0.001,
        mix_uniform_weight: float = 0.05,
        propensity_bias: float = 0.5,
        propensity_floor: float = 0.05,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        self.hidden_dim = hidden_dim
        self.prototype_count = prototype_count
        self.dropout = dropout
        self.epochs = epochs
        self.lr = lr
        self.weight_decay = weight_decay
        self.structure_weight = structure_weight
        self.pseudo_weight = pseudo_weight
        self.smoothing_weight = smoothing_weight
        self.entropy_weight = entropy_weight
        self.propensity_weight = propensity_weight
        self.mix_uniform_weight = mix_uniform_weight
        self.propensity_bias = propensity_bias
        self.propensity_floor = propensity_floor
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)

    def prepare_split(self, features, adj, labels, masks, split_idx):
        # Pre-compute edge index once per dataset for efficiency.
        if isinstance(adj, np.ndarray):
            if adj.ndim == 2 and adj.shape[0] == 2:
                edge_np = adj
            else:
                src, dst = np.nonzero(adj)
                edge_np = np.stack([src, dst], axis=0)
            edge_index = torch.tensor(edge_np, dtype=torch.long)
        elif hasattr(adj, "indices") and hasattr(adj, "shape"):
            src, dst = adj.nonzero()
            edge_np = np.stack([src, dst], axis=0)
            edge_index = torch.tensor(edge_np, dtype=torch.long)
        else:
            edge_index = torch.tensor(adj, dtype=torch.long)
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features = torch.tensor(features, dtype=torch.float32)
        labels = torch.tensor(labels, dtype=torch.long)
        train_mask = torch.tensor(train_mask.astype(bool))
        test_mask = torch.tensor(test_mask.astype(bool))
        if val_mask is None:
            val_mask = torch.zeros_like(train_mask, dtype=torch.bool)
        else:
            val_mask = torch.tensor(val_mask.astype(bool))

        edge_index = context.get("edge_index")
        if edge_index is None:
            src, dst = np.nonzero(adj)
            edge_index = torch.tensor(np.stack([src, dst], axis=0), dtype=torch.long)
        edge_index = edge_index.to(torch.long)

        num_nodes, in_dim = features.shape
        num_classes = int(labels.max().item()) + 1 if labels.numel() > 0 else 0
        model = E2EHeroModel(
            in_dim=in_dim,
            hidden_dim=self.hidden_dim,
            num_classes=num_classes,
            prototype_count=self.prototype_count,
            dropout=self.dropout,
            propensity_bias=self.propensity_bias,
            propensity_floor=self.propensity_floor,
        ).to(self.device)
        data_x = features.to(self.device)
        data_edge_index = edge_index.to(self.device)
        data_labels = labels.to(self.device)
        train_mask_t = train_mask.to(self.device)
        val_mask_t = val_mask.to(self.device)
        test_mask_t = test_mask.to(self.device)

        optimizer = torch.optim.Adam(model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        best_state: Dict[str, Tensor] | None = None
        best_val_acc = -1.0
        best_val_loss = float("inf")
        patience = 15
        epochs_no_improve = 0

        for epoch in range(self.epochs):
            model.train()
            optimizer.zero_grad()
            outputs = model(data_x, data_edge_index)
            loss = self._total_loss(outputs, data_labels, train_mask_t)
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                eval_outputs = model(data_x, data_edge_index)
                val_logits = eval_outputs.final_logits
                val_loss = self._total_loss(eval_outputs, data_labels, train_mask_t).item()
                val_acc = accuracy_from_logits(val_logits, data_labels, val_mask_t if val_mask_t.any() else train_mask_t)

            if val_acc > best_val_acc or (np.isclose(val_acc, best_val_acc) and val_loss < best_val_loss):
                best_val_acc = val_acc
                best_val_loss = val_loss
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1
                if epochs_no_improve >= patience:
                    break

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            final_outputs = model(data_x, data_edge_index)
            final_logits = final_outputs.final_logits
            train_acc = accuracy_from_logits(final_logits, data_labels, train_mask_t)
            val_acc = accuracy_from_logits(final_logits, data_labels, val_mask_t if val_mask_t.any() else train_mask_t)
            test_acc = accuracy_from_logits(final_logits, data_labels, test_mask_t)
            test_preds = final_logits[test_mask_t].argmax(dim=-1).cpu().numpy()
            test_truth = data_labels[test_mask_t].cpu().numpy()
            test_f1 = f1_score(test_truth, test_preds, average="macro") if test_mask_t.sum() > 0 else 0.0

        return RunResult(
            split=split_idx,
            metrics={
                "train_acc": train_acc,
                "val_acc": val_acc,
                "test_acc": test_acc,
                "test_f1": float(test_f1),
                "mean_propensity": float(final_outputs.propensity.mean().item()),
            },
            extras={
                "y_true": test_truth.tolist() if test_mask_t.sum() > 0 else [],
                "y_pred": test_preds.tolist() if test_mask_t.sum() > 0 else [],
            },
        )

    def _total_loss(self, outputs: E2EHeroOutputs, labels: Tensor, train_mask: Tensor) -> Tensor:
        ce = F.cross_entropy(outputs.final_logits[train_mask], labels[train_mask]) if train_mask.any() else torch.tensor(0.0, device=labels.device)
        struct = structure_loss(outputs, outputs.offer.size(0))
        pseudo = guarded_pseudo_loss(outputs, train_mask)
        smooth = posthoc_smoothing_loss(outputs)
        entropy = mixture_entropy_loss(outputs)
        prop_reg = (outputs.propensity * (1.0 - outputs.propensity)).mean()
        mix_uniform = mix_uniformity_loss(outputs)

        return (
            ce
            + self.structure_weight * struct
            + self.pseudo_weight * pseudo
            + self.smoothing_weight * smooth
            + self.entropy_weight * entropy
            + self.propensity_weight * prop_reg
            + self.mix_uniform_weight * mix_uniform
        )


__all__ = ["E2EHeroModule"]
