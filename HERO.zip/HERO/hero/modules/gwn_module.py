"""Graph Wave Network module compatible with the HERO experiment pipeline."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score
from torch import Tensor

from legacy.gwn import GraphWaveNet

from .base import HeterophilyModule, RunResult


def _to_tensor(data: np.ndarray | Tensor, device: torch.device) -> Tensor:
    if isinstance(data, Tensor):
        return data.to(device)
    return torch.tensor(data, dtype=torch.float32, device=device)


def _edge_index(adj: np.ndarray | Tensor) -> Tensor:
    if isinstance(adj, Tensor):
        if adj.dim() == 2 and adj.size(0) == 2:
            return adj.long()
        idx = torch.nonzero(adj, as_tuple=False).t()
        return idx.long()
    if adj.ndim == 2 and adj.shape[0] == 2:
        return torch.from_numpy(adj).long()
    row, col = np.nonzero(adj)
    return torch.from_numpy(np.stack([row, col], axis=0)).long()


@dataclass
class GWNConfig:
    hidden_dim: int = 64
    time_horizon: float = 1.0
    dt: float = 1.0
    dropout: float = 0.5
    laplacian: str = "sym"
    method: str = "exp"
    init_residual: bool = False
    epochs: int = 400
    patience: int = 50
    lr: float = 0.01
    weight_decay: float = 5e-4


class GWNModule(HeterophilyModule):
    name = "gwn"

    def __init__(
        self,
        results_root: str | None = None,
        hidden_dim: int = 64,
        time_horizon: float = 1.0,
        dt: float = 1.0,
        dropout: float = 0.5,
        laplacian: str = "sym",
        method: str = "exp",
        init_residual: bool = False,
        epochs: int = 400,
        patience: int = 50,
        lr: float = 0.01,
        weight_decay: float = 5e-4,
        device: Optional[str] = None,
    ) -> None:
        super().__init__(results_root)
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"
        self.device = torch.device(device)
        self.cfg = GWNConfig(
            hidden_dim=hidden_dim,
            time_horizon=time_horizon,
            dt=dt,
            dropout=dropout,
            laplacian=laplacian,
            method=method,
            init_residual=init_residual,
            epochs=epochs,
            patience=patience,
            lr=lr,
            weight_decay=weight_decay,
        )

    def prepare_split(self, features, adj, labels, masks, split_idx):
        edge_index = _edge_index(adj)
        return {"edge_index": edge_index}

    def run_split(self, features, adj, labels, masks, split_idx, context: Dict[str, Tensor]):
        train_mask = masks["train_mask"]
        val_mask = masks.get("val_mask")
        test_mask = masks["test_mask"]
        if train_mask.ndim == 2:
            train_mask = train_mask[:, split_idx]
        if val_mask is not None and val_mask.ndim == 2:
            val_mask = val_mask[:, split_idx]
        if test_mask.ndim == 2:
            test_mask = test_mask[:, split_idx]

        features_t = torch.tensor(features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.long, device=self.device)
        train_mask_t = torch.tensor(train_mask.astype(bool), device=self.device)
        val_mask_t = torch.tensor(val_mask.astype(bool), device=self.device) if val_mask is not None else train_mask_t
        if not val_mask_t.any():
            val_mask_t = train_mask_t
        test_mask_t = torch.tensor(test_mask.astype(bool), device=self.device)

        num_nodes, in_dim = features_t.shape
        num_classes = int(labels_t.max().item()) + 1 if labels_t.numel() else 0

        edge_index = context["edge_index"].to(self.device)

        model = GraphWaveNet(
            in_channels=in_dim,
            hidden_channels=self.cfg.hidden_dim,
            out_channels=num_classes,
            time_horizon=self.cfg.time_horizon,
            dt=self.cfg.dt,
            dropout=self.cfg.dropout,
            laplacian=self.cfg.laplacian,
            method=self.cfg.method,
            init_residual=self.cfg.init_residual,
        ).to(self.device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay
        )

        param_count = int(sum(p.numel() for p in model.parameters()))
        train_nodes = float(train_mask_t.sum().item())
        epoch_times: list[float] = []
        best_state = None
        best_val = -1.0
        patience_ctr = 0

        def _current_mem() -> float:
            if self.device.type == "cuda":
                return float(torch.cuda.memory_allocated(self.device))
            if self.device.type == "mps" and hasattr(torch, "mps"):
                return float(torch.mps.current_allocated_memory())
            return 0.0

        if self.device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(self.device)
        peak_mem_tracker = _current_mem()

        for epoch in range(self.cfg.epochs):
            start = time.perf_counter()
            model.train()
            optimizer.zero_grad()
            logits = model(features_t, edge_index)
            loss = F.cross_entropy(logits[train_mask_t], labels_t[train_mask_t])
            loss.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                logits = model(features_t, edge_index)
                val_logits = logits[val_mask_t]
                val_acc = (val_logits.argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()

            if val_acc > best_val:
                best_val = val_acc
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1
                if patience_ctr >= self.cfg.patience:
                    if self.device.type == "cuda":
                        torch.cuda.synchronize(self.device)
                    epoch_times.append(time.perf_counter() - start)
                    peak_mem_tracker = max(peak_mem_tracker, _current_mem())
                    break

            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
            epoch_times.append(time.perf_counter() - start)
            peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        with torch.no_grad():
            logits = model(features_t, edge_index)
            train_acc = (logits[train_mask_t].argmax(dim=-1) == labels_t[train_mask_t]).float().mean().item()
            val_acc = (logits[val_mask_t].argmax(dim=-1) == labels_t[val_mask_t]).float().mean().item()
            test_logits = logits[test_mask_t]
            test_pred = test_logits.argmax(dim=-1)
            test_acc = (test_pred == labels_t[test_mask_t]).float().mean().item()
            if test_mask_t.any():
                test_f1 = f1_score(labels_t[test_mask_t].cpu().numpy(), test_pred.cpu().numpy(), average="macro")
            else:
                test_f1 = 0.0
            roc_auc = self._roc_auc_metric(logits, labels_t, test_mask_t)
        peak_mem_tracker = max(peak_mem_tracker, _current_mem())

        epoch_time_mean = float(np.mean(epoch_times)) if epoch_times else 0.0
        epoch_time_std = float(np.std(epoch_times)) if epoch_times else 0.0
        throughput = (train_nodes / epoch_time_mean) if epoch_time_mean > 0 else 0.0
        if self.device.type == "cuda":
            peak_mem = float(torch.cuda.max_memory_allocated(self.device))
        else:
            peak_mem = peak_mem_tracker

        metrics = {
            "train_acc": float(train_acc),
            "val_acc": float(val_acc),
            "test_acc": float(test_acc),
            "test_f1": float(test_f1),
            "params": param_count,
            "epoch_time_mean": epoch_time_mean,
            "epoch_time_std": epoch_time_std,
            "throughput_nodes_per_sec": throughput,
            "peak_mem_bytes": peak_mem,
        }
        if roc_auc is not None:
            metrics["test_roc_auc"] = roc_auc

        return RunResult(
            split=split_idx,
            metrics=metrics,
            extras={
                "y_true": labels_t[test_mask_t].cpu().tolist(),
                "y_pred": test_pred.cpu().tolist(),
            },
        )
