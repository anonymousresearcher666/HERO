"""Label-guided graph rewiring module.

This module approximates a label-guided rewiring strategy:
- Uses train labels and high-confidence feature-based predictions to propose pseudo labels
- Adds edges between same-label nodes with high feature similarity (top-k)
- Optionally removes edges between nodes with confident different labels and low similarity
- Trains a request-profile model on the rewired graph and evaluates with kNN in embedding space
"""

from __future__ import annotations

from typing import Dict, Any
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression

from .base import HeterophilyModule, RunResult
from hero.core import ExperimentConfig, ProfileModel, ProfileTrainer, ProfileClassifier, BaselineClassifiers, DEVICE


def _row_norm(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=1, keepdims=True) + 1e-8
    return x / n


class LabelGuidedRewiringModule(HeterophilyModule):
    name = 'label_rewire'

    def __init__(self, results_root: str | None = None,
                 pos_k: int = 10,
                 conf_thr: float = 0.75,
                 neg_drop: bool = True,
                 neg_sim_thr: float = 0.1,
                 profile_dim: int = 64) -> None:
        super().__init__(results_root)
        self.pos_k = pos_k
        self.conf_thr = conf_thr
        self.neg_drop = neg_drop
        self.neg_sim_thr = neg_sim_thr
        self.profile_dim = profile_dim

    def _pseudo_labels(self, X: np.ndarray, y: np.ndarray, train_mask: np.ndarray, open_mask: np.ndarray) -> np.ndarray:
        # Train a feature-logistic model on train set
        clf = LogisticRegression(max_iter=1000)
        clf.fit(X[train_mask], y[train_mask])
        proba = clf.predict_proba(X[open_mask])
        pred = proba.argmax(axis=1)
        conf = proba.max(axis=1)
        pseudo = -np.ones_like(y)
        open_idx = np.where(open_mask)[0]
        accept = conf >= self.conf_thr
        pseudo[open_idx[accept]] = pred[accept]
        return pseudo

    def _rewire(self, X: np.ndarray, A: np.ndarray, y_true: np.ndarray,
                train_mask: np.ndarray, test_mask: np.ndarray) -> np.ndarray:
        n = X.shape[0]
        Xn = _row_norm(X)
        # Determine candidate nodes for pseudo labels (not train, not test)
        open_mask = (~train_mask) & (~test_mask)
        pseudo = self._pseudo_labels(Xn, y_true, train_mask, open_mask)
        # Build label view: use true labels on train, pseudo where available, else -1
        labels = -np.ones_like(y_true)
        labels[train_mask] = y_true[train_mask]
        lab_idx = np.where(pseudo >= 0)[0]
        labels[lab_idx] = pseudo[lab_idx]
        # Start with a copy
        Ar = A.copy().astype(np.float32)
        # Add edges between same-label nodes: for each node with label >= 0, connect to top-k same-label by cosine
        for c in np.unique(labels[labels >= 0]):
            idx_c = np.where(labels == c)[0]
            if idx_c.size <= 1:
                continue
            Xc = Xn[idx_c]
            S = Xc @ Xc.T
            np.fill_diagonal(S, -1)
            k = min(self.pos_k, idx_c.size - 1)
            topk = np.argpartition(-S, kth=k-1, axis=1)[:, :k]
            for i_local, neigh_local in enumerate(topk):
                u = idx_c[i_local]
                for j_local in neigh_local:
                    v = idx_c[int(j_local)]
                    Ar[u, v] = 1.0
        # Optionally drop edges between confident different-label pairs with low similarity
        if self.neg_drop:
            # Only consider pairs already connected
            edges = np.where(Ar > 0)
            for u, v in zip(edges[0], edges[1]):
                if labels[u] >= 0 and labels[v] >= 0 and labels[u] != labels[v]:
                    sim = float(np.dot(Xn[u], Xn[v]))
                    if sim < self.neg_sim_thr:
                        Ar[u, v] = 0.0
        return Ar

    def _unsup_config(self) -> ExperimentConfig:
        return ExperimentConfig(
            datasets=['custom'], profile_dim=self.profile_dim, learning_rate=0.005, epochs=40,
            early_stopping_patience=10, structure_weight=0.0, label_weight=0.0, contrastive_weight=1.0,
            unsupervised=True, temperature=0.1, strategy='contrastive_proto', proto_weight=0.1,
            feature_dropout=0.3, edge_dropout=0.3, k_neighbors=25, embedding_type='projected',
            use_weighted_voting=True, test_runs=1, save_results=False)

    def run_split(self, features, adj, labels, masks, split_idx, context):
        tm = masks['train_mask'][:, split_idx] if masks['train_mask'].ndim == 2 else masks['train_mask']
        sm = masks['test_mask'][:, split_idx] if masks['test_mask'].ndim == 2 else masks['test_mask']
        n_nodes, n_features = features.shape
        # Rewire graph
        Ar = self._rewire(features, adj, labels, tm, sm)
        # Train unsupervised on rewired adjacency
        cfg = self._unsup_config()
        model = ProfileModel(n_nodes, n_features, cfg.profile_dim, DEVICE)
        ProfileTrainer(model, cfg).train(features, Ar, labels, tm)
        # Predict and evaluate
        clf = ProfileClassifier(model, cfg, features)
        preds = clf.predict(labels, tm, sm)
        acc, f1 = self.evaluate_predictions(preds, labels, sm)
        test_idx = np.where(sm)[0]
        y_true = [int(labels[i]) for i in test_idx]
        y_pred = [int(preds[i]) for i in test_idx]
        return RunResult(split=split_idx,
                         metrics={'label_rewire_acc': acc, 'label_rewire_f1': f1},
                         extras={'y_true': y_true, 'y_pred': y_pred})
