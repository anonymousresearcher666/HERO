"""Plotting utilities for HERO experiments.

Generates PNG plots and, if tikzplotlib is available, LaTeX (.tex) figures.
"""

from __future__ import annotations

import os
from typing import List, Dict, Any, Tuple

import matplotlib.pyplot as plt


def _try_save_tex(path_base: str, enabled: bool):
    if not enabled:
        return
    try:
        import tikzplotlib  # type: ignore
        tikzplotlib.save(path_base + '.tex')
    except Exception:
        pass


def _collect_stats(results: List[Dict[str, Any]], keys: List[str]) -> Tuple[List[float], List[float]]:
    """Return mean and std for each key across splits."""
    import numpy as np
    vals = {k: [] for k in keys}
    for r in results:
        for k in keys:
            if k in r.metrics and isinstance(r.metrics[k], (int, float)):
                vals[k].append(float(r.metrics[k]))
    means = [float(np.mean(vals[k])) if vals[k] else 0.0 for k in keys]
    stds = [float(np.std(vals[k])) if vals[k] else 0.0 for k in keys]
    return means, stds


def plot_experiment_bars(results: List[Dict[str, Any]], mean: Dict[str, float], out_dir: str, save_tex: bool = False):
    """Plot simple accuracy bars for module results.

    Supports different metric keys depending on module type.
    """
    # Determine available metrics
    # Common keys across modules
    method_keys = []
    labels = []

    # AffinityContrastiveModule metrics
    if 'affinity_unsup_acc' in (results[0].metrics if results else {}):
        method_keys = ['affinity_unsup_acc']
        labels = ['affinity_unsup']
        # baselines
        if 'baseline_graph_acc' in results[0].metrics:
            method_keys.append('baseline_graph_acc'); labels.append('graph')
        if 'baseline_feat_acc' in results[0].metrics:
            method_keys.append('baseline_feat_acc'); labels.append('feature')
        if 'baseline_log_acc' in results[0].metrics:
            method_keys.append('baseline_log_acc'); labels.append('logistic')

    # AffinityPseudoLabelModule metrics
    elif 'pl_acc' in (results[0].metrics if results else {}):
        method_keys = ['pl_acc']
        labels = ['affinity_pl']

    # Fallback: use all float metrics in mean
    if not method_keys:
        for k, v in mean.items():
            if isinstance(v, float):
                method_keys.append(k)
                labels.append(k)

    # Aggregate mean values
    # Compute mean and std across splits
    vals, stds = _collect_stats(results, method_keys)

    if not vals:
        return

    # Plot
    plt.figure(figsize=(4.5, 4))
    plt.bar(labels, vals, yerr=stds, capsize=4,
            color=['#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f'][:len(labels)])
    plt.ylim(0, 1)
    plt.ylabel('Accuracy')
    plt.title('Experiment Summary (mean across splits)')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    base = os.path.join(out_dir, 'summary_bars')
    plt.savefig(base + '.png', dpi=150)
    _try_save_tex(base, save_tex)
    plt.close()


def plot_per_split_lines(results: List[Dict[str, Any]], keys: List[str], labels: List[str], out_dir: str, save_tex: bool = False):
    if not results:
        return
    splits = [r.split for r in results]
    plt.figure(figsize=(4.5, 4))
    colors = ['#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f']
    for idx, (k, lab) in enumerate(zip(keys, labels)):
        ys = [float(r.metrics.get(k, 0.0)) for r in results]
        plt.plot(splits, ys, marker='o', label=lab, color=colors[idx % len(colors)])
    plt.ylim(0, 1)
    plt.xlabel('Split')
    plt.ylabel('Accuracy')
    plt.title('Per-split accuracy')
    plt.legend()
    plt.tight_layout()
    base = os.path.join(out_dir, 'per_split_lines')
    plt.savefig(base + '.png', dpi=150)
    _try_save_tex(base, save_tex)
    plt.close()


def plot_confusion_matrix(y_true: List[int], y_pred: List[int], out_dir: str, name: str = 'confusion', save_tex: bool = False):
    from sklearn.metrics import confusion_matrix
    import numpy as np
    cm = confusion_matrix(y_true, y_pred)
    cm = cm.astype(float)
    # Normalize by true counts
    with np.errstate(all='ignore'):
        cm_norm = cm / (cm.sum(axis=1, keepdims=True) + 1e-12)
    plt.figure(figsize=(4.5, 4))
    plt.imshow(cm_norm, cmap='Blues', vmin=0, vmax=1)
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.title('Confusion matrix (normalized)')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.tight_layout()
    base = os.path.join(out_dir, name)
    plt.savefig(base + '.png', dpi=150)
    _try_save_tex(base, save_tex)
    plt.close()


def write_root_index(out_dir: str, title: str, links: List[Tuple[str, str]]):
    md_lines = [f"# {title}", "", "## Artifacts", ""]
    for label, rel in links:
        md_lines.append(f"- [{label}]({rel})")
    with open(os.path.join(out_dir, 'index.md'), 'w') as f:
        f.write("\n".join(md_lines))

    html = [
        "<html><head><meta charset='utf-8'><title>{}</title></head><body>".format(title),
        f"<h1>{title}</h1>",
        "<h2>Artifacts</h2>",
        "<ul>",
    ]
    for label, rel in links:
        html.append(f"<li><a href='{rel}'>{label}</a></li>")
    html.append("</ul>")
    html.append("</body></html>")
    with open(os.path.join(out_dir, 'index.html'), 'w') as f:
        f.write("\n".join(html))


def write_full_report(out_dir: str, title: str, mean: Dict[str, float], results: List[Dict[str, Any]]):
    """Write a richer Markdown and HTML report embedding plots and listing metrics."""
    # Markdown
    md = [f"# {title}", "", "## Summary Metrics", ""]
    for k, v in mean.items():
        if isinstance(v, float):
            md.append(f"- {k}: {v:.4f}")
    md += ["", "## Plots", "", "![](plots/summary_bars.png)", ""]
    if os.path.exists(os.path.join(out_dir, 'plots', 'per_split_lines.png')):
        md += ["![](plots/per_split_lines.png)", ""]
    if os.path.exists(os.path.join(out_dir, 'plots', 'confusion.png')):
        md += ["![](plots/confusion.png)", ""]
    if os.path.exists(os.path.join(out_dir, 'plots', 'confusion_agg.png')):
        md += ["![](plots/confusion_agg.png)", ""]
    with open(os.path.join(out_dir, 'report.md'), 'w') as f:
        f.write("\n".join(md))

    # HTML
    html = [
        "<html><head><meta charset='utf-8'><title>{}</title></head><body>".format(title),
        f"<h1>{title}</h1>",
        "<h2>Summary Metrics</h2><ul>",
    ]
    for k, v in mean.items():
        if isinstance(v, float):
            html.append(f"<li>{k}: {v:.4f}</li>")
    html.append("</ul>")
    html.append("<h2>Plots</h2>")
    html.append("<div><img src='plots/summary_bars.png' style='max-width:800px'></div>")
    if os.path.exists(os.path.join(out_dir, 'plots', 'per_split_lines.png')):
        html.append("<div><img src='plots/per_split_lines.png' style='max-width:800px'></div>")
    if os.path.exists(os.path.join(out_dir, 'plots', 'confusion.png')):
        html.append("<div><img src='plots/confusion.png' style='max-width:800px'></div>")
    if os.path.exists(os.path.join(out_dir, 'plots', 'confusion_agg.png')):
        html.append("<div><img src='plots/confusion_agg.png' style='max-width:800px'></div>")
    html.append("</body></html>")
    with open(os.path.join(out_dir, 'report.html'), 'w') as f:
        f.write("\n".join(html))



def write_index(out_dir: str, title: str, entries: List[Tuple[str, str]]):
    """Write a simple index.md and index.html linking to plots.

    entries: list of (label, relative_path)
    """
    md_lines = [f"# {title}", "", "## Plots", ""]
    for label, rel in entries:
        md_lines.append(f"- {label}: ![]({rel})")
    with open(os.path.join(out_dir, 'index.md'), 'w') as f:
        f.write("\n".join(md_lines))

    html = [
        "<html><head><meta charset='utf-8'><title>{}</title></head><body>".format(title),
        f"<h1>{title}</h1>",
        "<h2>Plots</h2>",
    ]
    for label, rel in entries:
        html.append(f"<div><h3>{label}</h3><img src='{rel}' style='max-width:800px'></div>")
    html.append("</body></html>")
    with open(os.path.join(out_dir, 'index.html'), 'w') as f:
        f.write("\n".join(html))
