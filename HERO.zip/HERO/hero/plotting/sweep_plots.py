"""Sweep plotting utilities.

Given a sweep summary JSON (containing multiple runs), generate plots similar
in style to hero.plotting.plots for a quick overview.
"""

from __future__ import annotations

import json
import os
from typing import Dict, List, Any

import numpy as np
import matplotlib.pyplot as plt

try:  # Support running as a module or as a script
    from .plots import write_index  # type: ignore
except Exception:  # pragma: no cover
    try:
        from hero.plotting.plots import write_index  # type: ignore
    except Exception:
        def write_index(out_dir: str, title: str, entries):
            md_lines = [f"# {title}", "", "## Plots", ""]
            for label, rel in entries:
                md_lines.append(f"- {label}: ![]({rel})")
            with open(os.path.join(out_dir, 'index.md'), 'w') as f:
                f.write("\n".join(md_lines))
            html = [
                "<html><head><meta charset='utf-8'><title>{}</title></head><body>".format(title),
                f"<h1>{title}</h1>",
                "<h2>Plots</h2>",
            ]
            for label, rel in entries:
                html.append(f"<div><h3>{label}</h3><img src='{rel}' style='max-width:800px'></div>")
            html.append("</body></html>")
            with open(os.path.join(out_dir, 'index.html'), 'w') as f:
                f.write("\n".join(html))


def _bar_plot(means: Dict[str, float], stds: Dict[str, float], out_base: str, title: str):
    labels = list(means.keys())
    vals = [means[k] for k in labels]
    errs = [stds.get(k, 0.0) for k in labels]
    plt.figure(figsize=(5, 4))
    colors = ['#4e79a7', '#f28e2b', '#59a14f', '#e15759', '#76b7b2']
    plt.bar(labels, vals, yerr=errs, capsize=4, color=colors[:len(labels)])
    plt.ylim(0, 1)
    plt.ylabel('Accuracy')
    plt.title(title)
    plt.xticks(rotation=20, ha='right')
    plt.tight_layout()
    plt.savefig(out_base + '.png', dpi=150)
    plt.close()


def _line_plot(x: List[int], series: Dict[str, List[float]], out_base: str, title: str, xlabel: str = 'Split'):
    plt.figure(figsize=(5.5, 4))
    colors = ['#4e79a7', '#f28e2b', '#59a14f', '#e15759', '#76b7b2']
    for i, (name, ys) in enumerate(series.items()):
        plt.plot(x, ys, marker='o', label=name, color=colors[i % len(colors)])
    plt.ylim(0, 1)
    plt.xlabel(xlabel)
    plt.ylabel('Accuracy')
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_base + '.png', dpi=150)
    plt.close()


def _resolve_json_path(path: str) -> str:
    """Accept a path to a JSON file or a directory containing a sweep_summary_*.json.

    If a directory is given, pick the newest sweep_summary_*.json file.
    """
    p = os.path.abspath(path)
    if os.path.isdir(p):
        import glob
        cands = sorted(glob.glob(os.path.join(p, 'sweep_summary_*.json')), key=os.path.getmtime, reverse=True)
        if not cands:
            raise FileNotFoundError(f"No sweep_summary_*.json found under {p}")
        return cands[0]
    return p


def generate_sweep_plots(path: str, out_dir: str | None = None) -> str:
    json_path = _resolve_json_path(path)
    with open(json_path, 'r') as f:
        data = json.load(f)

    run_entries = data.get('runs', [])
    if not run_entries:
        raise ValueError('No runs found in sweep summary JSON')

    # Aggregate across runs: use keys from mean_acc of each run
    keys = None
    agg: Dict[str, List[float]] = {}
    for r in run_entries:
        summ = (r.get('summary') or {})
        m = summ.get('mean_acc') or r.get('mean_acc')
        # Support modules that store metrics under 'mean' (e.g., pl_acc)
        if not m and 'mean' in summ and isinstance(summ['mean'], dict):
            m = summ['mean']
        if not m:
            # legacy fields at top-level of run
            m = {k: r.get(k) for k in ['affinity_unsup', 'affinity_semi', 'feature_knn', 'logistic'] if k in r}
        if m:
            if keys is None:
                keys = list(m.keys())
            for k, v in m.items():
                agg.setdefault(k, []).append(float(v))
    if not agg:
        raise ValueError('Could not find mean_acc entries in runs')

    means = {k: float(np.mean(vs)) for k, vs in agg.items()}
    stds = {k: float(np.std(vs)) for k, vs in agg.items()}

    # Output dir: by default, same as input directory
    base_dir = os.path.dirname(os.path.abspath(json_path))
    stamp = os.path.splitext(os.path.basename(json_path))[0].replace('sweep_summary_', '')
    if out_dir is None:
        out_dir = base_dir
    os.makedirs(out_dir, exist_ok=True)

    # 1) Bars for aggregated mean acc across runs
    bar_base = os.path.join(out_dir, 'sweep_mean_acc_bars')
    _bar_plot(means, stds, bar_base, 'Sweep Mean Accuracies (across runs)')

    # 2) Per-split lines for best run (by affinity_unsup then affinity_semi)
    def run_score(run: Dict[str, Any]) -> float:
        s = (run.get('summary') or {})
        m = s.get('mean_acc') or s.get('mean') or {}
        # Prefer pl_acc when present; fallback to affinity_unsup
        return float(m.get('pl_acc', 0.0) or 0.0) + 0.1 * float(m.get('affinity_unsup', 0.0) or 0.0)

    best = max(run_entries, key=run_score)
    splits = ((best.get('summary') or {}).get('splits')) or []
    if splits:
        x = list(range(1, len(splits) + 1))
        # Support both sweep types
        if 'acc_unsup' in splits[0] or 'acc_semi' in splits[0]:
            series = {
                'affinity_unsup': [float(s.get('acc_unsup', 0.0)) for s in splits],
                'affinity_semi': [float(s.get('acc_semi', 0.0)) for s in splits],
                'feature_knn': [float(s.get('acc_feat', 0.0)) for s in splits],
                'logistic': [float(s.get('acc_log', 0.0)) for s in splits],
            }
        else:
            series = {
                'pl_acc': [float((s.get('metrics') or {}).get('pl_acc', 0.0)) for s in splits],
            }
        line_base = os.path.join(out_dir, 'best_run_per_split_lines')
        _line_plot(x, series, line_base, f"Best Run Per-Split Accuracies ({best.get('tag','')})", xlabel='Split Index')

    # 3) Optional: scatter acc vs. pl_added for best run
    if splits and (('pl_added' in splits[0]) or ('metrics' in splits[0] and 'pl_added' in splits[0]['metrics'])):
        def get_pl(s):
            return s.get('pl_added', (s.get('metrics') or {}).get('pl_added', 0))
        def get_semi(s):
            return s.get('acc_semi', (s.get('metrics') or {}).get('pl_acc', 0.0))
        x = [int(get_pl(s)) for s in splits]
        y = [float(get_semi(s)) for s in splits]
        plt.figure(figsize=(5, 4))
        plt.scatter(x, y, c='#4e79a7')
        plt.xlabel('Pseudo-labels Added')
        plt.ylabel('Semi-supervised Acc')
        plt.title('Acc vs Pseudo-labels (best run)')
        plt.tight_layout()
        out_base = os.path.join(out_dir, 'best_run_pl_added_vs_acc')
        plt.savefig(out_base + '.png', dpi=150)
        plt.close()

    # Write simple index
    entries = []
    for fname, label in [
        ('sweep_mean_acc_bars.png', 'Sweep Mean Accuracies'),
        ('best_run_per_split_lines.png', 'Best Run: Per-Split Accuracies'),
        ('best_run_pl_added_vs_acc.png', 'Best Run: Acc vs Pseudo-labels'),
    ]:
        path = os.path.join(out_dir, fname)
        if os.path.exists(path):
            entries.append((label, fname))
    # Infer dataset/method from directory structure if missing
    title_ds = data.get('dataset')
    title_m = data.get('method')
    if not (title_ds and title_m):
        parts = base_dir.replace('\\', '/').split('/')
        if len(parts) >= 2:
            title_ds = title_ds or parts[-2]
            title_m = title_m or parts[-1]
    write_index(out_dir, f"{title_ds or 'dataset'} – {title_m or 'sweep'} ({stamp})", entries)

    return out_dir


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Generate sweep plots from a sweep summary JSON or directory containing it')
    parser.add_argument('path', help='Path to sweep_summary_*.json or a directory containing it')
    parser.add_argument('--out-dir', default=None, help='Output directory (default: same as input directory)')
    args = parser.parse_args()
    out_dir = generate_sweep_plots(args.path, out_dir=args.out_dir)
    print(f"Wrote plots to: {out_dir}")
