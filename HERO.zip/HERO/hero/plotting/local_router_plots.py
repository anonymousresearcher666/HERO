from __future__ import annotations

import json
import os
from typing import Optional, Dict, Any, List

import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

from .plots import write_index


def _load_artifacts(base_dir: str):
    # Required: summary.json, request_profiles.npy, clusters.npy, centroids.npy
    with open(os.path.join(base_dir, 'summary.json'), 'r') as f:
        summary = json.load(f)
    rn = np.load(os.path.join(base_dir, 'request_profiles.npy'))
    clusters = np.load(os.path.join(base_dir, 'clusters.npy'))
    centroids = np.load(os.path.join(base_dir, 'centroids.npy'))
    return summary, rn, clusters, centroids


def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)


def _plot_clusters_2d(rn: np.ndarray, clusters: np.ndarray, centroids: np.ndarray, out_base: str):
    pca = PCA(n_components=2, random_state=42)
    Z2 = pca.fit_transform(rn)
    C2 = pca.transform(centroids)
    K = int(clusters.max() + 1)
    plt.figure(figsize=(6, 5))
    for k in range(K):
        idx = clusters == k
        plt.scatter(Z2[idx, 0], Z2[idx, 1], s=6, alpha=0.6, label=f'C{k}')
    plt.scatter(C2[:, 0], C2[:, 1], c='k', s=60, marker='x', label='centroids')
    plt.legend(ncols=2, fontsize=8)
    plt.title('Request-profile clusters (PCA)')
    plt.tight_layout()
    plt.savefig(out_base + '.png', dpi=150)
    plt.close()


def _plot_regimes_bar(regimes: List[str], out_base: str):
    from collections import Counter
    cnt = Counter(regimes)
    labels = list(cnt.keys()); vals = [cnt[k] for k in labels]
    plt.figure(figsize=(4.5, 3.5))
    plt.bar(labels, vals, color=['#4e79a7', '#f28e2b', '#59a14f'][:len(labels)])
    plt.title('Per-cluster regimes')
    plt.ylabel('# clusters')
    plt.tight_layout()
    plt.savefig(out_base + '.png', dpi=150)
    plt.close()


def _plot_diagnostics(summary: Dict[str, Any], out_dir: str):
    diags = summary.get('diagnostics', [])
    if not diags:
        return []
    names = [f'C{k}' for k in range(len(diags))]
    d_loc = [d.get('d_local', 0.0) for d in diags]
    lift = [d.get('lift_local', 0.0) for d in diags]
    cov = [d.get('coverage', 0.0) for d in diags]
    kap = [d.get('kappa', 0.0) for d in diags]

    figs = []
    # Effect size
    plt.figure(figsize=(6, 3.2))
    plt.bar(names, d_loc, color='#4e79a7')
    plt.title('Local effect size (requests)')
    plt.xticks(rotation=45)
    plt.tight_layout(); f = os.path.join(out_dir, 'diag_effect_size.png'); plt.savefig(f, dpi=150); plt.close(); figs.append(('Local effect size', 'diag_effect_size.png'))
    # Propagation lift
    plt.figure(figsize=(6, 3.2))
    plt.bar(names, lift, color='#59a14f')
    plt.title('Local propagation lift (val)')
    plt.xticks(rotation=45)
    plt.tight_layout(); f = os.path.join(out_dir, 'diag_lift.png'); plt.savefig(f, dpi=150); plt.close(); figs.append(('Local propagation lift', 'diag_lift.png'))
    # PL safety coverage
    plt.figure(figsize=(6, 3.2))
    plt.bar(names, cov, color='#f28e2b')
    plt.title('PL safety coverage')
    plt.xticks(rotation=45)
    plt.tight_layout(); f = os.path.join(out_dir, 'diag_coverage.png'); plt.savefig(f, dpi=150); plt.close(); figs.append(('PL safety coverage', 'diag_coverage.png'))
    # Kappa
    plt.figure(figsize=(6, 3.2))
    plt.bar(names, kap, color='#e15759')
    plt.title('PL safety kappa')
    plt.xticks(rotation=45)
    plt.tight_layout(); f = os.path.join(out_dir, 'diag_kappa.png'); plt.savefig(f, dpi=150); plt.close(); figs.append(('PL safety kappa', 'diag_kappa.png'))
    return figs


def _plot_weights_entropy(rn: np.ndarray, centroids: np.ndarray, beta: float, out_base: str):
    # Compute weights w_ik ∝ exp(-β ||r_i - μ_k||^2); entropy H(w_i)
    diffs = np.stack([rn - centroids[k] for k in range(centroids.shape[0])], axis=0)
    d2 = np.sum(diffs ** 2, axis=2)
    w = np.exp(-beta * d2); w = (w / (np.sum(w, axis=0, keepdims=True) + 1e-8))
    w = w.T  # [n, K]
    eps = 1e-12
    H = -np.sum(w * np.log(w + eps), axis=1)
    plt.figure(figsize=(5.5, 3.5))
    plt.hist(H, bins=30, color='#76b7b2')
    plt.title('Blending weight entropy (lower = crisper)')
    plt.xlabel('Entropy'); plt.ylabel('# nodes')
    plt.tight_layout(); plt.savefig(out_base + '.png', dpi=150); plt.close()


def generate_local_router_plots(base_dir: str) -> str:
    summary, rn, clusters, centroids = _load_artifacts(base_dir)
    plots_dir = os.path.join(base_dir, 'plots'); _ensure_dir(plots_dir)

    # Clusters 2D
    _plot_clusters_2d(rn, clusters, centroids, os.path.join(plots_dir, 'clusters_2d'))
    # Regimes bar
    _plot_regimes_bar(summary.get('regimes', []), os.path.join(plots_dir, 'regimes_bar'))
    # Diagnostics
    entries = [('Clusters (PCA)', 'clusters_2d.png'), ('Regimes per cluster', 'regimes_bar.png')]
    entries += _plot_diagnostics(summary, plots_dir)
    # Weight entropy
    beta = float(summary.get('beta', 5.0))
    _plot_weights_entropy(rn, centroids, beta, os.path.join(plots_dir, 'weights_entropy'))
    entries.append(('Weight entropy', 'weights_entropy.png'))

    write_index(plots_dir, f"Local Router – {summary.get('dataset','dataset')}", entries)
    return plots_dir


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Generate plots for local router outputs')
    parser.add_argument('base_dir', help='Path to results/<dataset>/local_router')
    args = parser.parse_args()
    d = generate_local_router_plots(args.base_dir)
    print('Wrote plots to:', d)

