"""Common paths for the HERO project.

Resolves absolute paths for results and data directories regardless of CWD.
"""

import os

# Path to the repository root (parent of the `hero` package)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


def get_results_dir() -> str:
    path = os.path.join(PROJECT_ROOT, 'results')
    os.makedirs(path, exist_ok=True)
    return path


def get_data_dir() -> str:
    path = os.path.join(PROJECT_ROOT, 'data')
    os.makedirs(path, exist_ok=True)
    return path


__all__ = ["PROJECT_ROOT", "get_results_dir", "get_data_dir"]

