"""ACM-GNN layer definitions (adapted for the HERO pipeline)."""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn import Parameter


class GraphConvolution(nn.Module):
    """Graph convolution layer used by ACM-GNN variants."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        nnodes: int,
        *,
        model_type: str = "acmgcn",
        output_layer: int = 0,
        variant: bool = False,
        structure_info: int = 0,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.output_layer = output_layer
        self.model_type = model_type
        self.structure_info = structure_info
        self.variant = variant

        self.weight_low = Parameter(torch.empty(in_features, out_features))
        self.weight_high = Parameter(torch.empty(in_features, out_features))
        self.weight_mlp = Parameter(torch.empty(in_features, out_features))

        self.att_vec_low = Parameter(torch.empty(out_features, 1))
        self.att_vec_high = Parameter(torch.empty(out_features, 1))
        self.att_vec_mlp = Parameter(torch.empty(out_features, 1))

        self.layer_norm_low = nn.LayerNorm(out_features)
        self.layer_norm_high = nn.LayerNorm(out_features)
        self.layer_norm_mlp = nn.LayerNorm(out_features)

        self.layer_norm_struc_low: Optional[nn.LayerNorm]
        self.layer_norm_struc_high: Optional[nn.LayerNorm]
        self.att_struc_low: Optional[Parameter]
        self.struc_low: Optional[Parameter]

        if structure_info:
            self.layer_norm_struc_low = nn.LayerNorm(out_features)
            self.layer_norm_struc_high = nn.LayerNorm(out_features)
            self.att_struc_low = Parameter(torch.empty(out_features, 1))
            self.struc_low = Parameter(torch.empty(nnodes, out_features))
        else:
            self.layer_norm_struc_low = None
            self.layer_norm_struc_high = None
            self.att_struc_low = None
            self.struc_low = None

        att_dim = 4 if structure_info else 3
        self.att_vec = Parameter(torch.empty(att_dim, att_dim))

        self.reset_parameters()

    def reset_parameters(self) -> None:
        bound = 1.0 / math.sqrt(self.weight_mlp.size(1))
        att_bound = 1.0 / math.sqrt(self.att_vec_mlp.size(0))
        att_vec_bound = 1.0 / math.sqrt(self.att_vec.size(0))

        nn.init.uniform_(self.weight_low, -bound, bound)
        nn.init.uniform_(self.weight_high, -bound, bound)
        nn.init.uniform_(self.weight_mlp, -bound, bound)
        if self.struc_low is not None:
            nn.init.uniform_(self.struc_low, -bound, bound)

        nn.init.uniform_(self.att_vec_low, -att_bound, att_bound)
        nn.init.uniform_(self.att_vec_high, -att_bound, att_bound)
        nn.init.uniform_(self.att_vec_mlp, -att_bound, att_bound)
        if self.att_struc_low is not None:
            nn.init.uniform_(self.att_struc_low, -att_bound, att_bound)

        nn.init.uniform_(self.att_vec, -att_vec_bound, att_vec_bound)

        self.layer_norm_low.reset_parameters()
        self.layer_norm_high.reset_parameters()
        self.layer_norm_mlp.reset_parameters()
        if self.layer_norm_struc_low is not None:
            self.layer_norm_struc_low.reset_parameters()
        if self.layer_norm_struc_high is not None:
            self.layer_norm_struc_high.reset_parameters()

    def _attention3(self, output_low: Tensor, output_high: Tensor, output_mlp: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        T = 3.0
        if self.model_type in {"acmgcn+", "acmgcn++"}:
            low = self.layer_norm_low(output_low)
            high = self.layer_norm_high(output_high)
            mlp = self.layer_norm_mlp(output_mlp)
        else:
            low, high, mlp = output_low, output_high, output_mlp

        concat = torch.cat(
            [
                low @ self.att_vec_low,
                high @ self.att_vec_high,
                mlp @ self.att_vec_mlp,
            ],
            dim=1,
        )
        logits = torch.matmul(torch.sigmoid(concat), self.att_vec) / T
        att = torch.softmax(logits, dim=1)
        return att[:, 0:1], att[:, 1:2], att[:, 2:3]

    def _attention4(
        self,
        output_low: Tensor,
        output_high: Tensor,
        output_mlp: Tensor,
        struc_low: Tensor,
    ) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        assert self.att_struc_low is not None and self.layer_norm_struc_low is not None
        T = 4.0
        if self.model_type in {"acmgcn+", "acmgcn++"}:
            low = self.layer_norm_low(output_low)
            high = self.layer_norm_high(output_high)
            mlp = self.layer_norm_mlp(output_mlp)
            struc = self.layer_norm_struc_low(struc_low)
        else:
            low, high, mlp, struc = output_low, output_high, output_mlp, struc_low

        concat = torch.cat(
            [
                low @ self.att_vec_low,
                high @ self.att_vec_high,
                mlp @ self.att_vec_mlp,
                struc @ self.att_struc_low,
            ],
            dim=1,
        )
        logits = torch.matmul(torch.sigmoid(concat), self.att_vec) / T
        att = torch.softmax(logits, dim=1)
        return att[:, 0:1], att[:, 1:2], att[:, 2:3], att[:, 3:4]

    def forward(
        self,
        x: Tensor,
        adj_low: Tensor,
        adj_high: Tensor,
        adj_low_unnormalized: Optional[Tensor],
    ) -> Tensor:
        if self.model_type == "mlp":
            return x @ self.weight_mlp
        if self.model_type in {"sgc", "gcn"}:
            return self._apply_adj(adj_low, x @ self.weight_low)

        if self.variant:
            output_low = self._apply_adj(adj_low, F.relu(x @ self.weight_low))
            output_high = self._apply_adj(adj_high, F.relu(x @ self.weight_high))
            output_mlp = F.relu(x @ self.weight_mlp)
        else:
            output_low = F.relu(self._apply_adj(adj_low, x @ self.weight_low))
            output_high = F.relu(self._apply_adj(adj_high, x @ self.weight_high))
            output_mlp = F.relu(x @ self.weight_mlp)

        if self.structure_info:
            if adj_low_unnormalized is None:
                raise ValueError("adj_low_unnormalized required when structure_info > 0")
            if self.struc_low is None:
                raise RuntimeError("Structure parameter not initialised")
            output_struc_low = F.relu(self._apply_dense(adj_low_unnormalized, self.struc_low))
            att_low, att_high, att_mlp, att_struc = self._attention4(
                output_low, output_high, output_mlp, output_struc_low
            )
            return att_low * output_low + att_high * output_high + att_mlp * output_mlp + att_struc * output_struc_low

        att_low, att_high, att_mlp = self._attention3(output_low, output_high, output_mlp)
        return att_low * output_low + att_high * output_high + att_mlp * output_mlp

    @staticmethod
    def _apply_adj(adj: Tensor, mat: Tensor) -> Tensor:
        if adj.is_sparse:
            return torch.spmm(adj, mat)
        return adj @ mat

    @staticmethod
    def _apply_dense(adj: Tensor, mat: Tensor) -> Tensor:
        if adj.is_sparse:
            return torch.spmm(adj, mat)
        return adj @ mat


class MLP(nn.Module):
    """Simple MLP used within ACM-GNN."""

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
    ) -> None:
        super().__init__()
        self.lins = nn.ModuleList()
        self.bns = nn.ModuleList()

        if num_layers <= 1:
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            self.lins.append(nn.Linear(in_channels, hidden_channels))
            self.bns.append(nn.BatchNorm1d(hidden_channels))
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))
                self.bns.append(nn.BatchNorm1d(hidden_channels))
            self.lins.append(nn.Linear(hidden_channels, out_channels))

        self.dropout = float(dropout)

    def reset_parameters(self) -> None:
        for lin in self.lins:
            lin.reset_parameters()
        for bn in self.bns:
            bn.reset_parameters()

    def forward(self, x: Tensor, *, input_tensor: bool = True) -> Tensor:
        out = x
        for i, lin in enumerate(self.lins[:-1]):
            out = lin(out)
            out = F.relu(out, inplace=True)
            if self.bns:
                out = self.bns[min(i, len(self.bns) - 1)](out)
            out = F.dropout(out, p=self.dropout, training=self.training)
        out = self.lins[-1](out)
        return out


__all__ = ["GraphConvolution", "MLP"]
