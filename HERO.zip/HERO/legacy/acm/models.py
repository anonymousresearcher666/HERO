"""ACM-GNN model wrappers (simplified variants)."""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers import GraphConvolution, MLP


class ACMGCN(nn.Module):
    """Two-layer ACM-GCN variant used as the default ACM baseline."""

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        nnodes: int,
        *,
        dropout: float = 0.5,
        structure_info: int = 0,
        variant: bool = False,
        init_layers_X: int = 1,
    ) -> None:
        super().__init__()
        self.dropout = float(dropout)
        self.structure_info = structure_info
        self.variant = variant
        self.init_layers_X = init_layers_X

        self.conv1 = GraphConvolution(
            in_channels,
            hidden_channels,
            nnodes=nnodes,
            model_type="acmgcn",
            structure_info=structure_info,
            variant=variant,
        )
        self.conv2 = GraphConvolution(
            hidden_channels,
            out_channels,
            nnodes=nnodes,
            model_type="acmgcn",
            structure_info=structure_info,
            variant=variant,
        )

        self.mlp_feat: Optional[MLP]
        if init_layers_X and init_layers_X > 1:
            self.mlp_feat = MLP(
                in_channels, hidden_channels, hidden_channels, num_layers=init_layers_X, dropout=0.0
            )
        else:
            self.mlp_feat = None

        self.reset_parameters()

    def reset_parameters(self) -> None:
        self.conv1.reset_parameters()
        self.conv2.reset_parameters()
        if self.mlp_feat is not None:
            self.mlp_feat.reset_parameters()

    def forward(
        self,
        x: torch.Tensor,
        adj_low: torch.Tensor,
        adj_high: torch.Tensor,
        adj_low_unnormalized: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        h = F.dropout(x, p=self.dropout, training=self.training)
        h = self.conv1(h, adj_low, adj_high, adj_low_unnormalized)
        h = F.dropout(F.relu(h), p=self.dropout, training=self.training)
        out = self.conv2(h, adj_low, adj_high, adj_low_unnormalized)
        if self.mlp_feat is not None:
            feat = F.relu(self.mlp_feat(x))
            out = out + feat
        return out


__all__ = ["ACMGCN"]
