"""ACM-GNN legacy integration."""

from .models import ACMGCN

__all__ = ["ACMGCN"]
