"""LINKX legacy integration."""

from .models import LINKX

__all__ = ["LINKX"]
