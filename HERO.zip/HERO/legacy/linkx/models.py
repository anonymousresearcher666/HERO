"""LINKX model components adapted from CUAI/Non-Homophily-Large-Scale.

The implementation is simplified to avoid the ``torch_sparse`` dependency and
to integrate naturally with the HERO evaluation pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


def _sparse_linear_mul(x: torch.Tensor, linear: nn.Linear) -> torch.Tensor:
    """Apply ``linear`` to ``x`` supporting a sparse COO input.

    The first linear layer in LINKX operates on the sparse adjacency matrix
    (shape ``[num_nodes, num_nodes]``). We apply ``x @ W^T + b`` using
    ``torch.sparse.mm`` and then add the bias manually. Subsequent layers work
    on dense tensors, so the helper simply falls back to :class:`nn.Linear`.
    """

    if not x.is_sparse:
        return linear(x)
    out = torch.sparse.mm(x, linear.weight.t())
    if linear.bias is not None:
        out = out + linear.bias
    return out


class SparseMLP(nn.Module):
    """Multi-layer perceptron that accepts a sparse input for the first layer."""

    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int,
                 num_layers: int, dropout: float = 0.5) -> None:
        super().__init__()
        self.lins = nn.ModuleList()
        self.bns = nn.ModuleList()

        if num_layers == 1:
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            self.lins.append(nn.Linear(in_channels, hidden_channels))
            self.bns.append(nn.BatchNorm1d(hidden_channels))
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))
                self.bns.append(nn.BatchNorm1d(hidden_channels))
            self.lins.append(nn.Linear(hidden_channels, out_channels))

        self.dropout = float(dropout)

    def reset_parameters(self) -> None:
        for lin in self.lins:
            lin.reset_parameters()
        for bn in self.bns:
            bn.reset_parameters()

    def forward(self, x: torch.Tensor, *, sparse_input: bool = False) -> torch.Tensor:
        """Forward pass.

        Parameters
        ----------
        x: ``torch.Tensor``
            Input tensor of shape ``[num_nodes, feat_dim]``. If ``sparse_input``
            is true the first layer uses sparse multiplication.
        sparse_input: bool, optional (default: False)
            Whether the first layer should treat ``x`` as a sparse COO tensor.
        """

        for idx, lin in enumerate(self.lins):
            if sparse_input and x.is_sparse:
                x = _sparse_linear_mul(x, lin)
                sparse_input = False
            else:
                x = lin(x)

            if idx < len(self.lins) - 1:
                x = F.relu(x, inplace=True)
                if self.bns:
                    x = self.bns[min(idx, len(self.bns) - 1)](x)
                x = F.dropout(x, p=self.dropout, training=self.training)
        return x


class LINKX(nn.Module):
    """The LINKX architecture with optional inner activation/dropout."""

    def __init__(
        self,
        num_nodes: int,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        final_layers: int,
        dropout: float = 0.5,
        init_layers_A: int = 1,
        init_layers_X: int = 1,
        inner_activation: bool = False,
        inner_dropout: bool = False,
    ) -> None:
        super().__init__()
        self.mlp_adj = SparseMLP(num_nodes, hidden_channels, hidden_channels,
                                 init_layers_A, dropout=0.0)
        self.mlp_feat = SparseMLP(in_channels, hidden_channels, hidden_channels,
                                  init_layers_X, dropout=0.0)
        self.combine = nn.Linear(2 * hidden_channels, hidden_channels)
        self.final = SparseMLP(hidden_channels, hidden_channels, out_channels,
                               final_layers, dropout=dropout)

        self.inner_activation = inner_activation
        self.inner_dropout = inner_dropout
        self.dropout = dropout

    def reset_parameters(self) -> None:
        self.mlp_adj.reset_parameters()
        self.mlp_feat.reset_parameters()
        self.combine.reset_parameters()
        self.final.reset_parameters()

    def forward(self, adj: torch.Tensor, features: torch.Tensor) -> torch.Tensor:
        """Compute logits.

        Parameters
        ----------
        adj: ``torch.Tensor``
            Sparse COO tensor of shape ``[num_nodes, num_nodes]`` representing
            the adjacency matrix (without self-loops).
        features: ``torch.Tensor``
            Node feature matrix of shape ``[num_nodes, in_channels]``.
        """

        adj_repr = self.mlp_adj(adj, sparse_input=True)
        feat_repr = self.mlp_feat(features)

        combined = torch.cat((adj_repr, feat_repr), dim=-1)
        combined = self.combine(combined)

        if self.inner_dropout and self.training:
            combined = F.dropout(combined, p=self.dropout)
        if self.inner_activation:
            combined = F.relu(combined)

        combined = F.relu(combined + adj_repr + feat_repr)
        logits = self.final(combined)
        return logits


__all__ = ["LINKX", "SparseMLP"]
