"""PyTorch implementation of Graph Wave Network (GWN)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.conv.gcn_conv import gcn_norm
from torch_geometric.utils import add_remaining_self_loops


class GraphWaveNet(nn.Module):
    """Graph Wave Network core model.

    Parameters
    ----------
    in_channels: int
        Node feature dimensionality.
    hidden_channels: int
        Hidden dimensionality within the wave equation solver.
    out_channels: int
        Number of output classes.
    time: float
        Simulation time horizon.
    dt: float
        Time step size.
    dropout: float
        Dropout probability.
    laplacian: str
        'sym' for symmetric Laplacian, 'fa' for feature-adaptive Laplacian.
    method: str
        Numerical integration scheme ('exp' supported).
    init_residual: bool
        Whether to add learnable residual from the initial state.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        time_horizon: float = 1.0,
        dt: float = 1.0,
        dropout: float = 0.5,
        laplacian: str = "sym",
        method: str = "exp",
        init_residual: bool = False,
    ) -> None:
        super().__init__()
        self.dropout = float(dropout)
        self.pde = WavePDEFunc(
            in_channels=in_channels,
            channels=hidden_channels,
            time_horizon=time_horizon,
            dt=dt,
            dropout=dropout,
            laplacian=laplacian,
            method=method,
            init_residual=init_residual,
        )
        self.lin = nn.Linear(hidden_channels, out_channels)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        self.pde.reset_parameters()
        self.lin.reset_parameters()

    def forward(self, features: Tensor, edge_index: Tensor) -> Tensor:
        x = F.dropout(features, p=self.dropout, training=self.training)
        x = self.pde(x, edge_index)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin(x)
        return x


class WavePDEFunc(nn.Module):
    def __init__(
        self,
        in_channels: int,
        channels: int,
        time_horizon: float,
        dt: float,
        dropout: float,
        laplacian: str,
        method: str,
        init_residual: bool,
    ) -> None:
        super().__init__()
        self.dt = float(dt)
        self.dropout = float(dropout)
        self.laplacian = laplacian
        self.method = method
        self.init_residual = init_residual
        self.num_steps = max(1, math.ceil(time_horizon / dt))

        self.lin0 = nn.Linear(in_channels, channels)
        self.lin1 = nn.Linear(in_channels, channels)

        self.convs = nn.ModuleList()
        for _ in range(self.num_steps - 1):
            self.convs.append(
                WaveConv(
                    channels=channels,
                    dt=self.dt,
                    dropout=self.dropout,
                    laplacian=self.laplacian,
                    method=self.method,
                    init_residual=self.init_residual,
                )
            )
        if self.method == "exp":
            self.exp_conv_0 = WaveConv(
                channels=channels,
                dt=self.dt,
                dropout=self.dropout,
                laplacian=self.laplacian,
                method=self.method,
                init_residual=self.init_residual,
                exp_init=True,
            )
        else:
            raise NotImplementedError("Only explicit scheme supported")

        self.reset_parameters()

    def reset_parameters(self) -> None:
        self.lin0.reset_parameters()
        self.lin1.reset_parameters()
        for conv in self.convs:
            conv.reset_parameters()
        if hasattr(self, "exp_conv_0"):
            self.exp_conv_0.reset_parameters()

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x0 = self.lin0(x)
        x1_seed = self.lin1(x)
        if self.method == "exp":
            x1 = self.exp_conv_0(x1_seed, x0, edge_index)
        else:
            raise NotImplementedError

        x_prev, x_curr = x0, x1
        for conv in self.convs:
            x_next = conv(x_curr, x_prev, edge_index, x0=x0 if self.init_residual else None)
            x_prev, x_curr = x_curr, x_next
        return x_curr


class WaveConv(MessagePassing):
    def __init__(
        self,
        channels: int,
        dt: float,
        dropout: float,
        laplacian: str,
        method: str,
        init_residual: bool,
        exp_init: bool = False,
    ) -> None:
        super().__init__()
        self.channels = channels
        self.dt = float(dt)
        self.dropout = float(dropout)
        self.laplacian = laplacian
        self.method = method
        self.init_residual = init_residual
        self.exp_init = exp_init

        if laplacian == "fa":
            self.att_j = nn.Linear(channels, 1, bias=False)
            self.att_i = nn.Linear(channels, 1, bias=False)
        else:
            self.att_j = None
            self.att_i = None

        if init_residual:
            self.eps = nn.Parameter(torch.Tensor(1))

        self.reset_parameters()

    def reset_parameters(self) -> None:
        if self.att_j is not None:
            self.att_j.reset_parameters()
        if self.att_i is not None:
            self.att_i.reset_parameters()
        if self.init_residual:
            nn.init.uniform_(self.eps)

    def forward(self, x: Tensor, x_prev: Tensor, edge_index: Tensor, x0: Optional[Tensor] = None) -> Tensor:
        edge_index, edge_weight = self._laplacian(edge_index, x)
        if self.exp_init:
            edge_weight = (self.dt ** 2) * edge_weight / 2.0
            num_nodes = x.size(0)
            edge_weight = torch.cat([edge_weight[:-num_nodes], edge_weight[-num_nodes:] + 1.0])
            out = self.dt * x + self.propagate(edge_index, x=x_prev, edge_weight=edge_weight)
        else:
            out = (2 - self.dt ** 2) * x - x_prev + (self.dt ** 2) * self.propagate(edge_index, x=x, edge_weight=edge_weight)
        if self.init_residual and x0 is not None:
            out = out + self.eps * x0
        return out

    def message(self, x_j: Tensor, edge_weight: Tensor) -> Tensor:
        return edge_weight.unsqueeze(-1) * x_j

    def _laplacian(self, edge_index: Tensor, x: Tensor) -> tuple[Tensor, Tensor]:
        num_nodes = x.size(0)
        edge_weight = torch.ones(edge_index.size(1), dtype=x.dtype, device=edge_index.device)
        if self.laplacian == "sym":
            edge_index, edge_weight = add_remaining_self_loops(edge_index, edge_weight, 0.0, num_nodes)
            row, col = edge_index
            idx = col
            deg = torch.zeros(num_nodes, dtype=edge_weight.dtype, device=edge_weight.device)
            deg.scatter_add_(0, idx, edge_weight)
            deg_inv_sqrt = deg.pow(-0.5)
            deg_inv_sqrt.masked_fill_(deg_inv_sqrt == float("inf"), 0.0)
            edge_weight = deg_inv_sqrt[row] * edge_weight * deg_inv_sqrt[col]
            return edge_index, edge_weight
        if self.laplacian == "fa":
            edge_index, edge_weight = gcn_norm(edge_index, None, num_nodes, dtype=x.dtype)
            alpha_j = self.att_j(x)[edge_index[0]]
            alpha_i = self.att_i(x)[edge_index[1]]
            alpha = torch.tanh(alpha_j + alpha_i).squeeze(-1)
            alpha = F.dropout(alpha, p=self.dropout, training=self.training)
            edge_weight = alpha * edge_weight
            return edge_index, edge_weight
        raise NotImplementedError("Unsupported laplacian type")
