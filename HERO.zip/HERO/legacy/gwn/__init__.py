"""Graph Wave Network legacy integration."""

from .model import GraphWaveNet

__all__ = ["GraphWaveNet"]
