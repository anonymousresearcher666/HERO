"""Utility helpers for UniFilter integration."""

from __future__ import annotations

import gc
import math
import time
from typing import Tuple

import numpy as np
import scipy.sparse as sp
import torch
from torch_geometric.utils import is_undirected, to_undirected


def sparse_mx_to_torch_sparse_tensor(sparse_mx: sp.spmatrix) -> torch.Tensor:
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def _prop_matrix(adj: sp.spmatrix) -> sp.spmatrix:
    row_sum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(row_sum, -0.5).flatten()
    del row_sum
    gc.collect()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return d_mat_inv_sqrt.dot(adj).dot(d_mat_inv_sqrt)


def edgeindex_construct(edge_index: np.ndarray, num_nodes: int) -> Tuple[torch.Tensor, float, float]:
    edge_index = torch.as_tensor(edge_index, dtype=torch.long)
    if not is_undirected(edge_index):
        edge_index = to_undirected(edge_index)
    edge_np = edge_index.cpu().numpy()
    data = np.ones(edge_np.shape[1], dtype=np.float32)
    adj = sp.coo_matrix((data, (edge_np[0], edge_np[1])), shape=(num_nodes, num_nodes)).tocsr()

    start = time.time()
    adj = _prop_matrix(adj)
    prop_time = time.time() - start

    start = time.time()
    adj_t = sparse_mx_to_torch_sparse_tensor(adj).float()
    sparse_time = time.time() - start

    return adj_t, prop_time, sparse_time


def load_dataset(
    LP: torch.Tensor,
    feat: torch.Tensor,
    K: int = 6,
    tau: float = 1.0,
    homo_ratio: float = 0.6,
    plain: bool = False,
) -> Tuple[torch.Tensor, int]:
    num_nodes, dim = feat.shape
    cosval = math.cos(math.pi * (1.0 - homo_ratio) / 2.0)

    if not plain:
        norm = torch.norm(feat, dim=0).clamp(min=1e-8)
        last = feat / norm
        second = torch.zeros_like(last)
        basis_sum = torch.zeros_like(last)
        hm = torch.zeros_like(last)
        hm += feat
        basis_sum += last
        features = [feat]
        for k in range(1, K + 1):
            v_k = torch.spmm(LP, last)
            hm = torch.spmm(LP, hm)
            proj1 = torch.einsum("nd,nd->d", v_k, last)
            proj2 = torch.einsum("nd,nd->d", v_k, second)
            v_k -= proj1 * last + proj2 * second
            norm = torch.norm(v_k, dim=0).clamp(min=1e-8)
            v_k /= norm
            h_k = basis_sum / k
            tf = torch.sqrt(torch.square(torch.einsum("nd,nd->d", h_k, features[-1]) / cosval) - ((k - 1) * cosval + 1) / k)
            torch.nan_to_num_(tf, nan=0.0)
            h_k += tf * v_k
            norm = torch.norm(h_k, dim=0).clamp(min=1e-8)
            h_k /= norm
            norm = torch.norm(hm, dim=0).clamp(min=1e-8)
            features.append(hm * tau + h_k * (1.0 - tau))
            basis_sum += h_k
            second = last
            last = v_k
        features = torch.cat(features, dim=1)
    else:
        basis = feat
        features = [feat]
        for _ in range(1, K + 1):
            basis = torch.spmm(LP, basis)
            features.append(basis)
        features = torch.cat(features, dim=1)

    return features, dim
