"""UniFilter model definitions adapted for the HERO pipeline."""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class Dense(nn.Module):
    """Linear layer with optional batch-norm bias and residual."""

    def __init__(self, in_features: int, out_features: int, bias: str = "none") -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(in_features, out_features))
        if bias == "bn":
            self.bias = nn.BatchNorm1d(out_features)
        else:
            self.bias = lambda x: x
        self.reset_parameters()

    def reset_parameters(self) -> None:
        bound = 1.0 / math.sqrt(self.weight.size(1))
        nn.init.uniform_(self.weight, -bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = torch.mm(x, self.weight)
        out = self.bias(out)
        if self.in_features == self.out_features:
            out = out + x
        return out


class MLP(nn.Module):
    def __init__(
        self,
        in_dim: int,
        num_layers: int,
        hidden_dim: int,
        out_dim: int,
        dropout: float,
        bias: str,
    ) -> None:
        super().__init__()
        assert num_layers >= 1
        self.layers = nn.ModuleList()
        self.layers.append(Dense(in_dim, hidden_dim, bias))
        for _ in range(num_layers - 2):
            self.layers.append(Dense(hidden_dim, hidden_dim, bias))
        self.layers.append(Dense(hidden_dim, out_dim))
        self.dropout = float(dropout)
        self.activation = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.activation(self.layers[0](x))
        for layer in self.layers[1:-1]:
            x = F.dropout(x, self.dropout, training=self.training)
            x = self.activation(layer(x))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.layers[-1](x)
        return x


class Combination(nn.Module):
    """Learned combination of polynomial filter bases."""

    def __init__(self, channels: int, level: int, dropout: float, sole: bool = False) -> None:
        super().__init__()
        self.dropout = float(dropout)
        self.level = level
        init = torch.full((1, level, 1), 1.0 / max(1, level))
        self.comb_weight = nn.Parameter(init)

    def reset_parameters(self) -> None:
        nn.init.uniform_(self.comb_weight, 1.0 / self.level, 1.0 / self.level)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = F.dropout(x, self.dropout, training=self.training)
        out = out * self.comb_weight
        out = out.sum(dim=1)
        return out


class GFK(nn.Module):
    """UniFilter model combining adaptive bases and an MLP classifier."""

    def __init__(
        self,
        level: int,
        in_dim: int,
        num_layers: int,
        hidden_dim: int,
        out_dim: int,
        dropout_comb: float,
        dropout_mlp: float,
        bias: str,
        sole: bool = True,
    ) -> None:
        super().__init__()
        self.level = level + 1
        self.comb = Combination(in_dim, self.level, dropout_comb, sole=sole)
        self.mlp = MLP(in_dim, num_layers, hidden_dim, out_dim, dropout_mlp, bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.comb(x)
        x = self.mlp(x)
        return x


__all__ = ["Dense", "MLP", "Combination", "GFK"]
